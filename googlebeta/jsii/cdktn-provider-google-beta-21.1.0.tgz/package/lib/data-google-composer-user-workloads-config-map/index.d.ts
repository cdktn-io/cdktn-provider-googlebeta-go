/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleComposerUserWorkloadsConfigMapConfig extends cdktn.TerraformMetaArguments {
    /**
    * Environment where the Kubernetes ConfigMap will be stored and used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_composer_user_workloads_config_map#environment DataGoogleComposerUserWorkloadsConfigMap#environment}
    */
    readonly environment: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_composer_user_workloads_config_map#id DataGoogleComposerUserWorkloadsConfigMap#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the Kubernetes ConfigMap.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_composer_user_workloads_config_map#name DataGoogleComposerUserWorkloadsConfigMap#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_composer_user_workloads_config_map#project DataGoogleComposerUserWorkloadsConfigMap#project}
    */
    readonly project?: string;
    /**
    * The location or Compute Engine region for the environment.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_composer_user_workloads_config_map#region DataGoogleComposerUserWorkloadsConfigMap#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_composer_user_workloads_config_map google_composer_user_workloads_config_map}
*/
export declare class DataGoogleComposerUserWorkloadsConfigMap extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_composer_user_workloads_config_map";
    /**
    * Generates CDKTN code for importing a DataGoogleComposerUserWorkloadsConfigMap resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleComposerUserWorkloadsConfigMap to import
    * @param importFromId The id of the existing DataGoogleComposerUserWorkloadsConfigMap that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_composer_user_workloads_config_map#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleComposerUserWorkloadsConfigMap to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_composer_user_workloads_config_map google_composer_user_workloads_config_map} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleComposerUserWorkloadsConfigMapConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleComposerUserWorkloadsConfigMapConfig);
    private _data;
    get data(): cdktn.StringMap;
    get deletionPolicy(): string;
    private _environment?;
    get environment(): string;
    set environment(value: string);
    get environmentInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
