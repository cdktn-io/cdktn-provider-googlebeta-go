/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleSecretManagerRegionalSecretConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_secret_manager_regional_secret#id DataGoogleSecretManagerRegionalSecret#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the regional secret. eg us-central1
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_secret_manager_regional_secret#location DataGoogleSecretManagerRegionalSecret#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_secret_manager_regional_secret#project DataGoogleSecretManagerRegionalSecret#project}
    */
    readonly project?: string;
    /**
    * This must be unique within the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_secret_manager_regional_secret#secret_id DataGoogleSecretManagerRegionalSecret#secret_id}
    */
    readonly secretId: string;
}
export interface DataGoogleSecretManagerRegionalSecretCustomerManagedEncryption {
}
export declare function dataGoogleSecretManagerRegionalSecretCustomerManagedEncryptionToTerraform(struct?: DataGoogleSecretManagerRegionalSecretCustomerManagedEncryption): any;
export declare function dataGoogleSecretManagerRegionalSecretCustomerManagedEncryptionToHclTerraform(struct?: DataGoogleSecretManagerRegionalSecretCustomerManagedEncryption): any;
export declare class DataGoogleSecretManagerRegionalSecretCustomerManagedEncryptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSecretManagerRegionalSecretCustomerManagedEncryption | undefined;
    set internalValue(value: DataGoogleSecretManagerRegionalSecretCustomerManagedEncryption | undefined);
    get kmsKeyName(): string;
}
export declare class DataGoogleSecretManagerRegionalSecretCustomerManagedEncryptionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSecretManagerRegionalSecretCustomerManagedEncryptionOutputReference;
}
export interface DataGoogleSecretManagerRegionalSecretRotation {
}
export declare function dataGoogleSecretManagerRegionalSecretRotationToTerraform(struct?: DataGoogleSecretManagerRegionalSecretRotation): any;
export declare function dataGoogleSecretManagerRegionalSecretRotationToHclTerraform(struct?: DataGoogleSecretManagerRegionalSecretRotation): any;
export declare class DataGoogleSecretManagerRegionalSecretRotationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSecretManagerRegionalSecretRotation | undefined;
    set internalValue(value: DataGoogleSecretManagerRegionalSecretRotation | undefined);
    get nextRotationTime(): string;
    get rotationPeriod(): string;
}
export declare class DataGoogleSecretManagerRegionalSecretRotationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSecretManagerRegionalSecretRotationOutputReference;
}
export interface DataGoogleSecretManagerRegionalSecretTopics {
}
export declare function dataGoogleSecretManagerRegionalSecretTopicsToTerraform(struct?: DataGoogleSecretManagerRegionalSecretTopics): any;
export declare function dataGoogleSecretManagerRegionalSecretTopicsToHclTerraform(struct?: DataGoogleSecretManagerRegionalSecretTopics): any;
export declare class DataGoogleSecretManagerRegionalSecretTopicsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSecretManagerRegionalSecretTopics | undefined;
    set internalValue(value: DataGoogleSecretManagerRegionalSecretTopics | undefined);
    get name(): string;
}
export declare class DataGoogleSecretManagerRegionalSecretTopicsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSecretManagerRegionalSecretTopicsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_secret_manager_regional_secret google_secret_manager_regional_secret}
*/
export declare class DataGoogleSecretManagerRegionalSecret extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_secret_manager_regional_secret";
    /**
    * Generates CDKTN code for importing a DataGoogleSecretManagerRegionalSecret resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleSecretManagerRegionalSecret to import
    * @param importFromId The id of the existing DataGoogleSecretManagerRegionalSecret that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_secret_manager_regional_secret#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleSecretManagerRegionalSecret to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_secret_manager_regional_secret google_secret_manager_regional_secret} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleSecretManagerRegionalSecretConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleSecretManagerRegionalSecretConfig);
    private _annotations;
    get annotations(): cdktn.StringMap;
    get createTime(): string;
    private _customerManagedEncryption;
    get customerManagedEncryption(): DataGoogleSecretManagerRegionalSecretCustomerManagedEncryptionList;
    get deletionPolicy(): string;
    get deletionProtection(): cdktn.IResolvable;
    private _effectiveAnnotations;
    get effectiveAnnotations(): cdktn.StringMap;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get expireTime(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels;
    get labels(): cdktn.StringMap;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _rotation;
    get rotation(): DataGoogleSecretManagerRegionalSecretRotationList;
    private _secretId?;
    get secretId(): string;
    set secretId(value: string);
    get secretIdInput(): string | undefined;
    get secretType(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _topics;
    get topics(): DataGoogleSecretManagerRegionalSecretTopicsList;
    get ttl(): string;
    private _versionAliases;
    get versionAliases(): cdktn.StringMap;
    get versionDestroyTtl(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
