/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleMonitoringIstioCanonicalServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the canonical service underlying this service..
    *                         Corresponds to the destination_service_name metric label in Istio metrics.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_monitoring_istio_canonical_service#canonical_service DataGoogleMonitoringIstioCanonicalService#canonical_service}
    */
    readonly canonicalService: string;
    /**
    * The namespace of the canonical service underlying this service.
    *                         Corresponds to the destination_service_namespace metric label in Istio metrics.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_monitoring_istio_canonical_service#canonical_service_namespace DataGoogleMonitoringIstioCanonicalService#canonical_service_namespace}
    */
    readonly canonicalServiceNamespace: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_monitoring_istio_canonical_service#id DataGoogleMonitoringIstioCanonicalService#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Identifier for the Istio mesh in which this canonical service is defined.
    *                         Corresponds to the meshUid metric label in Istio metrics.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_monitoring_istio_canonical_service#mesh_uid DataGoogleMonitoringIstioCanonicalService#mesh_uid}
    */
    readonly meshUid: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_monitoring_istio_canonical_service#project DataGoogleMonitoringIstioCanonicalService#project}
    */
    readonly project?: string;
}
export interface DataGoogleMonitoringIstioCanonicalServiceTelemetry {
}
export declare function dataGoogleMonitoringIstioCanonicalServiceTelemetryToTerraform(struct?: DataGoogleMonitoringIstioCanonicalServiceTelemetry): any;
export declare function dataGoogleMonitoringIstioCanonicalServiceTelemetryToHclTerraform(struct?: DataGoogleMonitoringIstioCanonicalServiceTelemetry): any;
export declare class DataGoogleMonitoringIstioCanonicalServiceTelemetryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMonitoringIstioCanonicalServiceTelemetry | undefined;
    set internalValue(value: DataGoogleMonitoringIstioCanonicalServiceTelemetry | undefined);
    get resourceName(): string;
}
export declare class DataGoogleMonitoringIstioCanonicalServiceTelemetryList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMonitoringIstioCanonicalServiceTelemetryOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_monitoring_istio_canonical_service google_monitoring_istio_canonical_service}
*/
export declare class DataGoogleMonitoringIstioCanonicalService extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_monitoring_istio_canonical_service";
    /**
    * Generates CDKTN code for importing a DataGoogleMonitoringIstioCanonicalService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleMonitoringIstioCanonicalService to import
    * @param importFromId The id of the existing DataGoogleMonitoringIstioCanonicalService that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_monitoring_istio_canonical_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleMonitoringIstioCanonicalService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_monitoring_istio_canonical_service google_monitoring_istio_canonical_service} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleMonitoringIstioCanonicalServiceConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleMonitoringIstioCanonicalServiceConfig);
    private _canonicalService?;
    get canonicalService(): string;
    set canonicalService(value: string);
    get canonicalServiceInput(): string | undefined;
    private _canonicalServiceNamespace?;
    get canonicalServiceNamespace(): string;
    set canonicalServiceNamespace(value: string);
    get canonicalServiceNamespaceInput(): string | undefined;
    get deletionPolicy(): string;
    get displayName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _meshUid?;
    get meshUid(): string;
    set meshUid(value: string);
    get meshUidInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get serviceId(): string;
    private _telemetry;
    get telemetry(): DataGoogleMonitoringIstioCanonicalServiceTelemetryList;
    private _userLabels;
    get userLabels(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
