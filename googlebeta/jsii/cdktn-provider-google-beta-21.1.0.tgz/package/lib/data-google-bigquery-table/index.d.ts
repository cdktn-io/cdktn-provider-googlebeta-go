/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleBigqueryTableConfig extends cdktn.TerraformMetaArguments {
    /**
    * The dataset ID to create the table in. Changing this forces a new resource to be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_bigquery_table#dataset_id DataGoogleBigqueryTable#dataset_id}
    */
    readonly datasetId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_bigquery_table#id DataGoogleBigqueryTable#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the project in which the resource belongs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_bigquery_table#project DataGoogleBigqueryTable#project}
    */
    readonly project?: string;
    /**
    * A unique ID for the resource. Changing this forces a new resource to be created.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_bigquery_table#table_id DataGoogleBigqueryTable#table_id}
    */
    readonly tableId: string;
}
export interface DataGoogleBigqueryTableBiglakeConfiguration {
}
export declare function dataGoogleBigqueryTableBiglakeConfigurationToTerraform(struct?: DataGoogleBigqueryTableBiglakeConfiguration): any;
export declare function dataGoogleBigqueryTableBiglakeConfigurationToHclTerraform(struct?: DataGoogleBigqueryTableBiglakeConfiguration): any;
export declare class DataGoogleBigqueryTableBiglakeConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryTableBiglakeConfiguration | undefined;
    set internalValue(value: DataGoogleBigqueryTableBiglakeConfiguration | undefined);
    get connectionId(): string;
    get fileFormat(): string;
    get storageUri(): string;
    get tableFormat(): string;
}
export declare class DataGoogleBigqueryTableBiglakeConfigurationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryTableBiglakeConfigurationOutputReference;
}
export interface DataGoogleBigqueryTableEncryptionConfiguration {
}
export declare function dataGoogleBigqueryTableEncryptionConfigurationToTerraform(struct?: DataGoogleBigqueryTableEncryptionConfiguration): any;
export declare function dataGoogleBigqueryTableEncryptionConfigurationToHclTerraform(struct?: DataGoogleBigqueryTableEncryptionConfiguration): any;
export declare class DataGoogleBigqueryTableEncryptionConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryTableEncryptionConfiguration | undefined;
    set internalValue(value: DataGoogleBigqueryTableEncryptionConfiguration | undefined);
    get kmsKeyName(): string;
    get kmsKeyVersion(): string;
}
export declare class DataGoogleBigqueryTableEncryptionConfigurationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryTableEncryptionConfigurationOutputReference;
}
export interface DataGoogleBigqueryTableExternalCatalogTableOptionsStorageDescriptorSerdeInfo {
}
export declare function dataGoogleBigqueryTableExternalCatalogTableOptionsStorageDescriptorSerdeInfoToTerraform(struct?: DataGoogleBigqueryTableExternalCatalogTableOptionsStorageDescriptorSerdeInfo): any;
export declare function dataGoogleBigqueryTableExternalCatalogTableOptionsStorageDescriptorSerdeInfoToHclTerraform(struct?: DataGoogleBigqueryTableExternalCatalogTableOptionsStorageDescriptorSerdeInfo): any;
export declare class DataGoogleBigqueryTableExternalCatalogTableOptionsStorageDescriptorSerdeInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryTableExternalCatalogTableOptionsStorageDescriptorSerdeInfo | undefined;
    set internalValue(value: DataGoogleBigqueryTableExternalCatalogTableOptionsStorageDescriptorSerdeInfo | undefined);
    get name(): string;
    private _parameters;
    get parameters(): cdktn.StringMap;
    get serializationLibrary(): string;
}
export declare class DataGoogleBigqueryTableExternalCatalogTableOptionsStorageDescriptorSerdeInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryTableExternalCatalogTableOptionsStorageDescriptorSerdeInfoOutputReference;
}
export interface DataGoogleBigqueryTableExternalCatalogTableOptionsStorageDescriptor {
}
export declare function dataGoogleBigqueryTableExternalCatalogTableOptionsStorageDescriptorToTerraform(struct?: DataGoogleBigqueryTableExternalCatalogTableOptionsStorageDescriptor): any;
export declare function dataGoogleBigqueryTableExternalCatalogTableOptionsStorageDescriptorToHclTerraform(struct?: DataGoogleBigqueryTableExternalCatalogTableOptionsStorageDescriptor): any;
export declare class DataGoogleBigqueryTableExternalCatalogTableOptionsStorageDescriptorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryTableExternalCatalogTableOptionsStorageDescriptor | undefined;
    set internalValue(value: DataGoogleBigqueryTableExternalCatalogTableOptionsStorageDescriptor | undefined);
    get inputFormat(): string;
    get locationUri(): string;
    get outputFormat(): string;
    private _serdeInfo;
    get serdeInfo(): DataGoogleBigqueryTableExternalCatalogTableOptionsStorageDescriptorSerdeInfoList;
}
export declare class DataGoogleBigqueryTableExternalCatalogTableOptionsStorageDescriptorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryTableExternalCatalogTableOptionsStorageDescriptorOutputReference;
}
export interface DataGoogleBigqueryTableExternalCatalogTableOptions {
}
export declare function dataGoogleBigqueryTableExternalCatalogTableOptionsToTerraform(struct?: DataGoogleBigqueryTableExternalCatalogTableOptions): any;
export declare function dataGoogleBigqueryTableExternalCatalogTableOptionsToHclTerraform(struct?: DataGoogleBigqueryTableExternalCatalogTableOptions): any;
export declare class DataGoogleBigqueryTableExternalCatalogTableOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryTableExternalCatalogTableOptions | undefined;
    set internalValue(value: DataGoogleBigqueryTableExternalCatalogTableOptions | undefined);
    get connectionId(): string;
    private _parameters;
    get parameters(): cdktn.StringMap;
    private _storageDescriptor;
    get storageDescriptor(): DataGoogleBigqueryTableExternalCatalogTableOptionsStorageDescriptorList;
}
export declare class DataGoogleBigqueryTableExternalCatalogTableOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryTableExternalCatalogTableOptionsOutputReference;
}
export interface DataGoogleBigqueryTableExternalDataConfigurationAvroOptions {
}
export declare function dataGoogleBigqueryTableExternalDataConfigurationAvroOptionsToTerraform(struct?: DataGoogleBigqueryTableExternalDataConfigurationAvroOptions): any;
export declare function dataGoogleBigqueryTableExternalDataConfigurationAvroOptionsToHclTerraform(struct?: DataGoogleBigqueryTableExternalDataConfigurationAvroOptions): any;
export declare class DataGoogleBigqueryTableExternalDataConfigurationAvroOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryTableExternalDataConfigurationAvroOptions | undefined;
    set internalValue(value: DataGoogleBigqueryTableExternalDataConfigurationAvroOptions | undefined);
    get useAvroLogicalTypes(): cdktn.IResolvable;
}
export declare class DataGoogleBigqueryTableExternalDataConfigurationAvroOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryTableExternalDataConfigurationAvroOptionsOutputReference;
}
export interface DataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsColumnFamilyColumn {
}
export declare function dataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsColumnFamilyColumnToTerraform(struct?: DataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsColumnFamilyColumn): any;
export declare function dataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsColumnFamilyColumnToHclTerraform(struct?: DataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsColumnFamilyColumn): any;
export declare class DataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsColumnFamilyColumnOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsColumnFamilyColumn | undefined;
    set internalValue(value: DataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsColumnFamilyColumn | undefined);
    get encoding(): string;
    get fieldName(): string;
    get onlyReadLatest(): cdktn.IResolvable;
    get qualifierEncoded(): string;
    get qualifierString(): string;
    get type(): string;
}
export declare class DataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsColumnFamilyColumnList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsColumnFamilyColumnOutputReference;
}
export interface DataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsColumnFamily {
}
export declare function dataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsColumnFamilyToTerraform(struct?: DataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsColumnFamily): any;
export declare function dataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsColumnFamilyToHclTerraform(struct?: DataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsColumnFamily): any;
export declare class DataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsColumnFamilyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsColumnFamily | undefined;
    set internalValue(value: DataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsColumnFamily | undefined);
    private _column;
    get column(): DataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsColumnFamilyColumnList;
    get encoding(): string;
    get familyId(): string;
    get onlyReadLatest(): cdktn.IResolvable;
    get type(): string;
}
export declare class DataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsColumnFamilyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsColumnFamilyOutputReference;
}
export interface DataGoogleBigqueryTableExternalDataConfigurationBigtableOptions {
}
export declare function dataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsToTerraform(struct?: DataGoogleBigqueryTableExternalDataConfigurationBigtableOptions): any;
export declare function dataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsToHclTerraform(struct?: DataGoogleBigqueryTableExternalDataConfigurationBigtableOptions): any;
export declare class DataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryTableExternalDataConfigurationBigtableOptions | undefined;
    set internalValue(value: DataGoogleBigqueryTableExternalDataConfigurationBigtableOptions | undefined);
    private _columnFamily;
    get columnFamily(): DataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsColumnFamilyList;
    get ignoreUnspecifiedColumnFamilies(): cdktn.IResolvable;
    get outputColumnFamiliesAsJson(): cdktn.IResolvable;
    get readRowkeyAsString(): cdktn.IResolvable;
}
export declare class DataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsOutputReference;
}
export interface DataGoogleBigqueryTableExternalDataConfigurationCsvOptions {
}
export declare function dataGoogleBigqueryTableExternalDataConfigurationCsvOptionsToTerraform(struct?: DataGoogleBigqueryTableExternalDataConfigurationCsvOptions): any;
export declare function dataGoogleBigqueryTableExternalDataConfigurationCsvOptionsToHclTerraform(struct?: DataGoogleBigqueryTableExternalDataConfigurationCsvOptions): any;
export declare class DataGoogleBigqueryTableExternalDataConfigurationCsvOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryTableExternalDataConfigurationCsvOptions | undefined;
    set internalValue(value: DataGoogleBigqueryTableExternalDataConfigurationCsvOptions | undefined);
    get allowJaggedRows(): cdktn.IResolvable;
    get allowQuotedNewlines(): cdktn.IResolvable;
    get encoding(): string;
    get fieldDelimiter(): string;
    get quote(): string;
    get skipLeadingRows(): number;
    get sourceColumnMatch(): string;
}
export declare class DataGoogleBigqueryTableExternalDataConfigurationCsvOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryTableExternalDataConfigurationCsvOptionsOutputReference;
}
export interface DataGoogleBigqueryTableExternalDataConfigurationGoogleSheetsOptions {
}
export declare function dataGoogleBigqueryTableExternalDataConfigurationGoogleSheetsOptionsToTerraform(struct?: DataGoogleBigqueryTableExternalDataConfigurationGoogleSheetsOptions): any;
export declare function dataGoogleBigqueryTableExternalDataConfigurationGoogleSheetsOptionsToHclTerraform(struct?: DataGoogleBigqueryTableExternalDataConfigurationGoogleSheetsOptions): any;
export declare class DataGoogleBigqueryTableExternalDataConfigurationGoogleSheetsOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryTableExternalDataConfigurationGoogleSheetsOptions | undefined;
    set internalValue(value: DataGoogleBigqueryTableExternalDataConfigurationGoogleSheetsOptions | undefined);
    get range(): string;
    get skipLeadingRows(): number;
}
export declare class DataGoogleBigqueryTableExternalDataConfigurationGoogleSheetsOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryTableExternalDataConfigurationGoogleSheetsOptionsOutputReference;
}
export interface DataGoogleBigqueryTableExternalDataConfigurationHivePartitioningOptions {
}
export declare function dataGoogleBigqueryTableExternalDataConfigurationHivePartitioningOptionsToTerraform(struct?: DataGoogleBigqueryTableExternalDataConfigurationHivePartitioningOptions): any;
export declare function dataGoogleBigqueryTableExternalDataConfigurationHivePartitioningOptionsToHclTerraform(struct?: DataGoogleBigqueryTableExternalDataConfigurationHivePartitioningOptions): any;
export declare class DataGoogleBigqueryTableExternalDataConfigurationHivePartitioningOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryTableExternalDataConfigurationHivePartitioningOptions | undefined;
    set internalValue(value: DataGoogleBigqueryTableExternalDataConfigurationHivePartitioningOptions | undefined);
    get mode(): string;
    get requirePartitionFilter(): cdktn.IResolvable;
    get sourceUriPrefix(): string;
}
export declare class DataGoogleBigqueryTableExternalDataConfigurationHivePartitioningOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryTableExternalDataConfigurationHivePartitioningOptionsOutputReference;
}
export interface DataGoogleBigqueryTableExternalDataConfigurationJsonOptions {
}
export declare function dataGoogleBigqueryTableExternalDataConfigurationJsonOptionsToTerraform(struct?: DataGoogleBigqueryTableExternalDataConfigurationJsonOptions): any;
export declare function dataGoogleBigqueryTableExternalDataConfigurationJsonOptionsToHclTerraform(struct?: DataGoogleBigqueryTableExternalDataConfigurationJsonOptions): any;
export declare class DataGoogleBigqueryTableExternalDataConfigurationJsonOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryTableExternalDataConfigurationJsonOptions | undefined;
    set internalValue(value: DataGoogleBigqueryTableExternalDataConfigurationJsonOptions | undefined);
    get encoding(): string;
}
export declare class DataGoogleBigqueryTableExternalDataConfigurationJsonOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryTableExternalDataConfigurationJsonOptionsOutputReference;
}
export interface DataGoogleBigqueryTableExternalDataConfigurationParquetOptions {
}
export declare function dataGoogleBigqueryTableExternalDataConfigurationParquetOptionsToTerraform(struct?: DataGoogleBigqueryTableExternalDataConfigurationParquetOptions): any;
export declare function dataGoogleBigqueryTableExternalDataConfigurationParquetOptionsToHclTerraform(struct?: DataGoogleBigqueryTableExternalDataConfigurationParquetOptions): any;
export declare class DataGoogleBigqueryTableExternalDataConfigurationParquetOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryTableExternalDataConfigurationParquetOptions | undefined;
    set internalValue(value: DataGoogleBigqueryTableExternalDataConfigurationParquetOptions | undefined);
    get enableListInference(): cdktn.IResolvable;
    get enumAsString(): cdktn.IResolvable;
}
export declare class DataGoogleBigqueryTableExternalDataConfigurationParquetOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryTableExternalDataConfigurationParquetOptionsOutputReference;
}
export interface DataGoogleBigqueryTableExternalDataConfiguration {
}
export declare function dataGoogleBigqueryTableExternalDataConfigurationToTerraform(struct?: DataGoogleBigqueryTableExternalDataConfiguration): any;
export declare function dataGoogleBigqueryTableExternalDataConfigurationToHclTerraform(struct?: DataGoogleBigqueryTableExternalDataConfiguration): any;
export declare class DataGoogleBigqueryTableExternalDataConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryTableExternalDataConfiguration | undefined;
    set internalValue(value: DataGoogleBigqueryTableExternalDataConfiguration | undefined);
    get autodetect(): cdktn.IResolvable;
    private _avroOptions;
    get avroOptions(): DataGoogleBigqueryTableExternalDataConfigurationAvroOptionsList;
    private _bigtableOptions;
    get bigtableOptions(): DataGoogleBigqueryTableExternalDataConfigurationBigtableOptionsList;
    get compression(): string;
    get connectionId(): string;
    private _csvOptions;
    get csvOptions(): DataGoogleBigqueryTableExternalDataConfigurationCsvOptionsList;
    get decimalTargetTypes(): string[];
    get fileSetSpecType(): string;
    private _googleSheetsOptions;
    get googleSheetsOptions(): DataGoogleBigqueryTableExternalDataConfigurationGoogleSheetsOptionsList;
    private _hivePartitioningOptions;
    get hivePartitioningOptions(): DataGoogleBigqueryTableExternalDataConfigurationHivePartitioningOptionsList;
    get ignoreUnknownValues(): cdktn.IResolvable;
    get jsonExtension(): string;
    private _jsonOptions;
    get jsonOptions(): DataGoogleBigqueryTableExternalDataConfigurationJsonOptionsList;
    get maxBadRecords(): number;
    get metadataCacheMode(): string;
    get objectMetadata(): string;
    private _parquetOptions;
    get parquetOptions(): DataGoogleBigqueryTableExternalDataConfigurationParquetOptionsList;
    get referenceFileSchemaUri(): string;
    get schema(): string;
    get sourceFormat(): string;
    get sourceUris(): string[];
}
export declare class DataGoogleBigqueryTableExternalDataConfigurationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryTableExternalDataConfigurationOutputReference;
}
export interface DataGoogleBigqueryTableMaterializedView {
}
export declare function dataGoogleBigqueryTableMaterializedViewToTerraform(struct?: DataGoogleBigqueryTableMaterializedView): any;
export declare function dataGoogleBigqueryTableMaterializedViewToHclTerraform(struct?: DataGoogleBigqueryTableMaterializedView): any;
export declare class DataGoogleBigqueryTableMaterializedViewOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryTableMaterializedView | undefined;
    set internalValue(value: DataGoogleBigqueryTableMaterializedView | undefined);
    get allowNonIncrementalDefinition(): cdktn.IResolvable;
    get enableRefresh(): cdktn.IResolvable;
    get query(): string;
    get refreshIntervalMs(): number;
}
export declare class DataGoogleBigqueryTableMaterializedViewList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryTableMaterializedViewOutputReference;
}
export interface DataGoogleBigqueryTableRangePartitioningRange {
}
export declare function dataGoogleBigqueryTableRangePartitioningRangeToTerraform(struct?: DataGoogleBigqueryTableRangePartitioningRange): any;
export declare function dataGoogleBigqueryTableRangePartitioningRangeToHclTerraform(struct?: DataGoogleBigqueryTableRangePartitioningRange): any;
export declare class DataGoogleBigqueryTableRangePartitioningRangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryTableRangePartitioningRange | undefined;
    set internalValue(value: DataGoogleBigqueryTableRangePartitioningRange | undefined);
    get end(): number;
    get interval(): number;
    get start(): number;
}
export declare class DataGoogleBigqueryTableRangePartitioningRangeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryTableRangePartitioningRangeOutputReference;
}
export interface DataGoogleBigqueryTableRangePartitioning {
}
export declare function dataGoogleBigqueryTableRangePartitioningToTerraform(struct?: DataGoogleBigqueryTableRangePartitioning): any;
export declare function dataGoogleBigqueryTableRangePartitioningToHclTerraform(struct?: DataGoogleBigqueryTableRangePartitioning): any;
export declare class DataGoogleBigqueryTableRangePartitioningOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryTableRangePartitioning | undefined;
    set internalValue(value: DataGoogleBigqueryTableRangePartitioning | undefined);
    get field(): string;
    private _range;
    get range(): DataGoogleBigqueryTableRangePartitioningRangeList;
}
export declare class DataGoogleBigqueryTableRangePartitioningList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryTableRangePartitioningOutputReference;
}
export interface DataGoogleBigqueryTableSchemaForeignTypeInfo {
}
export declare function dataGoogleBigqueryTableSchemaForeignTypeInfoToTerraform(struct?: DataGoogleBigqueryTableSchemaForeignTypeInfo): any;
export declare function dataGoogleBigqueryTableSchemaForeignTypeInfoToHclTerraform(struct?: DataGoogleBigqueryTableSchemaForeignTypeInfo): any;
export declare class DataGoogleBigqueryTableSchemaForeignTypeInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryTableSchemaForeignTypeInfo | undefined;
    set internalValue(value: DataGoogleBigqueryTableSchemaForeignTypeInfo | undefined);
    get typeSystem(): string;
}
export declare class DataGoogleBigqueryTableSchemaForeignTypeInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryTableSchemaForeignTypeInfoOutputReference;
}
export interface DataGoogleBigqueryTableTableConstraintsForeignKeysColumnReferences {
}
export declare function dataGoogleBigqueryTableTableConstraintsForeignKeysColumnReferencesToTerraform(struct?: DataGoogleBigqueryTableTableConstraintsForeignKeysColumnReferences): any;
export declare function dataGoogleBigqueryTableTableConstraintsForeignKeysColumnReferencesToHclTerraform(struct?: DataGoogleBigqueryTableTableConstraintsForeignKeysColumnReferences): any;
export declare class DataGoogleBigqueryTableTableConstraintsForeignKeysColumnReferencesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryTableTableConstraintsForeignKeysColumnReferences | undefined;
    set internalValue(value: DataGoogleBigqueryTableTableConstraintsForeignKeysColumnReferences | undefined);
    get referencedColumn(): string;
    get referencingColumn(): string;
}
export declare class DataGoogleBigqueryTableTableConstraintsForeignKeysColumnReferencesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryTableTableConstraintsForeignKeysColumnReferencesOutputReference;
}
export interface DataGoogleBigqueryTableTableConstraintsForeignKeysReferencedTable {
}
export declare function dataGoogleBigqueryTableTableConstraintsForeignKeysReferencedTableToTerraform(struct?: DataGoogleBigqueryTableTableConstraintsForeignKeysReferencedTable): any;
export declare function dataGoogleBigqueryTableTableConstraintsForeignKeysReferencedTableToHclTerraform(struct?: DataGoogleBigqueryTableTableConstraintsForeignKeysReferencedTable): any;
export declare class DataGoogleBigqueryTableTableConstraintsForeignKeysReferencedTableOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryTableTableConstraintsForeignKeysReferencedTable | undefined;
    set internalValue(value: DataGoogleBigqueryTableTableConstraintsForeignKeysReferencedTable | undefined);
    get datasetId(): string;
    get projectId(): string;
    get tableId(): string;
}
export declare class DataGoogleBigqueryTableTableConstraintsForeignKeysReferencedTableList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryTableTableConstraintsForeignKeysReferencedTableOutputReference;
}
export interface DataGoogleBigqueryTableTableConstraintsForeignKeys {
}
export declare function dataGoogleBigqueryTableTableConstraintsForeignKeysToTerraform(struct?: DataGoogleBigqueryTableTableConstraintsForeignKeys): any;
export declare function dataGoogleBigqueryTableTableConstraintsForeignKeysToHclTerraform(struct?: DataGoogleBigqueryTableTableConstraintsForeignKeys): any;
export declare class DataGoogleBigqueryTableTableConstraintsForeignKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryTableTableConstraintsForeignKeys | undefined;
    set internalValue(value: DataGoogleBigqueryTableTableConstraintsForeignKeys | undefined);
    private _columnReferences;
    get columnReferences(): DataGoogleBigqueryTableTableConstraintsForeignKeysColumnReferencesList;
    get name(): string;
    private _referencedTable;
    get referencedTable(): DataGoogleBigqueryTableTableConstraintsForeignKeysReferencedTableList;
}
export declare class DataGoogleBigqueryTableTableConstraintsForeignKeysList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryTableTableConstraintsForeignKeysOutputReference;
}
export interface DataGoogleBigqueryTableTableConstraintsPrimaryKey {
}
export declare function dataGoogleBigqueryTableTableConstraintsPrimaryKeyToTerraform(struct?: DataGoogleBigqueryTableTableConstraintsPrimaryKey): any;
export declare function dataGoogleBigqueryTableTableConstraintsPrimaryKeyToHclTerraform(struct?: DataGoogleBigqueryTableTableConstraintsPrimaryKey): any;
export declare class DataGoogleBigqueryTableTableConstraintsPrimaryKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryTableTableConstraintsPrimaryKey | undefined;
    set internalValue(value: DataGoogleBigqueryTableTableConstraintsPrimaryKey | undefined);
    get columns(): string[];
}
export declare class DataGoogleBigqueryTableTableConstraintsPrimaryKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryTableTableConstraintsPrimaryKeyOutputReference;
}
export interface DataGoogleBigqueryTableTableConstraints {
}
export declare function dataGoogleBigqueryTableTableConstraintsToTerraform(struct?: DataGoogleBigqueryTableTableConstraints): any;
export declare function dataGoogleBigqueryTableTableConstraintsToHclTerraform(struct?: DataGoogleBigqueryTableTableConstraints): any;
export declare class DataGoogleBigqueryTableTableConstraintsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryTableTableConstraints | undefined;
    set internalValue(value: DataGoogleBigqueryTableTableConstraints | undefined);
    private _foreignKeys;
    get foreignKeys(): DataGoogleBigqueryTableTableConstraintsForeignKeysList;
    private _primaryKey;
    get primaryKey(): DataGoogleBigqueryTableTableConstraintsPrimaryKeyList;
}
export declare class DataGoogleBigqueryTableTableConstraintsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryTableTableConstraintsOutputReference;
}
export interface DataGoogleBigqueryTableTableReplicationInfo {
}
export declare function dataGoogleBigqueryTableTableReplicationInfoToTerraform(struct?: DataGoogleBigqueryTableTableReplicationInfo): any;
export declare function dataGoogleBigqueryTableTableReplicationInfoToHclTerraform(struct?: DataGoogleBigqueryTableTableReplicationInfo): any;
export declare class DataGoogleBigqueryTableTableReplicationInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryTableTableReplicationInfo | undefined;
    set internalValue(value: DataGoogleBigqueryTableTableReplicationInfo | undefined);
    get replicationIntervalMs(): number;
    get sourceDatasetId(): string;
    get sourceProjectId(): string;
    get sourceTableId(): string;
}
export declare class DataGoogleBigqueryTableTableReplicationInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryTableTableReplicationInfoOutputReference;
}
export interface DataGoogleBigqueryTableTimePartitioning {
}
export declare function dataGoogleBigqueryTableTimePartitioningToTerraform(struct?: DataGoogleBigqueryTableTimePartitioning): any;
export declare function dataGoogleBigqueryTableTimePartitioningToHclTerraform(struct?: DataGoogleBigqueryTableTimePartitioning): any;
export declare class DataGoogleBigqueryTableTimePartitioningOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryTableTimePartitioning | undefined;
    set internalValue(value: DataGoogleBigqueryTableTimePartitioning | undefined);
    get expirationMs(): number;
    get field(): string;
    get requirePartitionFilter(): cdktn.IResolvable;
    get type(): string;
}
export declare class DataGoogleBigqueryTableTimePartitioningList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryTableTimePartitioningOutputReference;
}
export interface DataGoogleBigqueryTableView {
}
export declare function dataGoogleBigqueryTableViewToTerraform(struct?: DataGoogleBigqueryTableView): any;
export declare function dataGoogleBigqueryTableViewToHclTerraform(struct?: DataGoogleBigqueryTableView): any;
export declare class DataGoogleBigqueryTableViewOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryTableView | undefined;
    set internalValue(value: DataGoogleBigqueryTableView | undefined);
    get query(): string;
    get useLegacySql(): cdktn.IResolvable;
}
export declare class DataGoogleBigqueryTableViewList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryTableViewOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_bigquery_table google_bigquery_table}
*/
export declare class DataGoogleBigqueryTable extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_bigquery_table";
    /**
    * Generates CDKTN code for importing a DataGoogleBigqueryTable resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleBigqueryTable to import
    * @param importFromId The id of the existing DataGoogleBigqueryTable that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_bigquery_table#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleBigqueryTable to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_bigquery_table google_bigquery_table} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleBigqueryTableConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleBigqueryTableConfig);
    private _biglakeConfiguration;
    get biglakeConfiguration(): DataGoogleBigqueryTableBiglakeConfigurationList;
    get clustering(): string[];
    get creationTime(): number;
    private _datasetId?;
    get datasetId(): string;
    set datasetId(value: string);
    get datasetIdInput(): string | undefined;
    get deletionPolicy(): string;
    get deletionProtection(): cdktn.IResolvable;
    get description(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _encryptionConfiguration;
    get encryptionConfiguration(): DataGoogleBigqueryTableEncryptionConfigurationList;
    get etag(): string;
    get expirationTime(): number;
    private _externalCatalogTableOptions;
    get externalCatalogTableOptions(): DataGoogleBigqueryTableExternalCatalogTableOptionsList;
    private _externalDataConfiguration;
    get externalDataConfiguration(): DataGoogleBigqueryTableExternalDataConfigurationList;
    get friendlyName(): string;
    get generatedSchemaColumns(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ignoreAutoGeneratedSchema(): cdktn.IResolvable;
    get ignoreSchemaChanges(): string[];
    private _labels;
    get labels(): cdktn.StringMap;
    get lastModifiedTime(): number;
    get location(): string;
    private _materializedView;
    get materializedView(): DataGoogleBigqueryTableMaterializedViewList;
    get maxStaleness(): string;
    get numBytes(): number;
    get numLongTermBytes(): number;
    get numRows(): number;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _rangePartitioning;
    get rangePartitioning(): DataGoogleBigqueryTableRangePartitioningList;
    get requirePartitionFilter(): cdktn.IResolvable;
    private _resourceTags;
    get resourceTags(): cdktn.StringMap;
    get schema(): string;
    private _schemaForeignTypeInfo;
    get schemaForeignTypeInfo(): DataGoogleBigqueryTableSchemaForeignTypeInfoList;
    get selfLink(): string;
    private _tableConstraints;
    get tableConstraints(): DataGoogleBigqueryTableTableConstraintsList;
    private _tableId?;
    get tableId(): string;
    set tableId(value: string);
    get tableIdInput(): string | undefined;
    get tableMetadataView(): string;
    private _tableReplicationInfo;
    get tableReplicationInfo(): DataGoogleBigqueryTableTableReplicationInfoList;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _timePartitioning;
    get timePartitioning(): DataGoogleBigqueryTableTimePartitioningList;
    get type(): string;
    private _view;
    get view(): DataGoogleBigqueryTableViewList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
