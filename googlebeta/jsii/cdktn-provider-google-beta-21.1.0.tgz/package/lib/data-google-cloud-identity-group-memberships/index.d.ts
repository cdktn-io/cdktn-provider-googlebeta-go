/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleCloudIdentityGroupMembershipsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the Group to get memberships from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloud_identity_group_memberships#group DataGoogleCloudIdentityGroupMemberships#group}
    */
    readonly group: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloud_identity_group_memberships#id DataGoogleCloudIdentityGroupMemberships#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataGoogleCloudIdentityGroupMembershipsMembershipsMemberKey {
}
export declare function dataGoogleCloudIdentityGroupMembershipsMembershipsMemberKeyToTerraform(struct?: DataGoogleCloudIdentityGroupMembershipsMembershipsMemberKey): any;
export declare function dataGoogleCloudIdentityGroupMembershipsMembershipsMemberKeyToHclTerraform(struct?: DataGoogleCloudIdentityGroupMembershipsMembershipsMemberKey): any;
export declare class DataGoogleCloudIdentityGroupMembershipsMembershipsMemberKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudIdentityGroupMembershipsMembershipsMemberKey | undefined;
    set internalValue(value: DataGoogleCloudIdentityGroupMembershipsMembershipsMemberKey | undefined);
    get id(): string;
    get namespace(): string;
}
export declare class DataGoogleCloudIdentityGroupMembershipsMembershipsMemberKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudIdentityGroupMembershipsMembershipsMemberKeyOutputReference;
}
export interface DataGoogleCloudIdentityGroupMembershipsMembershipsPreferredMemberKey {
}
export declare function dataGoogleCloudIdentityGroupMembershipsMembershipsPreferredMemberKeyToTerraform(struct?: DataGoogleCloudIdentityGroupMembershipsMembershipsPreferredMemberKey): any;
export declare function dataGoogleCloudIdentityGroupMembershipsMembershipsPreferredMemberKeyToHclTerraform(struct?: DataGoogleCloudIdentityGroupMembershipsMembershipsPreferredMemberKey): any;
export declare class DataGoogleCloudIdentityGroupMembershipsMembershipsPreferredMemberKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudIdentityGroupMembershipsMembershipsPreferredMemberKey | undefined;
    set internalValue(value: DataGoogleCloudIdentityGroupMembershipsMembershipsPreferredMemberKey | undefined);
    get id(): string;
    get namespace(): string;
}
export declare class DataGoogleCloudIdentityGroupMembershipsMembershipsPreferredMemberKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudIdentityGroupMembershipsMembershipsPreferredMemberKeyOutputReference;
}
export interface DataGoogleCloudIdentityGroupMembershipsMembershipsRolesExpiryDetail {
}
export declare function dataGoogleCloudIdentityGroupMembershipsMembershipsRolesExpiryDetailToTerraform(struct?: DataGoogleCloudIdentityGroupMembershipsMembershipsRolesExpiryDetail): any;
export declare function dataGoogleCloudIdentityGroupMembershipsMembershipsRolesExpiryDetailToHclTerraform(struct?: DataGoogleCloudIdentityGroupMembershipsMembershipsRolesExpiryDetail): any;
export declare class DataGoogleCloudIdentityGroupMembershipsMembershipsRolesExpiryDetailOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudIdentityGroupMembershipsMembershipsRolesExpiryDetail | undefined;
    set internalValue(value: DataGoogleCloudIdentityGroupMembershipsMembershipsRolesExpiryDetail | undefined);
    get expireTime(): string;
}
export declare class DataGoogleCloudIdentityGroupMembershipsMembershipsRolesExpiryDetailList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudIdentityGroupMembershipsMembershipsRolesExpiryDetailOutputReference;
}
export interface DataGoogleCloudIdentityGroupMembershipsMembershipsRoles {
}
export declare function dataGoogleCloudIdentityGroupMembershipsMembershipsRolesToTerraform(struct?: DataGoogleCloudIdentityGroupMembershipsMembershipsRoles): any;
export declare function dataGoogleCloudIdentityGroupMembershipsMembershipsRolesToHclTerraform(struct?: DataGoogleCloudIdentityGroupMembershipsMembershipsRoles): any;
export declare class DataGoogleCloudIdentityGroupMembershipsMembershipsRolesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudIdentityGroupMembershipsMembershipsRoles | undefined;
    set internalValue(value: DataGoogleCloudIdentityGroupMembershipsMembershipsRoles | undefined);
    private _expiryDetail;
    get expiryDetail(): DataGoogleCloudIdentityGroupMembershipsMembershipsRolesExpiryDetailList;
    get name(): string;
}
export declare class DataGoogleCloudIdentityGroupMembershipsMembershipsRolesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudIdentityGroupMembershipsMembershipsRolesOutputReference;
}
export interface DataGoogleCloudIdentityGroupMembershipsMemberships {
}
export declare function dataGoogleCloudIdentityGroupMembershipsMembershipsToTerraform(struct?: DataGoogleCloudIdentityGroupMembershipsMemberships): any;
export declare function dataGoogleCloudIdentityGroupMembershipsMembershipsToHclTerraform(struct?: DataGoogleCloudIdentityGroupMembershipsMemberships): any;
export declare class DataGoogleCloudIdentityGroupMembershipsMembershipsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudIdentityGroupMembershipsMemberships | undefined;
    set internalValue(value: DataGoogleCloudIdentityGroupMembershipsMemberships | undefined);
    get createIgnoreAlreadyExists(): cdktn.IResolvable;
    get createTime(): string;
    get deletionPolicy(): string;
    get group(): string;
    private _memberKey;
    get memberKey(): DataGoogleCloudIdentityGroupMembershipsMembershipsMemberKeyList;
    get name(): string;
    private _preferredMemberKey;
    get preferredMemberKey(): DataGoogleCloudIdentityGroupMembershipsMembershipsPreferredMemberKeyList;
    private _roles;
    get roles(): DataGoogleCloudIdentityGroupMembershipsMembershipsRolesList;
    get type(): string;
    get updateTime(): string;
}
export declare class DataGoogleCloudIdentityGroupMembershipsMembershipsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudIdentityGroupMembershipsMembershipsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloud_identity_group_memberships google_cloud_identity_group_memberships}
*/
export declare class DataGoogleCloudIdentityGroupMemberships extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_cloud_identity_group_memberships";
    /**
    * Generates CDKTN code for importing a DataGoogleCloudIdentityGroupMemberships resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleCloudIdentityGroupMemberships to import
    * @param importFromId The id of the existing DataGoogleCloudIdentityGroupMemberships that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloud_identity_group_memberships#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleCloudIdentityGroupMemberships to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloud_identity_group_memberships google_cloud_identity_group_memberships} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleCloudIdentityGroupMembershipsConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleCloudIdentityGroupMembershipsConfig);
    private _group?;
    get group(): string;
    set group(value: string);
    get groupInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _memberships;
    get memberships(): DataGoogleCloudIdentityGroupMembershipsMembershipsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
