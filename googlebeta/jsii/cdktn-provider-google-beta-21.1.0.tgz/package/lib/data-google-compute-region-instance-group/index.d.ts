/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleComputeRegionInstanceGroupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_region_instance_group#id DataGoogleComputeRegionInstanceGroup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_region_instance_group#name DataGoogleComputeRegionInstanceGroup#name}
    */
    readonly name?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_region_instance_group#project DataGoogleComputeRegionInstanceGroup#project}
    */
    readonly project?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_region_instance_group#region DataGoogleComputeRegionInstanceGroup#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_region_instance_group#self_link DataGoogleComputeRegionInstanceGroup#self_link}
    */
    readonly selfLink?: string;
}
export interface DataGoogleComputeRegionInstanceGroupInstancesNamedPorts {
}
export declare function dataGoogleComputeRegionInstanceGroupInstancesNamedPortsToTerraform(struct?: DataGoogleComputeRegionInstanceGroupInstancesNamedPorts): any;
export declare function dataGoogleComputeRegionInstanceGroupInstancesNamedPortsToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupInstancesNamedPorts): any;
export declare class DataGoogleComputeRegionInstanceGroupInstancesNamedPortsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupInstancesNamedPorts | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupInstancesNamedPorts | undefined);
    get name(): string;
    get port(): number;
}
export declare class DataGoogleComputeRegionInstanceGroupInstancesNamedPortsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupInstancesNamedPortsOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupInstances {
}
export declare function dataGoogleComputeRegionInstanceGroupInstancesToTerraform(struct?: DataGoogleComputeRegionInstanceGroupInstances): any;
export declare function dataGoogleComputeRegionInstanceGroupInstancesToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupInstances): any;
export declare class DataGoogleComputeRegionInstanceGroupInstancesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupInstances | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupInstances | undefined);
    get instance(): string;
    private _namedPorts;
    get namedPorts(): DataGoogleComputeRegionInstanceGroupInstancesNamedPortsList;
    get status(): string;
}
export declare class DataGoogleComputeRegionInstanceGroupInstancesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupInstancesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_region_instance_group google_compute_region_instance_group}
*/
export declare class DataGoogleComputeRegionInstanceGroup extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_compute_region_instance_group";
    /**
    * Generates CDKTN code for importing a DataGoogleComputeRegionInstanceGroup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleComputeRegionInstanceGroup to import
    * @param importFromId The id of the existing DataGoogleComputeRegionInstanceGroup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_region_instance_group#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleComputeRegionInstanceGroup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_region_instance_group google_compute_region_instance_group} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleComputeRegionInstanceGroupConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGoogleComputeRegionInstanceGroupConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instances;
    get instances(): DataGoogleComputeRegionInstanceGroupInstancesList;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _selfLink?;
    get selfLink(): string;
    set selfLink(value: string);
    resetSelfLink(): void;
    get selfLinkInput(): string | undefined;
    get size(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
