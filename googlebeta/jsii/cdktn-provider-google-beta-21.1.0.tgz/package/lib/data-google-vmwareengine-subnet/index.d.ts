/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleVmwareengineSubnetConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vmwareengine_subnet#id DataGoogleVmwareengineSubnet#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the subnet. For userDefined subnets, this name should be in the format of "service-n",
    * where n ranges from 1 to 5.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vmwareengine_subnet#name DataGoogleVmwareengineSubnet#name}
    */
    readonly name: string;
    /**
    * The resource name of the private cloud to create a new subnet in.
    * Resource names are schemeless URIs that follow the conventions in https://cloud.google.com/apis/design/resource_names.
    * For example: projects/my-project/locations/us-west1-a/privateClouds/my-cloud
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vmwareengine_subnet#parent DataGoogleVmwareengineSubnet#parent}
    */
    readonly parent: string;
}
export interface DataGoogleVmwareengineSubnetDhcpAddressRanges {
}
export declare function dataGoogleVmwareengineSubnetDhcpAddressRangesToTerraform(struct?: DataGoogleVmwareengineSubnetDhcpAddressRanges): any;
export declare function dataGoogleVmwareengineSubnetDhcpAddressRangesToHclTerraform(struct?: DataGoogleVmwareengineSubnetDhcpAddressRanges): any;
export declare class DataGoogleVmwareengineSubnetDhcpAddressRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleVmwareengineSubnetDhcpAddressRanges | undefined;
    set internalValue(value: DataGoogleVmwareengineSubnetDhcpAddressRanges | undefined);
    get firstAddress(): string;
    get lastAddress(): string;
}
export declare class DataGoogleVmwareengineSubnetDhcpAddressRangesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleVmwareengineSubnetDhcpAddressRangesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vmwareengine_subnet google_vmwareengine_subnet}
*/
export declare class DataGoogleVmwareengineSubnet extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_vmwareengine_subnet";
    /**
    * Generates CDKTN code for importing a DataGoogleVmwareengineSubnet resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleVmwareengineSubnet to import
    * @param importFromId The id of the existing DataGoogleVmwareengineSubnet that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vmwareengine_subnet#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleVmwareengineSubnet to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vmwareengine_subnet google_vmwareengine_subnet} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleVmwareengineSubnetConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleVmwareengineSubnetConfig);
    get createTime(): string;
    private _dhcpAddressRanges;
    get dhcpAddressRanges(): DataGoogleVmwareengineSubnetDhcpAddressRangesList;
    get gatewayId(): string;
    get gatewayIp(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ipCidrRange(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    get standardConfig(): cdktn.IResolvable;
    get state(): string;
    get type(): string;
    get uid(): string;
    get updateTime(): string;
    get vlanId(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
