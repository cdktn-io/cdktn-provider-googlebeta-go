/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleSecretManagerRegionalSecretsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Filter string, adhering to the rules in List-operation filtering (https://cloud.google.com/secret-manager/docs/filtering).
    * List only secrets matching the filter. If filter is empty, all regional secrets are listed from the specified location.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_secret_manager_regional_secrets#filter DataGoogleSecretManagerRegionalSecrets#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_secret_manager_regional_secrets#id DataGoogleSecretManagerRegionalSecrets#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_secret_manager_regional_secrets#location DataGoogleSecretManagerRegionalSecrets#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_secret_manager_regional_secrets#project DataGoogleSecretManagerRegionalSecrets#project}
    */
    readonly project?: string;
}
export interface DataGoogleSecretManagerRegionalSecretsSecretsCustomerManagedEncryption {
}
export declare function dataGoogleSecretManagerRegionalSecretsSecretsCustomerManagedEncryptionToTerraform(struct?: DataGoogleSecretManagerRegionalSecretsSecretsCustomerManagedEncryption): any;
export declare function dataGoogleSecretManagerRegionalSecretsSecretsCustomerManagedEncryptionToHclTerraform(struct?: DataGoogleSecretManagerRegionalSecretsSecretsCustomerManagedEncryption): any;
export declare class DataGoogleSecretManagerRegionalSecretsSecretsCustomerManagedEncryptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSecretManagerRegionalSecretsSecretsCustomerManagedEncryption | undefined;
    set internalValue(value: DataGoogleSecretManagerRegionalSecretsSecretsCustomerManagedEncryption | undefined);
    get kmsKeyName(): string;
}
export declare class DataGoogleSecretManagerRegionalSecretsSecretsCustomerManagedEncryptionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSecretManagerRegionalSecretsSecretsCustomerManagedEncryptionOutputReference;
}
export interface DataGoogleSecretManagerRegionalSecretsSecretsRotation {
}
export declare function dataGoogleSecretManagerRegionalSecretsSecretsRotationToTerraform(struct?: DataGoogleSecretManagerRegionalSecretsSecretsRotation): any;
export declare function dataGoogleSecretManagerRegionalSecretsSecretsRotationToHclTerraform(struct?: DataGoogleSecretManagerRegionalSecretsSecretsRotation): any;
export declare class DataGoogleSecretManagerRegionalSecretsSecretsRotationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSecretManagerRegionalSecretsSecretsRotation | undefined;
    set internalValue(value: DataGoogleSecretManagerRegionalSecretsSecretsRotation | undefined);
    get nextRotationTime(): string;
    get rotationPeriod(): string;
}
export declare class DataGoogleSecretManagerRegionalSecretsSecretsRotationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSecretManagerRegionalSecretsSecretsRotationOutputReference;
}
export interface DataGoogleSecretManagerRegionalSecretsSecretsTopics {
}
export declare function dataGoogleSecretManagerRegionalSecretsSecretsTopicsToTerraform(struct?: DataGoogleSecretManagerRegionalSecretsSecretsTopics): any;
export declare function dataGoogleSecretManagerRegionalSecretsSecretsTopicsToHclTerraform(struct?: DataGoogleSecretManagerRegionalSecretsSecretsTopics): any;
export declare class DataGoogleSecretManagerRegionalSecretsSecretsTopicsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSecretManagerRegionalSecretsSecretsTopics | undefined;
    set internalValue(value: DataGoogleSecretManagerRegionalSecretsSecretsTopics | undefined);
    get name(): string;
}
export declare class DataGoogleSecretManagerRegionalSecretsSecretsTopicsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSecretManagerRegionalSecretsSecretsTopicsOutputReference;
}
export interface DataGoogleSecretManagerRegionalSecretsSecrets {
}
export declare function dataGoogleSecretManagerRegionalSecretsSecretsToTerraform(struct?: DataGoogleSecretManagerRegionalSecretsSecrets): any;
export declare function dataGoogleSecretManagerRegionalSecretsSecretsToHclTerraform(struct?: DataGoogleSecretManagerRegionalSecretsSecrets): any;
export declare class DataGoogleSecretManagerRegionalSecretsSecretsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSecretManagerRegionalSecretsSecrets | undefined;
    set internalValue(value: DataGoogleSecretManagerRegionalSecretsSecrets | undefined);
    private _annotations;
    get annotations(): cdktn.StringMap;
    get createTime(): string;
    private _customerManagedEncryption;
    get customerManagedEncryption(): DataGoogleSecretManagerRegionalSecretsSecretsCustomerManagedEncryptionList;
    get deletionPolicy(): string;
    get deletionProtection(): cdktn.IResolvable;
    private _effectiveAnnotations;
    get effectiveAnnotations(): cdktn.StringMap;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get expireTime(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    get location(): string;
    get name(): string;
    get project(): string;
    private _rotation;
    get rotation(): DataGoogleSecretManagerRegionalSecretsSecretsRotationList;
    get secretId(): string;
    get secretType(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _topics;
    get topics(): DataGoogleSecretManagerRegionalSecretsSecretsTopicsList;
    get ttl(): string;
    private _versionAliases;
    get versionAliases(): cdktn.StringMap;
    get versionDestroyTtl(): string;
}
export declare class DataGoogleSecretManagerRegionalSecretsSecretsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSecretManagerRegionalSecretsSecretsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_secret_manager_regional_secrets google_secret_manager_regional_secrets}
*/
export declare class DataGoogleSecretManagerRegionalSecrets extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_secret_manager_regional_secrets";
    /**
    * Generates CDKTN code for importing a DataGoogleSecretManagerRegionalSecrets resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleSecretManagerRegionalSecrets to import
    * @param importFromId The id of the existing DataGoogleSecretManagerRegionalSecrets that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_secret_manager_regional_secrets#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleSecretManagerRegionalSecrets to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_secret_manager_regional_secrets google_secret_manager_regional_secrets} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleSecretManagerRegionalSecretsConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleSecretManagerRegionalSecretsConfig);
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _secrets;
    get secrets(): DataGoogleSecretManagerRegionalSecretsSecretsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
