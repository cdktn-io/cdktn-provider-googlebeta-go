/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleArtifactRegistryFileConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_file#file_id DataGoogleArtifactRegistryFile#file_id}
    */
    readonly fileId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_file#id DataGoogleArtifactRegistryFile#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_file#location DataGoogleArtifactRegistryFile#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_file#output_path DataGoogleArtifactRegistryFile#output_path}
    */
    readonly outputPath: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_file#overwrite DataGoogleArtifactRegistryFile#overwrite}
    */
    readonly overwrite?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_file#project DataGoogleArtifactRegistryFile#project}
    */
    readonly project?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_file#repository_id DataGoogleArtifactRegistryFile#repository_id}
    */
    readonly repositoryId: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_file#timeouts DataGoogleArtifactRegistryFile#timeouts}
    */
    readonly timeouts?: DataGoogleArtifactRegistryFileTimeouts;
}
export interface DataGoogleArtifactRegistryFileTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_file#read DataGoogleArtifactRegistryFile#read}
    */
    readonly read?: string;
}
export declare function dataGoogleArtifactRegistryFileTimeoutsToTerraform(struct?: DataGoogleArtifactRegistryFileTimeouts | cdktn.IResolvable): any;
export declare function dataGoogleArtifactRegistryFileTimeoutsToHclTerraform(struct?: DataGoogleArtifactRegistryFileTimeouts | cdktn.IResolvable): any;
export declare class DataGoogleArtifactRegistryFileTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataGoogleArtifactRegistryFileTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataGoogleArtifactRegistryFileTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_file google_artifact_registry_file}
*/
export declare class DataGoogleArtifactRegistryFile extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_artifact_registry_file";
    /**
    * Generates CDKTN code for importing a DataGoogleArtifactRegistryFile resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleArtifactRegistryFile to import
    * @param importFromId The id of the existing DataGoogleArtifactRegistryFile that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_file#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleArtifactRegistryFile to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_file google_artifact_registry_file} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleArtifactRegistryFileConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleArtifactRegistryFileConfig);
    get createTime(): string;
    private _fileId?;
    get fileId(): string;
    set fileId(value: string);
    get fileIdInput(): string | undefined;
    private _hashes;
    get hashes(): cdktn.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    get outputBase64Sha256(): string;
    private _outputPath?;
    get outputPath(): string;
    set outputPath(value: string);
    get outputPathInput(): string | undefined;
    get outputSha256(): string;
    private _overwrite?;
    get overwrite(): boolean | cdktn.IResolvable;
    set overwrite(value: boolean | cdktn.IResolvable);
    resetOverwrite(): void;
    get overwriteInput(): boolean | cdktn.IResolvable | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _repositoryId?;
    get repositoryId(): string;
    set repositoryId(value: string);
    get repositoryIdInput(): string | undefined;
    get sizeBytes(): number;
    get updateTime(): string;
    private _timeouts;
    get timeouts(): DataGoogleArtifactRegistryFileTimeoutsOutputReference;
    putTimeouts(value: DataGoogleArtifactRegistryFileTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataGoogleArtifactRegistryFileTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
