/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleComputeRouterStatusConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_router_status#id DataGoogleComputeRouterStatus#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the router to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_router_status#name DataGoogleComputeRouterStatus#name}
    */
    readonly name: string;
    /**
    * Project ID of the target router.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_router_status#project DataGoogleComputeRouterStatus#project}
    */
    readonly project?: string;
    /**
    * Region of the target router.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_router_status#region DataGoogleComputeRouterStatus#region}
    */
    readonly region?: string;
}
export interface DataGoogleComputeRouterStatusBestRoutesAsPaths {
}
export declare function dataGoogleComputeRouterStatusBestRoutesAsPathsToTerraform(struct?: DataGoogleComputeRouterStatusBestRoutesAsPaths): any;
export declare function dataGoogleComputeRouterStatusBestRoutesAsPathsToHclTerraform(struct?: DataGoogleComputeRouterStatusBestRoutesAsPaths): any;
export declare class DataGoogleComputeRouterStatusBestRoutesAsPathsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRouterStatusBestRoutesAsPaths | undefined;
    set internalValue(value: DataGoogleComputeRouterStatusBestRoutesAsPaths | undefined);
    get asLists(): number[];
    get pathSegmentType(): string;
}
export declare class DataGoogleComputeRouterStatusBestRoutesAsPathsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRouterStatusBestRoutesAsPathsOutputReference;
}
export interface DataGoogleComputeRouterStatusBestRoutesParams {
}
export declare function dataGoogleComputeRouterStatusBestRoutesParamsToTerraform(struct?: DataGoogleComputeRouterStatusBestRoutesParams): any;
export declare function dataGoogleComputeRouterStatusBestRoutesParamsToHclTerraform(struct?: DataGoogleComputeRouterStatusBestRoutesParams): any;
export declare class DataGoogleComputeRouterStatusBestRoutesParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRouterStatusBestRoutesParams | undefined;
    set internalValue(value: DataGoogleComputeRouterStatusBestRoutesParams | undefined);
    private _resourceManagerTags;
    get resourceManagerTags(): cdktn.StringMap;
}
export declare class DataGoogleComputeRouterStatusBestRoutesParamsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRouterStatusBestRoutesParamsOutputReference;
}
export interface DataGoogleComputeRouterStatusBestRoutesWarningsData {
}
export declare function dataGoogleComputeRouterStatusBestRoutesWarningsDataToTerraform(struct?: DataGoogleComputeRouterStatusBestRoutesWarningsData): any;
export declare function dataGoogleComputeRouterStatusBestRoutesWarningsDataToHclTerraform(struct?: DataGoogleComputeRouterStatusBestRoutesWarningsData): any;
export declare class DataGoogleComputeRouterStatusBestRoutesWarningsDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRouterStatusBestRoutesWarningsData | undefined;
    set internalValue(value: DataGoogleComputeRouterStatusBestRoutesWarningsData | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataGoogleComputeRouterStatusBestRoutesWarningsDataList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRouterStatusBestRoutesWarningsDataOutputReference;
}
export interface DataGoogleComputeRouterStatusBestRoutesWarnings {
}
export declare function dataGoogleComputeRouterStatusBestRoutesWarningsToTerraform(struct?: DataGoogleComputeRouterStatusBestRoutesWarnings): any;
export declare function dataGoogleComputeRouterStatusBestRoutesWarningsToHclTerraform(struct?: DataGoogleComputeRouterStatusBestRoutesWarnings): any;
export declare class DataGoogleComputeRouterStatusBestRoutesWarningsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRouterStatusBestRoutesWarnings | undefined;
    set internalValue(value: DataGoogleComputeRouterStatusBestRoutesWarnings | undefined);
    get code(): string;
    private _data;
    get data(): DataGoogleComputeRouterStatusBestRoutesWarningsDataList;
    get message(): string;
}
export declare class DataGoogleComputeRouterStatusBestRoutesWarningsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRouterStatusBestRoutesWarningsOutputReference;
}
export interface DataGoogleComputeRouterStatusBestRoutes {
}
export declare function dataGoogleComputeRouterStatusBestRoutesToTerraform(struct?: DataGoogleComputeRouterStatusBestRoutes): any;
export declare function dataGoogleComputeRouterStatusBestRoutesToHclTerraform(struct?: DataGoogleComputeRouterStatusBestRoutes): any;
export declare class DataGoogleComputeRouterStatusBestRoutesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRouterStatusBestRoutes | undefined;
    set internalValue(value: DataGoogleComputeRouterStatusBestRoutes | undefined);
    private _asPaths;
    get asPaths(): DataGoogleComputeRouterStatusBestRoutesAsPathsList;
    get creationTimestamp(): string;
    get deletionPolicy(): string;
    get description(): string;
    get destRange(): string;
    get name(): string;
    get network(): string;
    get nextHopGateway(): string;
    get nextHopHub(): string;
    get nextHopIlb(): string;
    get nextHopInstance(): string;
    get nextHopInstanceZone(): string;
    get nextHopInterRegionCost(): string;
    get nextHopIp(): string;
    get nextHopMed(): string;
    get nextHopNetwork(): string;
    get nextHopOrigin(): string;
    get nextHopPeering(): string;
    get nextHopVpnTunnel(): string;
    private _params;
    get params(): DataGoogleComputeRouterStatusBestRoutesParamsList;
    get priority(): number;
    get project(): string;
    get routeStatus(): string;
    get routeType(): string;
    get selfLink(): string;
    get tags(): string[];
    private _warnings;
    get warnings(): DataGoogleComputeRouterStatusBestRoutesWarningsList;
}
export declare class DataGoogleComputeRouterStatusBestRoutesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRouterStatusBestRoutesOutputReference;
}
export interface DataGoogleComputeRouterStatusBestRoutesForRouterAsPaths {
}
export declare function dataGoogleComputeRouterStatusBestRoutesForRouterAsPathsToTerraform(struct?: DataGoogleComputeRouterStatusBestRoutesForRouterAsPaths): any;
export declare function dataGoogleComputeRouterStatusBestRoutesForRouterAsPathsToHclTerraform(struct?: DataGoogleComputeRouterStatusBestRoutesForRouterAsPaths): any;
export declare class DataGoogleComputeRouterStatusBestRoutesForRouterAsPathsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRouterStatusBestRoutesForRouterAsPaths | undefined;
    set internalValue(value: DataGoogleComputeRouterStatusBestRoutesForRouterAsPaths | undefined);
    get asLists(): number[];
    get pathSegmentType(): string;
}
export declare class DataGoogleComputeRouterStatusBestRoutesForRouterAsPathsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRouterStatusBestRoutesForRouterAsPathsOutputReference;
}
export interface DataGoogleComputeRouterStatusBestRoutesForRouterParams {
}
export declare function dataGoogleComputeRouterStatusBestRoutesForRouterParamsToTerraform(struct?: DataGoogleComputeRouterStatusBestRoutesForRouterParams): any;
export declare function dataGoogleComputeRouterStatusBestRoutesForRouterParamsToHclTerraform(struct?: DataGoogleComputeRouterStatusBestRoutesForRouterParams): any;
export declare class DataGoogleComputeRouterStatusBestRoutesForRouterParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRouterStatusBestRoutesForRouterParams | undefined;
    set internalValue(value: DataGoogleComputeRouterStatusBestRoutesForRouterParams | undefined);
    private _resourceManagerTags;
    get resourceManagerTags(): cdktn.StringMap;
}
export declare class DataGoogleComputeRouterStatusBestRoutesForRouterParamsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRouterStatusBestRoutesForRouterParamsOutputReference;
}
export interface DataGoogleComputeRouterStatusBestRoutesForRouterWarningsData {
}
export declare function dataGoogleComputeRouterStatusBestRoutesForRouterWarningsDataToTerraform(struct?: DataGoogleComputeRouterStatusBestRoutesForRouterWarningsData): any;
export declare function dataGoogleComputeRouterStatusBestRoutesForRouterWarningsDataToHclTerraform(struct?: DataGoogleComputeRouterStatusBestRoutesForRouterWarningsData): any;
export declare class DataGoogleComputeRouterStatusBestRoutesForRouterWarningsDataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRouterStatusBestRoutesForRouterWarningsData | undefined;
    set internalValue(value: DataGoogleComputeRouterStatusBestRoutesForRouterWarningsData | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataGoogleComputeRouterStatusBestRoutesForRouterWarningsDataList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRouterStatusBestRoutesForRouterWarningsDataOutputReference;
}
export interface DataGoogleComputeRouterStatusBestRoutesForRouterWarnings {
}
export declare function dataGoogleComputeRouterStatusBestRoutesForRouterWarningsToTerraform(struct?: DataGoogleComputeRouterStatusBestRoutesForRouterWarnings): any;
export declare function dataGoogleComputeRouterStatusBestRoutesForRouterWarningsToHclTerraform(struct?: DataGoogleComputeRouterStatusBestRoutesForRouterWarnings): any;
export declare class DataGoogleComputeRouterStatusBestRoutesForRouterWarningsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRouterStatusBestRoutesForRouterWarnings | undefined;
    set internalValue(value: DataGoogleComputeRouterStatusBestRoutesForRouterWarnings | undefined);
    get code(): string;
    private _data;
    get data(): DataGoogleComputeRouterStatusBestRoutesForRouterWarningsDataList;
    get message(): string;
}
export declare class DataGoogleComputeRouterStatusBestRoutesForRouterWarningsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRouterStatusBestRoutesForRouterWarningsOutputReference;
}
export interface DataGoogleComputeRouterStatusBestRoutesForRouter {
}
export declare function dataGoogleComputeRouterStatusBestRoutesForRouterToTerraform(struct?: DataGoogleComputeRouterStatusBestRoutesForRouter): any;
export declare function dataGoogleComputeRouterStatusBestRoutesForRouterToHclTerraform(struct?: DataGoogleComputeRouterStatusBestRoutesForRouter): any;
export declare class DataGoogleComputeRouterStatusBestRoutesForRouterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRouterStatusBestRoutesForRouter | undefined;
    set internalValue(value: DataGoogleComputeRouterStatusBestRoutesForRouter | undefined);
    private _asPaths;
    get asPaths(): DataGoogleComputeRouterStatusBestRoutesForRouterAsPathsList;
    get creationTimestamp(): string;
    get deletionPolicy(): string;
    get description(): string;
    get destRange(): string;
    get name(): string;
    get network(): string;
    get nextHopGateway(): string;
    get nextHopHub(): string;
    get nextHopIlb(): string;
    get nextHopInstance(): string;
    get nextHopInstanceZone(): string;
    get nextHopInterRegionCost(): string;
    get nextHopIp(): string;
    get nextHopMed(): string;
    get nextHopNetwork(): string;
    get nextHopOrigin(): string;
    get nextHopPeering(): string;
    get nextHopVpnTunnel(): string;
    private _params;
    get params(): DataGoogleComputeRouterStatusBestRoutesForRouterParamsList;
    get priority(): number;
    get project(): string;
    get routeStatus(): string;
    get routeType(): string;
    get selfLink(): string;
    get tags(): string[];
    private _warnings;
    get warnings(): DataGoogleComputeRouterStatusBestRoutesForRouterWarningsList;
}
export declare class DataGoogleComputeRouterStatusBestRoutesForRouterList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRouterStatusBestRoutesForRouterOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_router_status google_compute_router_status}
*/
export declare class DataGoogleComputeRouterStatus extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_compute_router_status";
    /**
    * Generates CDKTN code for importing a DataGoogleComputeRouterStatus resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleComputeRouterStatus to import
    * @param importFromId The id of the existing DataGoogleComputeRouterStatus that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_router_status#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleComputeRouterStatus to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_router_status google_compute_router_status} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleComputeRouterStatusConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleComputeRouterStatusConfig);
    private _bestRoutes;
    get bestRoutes(): DataGoogleComputeRouterStatusBestRoutesList;
    private _bestRoutesForRouter;
    get bestRoutesForRouter(): DataGoogleComputeRouterStatusBestRoutesForRouterList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get network(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
