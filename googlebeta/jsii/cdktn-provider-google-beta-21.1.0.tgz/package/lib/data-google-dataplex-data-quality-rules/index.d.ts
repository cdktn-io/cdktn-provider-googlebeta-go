/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleDataplexDataQualityRulesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_dataplex_data_quality_rules#data_scan_id DataGoogleDataplexDataQualityRules#data_scan_id}
    */
    readonly dataScanId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_dataplex_data_quality_rules#id DataGoogleDataplexDataQualityRules#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_dataplex_data_quality_rules#location DataGoogleDataplexDataQualityRules#location}
    */
    readonly location?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_dataplex_data_quality_rules#project DataGoogleDataplexDataQualityRules#project}
    */
    readonly project?: string;
}
export interface DataGoogleDataplexDataQualityRulesRulesNonNullExpectation {
}
export declare function dataGoogleDataplexDataQualityRulesRulesNonNullExpectationToTerraform(struct?: DataGoogleDataplexDataQualityRulesRulesNonNullExpectation): any;
export declare function dataGoogleDataplexDataQualityRulesRulesNonNullExpectationToHclTerraform(struct?: DataGoogleDataplexDataQualityRulesRulesNonNullExpectation): any;
export declare class DataGoogleDataplexDataQualityRulesRulesNonNullExpectationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleDataplexDataQualityRulesRulesNonNullExpectation | undefined;
    set internalValue(value: DataGoogleDataplexDataQualityRulesRulesNonNullExpectation | undefined);
}
export declare class DataGoogleDataplexDataQualityRulesRulesNonNullExpectationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleDataplexDataQualityRulesRulesNonNullExpectationOutputReference;
}
export interface DataGoogleDataplexDataQualityRulesRulesRangeExpectation {
}
export declare function dataGoogleDataplexDataQualityRulesRulesRangeExpectationToTerraform(struct?: DataGoogleDataplexDataQualityRulesRulesRangeExpectation): any;
export declare function dataGoogleDataplexDataQualityRulesRulesRangeExpectationToHclTerraform(struct?: DataGoogleDataplexDataQualityRulesRulesRangeExpectation): any;
export declare class DataGoogleDataplexDataQualityRulesRulesRangeExpectationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleDataplexDataQualityRulesRulesRangeExpectation | undefined;
    set internalValue(value: DataGoogleDataplexDataQualityRulesRulesRangeExpectation | undefined);
    get maxValue(): string;
    get minValue(): string;
    get strictMaxEnabled(): cdktn.IResolvable;
    get strictMinEnabled(): cdktn.IResolvable;
}
export declare class DataGoogleDataplexDataQualityRulesRulesRangeExpectationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleDataplexDataQualityRulesRulesRangeExpectationOutputReference;
}
export interface DataGoogleDataplexDataQualityRulesRulesRegexExpectation {
}
export declare function dataGoogleDataplexDataQualityRulesRulesRegexExpectationToTerraform(struct?: DataGoogleDataplexDataQualityRulesRulesRegexExpectation): any;
export declare function dataGoogleDataplexDataQualityRulesRulesRegexExpectationToHclTerraform(struct?: DataGoogleDataplexDataQualityRulesRulesRegexExpectation): any;
export declare class DataGoogleDataplexDataQualityRulesRulesRegexExpectationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleDataplexDataQualityRulesRulesRegexExpectation | undefined;
    set internalValue(value: DataGoogleDataplexDataQualityRulesRulesRegexExpectation | undefined);
    get regex(): string;
}
export declare class DataGoogleDataplexDataQualityRulesRulesRegexExpectationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleDataplexDataQualityRulesRulesRegexExpectationOutputReference;
}
export interface DataGoogleDataplexDataQualityRulesRulesRowConditionExpectation {
}
export declare function dataGoogleDataplexDataQualityRulesRulesRowConditionExpectationToTerraform(struct?: DataGoogleDataplexDataQualityRulesRulesRowConditionExpectation): any;
export declare function dataGoogleDataplexDataQualityRulesRulesRowConditionExpectationToHclTerraform(struct?: DataGoogleDataplexDataQualityRulesRulesRowConditionExpectation): any;
export declare class DataGoogleDataplexDataQualityRulesRulesRowConditionExpectationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleDataplexDataQualityRulesRulesRowConditionExpectation | undefined;
    set internalValue(value: DataGoogleDataplexDataQualityRulesRulesRowConditionExpectation | undefined);
    get sqlExpression(): string;
}
export declare class DataGoogleDataplexDataQualityRulesRulesRowConditionExpectationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleDataplexDataQualityRulesRulesRowConditionExpectationOutputReference;
}
export interface DataGoogleDataplexDataQualityRulesRulesSetExpectation {
}
export declare function dataGoogleDataplexDataQualityRulesRulesSetExpectationToTerraform(struct?: DataGoogleDataplexDataQualityRulesRulesSetExpectation): any;
export declare function dataGoogleDataplexDataQualityRulesRulesSetExpectationToHclTerraform(struct?: DataGoogleDataplexDataQualityRulesRulesSetExpectation): any;
export declare class DataGoogleDataplexDataQualityRulesRulesSetExpectationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleDataplexDataQualityRulesRulesSetExpectation | undefined;
    set internalValue(value: DataGoogleDataplexDataQualityRulesRulesSetExpectation | undefined);
    get values(): string[];
}
export declare class DataGoogleDataplexDataQualityRulesRulesSetExpectationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleDataplexDataQualityRulesRulesSetExpectationOutputReference;
}
export interface DataGoogleDataplexDataQualityRulesRulesSqlAssertion {
}
export declare function dataGoogleDataplexDataQualityRulesRulesSqlAssertionToTerraform(struct?: DataGoogleDataplexDataQualityRulesRulesSqlAssertion): any;
export declare function dataGoogleDataplexDataQualityRulesRulesSqlAssertionToHclTerraform(struct?: DataGoogleDataplexDataQualityRulesRulesSqlAssertion): any;
export declare class DataGoogleDataplexDataQualityRulesRulesSqlAssertionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleDataplexDataQualityRulesRulesSqlAssertion | undefined;
    set internalValue(value: DataGoogleDataplexDataQualityRulesRulesSqlAssertion | undefined);
    get sqlStatement(): string;
}
export declare class DataGoogleDataplexDataQualityRulesRulesSqlAssertionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleDataplexDataQualityRulesRulesSqlAssertionOutputReference;
}
export interface DataGoogleDataplexDataQualityRulesRulesStatisticRangeExpectation {
}
export declare function dataGoogleDataplexDataQualityRulesRulesStatisticRangeExpectationToTerraform(struct?: DataGoogleDataplexDataQualityRulesRulesStatisticRangeExpectation): any;
export declare function dataGoogleDataplexDataQualityRulesRulesStatisticRangeExpectationToHclTerraform(struct?: DataGoogleDataplexDataQualityRulesRulesStatisticRangeExpectation): any;
export declare class DataGoogleDataplexDataQualityRulesRulesStatisticRangeExpectationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleDataplexDataQualityRulesRulesStatisticRangeExpectation | undefined;
    set internalValue(value: DataGoogleDataplexDataQualityRulesRulesStatisticRangeExpectation | undefined);
    get maxValue(): string;
    get minValue(): string;
    get statistic(): string;
    get strictMaxEnabled(): cdktn.IResolvable;
    get strictMinEnabled(): cdktn.IResolvable;
}
export declare class DataGoogleDataplexDataQualityRulesRulesStatisticRangeExpectationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleDataplexDataQualityRulesRulesStatisticRangeExpectationOutputReference;
}
export interface DataGoogleDataplexDataQualityRulesRulesTableConditionExpectation {
}
export declare function dataGoogleDataplexDataQualityRulesRulesTableConditionExpectationToTerraform(struct?: DataGoogleDataplexDataQualityRulesRulesTableConditionExpectation): any;
export declare function dataGoogleDataplexDataQualityRulesRulesTableConditionExpectationToHclTerraform(struct?: DataGoogleDataplexDataQualityRulesRulesTableConditionExpectation): any;
export declare class DataGoogleDataplexDataQualityRulesRulesTableConditionExpectationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleDataplexDataQualityRulesRulesTableConditionExpectation | undefined;
    set internalValue(value: DataGoogleDataplexDataQualityRulesRulesTableConditionExpectation | undefined);
    get sqlExpression(): string;
}
export declare class DataGoogleDataplexDataQualityRulesRulesTableConditionExpectationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleDataplexDataQualityRulesRulesTableConditionExpectationOutputReference;
}
export interface DataGoogleDataplexDataQualityRulesRulesUniquenessExpectation {
}
export declare function dataGoogleDataplexDataQualityRulesRulesUniquenessExpectationToTerraform(struct?: DataGoogleDataplexDataQualityRulesRulesUniquenessExpectation): any;
export declare function dataGoogleDataplexDataQualityRulesRulesUniquenessExpectationToHclTerraform(struct?: DataGoogleDataplexDataQualityRulesRulesUniquenessExpectation): any;
export declare class DataGoogleDataplexDataQualityRulesRulesUniquenessExpectationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleDataplexDataQualityRulesRulesUniquenessExpectation | undefined;
    set internalValue(value: DataGoogleDataplexDataQualityRulesRulesUniquenessExpectation | undefined);
}
export declare class DataGoogleDataplexDataQualityRulesRulesUniquenessExpectationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleDataplexDataQualityRulesRulesUniquenessExpectationOutputReference;
}
export interface DataGoogleDataplexDataQualityRulesRules {
}
export declare function dataGoogleDataplexDataQualityRulesRulesToTerraform(struct?: DataGoogleDataplexDataQualityRulesRules): any;
export declare function dataGoogleDataplexDataQualityRulesRulesToHclTerraform(struct?: DataGoogleDataplexDataQualityRulesRules): any;
export declare class DataGoogleDataplexDataQualityRulesRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleDataplexDataQualityRulesRules | undefined;
    set internalValue(value: DataGoogleDataplexDataQualityRulesRules | undefined);
    get column(): string;
    get description(): string;
    get dimension(): string;
    get ignoreNull(): cdktn.IResolvable;
    get name(): string;
    private _nonNullExpectation;
    get nonNullExpectation(): DataGoogleDataplexDataQualityRulesRulesNonNullExpectationList;
    private _rangeExpectation;
    get rangeExpectation(): DataGoogleDataplexDataQualityRulesRulesRangeExpectationList;
    private _regexExpectation;
    get regexExpectation(): DataGoogleDataplexDataQualityRulesRulesRegexExpectationList;
    private _rowConditionExpectation;
    get rowConditionExpectation(): DataGoogleDataplexDataQualityRulesRulesRowConditionExpectationList;
    private _setExpectation;
    get setExpectation(): DataGoogleDataplexDataQualityRulesRulesSetExpectationList;
    private _sqlAssertion;
    get sqlAssertion(): DataGoogleDataplexDataQualityRulesRulesSqlAssertionList;
    private _statisticRangeExpectation;
    get statisticRangeExpectation(): DataGoogleDataplexDataQualityRulesRulesStatisticRangeExpectationList;
    get suspended(): cdktn.IResolvable;
    private _tableConditionExpectation;
    get tableConditionExpectation(): DataGoogleDataplexDataQualityRulesRulesTableConditionExpectationList;
    get threshold(): number;
    private _uniquenessExpectation;
    get uniquenessExpectation(): DataGoogleDataplexDataQualityRulesRulesUniquenessExpectationList;
}
export declare class DataGoogleDataplexDataQualityRulesRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleDataplexDataQualityRulesRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_dataplex_data_quality_rules google_dataplex_data_quality_rules}
*/
export declare class DataGoogleDataplexDataQualityRules extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_dataplex_data_quality_rules";
    /**
    * Generates CDKTN code for importing a DataGoogleDataplexDataQualityRules resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleDataplexDataQualityRules to import
    * @param importFromId The id of the existing DataGoogleDataplexDataQualityRules that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_dataplex_data_quality_rules#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleDataplexDataQualityRules to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_dataplex_data_quality_rules google_dataplex_data_quality_rules} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleDataplexDataQualityRulesConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleDataplexDataQualityRulesConfig);
    private _dataScanId?;
    get dataScanId(): string;
    set dataScanId(value: string);
    get dataScanIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _rules;
    get rules(): DataGoogleDataplexDataQualityRulesRulesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
