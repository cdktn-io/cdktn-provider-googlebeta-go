/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleAlloydbLocationsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_alloydb_locations#id DataGoogleAlloydbLocations#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Project ID of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_alloydb_locations#project DataGoogleAlloydbLocations#project}
    */
    readonly project?: string;
}
export interface DataGoogleAlloydbLocationsLocations {
}
export declare function dataGoogleAlloydbLocationsLocationsToTerraform(struct?: DataGoogleAlloydbLocationsLocations): any;
export declare function dataGoogleAlloydbLocationsLocationsToHclTerraform(struct?: DataGoogleAlloydbLocationsLocations): any;
export declare class DataGoogleAlloydbLocationsLocationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbLocationsLocations | undefined;
    set internalValue(value: DataGoogleAlloydbLocationsLocations | undefined);
    get displayName(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    get locationId(): string;
    private _metadata;
    get metadata(): cdktn.StringMap;
    get name(): string;
}
export declare class DataGoogleAlloydbLocationsLocationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbLocationsLocationsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_alloydb_locations google_alloydb_locations}
*/
export declare class DataGoogleAlloydbLocations extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_alloydb_locations";
    /**
    * Generates CDKTN code for importing a DataGoogleAlloydbLocations resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleAlloydbLocations to import
    * @param importFromId The id of the existing DataGoogleAlloydbLocations that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_alloydb_locations#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleAlloydbLocations to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_alloydb_locations google_alloydb_locations} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleAlloydbLocationsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGoogleAlloydbLocationsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _locations;
    get locations(): DataGoogleAlloydbLocationsLocationsList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
