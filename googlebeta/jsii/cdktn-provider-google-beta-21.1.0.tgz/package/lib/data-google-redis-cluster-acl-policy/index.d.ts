/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleRedisClusterAclPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The logical name of the ACL policy in the customer project
    * with the following restrictions:
    *
    * * Must contain only lowercase letters, numbers, and hyphens.
    * * Must start with a letter.
    * * Must be between 1-63 characters.
    * * Must end with a number or a letter.
    * * Must be unique within the customer project / location
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_redis_cluster_acl_policy#acl_policy_id DataGoogleRedisClusterAclPolicy#acl_policy_id}
    */
    readonly aclPolicyId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_redis_cluster_acl_policy#id DataGoogleRedisClusterAclPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_redis_cluster_acl_policy#location DataGoogleRedisClusterAclPolicy#location}
    */
    readonly location?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_redis_cluster_acl_policy#project DataGoogleRedisClusterAclPolicy#project}
    */
    readonly project?: string;
}
export interface DataGoogleRedisClusterAclPolicyRules {
}
export declare function dataGoogleRedisClusterAclPolicyRulesToTerraform(struct?: DataGoogleRedisClusterAclPolicyRules): any;
export declare function dataGoogleRedisClusterAclPolicyRulesToHclTerraform(struct?: DataGoogleRedisClusterAclPolicyRules): any;
export declare class DataGoogleRedisClusterAclPolicyRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterAclPolicyRules | undefined;
    set internalValue(value: DataGoogleRedisClusterAclPolicyRules | undefined);
    get rule(): string;
    get username(): string;
}
export declare class DataGoogleRedisClusterAclPolicyRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterAclPolicyRulesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_redis_cluster_acl_policy google_redis_cluster_acl_policy}
*/
export declare class DataGoogleRedisClusterAclPolicy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_redis_cluster_acl_policy";
    /**
    * Generates CDKTN code for importing a DataGoogleRedisClusterAclPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleRedisClusterAclPolicy to import
    * @param importFromId The id of the existing DataGoogleRedisClusterAclPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_redis_cluster_acl_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleRedisClusterAclPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_redis_cluster_acl_policy google_redis_cluster_acl_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleRedisClusterAclPolicyConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleRedisClusterAclPolicyConfig);
    private _aclPolicyId?;
    get aclPolicyId(): string;
    set aclPolicyId(value: string);
    get aclPolicyIdInput(): string | undefined;
    get deletionPolicy(): string;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _rules;
    get rules(): DataGoogleRedisClusterAclPolicyRulesList;
    get state(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
