/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleStorageControlFolderIntelligenceConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_storage_control_folder_intelligence_config#id DataGoogleStorageControlFolderIntelligenceConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Identifier of the GCP Folder. For GCP Folder, this field can be folder number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_storage_control_folder_intelligence_config#name DataGoogleStorageControlFolderIntelligenceConfig#name}
    */
    readonly name: string;
}
export interface DataGoogleStorageControlFolderIntelligenceConfigEffectiveIntelligenceConfig {
}
export declare function dataGoogleStorageControlFolderIntelligenceConfigEffectiveIntelligenceConfigToTerraform(struct?: DataGoogleStorageControlFolderIntelligenceConfigEffectiveIntelligenceConfig): any;
export declare function dataGoogleStorageControlFolderIntelligenceConfigEffectiveIntelligenceConfigToHclTerraform(struct?: DataGoogleStorageControlFolderIntelligenceConfigEffectiveIntelligenceConfig): any;
export declare class DataGoogleStorageControlFolderIntelligenceConfigEffectiveIntelligenceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlFolderIntelligenceConfigEffectiveIntelligenceConfig | undefined;
    set internalValue(value: DataGoogleStorageControlFolderIntelligenceConfigEffectiveIntelligenceConfig | undefined);
    get effectiveEdition(): string;
    get intelligenceConfig(): string;
}
export declare class DataGoogleStorageControlFolderIntelligenceConfigEffectiveIntelligenceConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlFolderIntelligenceConfigEffectiveIntelligenceConfigOutputReference;
}
export interface DataGoogleStorageControlFolderIntelligenceConfigFilterExcludedCloudStorageBuckets {
}
export declare function dataGoogleStorageControlFolderIntelligenceConfigFilterExcludedCloudStorageBucketsToTerraform(struct?: DataGoogleStorageControlFolderIntelligenceConfigFilterExcludedCloudStorageBuckets): any;
export declare function dataGoogleStorageControlFolderIntelligenceConfigFilterExcludedCloudStorageBucketsToHclTerraform(struct?: DataGoogleStorageControlFolderIntelligenceConfigFilterExcludedCloudStorageBuckets): any;
export declare class DataGoogleStorageControlFolderIntelligenceConfigFilterExcludedCloudStorageBucketsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlFolderIntelligenceConfigFilterExcludedCloudStorageBuckets | undefined;
    set internalValue(value: DataGoogleStorageControlFolderIntelligenceConfigFilterExcludedCloudStorageBuckets | undefined);
    get bucketIdRegexes(): string[];
}
export declare class DataGoogleStorageControlFolderIntelligenceConfigFilterExcludedCloudStorageBucketsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlFolderIntelligenceConfigFilterExcludedCloudStorageBucketsOutputReference;
}
export interface DataGoogleStorageControlFolderIntelligenceConfigFilterExcludedCloudStorageLocations {
}
export declare function dataGoogleStorageControlFolderIntelligenceConfigFilterExcludedCloudStorageLocationsToTerraform(struct?: DataGoogleStorageControlFolderIntelligenceConfigFilterExcludedCloudStorageLocations): any;
export declare function dataGoogleStorageControlFolderIntelligenceConfigFilterExcludedCloudStorageLocationsToHclTerraform(struct?: DataGoogleStorageControlFolderIntelligenceConfigFilterExcludedCloudStorageLocations): any;
export declare class DataGoogleStorageControlFolderIntelligenceConfigFilterExcludedCloudStorageLocationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlFolderIntelligenceConfigFilterExcludedCloudStorageLocations | undefined;
    set internalValue(value: DataGoogleStorageControlFolderIntelligenceConfigFilterExcludedCloudStorageLocations | undefined);
    get locations(): string[];
}
export declare class DataGoogleStorageControlFolderIntelligenceConfigFilterExcludedCloudStorageLocationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlFolderIntelligenceConfigFilterExcludedCloudStorageLocationsOutputReference;
}
export interface DataGoogleStorageControlFolderIntelligenceConfigFilterIncludedCloudStorageBuckets {
}
export declare function dataGoogleStorageControlFolderIntelligenceConfigFilterIncludedCloudStorageBucketsToTerraform(struct?: DataGoogleStorageControlFolderIntelligenceConfigFilterIncludedCloudStorageBuckets): any;
export declare function dataGoogleStorageControlFolderIntelligenceConfigFilterIncludedCloudStorageBucketsToHclTerraform(struct?: DataGoogleStorageControlFolderIntelligenceConfigFilterIncludedCloudStorageBuckets): any;
export declare class DataGoogleStorageControlFolderIntelligenceConfigFilterIncludedCloudStorageBucketsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlFolderIntelligenceConfigFilterIncludedCloudStorageBuckets | undefined;
    set internalValue(value: DataGoogleStorageControlFolderIntelligenceConfigFilterIncludedCloudStorageBuckets | undefined);
    get bucketIdRegexes(): string[];
}
export declare class DataGoogleStorageControlFolderIntelligenceConfigFilterIncludedCloudStorageBucketsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlFolderIntelligenceConfigFilterIncludedCloudStorageBucketsOutputReference;
}
export interface DataGoogleStorageControlFolderIntelligenceConfigFilterIncludedCloudStorageLocations {
}
export declare function dataGoogleStorageControlFolderIntelligenceConfigFilterIncludedCloudStorageLocationsToTerraform(struct?: DataGoogleStorageControlFolderIntelligenceConfigFilterIncludedCloudStorageLocations): any;
export declare function dataGoogleStorageControlFolderIntelligenceConfigFilterIncludedCloudStorageLocationsToHclTerraform(struct?: DataGoogleStorageControlFolderIntelligenceConfigFilterIncludedCloudStorageLocations): any;
export declare class DataGoogleStorageControlFolderIntelligenceConfigFilterIncludedCloudStorageLocationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlFolderIntelligenceConfigFilterIncludedCloudStorageLocations | undefined;
    set internalValue(value: DataGoogleStorageControlFolderIntelligenceConfigFilterIncludedCloudStorageLocations | undefined);
    get locations(): string[];
}
export declare class DataGoogleStorageControlFolderIntelligenceConfigFilterIncludedCloudStorageLocationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlFolderIntelligenceConfigFilterIncludedCloudStorageLocationsOutputReference;
}
export interface DataGoogleStorageControlFolderIntelligenceConfigFilter {
}
export declare function dataGoogleStorageControlFolderIntelligenceConfigFilterToTerraform(struct?: DataGoogleStorageControlFolderIntelligenceConfigFilter): any;
export declare function dataGoogleStorageControlFolderIntelligenceConfigFilterToHclTerraform(struct?: DataGoogleStorageControlFolderIntelligenceConfigFilter): any;
export declare class DataGoogleStorageControlFolderIntelligenceConfigFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlFolderIntelligenceConfigFilter | undefined;
    set internalValue(value: DataGoogleStorageControlFolderIntelligenceConfigFilter | undefined);
    private _excludedCloudStorageBuckets;
    get excludedCloudStorageBuckets(): DataGoogleStorageControlFolderIntelligenceConfigFilterExcludedCloudStorageBucketsList;
    private _excludedCloudStorageLocations;
    get excludedCloudStorageLocations(): DataGoogleStorageControlFolderIntelligenceConfigFilterExcludedCloudStorageLocationsList;
    private _includedCloudStorageBuckets;
    get includedCloudStorageBuckets(): DataGoogleStorageControlFolderIntelligenceConfigFilterIncludedCloudStorageBucketsList;
    private _includedCloudStorageLocations;
    get includedCloudStorageLocations(): DataGoogleStorageControlFolderIntelligenceConfigFilterIncludedCloudStorageLocationsList;
}
export declare class DataGoogleStorageControlFolderIntelligenceConfigFilterList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlFolderIntelligenceConfigFilterOutputReference;
}
export interface DataGoogleStorageControlFolderIntelligenceConfigTrialConfig {
}
export declare function dataGoogleStorageControlFolderIntelligenceConfigTrialConfigToTerraform(struct?: DataGoogleStorageControlFolderIntelligenceConfigTrialConfig): any;
export declare function dataGoogleStorageControlFolderIntelligenceConfigTrialConfigToHclTerraform(struct?: DataGoogleStorageControlFolderIntelligenceConfigTrialConfig): any;
export declare class DataGoogleStorageControlFolderIntelligenceConfigTrialConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlFolderIntelligenceConfigTrialConfig | undefined;
    set internalValue(value: DataGoogleStorageControlFolderIntelligenceConfigTrialConfig | undefined);
    get expireTime(): string;
}
export declare class DataGoogleStorageControlFolderIntelligenceConfigTrialConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlFolderIntelligenceConfigTrialConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_storage_control_folder_intelligence_config google_storage_control_folder_intelligence_config}
*/
export declare class DataGoogleStorageControlFolderIntelligenceConfig extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_storage_control_folder_intelligence_config";
    /**
    * Generates CDKTN code for importing a DataGoogleStorageControlFolderIntelligenceConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleStorageControlFolderIntelligenceConfig to import
    * @param importFromId The id of the existing DataGoogleStorageControlFolderIntelligenceConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_storage_control_folder_intelligence_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleStorageControlFolderIntelligenceConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_storage_control_folder_intelligence_config google_storage_control_folder_intelligence_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleStorageControlFolderIntelligenceConfigConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleStorageControlFolderIntelligenceConfigConfig);
    get editionConfig(): string;
    private _effectiveIntelligenceConfig;
    get effectiveIntelligenceConfig(): DataGoogleStorageControlFolderIntelligenceConfigEffectiveIntelligenceConfigList;
    private _filter;
    get filter(): DataGoogleStorageControlFolderIntelligenceConfigFilterList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _trialConfig;
    get trialConfig(): DataGoogleStorageControlFolderIntelligenceConfigTrialConfigList;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
