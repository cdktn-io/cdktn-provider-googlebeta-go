/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleCloudfunctions2FunctionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloudfunctions2_function#id DataGoogleCloudfunctions2Function#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of this cloud function.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloudfunctions2_function#location DataGoogleCloudfunctions2Function#location}
    */
    readonly location: string;
    /**
    * A user-defined name of the function. Function names must
    * be unique globally and match pattern 'projects/* /locations/* /functions/*'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloudfunctions2_function#name DataGoogleCloudfunctions2Function#name}
     *
    * Note: The above comment contained a comment block ending sequence (* followed by /). We have introduced a space between to prevent syntax errors. Please ignore the space.
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloudfunctions2_function#project DataGoogleCloudfunctions2Function#project}
    */
    readonly project?: string;
}
export interface DataGoogleCloudfunctions2FunctionBuildConfigAutomaticUpdatePolicy {
}
export declare function dataGoogleCloudfunctions2FunctionBuildConfigAutomaticUpdatePolicyToTerraform(struct?: DataGoogleCloudfunctions2FunctionBuildConfigAutomaticUpdatePolicy): any;
export declare function dataGoogleCloudfunctions2FunctionBuildConfigAutomaticUpdatePolicyToHclTerraform(struct?: DataGoogleCloudfunctions2FunctionBuildConfigAutomaticUpdatePolicy): any;
export declare class DataGoogleCloudfunctions2FunctionBuildConfigAutomaticUpdatePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudfunctions2FunctionBuildConfigAutomaticUpdatePolicy | undefined;
    set internalValue(value: DataGoogleCloudfunctions2FunctionBuildConfigAutomaticUpdatePolicy | undefined);
}
export declare class DataGoogleCloudfunctions2FunctionBuildConfigAutomaticUpdatePolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudfunctions2FunctionBuildConfigAutomaticUpdatePolicyOutputReference;
}
export interface DataGoogleCloudfunctions2FunctionBuildConfigOnDeployUpdatePolicy {
}
export declare function dataGoogleCloudfunctions2FunctionBuildConfigOnDeployUpdatePolicyToTerraform(struct?: DataGoogleCloudfunctions2FunctionBuildConfigOnDeployUpdatePolicy): any;
export declare function dataGoogleCloudfunctions2FunctionBuildConfigOnDeployUpdatePolicyToHclTerraform(struct?: DataGoogleCloudfunctions2FunctionBuildConfigOnDeployUpdatePolicy): any;
export declare class DataGoogleCloudfunctions2FunctionBuildConfigOnDeployUpdatePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudfunctions2FunctionBuildConfigOnDeployUpdatePolicy | undefined;
    set internalValue(value: DataGoogleCloudfunctions2FunctionBuildConfigOnDeployUpdatePolicy | undefined);
    get runtimeVersion(): string;
}
export declare class DataGoogleCloudfunctions2FunctionBuildConfigOnDeployUpdatePolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudfunctions2FunctionBuildConfigOnDeployUpdatePolicyOutputReference;
}
export interface DataGoogleCloudfunctions2FunctionBuildConfigSourceRepoSource {
}
export declare function dataGoogleCloudfunctions2FunctionBuildConfigSourceRepoSourceToTerraform(struct?: DataGoogleCloudfunctions2FunctionBuildConfigSourceRepoSource): any;
export declare function dataGoogleCloudfunctions2FunctionBuildConfigSourceRepoSourceToHclTerraform(struct?: DataGoogleCloudfunctions2FunctionBuildConfigSourceRepoSource): any;
export declare class DataGoogleCloudfunctions2FunctionBuildConfigSourceRepoSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudfunctions2FunctionBuildConfigSourceRepoSource | undefined;
    set internalValue(value: DataGoogleCloudfunctions2FunctionBuildConfigSourceRepoSource | undefined);
    get branchName(): string;
    get commitSha(): string;
    get dir(): string;
    get invertRegex(): cdktn.IResolvable;
    get projectId(): string;
    get repoName(): string;
    get tagName(): string;
}
export declare class DataGoogleCloudfunctions2FunctionBuildConfigSourceRepoSourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudfunctions2FunctionBuildConfigSourceRepoSourceOutputReference;
}
export interface DataGoogleCloudfunctions2FunctionBuildConfigSourceStorageSource {
}
export declare function dataGoogleCloudfunctions2FunctionBuildConfigSourceStorageSourceToTerraform(struct?: DataGoogleCloudfunctions2FunctionBuildConfigSourceStorageSource): any;
export declare function dataGoogleCloudfunctions2FunctionBuildConfigSourceStorageSourceToHclTerraform(struct?: DataGoogleCloudfunctions2FunctionBuildConfigSourceStorageSource): any;
export declare class DataGoogleCloudfunctions2FunctionBuildConfigSourceStorageSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudfunctions2FunctionBuildConfigSourceStorageSource | undefined;
    set internalValue(value: DataGoogleCloudfunctions2FunctionBuildConfigSourceStorageSource | undefined);
    get bucket(): string;
    get generation(): number;
    get object(): string;
}
export declare class DataGoogleCloudfunctions2FunctionBuildConfigSourceStorageSourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudfunctions2FunctionBuildConfigSourceStorageSourceOutputReference;
}
export interface DataGoogleCloudfunctions2FunctionBuildConfigSource {
}
export declare function dataGoogleCloudfunctions2FunctionBuildConfigSourceToTerraform(struct?: DataGoogleCloudfunctions2FunctionBuildConfigSource): any;
export declare function dataGoogleCloudfunctions2FunctionBuildConfigSourceToHclTerraform(struct?: DataGoogleCloudfunctions2FunctionBuildConfigSource): any;
export declare class DataGoogleCloudfunctions2FunctionBuildConfigSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudfunctions2FunctionBuildConfigSource | undefined;
    set internalValue(value: DataGoogleCloudfunctions2FunctionBuildConfigSource | undefined);
    private _repoSource;
    get repoSource(): DataGoogleCloudfunctions2FunctionBuildConfigSourceRepoSourceList;
    private _storageSource;
    get storageSource(): DataGoogleCloudfunctions2FunctionBuildConfigSourceStorageSourceList;
}
export declare class DataGoogleCloudfunctions2FunctionBuildConfigSourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudfunctions2FunctionBuildConfigSourceOutputReference;
}
export interface DataGoogleCloudfunctions2FunctionBuildConfig {
}
export declare function dataGoogleCloudfunctions2FunctionBuildConfigToTerraform(struct?: DataGoogleCloudfunctions2FunctionBuildConfig): any;
export declare function dataGoogleCloudfunctions2FunctionBuildConfigToHclTerraform(struct?: DataGoogleCloudfunctions2FunctionBuildConfig): any;
export declare class DataGoogleCloudfunctions2FunctionBuildConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudfunctions2FunctionBuildConfig | undefined;
    set internalValue(value: DataGoogleCloudfunctions2FunctionBuildConfig | undefined);
    private _automaticUpdatePolicy;
    get automaticUpdatePolicy(): DataGoogleCloudfunctions2FunctionBuildConfigAutomaticUpdatePolicyList;
    get buildAttribute(): string;
    get dockerRepository(): string;
    get entryPoint(): string;
    private _environmentVariables;
    get environmentVariables(): cdktn.StringMap;
    private _onDeployUpdatePolicy;
    get onDeployUpdatePolicy(): DataGoogleCloudfunctions2FunctionBuildConfigOnDeployUpdatePolicyList;
    get runtime(): string;
    get serviceAccount(): string;
    private _source;
    get source(): DataGoogleCloudfunctions2FunctionBuildConfigSourceList;
    get workerPool(): string;
}
export declare class DataGoogleCloudfunctions2FunctionBuildConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudfunctions2FunctionBuildConfigOutputReference;
}
export interface DataGoogleCloudfunctions2FunctionEventTriggerEventFilters {
}
export declare function dataGoogleCloudfunctions2FunctionEventTriggerEventFiltersToTerraform(struct?: DataGoogleCloudfunctions2FunctionEventTriggerEventFilters): any;
export declare function dataGoogleCloudfunctions2FunctionEventTriggerEventFiltersToHclTerraform(struct?: DataGoogleCloudfunctions2FunctionEventTriggerEventFilters): any;
export declare class DataGoogleCloudfunctions2FunctionEventTriggerEventFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudfunctions2FunctionEventTriggerEventFilters | undefined;
    set internalValue(value: DataGoogleCloudfunctions2FunctionEventTriggerEventFilters | undefined);
    get attribute(): string;
    get operator(): string;
    get value(): string;
}
export declare class DataGoogleCloudfunctions2FunctionEventTriggerEventFiltersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudfunctions2FunctionEventTriggerEventFiltersOutputReference;
}
export interface DataGoogleCloudfunctions2FunctionEventTrigger {
}
export declare function dataGoogleCloudfunctions2FunctionEventTriggerToTerraform(struct?: DataGoogleCloudfunctions2FunctionEventTrigger): any;
export declare function dataGoogleCloudfunctions2FunctionEventTriggerToHclTerraform(struct?: DataGoogleCloudfunctions2FunctionEventTrigger): any;
export declare class DataGoogleCloudfunctions2FunctionEventTriggerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudfunctions2FunctionEventTrigger | undefined;
    set internalValue(value: DataGoogleCloudfunctions2FunctionEventTrigger | undefined);
    private _eventFilters;
    get eventFilters(): DataGoogleCloudfunctions2FunctionEventTriggerEventFiltersList;
    get eventType(): string;
    get pubsubTopic(): string;
    get retryPolicy(): string;
    get serviceAccountEmail(): string;
    get trigger(): string;
    get triggerRegion(): string;
}
export declare class DataGoogleCloudfunctions2FunctionEventTriggerList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudfunctions2FunctionEventTriggerOutputReference;
}
export interface DataGoogleCloudfunctions2FunctionServiceConfigDirectVpcNetworkInterface {
}
export declare function dataGoogleCloudfunctions2FunctionServiceConfigDirectVpcNetworkInterfaceToTerraform(struct?: DataGoogleCloudfunctions2FunctionServiceConfigDirectVpcNetworkInterface): any;
export declare function dataGoogleCloudfunctions2FunctionServiceConfigDirectVpcNetworkInterfaceToHclTerraform(struct?: DataGoogleCloudfunctions2FunctionServiceConfigDirectVpcNetworkInterface): any;
export declare class DataGoogleCloudfunctions2FunctionServiceConfigDirectVpcNetworkInterfaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudfunctions2FunctionServiceConfigDirectVpcNetworkInterface | undefined;
    set internalValue(value: DataGoogleCloudfunctions2FunctionServiceConfigDirectVpcNetworkInterface | undefined);
    get network(): string;
    get subnetwork(): string;
    get tags(): string[];
}
export declare class DataGoogleCloudfunctions2FunctionServiceConfigDirectVpcNetworkInterfaceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudfunctions2FunctionServiceConfigDirectVpcNetworkInterfaceOutputReference;
}
export interface DataGoogleCloudfunctions2FunctionServiceConfigSecretEnvironmentVariables {
}
export declare function dataGoogleCloudfunctions2FunctionServiceConfigSecretEnvironmentVariablesToTerraform(struct?: DataGoogleCloudfunctions2FunctionServiceConfigSecretEnvironmentVariables): any;
export declare function dataGoogleCloudfunctions2FunctionServiceConfigSecretEnvironmentVariablesToHclTerraform(struct?: DataGoogleCloudfunctions2FunctionServiceConfigSecretEnvironmentVariables): any;
export declare class DataGoogleCloudfunctions2FunctionServiceConfigSecretEnvironmentVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudfunctions2FunctionServiceConfigSecretEnvironmentVariables | undefined;
    set internalValue(value: DataGoogleCloudfunctions2FunctionServiceConfigSecretEnvironmentVariables | undefined);
    get key(): string;
    get projectId(): string;
    get secret(): string;
    get version(): string;
}
export declare class DataGoogleCloudfunctions2FunctionServiceConfigSecretEnvironmentVariablesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudfunctions2FunctionServiceConfigSecretEnvironmentVariablesOutputReference;
}
export interface DataGoogleCloudfunctions2FunctionServiceConfigSecretVolumesVersions {
}
export declare function dataGoogleCloudfunctions2FunctionServiceConfigSecretVolumesVersionsToTerraform(struct?: DataGoogleCloudfunctions2FunctionServiceConfigSecretVolumesVersions): any;
export declare function dataGoogleCloudfunctions2FunctionServiceConfigSecretVolumesVersionsToHclTerraform(struct?: DataGoogleCloudfunctions2FunctionServiceConfigSecretVolumesVersions): any;
export declare class DataGoogleCloudfunctions2FunctionServiceConfigSecretVolumesVersionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudfunctions2FunctionServiceConfigSecretVolumesVersions | undefined;
    set internalValue(value: DataGoogleCloudfunctions2FunctionServiceConfigSecretVolumesVersions | undefined);
    get path(): string;
    get version(): string;
}
export declare class DataGoogleCloudfunctions2FunctionServiceConfigSecretVolumesVersionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudfunctions2FunctionServiceConfigSecretVolumesVersionsOutputReference;
}
export interface DataGoogleCloudfunctions2FunctionServiceConfigSecretVolumes {
}
export declare function dataGoogleCloudfunctions2FunctionServiceConfigSecretVolumesToTerraform(struct?: DataGoogleCloudfunctions2FunctionServiceConfigSecretVolumes): any;
export declare function dataGoogleCloudfunctions2FunctionServiceConfigSecretVolumesToHclTerraform(struct?: DataGoogleCloudfunctions2FunctionServiceConfigSecretVolumes): any;
export declare class DataGoogleCloudfunctions2FunctionServiceConfigSecretVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudfunctions2FunctionServiceConfigSecretVolumes | undefined;
    set internalValue(value: DataGoogleCloudfunctions2FunctionServiceConfigSecretVolumes | undefined);
    get mountPath(): string;
    get projectId(): string;
    get secret(): string;
    private _versions;
    get versions(): DataGoogleCloudfunctions2FunctionServiceConfigSecretVolumesVersionsList;
}
export declare class DataGoogleCloudfunctions2FunctionServiceConfigSecretVolumesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudfunctions2FunctionServiceConfigSecretVolumesOutputReference;
}
export interface DataGoogleCloudfunctions2FunctionServiceConfig {
}
export declare function dataGoogleCloudfunctions2FunctionServiceConfigToTerraform(struct?: DataGoogleCloudfunctions2FunctionServiceConfig): any;
export declare function dataGoogleCloudfunctions2FunctionServiceConfigToHclTerraform(struct?: DataGoogleCloudfunctions2FunctionServiceConfig): any;
export declare class DataGoogleCloudfunctions2FunctionServiceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudfunctions2FunctionServiceConfig | undefined;
    set internalValue(value: DataGoogleCloudfunctions2FunctionServiceConfig | undefined);
    get allTrafficOnLatestRevision(): cdktn.IResolvable;
    get availableCpu(): string;
    get availableMemory(): string;
    get binaryAuthorizationPolicy(): string;
    get directVpcEgress(): string;
    private _directVpcNetworkInterface;
    get directVpcNetworkInterface(): DataGoogleCloudfunctions2FunctionServiceConfigDirectVpcNetworkInterfaceList;
    private _environmentVariables;
    get environmentVariables(): cdktn.StringMap;
    get gcfUri(): string;
    get ingressSettings(): string;
    get maxInstanceCount(): number;
    get maxInstanceRequestConcurrency(): number;
    get minInstanceCount(): number;
    private _secretEnvironmentVariables;
    get secretEnvironmentVariables(): DataGoogleCloudfunctions2FunctionServiceConfigSecretEnvironmentVariablesList;
    private _secretVolumes;
    get secretVolumes(): DataGoogleCloudfunctions2FunctionServiceConfigSecretVolumesList;
    get service(): string;
    get serviceAccountEmail(): string;
    get timeoutSeconds(): number;
    get uri(): string;
    get vpcConnector(): string;
    get vpcConnectorEgressSettings(): string;
}
export declare class DataGoogleCloudfunctions2FunctionServiceConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudfunctions2FunctionServiceConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloudfunctions2_function google_cloudfunctions2_function}
*/
export declare class DataGoogleCloudfunctions2Function extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_cloudfunctions2_function";
    /**
    * Generates CDKTN code for importing a DataGoogleCloudfunctions2Function resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleCloudfunctions2Function to import
    * @param importFromId The id of the existing DataGoogleCloudfunctions2Function that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloudfunctions2_function#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleCloudfunctions2Function to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloudfunctions2_function google_cloudfunctions2_function} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleCloudfunctions2FunctionConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleCloudfunctions2FunctionConfig);
    private _buildConfig;
    get buildConfig(): DataGoogleCloudfunctions2FunctionBuildConfigList;
    get deletionPolicy(): string;
    get description(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get environment(): string;
    private _eventTrigger;
    get eventTrigger(): DataGoogleCloudfunctions2FunctionEventTriggerList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get kmsKeyName(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _serviceConfig;
    get serviceConfig(): DataGoogleCloudfunctions2FunctionServiceConfigList;
    get state(): string;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get updateTime(): string;
    get url(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
