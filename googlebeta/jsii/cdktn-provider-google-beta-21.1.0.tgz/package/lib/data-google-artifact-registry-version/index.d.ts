/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleArtifactRegistryVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_version#id DataGoogleArtifactRegistryVersion#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_version#location DataGoogleArtifactRegistryVersion#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_version#package_name DataGoogleArtifactRegistryVersion#package_name}
    */
    readonly packageName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_version#project DataGoogleArtifactRegistryVersion#project}
    */
    readonly project?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_version#repository_id DataGoogleArtifactRegistryVersion#repository_id}
    */
    readonly repositoryId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_version#version_name DataGoogleArtifactRegistryVersion#version_name}
    */
    readonly versionName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_version#view DataGoogleArtifactRegistryVersion#view}
    */
    readonly view?: string;
}
export interface DataGoogleArtifactRegistryVersionRelatedTags {
}
export declare function dataGoogleArtifactRegistryVersionRelatedTagsToTerraform(struct?: DataGoogleArtifactRegistryVersionRelatedTags): any;
export declare function dataGoogleArtifactRegistryVersionRelatedTagsToHclTerraform(struct?: DataGoogleArtifactRegistryVersionRelatedTags): any;
export declare class DataGoogleArtifactRegistryVersionRelatedTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleArtifactRegistryVersionRelatedTags | undefined;
    set internalValue(value: DataGoogleArtifactRegistryVersionRelatedTags | undefined);
    get name(): string;
    get version(): string;
}
export declare class DataGoogleArtifactRegistryVersionRelatedTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleArtifactRegistryVersionRelatedTagsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_version google_artifact_registry_version}
*/
export declare class DataGoogleArtifactRegistryVersion extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_artifact_registry_version";
    /**
    * Generates CDKTN code for importing a DataGoogleArtifactRegistryVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleArtifactRegistryVersion to import
    * @param importFromId The id of the existing DataGoogleArtifactRegistryVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleArtifactRegistryVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_version google_artifact_registry_version} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleArtifactRegistryVersionConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleArtifactRegistryVersionConfig);
    private _annotations;
    get annotations(): cdktn.StringMap;
    get createTime(): string;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _packageName?;
    get packageName(): string;
    set packageName(value: string);
    get packageNameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _relatedTags;
    get relatedTags(): DataGoogleArtifactRegistryVersionRelatedTagsList;
    private _repositoryId?;
    get repositoryId(): string;
    set repositoryId(value: string);
    get repositoryIdInput(): string | undefined;
    get updateTime(): string;
    private _versionName?;
    get versionName(): string;
    set versionName(value: string);
    get versionNameInput(): string | undefined;
    private _view?;
    get view(): string;
    set view(value: string);
    resetView(): void;
    get viewInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
