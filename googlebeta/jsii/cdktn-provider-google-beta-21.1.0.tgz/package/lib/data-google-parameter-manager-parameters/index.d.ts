/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleParameterManagerParametersConfig extends cdktn.TerraformMetaArguments {
    /**
    * Filter string, adhering to the rules in List-operation filtering. List only parameters matching the filter.
    * If filter is empty, all parameters are listed.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_parameter_manager_parameters#filter DataGoogleParameterManagerParameters#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_parameter_manager_parameters#id DataGoogleParameterManagerParameters#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_parameter_manager_parameters#project DataGoogleParameterManagerParameters#project}
    */
    readonly project?: string;
}
export interface DataGoogleParameterManagerParametersParametersPolicyMember {
}
export declare function dataGoogleParameterManagerParametersParametersPolicyMemberToTerraform(struct?: DataGoogleParameterManagerParametersParametersPolicyMember): any;
export declare function dataGoogleParameterManagerParametersParametersPolicyMemberToHclTerraform(struct?: DataGoogleParameterManagerParametersParametersPolicyMember): any;
export declare class DataGoogleParameterManagerParametersParametersPolicyMemberOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleParameterManagerParametersParametersPolicyMember | undefined;
    set internalValue(value: DataGoogleParameterManagerParametersParametersPolicyMember | undefined);
    get iamPolicyNamePrincipal(): string;
    get iamPolicyUidPrincipal(): string;
}
export declare class DataGoogleParameterManagerParametersParametersPolicyMemberList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleParameterManagerParametersParametersPolicyMemberOutputReference;
}
export interface DataGoogleParameterManagerParametersParameters {
}
export declare function dataGoogleParameterManagerParametersParametersToTerraform(struct?: DataGoogleParameterManagerParametersParameters): any;
export declare function dataGoogleParameterManagerParametersParametersToHclTerraform(struct?: DataGoogleParameterManagerParametersParameters): any;
export declare class DataGoogleParameterManagerParametersParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleParameterManagerParametersParameters | undefined;
    set internalValue(value: DataGoogleParameterManagerParametersParameters | undefined);
    get createTime(): string;
    get deletionPolicy(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get format(): string;
    get kmsKey(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    get name(): string;
    get parameterId(): string;
    private _policyMember;
    get policyMember(): DataGoogleParameterManagerParametersParametersPolicyMemberList;
    get project(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get updateTime(): string;
}
export declare class DataGoogleParameterManagerParametersParametersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleParameterManagerParametersParametersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_parameter_manager_parameters google_parameter_manager_parameters}
*/
export declare class DataGoogleParameterManagerParameters extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_parameter_manager_parameters";
    /**
    * Generates CDKTN code for importing a DataGoogleParameterManagerParameters resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleParameterManagerParameters to import
    * @param importFromId The id of the existing DataGoogleParameterManagerParameters that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_parameter_manager_parameters#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleParameterManagerParameters to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_parameter_manager_parameters google_parameter_manager_parameters} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleParameterManagerParametersConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGoogleParameterManagerParametersConfig);
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _parameters;
    get parameters(): DataGoogleParameterManagerParametersParametersList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
