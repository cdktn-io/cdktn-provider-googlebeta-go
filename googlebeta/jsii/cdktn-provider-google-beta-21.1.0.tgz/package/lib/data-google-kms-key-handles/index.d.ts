/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleKmsKeyHandlesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_key_handles#id DataGoogleKmsKeyHandles#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The canonical id for the location. For example: "us-east1".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_key_handles#location DataGoogleKmsKeyHandles#location}
    */
    readonly location: string;
    /**
    * Project ID of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_key_handles#project DataGoogleKmsKeyHandles#project}
    */
    readonly project?: string;
    /**
    *
    * 					The resource_type_selector argument is used to add a filter query parameter that limits which key handles are retrieved by the data source: ?filter=resource_type_selector="{{resource_type_selector}}".
    * 					Example values:
    * 					* resource_type_selector="{SERVICE}.googleapis.com/{TYPE}".
    * 					[See the documentation about using filters](https://cloud.google.com/kms/docs/reference/rest/v1/projects.locations.keyHandles/list)
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_key_handles#resource_type_selector DataGoogleKmsKeyHandles#resource_type_selector}
    */
    readonly resourceTypeSelector: string;
}
export interface DataGoogleKmsKeyHandlesKeyHandles {
}
export declare function dataGoogleKmsKeyHandlesKeyHandlesToTerraform(struct?: DataGoogleKmsKeyHandlesKeyHandles): any;
export declare function dataGoogleKmsKeyHandlesKeyHandlesToHclTerraform(struct?: DataGoogleKmsKeyHandlesKeyHandles): any;
export declare class DataGoogleKmsKeyHandlesKeyHandlesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleKmsKeyHandlesKeyHandles | undefined;
    set internalValue(value: DataGoogleKmsKeyHandlesKeyHandles | undefined);
    get kmsKey(): string;
    get name(): string;
    get resourceTypeSelector(): string;
}
export declare class DataGoogleKmsKeyHandlesKeyHandlesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleKmsKeyHandlesKeyHandlesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_key_handles google_kms_key_handles}
*/
export declare class DataGoogleKmsKeyHandles extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_kms_key_handles";
    /**
    * Generates CDKTN code for importing a DataGoogleKmsKeyHandles resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleKmsKeyHandles to import
    * @param importFromId The id of the existing DataGoogleKmsKeyHandles that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_key_handles#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleKmsKeyHandles to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_key_handles google_kms_key_handles} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleKmsKeyHandlesConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleKmsKeyHandlesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keyHandles;
    get keyHandles(): DataGoogleKmsKeyHandlesKeyHandlesList;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _resourceTypeSelector?;
    get resourceTypeSelector(): string;
    set resourceTypeSelector(value: string);
    get resourceTypeSelectorInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
