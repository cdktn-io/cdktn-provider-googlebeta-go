/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleComputeStoragePoolTypesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_storage_pool_types#project DataGoogleComputeStoragePoolTypes#project}
    */
    readonly project?: string;
    /**
    * Name of the storage pool type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_storage_pool_types#storage_pool_type DataGoogleComputeStoragePoolTypes#storage_pool_type}
    */
    readonly storagePoolType: string;
    /**
    * The name of the zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_storage_pool_types#zone DataGoogleComputeStoragePoolTypes#zone}
    */
    readonly zone: string;
}
export interface DataGoogleComputeStoragePoolTypesDeprecated {
}
export declare function dataGoogleComputeStoragePoolTypesDeprecatedToTerraform(struct?: DataGoogleComputeStoragePoolTypesDeprecated): any;
export declare function dataGoogleComputeStoragePoolTypesDeprecatedToHclTerraform(struct?: DataGoogleComputeStoragePoolTypesDeprecated): any;
export declare class DataGoogleComputeStoragePoolTypesDeprecatedOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeStoragePoolTypesDeprecated | undefined;
    set internalValue(value: DataGoogleComputeStoragePoolTypesDeprecated | undefined);
    get deleted(): string;
    get deprecated(): string;
    get obsolete(): string;
    get replacement(): string;
    get state(): string;
}
export declare class DataGoogleComputeStoragePoolTypesDeprecatedList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeStoragePoolTypesDeprecatedOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_storage_pool_types google_compute_storage_pool_types}
*/
export declare class DataGoogleComputeStoragePoolTypes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_compute_storage_pool_types";
    /**
    * Generates CDKTN code for importing a DataGoogleComputeStoragePoolTypes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleComputeStoragePoolTypes to import
    * @param importFromId The id of the existing DataGoogleComputeStoragePoolTypes that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_storage_pool_types#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleComputeStoragePoolTypes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_storage_pool_types google_compute_storage_pool_types} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleComputeStoragePoolTypesConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleComputeStoragePoolTypesConfig);
    get creationTimestamp(): string;
    private _deprecated;
    get deprecated(): DataGoogleComputeStoragePoolTypesDeprecatedList;
    get description(): string;
    get id(): number;
    get kind(): string;
    get maxPoolProvisionedCapacityGb(): number;
    get maxPoolProvisionedIops(): number;
    get maxPoolProvisionedThroughput(): number;
    get minPoolProvisionedCapacityGb(): number;
    get minPoolProvisionedIops(): number;
    get minPoolProvisionedThroughput(): number;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get selfLink(): string;
    get selfLinkWithId(): string;
    private _storagePoolType?;
    get storagePoolType(): string;
    set storagePoolType(value: string);
    get storagePoolTypeInput(): string | undefined;
    get supportedDiskTypes(): string[];
    private _zone?;
    get zone(): string;
    set zone(value: string);
    get zoneInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
