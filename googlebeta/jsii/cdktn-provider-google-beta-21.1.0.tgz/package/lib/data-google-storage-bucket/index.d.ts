/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleStorageBucketConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_storage_bucket#id DataGoogleStorageBucket#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_storage_bucket#name DataGoogleStorageBucket#name}
    */
    readonly name: string;
    /**
    * The ID of the project in which the resource belongs. If it is not provided, the provider project is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_storage_bucket#project DataGoogleStorageBucket#project}
    */
    readonly project?: string;
}
export interface DataGoogleStorageBucketAutoclass {
}
export declare function dataGoogleStorageBucketAutoclassToTerraform(struct?: DataGoogleStorageBucketAutoclass): any;
export declare function dataGoogleStorageBucketAutoclassToHclTerraform(struct?: DataGoogleStorageBucketAutoclass): any;
export declare class DataGoogleStorageBucketAutoclassOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageBucketAutoclass | undefined;
    set internalValue(value: DataGoogleStorageBucketAutoclass | undefined);
    get enabled(): cdktn.IResolvable;
    get terminalStorageClass(): string;
}
export declare class DataGoogleStorageBucketAutoclassList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageBucketAutoclassOutputReference;
}
export interface DataGoogleStorageBucketCors {
}
export declare function dataGoogleStorageBucketCorsToTerraform(struct?: DataGoogleStorageBucketCors): any;
export declare function dataGoogleStorageBucketCorsToHclTerraform(struct?: DataGoogleStorageBucketCors): any;
export declare class DataGoogleStorageBucketCorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageBucketCors | undefined;
    set internalValue(value: DataGoogleStorageBucketCors | undefined);
    get maxAgeSeconds(): number;
    get method(): string[];
    get origin(): string[];
    get responseHeader(): string[];
}
export declare class DataGoogleStorageBucketCorsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageBucketCorsOutputReference;
}
export interface DataGoogleStorageBucketCustomPlacementConfig {
}
export declare function dataGoogleStorageBucketCustomPlacementConfigToTerraform(struct?: DataGoogleStorageBucketCustomPlacementConfig): any;
export declare function dataGoogleStorageBucketCustomPlacementConfigToHclTerraform(struct?: DataGoogleStorageBucketCustomPlacementConfig): any;
export declare class DataGoogleStorageBucketCustomPlacementConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageBucketCustomPlacementConfig | undefined;
    set internalValue(value: DataGoogleStorageBucketCustomPlacementConfig | undefined);
    get dataLocations(): string[];
}
export declare class DataGoogleStorageBucketCustomPlacementConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageBucketCustomPlacementConfigOutputReference;
}
export interface DataGoogleStorageBucketEncryptionCustomerManagedEncryptionEnforcementConfig {
}
export declare function dataGoogleStorageBucketEncryptionCustomerManagedEncryptionEnforcementConfigToTerraform(struct?: DataGoogleStorageBucketEncryptionCustomerManagedEncryptionEnforcementConfig): any;
export declare function dataGoogleStorageBucketEncryptionCustomerManagedEncryptionEnforcementConfigToHclTerraform(struct?: DataGoogleStorageBucketEncryptionCustomerManagedEncryptionEnforcementConfig): any;
export declare class DataGoogleStorageBucketEncryptionCustomerManagedEncryptionEnforcementConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageBucketEncryptionCustomerManagedEncryptionEnforcementConfig | undefined;
    set internalValue(value: DataGoogleStorageBucketEncryptionCustomerManagedEncryptionEnforcementConfig | undefined);
    get effectiveTime(): string;
    get restrictionMode(): string;
}
export declare class DataGoogleStorageBucketEncryptionCustomerManagedEncryptionEnforcementConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageBucketEncryptionCustomerManagedEncryptionEnforcementConfigOutputReference;
}
export interface DataGoogleStorageBucketEncryptionCustomerSuppliedEncryptionEnforcementConfig {
}
export declare function dataGoogleStorageBucketEncryptionCustomerSuppliedEncryptionEnforcementConfigToTerraform(struct?: DataGoogleStorageBucketEncryptionCustomerSuppliedEncryptionEnforcementConfig): any;
export declare function dataGoogleStorageBucketEncryptionCustomerSuppliedEncryptionEnforcementConfigToHclTerraform(struct?: DataGoogleStorageBucketEncryptionCustomerSuppliedEncryptionEnforcementConfig): any;
export declare class DataGoogleStorageBucketEncryptionCustomerSuppliedEncryptionEnforcementConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageBucketEncryptionCustomerSuppliedEncryptionEnforcementConfig | undefined;
    set internalValue(value: DataGoogleStorageBucketEncryptionCustomerSuppliedEncryptionEnforcementConfig | undefined);
    get effectiveTime(): string;
    get restrictionMode(): string;
}
export declare class DataGoogleStorageBucketEncryptionCustomerSuppliedEncryptionEnforcementConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageBucketEncryptionCustomerSuppliedEncryptionEnforcementConfigOutputReference;
}
export interface DataGoogleStorageBucketEncryptionGoogleManagedEncryptionEnforcementConfig {
}
export declare function dataGoogleStorageBucketEncryptionGoogleManagedEncryptionEnforcementConfigToTerraform(struct?: DataGoogleStorageBucketEncryptionGoogleManagedEncryptionEnforcementConfig): any;
export declare function dataGoogleStorageBucketEncryptionGoogleManagedEncryptionEnforcementConfigToHclTerraform(struct?: DataGoogleStorageBucketEncryptionGoogleManagedEncryptionEnforcementConfig): any;
export declare class DataGoogleStorageBucketEncryptionGoogleManagedEncryptionEnforcementConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageBucketEncryptionGoogleManagedEncryptionEnforcementConfig | undefined;
    set internalValue(value: DataGoogleStorageBucketEncryptionGoogleManagedEncryptionEnforcementConfig | undefined);
    get effectiveTime(): string;
    get restrictionMode(): string;
}
export declare class DataGoogleStorageBucketEncryptionGoogleManagedEncryptionEnforcementConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageBucketEncryptionGoogleManagedEncryptionEnforcementConfigOutputReference;
}
export interface DataGoogleStorageBucketEncryption {
}
export declare function dataGoogleStorageBucketEncryptionToTerraform(struct?: DataGoogleStorageBucketEncryption): any;
export declare function dataGoogleStorageBucketEncryptionToHclTerraform(struct?: DataGoogleStorageBucketEncryption): any;
export declare class DataGoogleStorageBucketEncryptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageBucketEncryption | undefined;
    set internalValue(value: DataGoogleStorageBucketEncryption | undefined);
    private _customerManagedEncryptionEnforcementConfig;
    get customerManagedEncryptionEnforcementConfig(): DataGoogleStorageBucketEncryptionCustomerManagedEncryptionEnforcementConfigList;
    private _customerSuppliedEncryptionEnforcementConfig;
    get customerSuppliedEncryptionEnforcementConfig(): DataGoogleStorageBucketEncryptionCustomerSuppliedEncryptionEnforcementConfigList;
    get defaultKmsKeyName(): string;
    private _googleManagedEncryptionEnforcementConfig;
    get googleManagedEncryptionEnforcementConfig(): DataGoogleStorageBucketEncryptionGoogleManagedEncryptionEnforcementConfigList;
}
export declare class DataGoogleStorageBucketEncryptionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageBucketEncryptionOutputReference;
}
export interface DataGoogleStorageBucketHierarchicalNamespace {
}
export declare function dataGoogleStorageBucketHierarchicalNamespaceToTerraform(struct?: DataGoogleStorageBucketHierarchicalNamespace): any;
export declare function dataGoogleStorageBucketHierarchicalNamespaceToHclTerraform(struct?: DataGoogleStorageBucketHierarchicalNamespace): any;
export declare class DataGoogleStorageBucketHierarchicalNamespaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageBucketHierarchicalNamespace | undefined;
    set internalValue(value: DataGoogleStorageBucketHierarchicalNamespace | undefined);
    get enabled(): cdktn.IResolvable;
}
export declare class DataGoogleStorageBucketHierarchicalNamespaceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageBucketHierarchicalNamespaceOutputReference;
}
export interface DataGoogleStorageBucketIpFilterPublicNetworkSource {
}
export declare function dataGoogleStorageBucketIpFilterPublicNetworkSourceToTerraform(struct?: DataGoogleStorageBucketIpFilterPublicNetworkSource): any;
export declare function dataGoogleStorageBucketIpFilterPublicNetworkSourceToHclTerraform(struct?: DataGoogleStorageBucketIpFilterPublicNetworkSource): any;
export declare class DataGoogleStorageBucketIpFilterPublicNetworkSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageBucketIpFilterPublicNetworkSource | undefined;
    set internalValue(value: DataGoogleStorageBucketIpFilterPublicNetworkSource | undefined);
    get allowedIpCidrRanges(): string[];
}
export declare class DataGoogleStorageBucketIpFilterPublicNetworkSourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageBucketIpFilterPublicNetworkSourceOutputReference;
}
export interface DataGoogleStorageBucketIpFilterVpcNetworkSources {
}
export declare function dataGoogleStorageBucketIpFilterVpcNetworkSourcesToTerraform(struct?: DataGoogleStorageBucketIpFilterVpcNetworkSources): any;
export declare function dataGoogleStorageBucketIpFilterVpcNetworkSourcesToHclTerraform(struct?: DataGoogleStorageBucketIpFilterVpcNetworkSources): any;
export declare class DataGoogleStorageBucketIpFilterVpcNetworkSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageBucketIpFilterVpcNetworkSources | undefined;
    set internalValue(value: DataGoogleStorageBucketIpFilterVpcNetworkSources | undefined);
    get allowedIpCidrRanges(): string[];
    get network(): string;
}
export declare class DataGoogleStorageBucketIpFilterVpcNetworkSourcesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageBucketIpFilterVpcNetworkSourcesOutputReference;
}
export interface DataGoogleStorageBucketIpFilter {
}
export declare function dataGoogleStorageBucketIpFilterToTerraform(struct?: DataGoogleStorageBucketIpFilter): any;
export declare function dataGoogleStorageBucketIpFilterToHclTerraform(struct?: DataGoogleStorageBucketIpFilter): any;
export declare class DataGoogleStorageBucketIpFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageBucketIpFilter | undefined;
    set internalValue(value: DataGoogleStorageBucketIpFilter | undefined);
    get allowAllServiceAgentAccess(): cdktn.IResolvable;
    get allowCrossOrgVpcs(): cdktn.IResolvable;
    get mode(): string;
    private _publicNetworkSource;
    get publicNetworkSource(): DataGoogleStorageBucketIpFilterPublicNetworkSourceList;
    private _vpcNetworkSources;
    get vpcNetworkSources(): DataGoogleStorageBucketIpFilterVpcNetworkSourcesList;
}
export declare class DataGoogleStorageBucketIpFilterList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageBucketIpFilterOutputReference;
}
export interface DataGoogleStorageBucketLifecycleRuleAction {
}
export declare function dataGoogleStorageBucketLifecycleRuleActionToTerraform(struct?: DataGoogleStorageBucketLifecycleRuleAction): any;
export declare function dataGoogleStorageBucketLifecycleRuleActionToHclTerraform(struct?: DataGoogleStorageBucketLifecycleRuleAction): any;
export declare class DataGoogleStorageBucketLifecycleRuleActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageBucketLifecycleRuleAction | undefined;
    set internalValue(value: DataGoogleStorageBucketLifecycleRuleAction | undefined);
    get storageClass(): string;
    get type(): string;
}
export declare class DataGoogleStorageBucketLifecycleRuleActionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageBucketLifecycleRuleActionOutputReference;
}
export interface DataGoogleStorageBucketLifecycleRuleCondition {
}
export declare function dataGoogleStorageBucketLifecycleRuleConditionToTerraform(struct?: DataGoogleStorageBucketLifecycleRuleCondition): any;
export declare function dataGoogleStorageBucketLifecycleRuleConditionToHclTerraform(struct?: DataGoogleStorageBucketLifecycleRuleCondition): any;
export declare class DataGoogleStorageBucketLifecycleRuleConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageBucketLifecycleRuleCondition | undefined;
    set internalValue(value: DataGoogleStorageBucketLifecycleRuleCondition | undefined);
    get age(): number;
    get createdBefore(): string;
    get customTimeBefore(): string;
    get daysSinceCustomTime(): number;
    get daysSinceNoncurrentTime(): number;
    get matchesPrefix(): string[];
    get matchesStorageClass(): string[];
    get matchesSuffix(): string[];
    get noncurrentTimeBefore(): string;
    get numNewerVersions(): number;
    get sendAgeIfZero(): cdktn.IResolvable;
    get sendDaysSinceCustomTimeIfZero(): cdktn.IResolvable;
    get sendDaysSinceNoncurrentTimeIfZero(): cdktn.IResolvable;
    get sendNumNewerVersionsIfZero(): cdktn.IResolvable;
    get sizeAboveBytes(): number;
    get sizeBelowBytes(): number;
    get withState(): string;
}
export declare class DataGoogleStorageBucketLifecycleRuleConditionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageBucketLifecycleRuleConditionOutputReference;
}
export interface DataGoogleStorageBucketLifecycleRule {
}
export declare function dataGoogleStorageBucketLifecycleRuleToTerraform(struct?: DataGoogleStorageBucketLifecycleRule): any;
export declare function dataGoogleStorageBucketLifecycleRuleToHclTerraform(struct?: DataGoogleStorageBucketLifecycleRule): any;
export declare class DataGoogleStorageBucketLifecycleRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageBucketLifecycleRule | undefined;
    set internalValue(value: DataGoogleStorageBucketLifecycleRule | undefined);
    private _action;
    get action(): DataGoogleStorageBucketLifecycleRuleActionList;
    private _condition;
    get condition(): DataGoogleStorageBucketLifecycleRuleConditionList;
}
export declare class DataGoogleStorageBucketLifecycleRuleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageBucketLifecycleRuleOutputReference;
}
export interface DataGoogleStorageBucketLogging {
}
export declare function dataGoogleStorageBucketLoggingToTerraform(struct?: DataGoogleStorageBucketLogging): any;
export declare function dataGoogleStorageBucketLoggingToHclTerraform(struct?: DataGoogleStorageBucketLogging): any;
export declare class DataGoogleStorageBucketLoggingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageBucketLogging | undefined;
    set internalValue(value: DataGoogleStorageBucketLogging | undefined);
    get logBucket(): string;
    get logObjectPrefix(): string;
}
export declare class DataGoogleStorageBucketLoggingList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageBucketLoggingOutputReference;
}
export interface DataGoogleStorageBucketRetentionPolicy {
}
export declare function dataGoogleStorageBucketRetentionPolicyToTerraform(struct?: DataGoogleStorageBucketRetentionPolicy): any;
export declare function dataGoogleStorageBucketRetentionPolicyToHclTerraform(struct?: DataGoogleStorageBucketRetentionPolicy): any;
export declare class DataGoogleStorageBucketRetentionPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageBucketRetentionPolicy | undefined;
    set internalValue(value: DataGoogleStorageBucketRetentionPolicy | undefined);
    get isLocked(): cdktn.IResolvable;
    get retentionPeriod(): string;
}
export declare class DataGoogleStorageBucketRetentionPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageBucketRetentionPolicyOutputReference;
}
export interface DataGoogleStorageBucketSoftDeletePolicy {
}
export declare function dataGoogleStorageBucketSoftDeletePolicyToTerraform(struct?: DataGoogleStorageBucketSoftDeletePolicy): any;
export declare function dataGoogleStorageBucketSoftDeletePolicyToHclTerraform(struct?: DataGoogleStorageBucketSoftDeletePolicy): any;
export declare class DataGoogleStorageBucketSoftDeletePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageBucketSoftDeletePolicy | undefined;
    set internalValue(value: DataGoogleStorageBucketSoftDeletePolicy | undefined);
    get effectiveTime(): string;
    get retentionDurationSeconds(): number;
}
export declare class DataGoogleStorageBucketSoftDeletePolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageBucketSoftDeletePolicyOutputReference;
}
export interface DataGoogleStorageBucketVersioning {
}
export declare function dataGoogleStorageBucketVersioningToTerraform(struct?: DataGoogleStorageBucketVersioning): any;
export declare function dataGoogleStorageBucketVersioningToHclTerraform(struct?: DataGoogleStorageBucketVersioning): any;
export declare class DataGoogleStorageBucketVersioningOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageBucketVersioning | undefined;
    set internalValue(value: DataGoogleStorageBucketVersioning | undefined);
    get enabled(): cdktn.IResolvable;
}
export declare class DataGoogleStorageBucketVersioningList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageBucketVersioningOutputReference;
}
export interface DataGoogleStorageBucketWebsite {
}
export declare function dataGoogleStorageBucketWebsiteToTerraform(struct?: DataGoogleStorageBucketWebsite): any;
export declare function dataGoogleStorageBucketWebsiteToHclTerraform(struct?: DataGoogleStorageBucketWebsite): any;
export declare class DataGoogleStorageBucketWebsiteOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageBucketWebsite | undefined;
    set internalValue(value: DataGoogleStorageBucketWebsite | undefined);
    get mainPageSuffix(): string;
    get notFoundPage(): string;
}
export declare class DataGoogleStorageBucketWebsiteList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageBucketWebsiteOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_storage_bucket google_storage_bucket}
*/
export declare class DataGoogleStorageBucket extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_storage_bucket";
    /**
    * Generates CDKTN code for importing a DataGoogleStorageBucket resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleStorageBucket to import
    * @param importFromId The id of the existing DataGoogleStorageBucket that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_storage_bucket#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleStorageBucket to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_storage_bucket google_storage_bucket} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleStorageBucketConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleStorageBucketConfig);
    private _autoclass;
    get autoclass(): DataGoogleStorageBucketAutoclassList;
    private _cors;
    get cors(): DataGoogleStorageBucketCorsList;
    private _customPlacementConfig;
    get customPlacementConfig(): DataGoogleStorageBucketCustomPlacementConfigList;
    get defaultEventBasedHold(): cdktn.IResolvable;
    get deletionPolicy(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get enableObjectRetention(): cdktn.IResolvable;
    private _encryption;
    get encryption(): DataGoogleStorageBucketEncryptionList;
    get forceDestroy(): cdktn.IResolvable;
    private _hierarchicalNamespace;
    get hierarchicalNamespace(): DataGoogleStorageBucketHierarchicalNamespaceList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ipFilter;
    get ipFilter(): DataGoogleStorageBucketIpFilterList;
    private _labels;
    get labels(): cdktn.StringMap;
    private _lifecycleRule;
    get lifecycleRule(): DataGoogleStorageBucketLifecycleRuleList;
    get location(): string;
    private _logging;
    get logging(): DataGoogleStorageBucketLoggingList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get projectNumber(): number;
    get publicAccessPrevention(): string;
    get requesterPays(): cdktn.IResolvable;
    private _retentionPolicy;
    get retentionPolicy(): DataGoogleStorageBucketRetentionPolicyList;
    get rpo(): string;
    get selfLink(): string;
    private _softDeletePolicy;
    get softDeletePolicy(): DataGoogleStorageBucketSoftDeletePolicyList;
    get storageClass(): string;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get timeCreated(): string;
    get uniformBucketLevelAccess(): cdktn.IResolvable;
    get updated(): string;
    get url(): string;
    private _versioning;
    get versioning(): DataGoogleStorageBucketVersioningList;
    private _website;
    get website(): DataGoogleStorageBucketWebsiteList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
