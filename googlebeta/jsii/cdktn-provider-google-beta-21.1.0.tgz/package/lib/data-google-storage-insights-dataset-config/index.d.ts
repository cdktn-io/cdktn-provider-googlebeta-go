/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleStorageInsightsDatasetConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * The user-defined ID of the DatasetConfig
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_storage_insights_dataset_config#dataset_config_id DataGoogleStorageInsightsDatasetConfig#dataset_config_id}
    */
    readonly datasetConfigId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_storage_insights_dataset_config#id DataGoogleStorageInsightsDatasetConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the DatasetConfig.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_storage_insights_dataset_config#location DataGoogleStorageInsightsDatasetConfig#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_storage_insights_dataset_config#project DataGoogleStorageInsightsDatasetConfig#project}
    */
    readonly project?: string;
}
export interface DataGoogleStorageInsightsDatasetConfigExcludeCloudStorageBucketsCloudStorageBuckets {
}
export declare function dataGoogleStorageInsightsDatasetConfigExcludeCloudStorageBucketsCloudStorageBucketsToTerraform(struct?: DataGoogleStorageInsightsDatasetConfigExcludeCloudStorageBucketsCloudStorageBuckets): any;
export declare function dataGoogleStorageInsightsDatasetConfigExcludeCloudStorageBucketsCloudStorageBucketsToHclTerraform(struct?: DataGoogleStorageInsightsDatasetConfigExcludeCloudStorageBucketsCloudStorageBuckets): any;
export declare class DataGoogleStorageInsightsDatasetConfigExcludeCloudStorageBucketsCloudStorageBucketsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageInsightsDatasetConfigExcludeCloudStorageBucketsCloudStorageBuckets | undefined;
    set internalValue(value: DataGoogleStorageInsightsDatasetConfigExcludeCloudStorageBucketsCloudStorageBuckets | undefined);
    get bucketName(): string;
    get bucketPrefixRegex(): string;
}
export declare class DataGoogleStorageInsightsDatasetConfigExcludeCloudStorageBucketsCloudStorageBucketsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageInsightsDatasetConfigExcludeCloudStorageBucketsCloudStorageBucketsOutputReference;
}
export interface DataGoogleStorageInsightsDatasetConfigExcludeCloudStorageBuckets {
}
export declare function dataGoogleStorageInsightsDatasetConfigExcludeCloudStorageBucketsToTerraform(struct?: DataGoogleStorageInsightsDatasetConfigExcludeCloudStorageBuckets): any;
export declare function dataGoogleStorageInsightsDatasetConfigExcludeCloudStorageBucketsToHclTerraform(struct?: DataGoogleStorageInsightsDatasetConfigExcludeCloudStorageBuckets): any;
export declare class DataGoogleStorageInsightsDatasetConfigExcludeCloudStorageBucketsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageInsightsDatasetConfigExcludeCloudStorageBuckets | undefined;
    set internalValue(value: DataGoogleStorageInsightsDatasetConfigExcludeCloudStorageBuckets | undefined);
    private _cloudStorageBuckets;
    get cloudStorageBuckets(): DataGoogleStorageInsightsDatasetConfigExcludeCloudStorageBucketsCloudStorageBucketsList;
}
export declare class DataGoogleStorageInsightsDatasetConfigExcludeCloudStorageBucketsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageInsightsDatasetConfigExcludeCloudStorageBucketsOutputReference;
}
export interface DataGoogleStorageInsightsDatasetConfigExcludeCloudStorageLocations {
}
export declare function dataGoogleStorageInsightsDatasetConfigExcludeCloudStorageLocationsToTerraform(struct?: DataGoogleStorageInsightsDatasetConfigExcludeCloudStorageLocations): any;
export declare function dataGoogleStorageInsightsDatasetConfigExcludeCloudStorageLocationsToHclTerraform(struct?: DataGoogleStorageInsightsDatasetConfigExcludeCloudStorageLocations): any;
export declare class DataGoogleStorageInsightsDatasetConfigExcludeCloudStorageLocationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageInsightsDatasetConfigExcludeCloudStorageLocations | undefined;
    set internalValue(value: DataGoogleStorageInsightsDatasetConfigExcludeCloudStorageLocations | undefined);
    get locations(): string[];
}
export declare class DataGoogleStorageInsightsDatasetConfigExcludeCloudStorageLocationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageInsightsDatasetConfigExcludeCloudStorageLocationsOutputReference;
}
export interface DataGoogleStorageInsightsDatasetConfigIdentity {
}
export declare function dataGoogleStorageInsightsDatasetConfigIdentityToTerraform(struct?: DataGoogleStorageInsightsDatasetConfigIdentity): any;
export declare function dataGoogleStorageInsightsDatasetConfigIdentityToHclTerraform(struct?: DataGoogleStorageInsightsDatasetConfigIdentity): any;
export declare class DataGoogleStorageInsightsDatasetConfigIdentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageInsightsDatasetConfigIdentity | undefined;
    set internalValue(value: DataGoogleStorageInsightsDatasetConfigIdentity | undefined);
    get name(): string;
    get type(): string;
}
export declare class DataGoogleStorageInsightsDatasetConfigIdentityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageInsightsDatasetConfigIdentityOutputReference;
}
export interface DataGoogleStorageInsightsDatasetConfigIncludeCloudStorageBucketsCloudStorageBuckets {
}
export declare function dataGoogleStorageInsightsDatasetConfigIncludeCloudStorageBucketsCloudStorageBucketsToTerraform(struct?: DataGoogleStorageInsightsDatasetConfigIncludeCloudStorageBucketsCloudStorageBuckets): any;
export declare function dataGoogleStorageInsightsDatasetConfigIncludeCloudStorageBucketsCloudStorageBucketsToHclTerraform(struct?: DataGoogleStorageInsightsDatasetConfigIncludeCloudStorageBucketsCloudStorageBuckets): any;
export declare class DataGoogleStorageInsightsDatasetConfigIncludeCloudStorageBucketsCloudStorageBucketsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageInsightsDatasetConfigIncludeCloudStorageBucketsCloudStorageBuckets | undefined;
    set internalValue(value: DataGoogleStorageInsightsDatasetConfigIncludeCloudStorageBucketsCloudStorageBuckets | undefined);
    get bucketName(): string;
    get bucketPrefixRegex(): string;
}
export declare class DataGoogleStorageInsightsDatasetConfigIncludeCloudStorageBucketsCloudStorageBucketsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageInsightsDatasetConfigIncludeCloudStorageBucketsCloudStorageBucketsOutputReference;
}
export interface DataGoogleStorageInsightsDatasetConfigIncludeCloudStorageBuckets {
}
export declare function dataGoogleStorageInsightsDatasetConfigIncludeCloudStorageBucketsToTerraform(struct?: DataGoogleStorageInsightsDatasetConfigIncludeCloudStorageBuckets): any;
export declare function dataGoogleStorageInsightsDatasetConfigIncludeCloudStorageBucketsToHclTerraform(struct?: DataGoogleStorageInsightsDatasetConfigIncludeCloudStorageBuckets): any;
export declare class DataGoogleStorageInsightsDatasetConfigIncludeCloudStorageBucketsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageInsightsDatasetConfigIncludeCloudStorageBuckets | undefined;
    set internalValue(value: DataGoogleStorageInsightsDatasetConfigIncludeCloudStorageBuckets | undefined);
    private _cloudStorageBuckets;
    get cloudStorageBuckets(): DataGoogleStorageInsightsDatasetConfigIncludeCloudStorageBucketsCloudStorageBucketsList;
}
export declare class DataGoogleStorageInsightsDatasetConfigIncludeCloudStorageBucketsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageInsightsDatasetConfigIncludeCloudStorageBucketsOutputReference;
}
export interface DataGoogleStorageInsightsDatasetConfigIncludeCloudStorageLocations {
}
export declare function dataGoogleStorageInsightsDatasetConfigIncludeCloudStorageLocationsToTerraform(struct?: DataGoogleStorageInsightsDatasetConfigIncludeCloudStorageLocations): any;
export declare function dataGoogleStorageInsightsDatasetConfigIncludeCloudStorageLocationsToHclTerraform(struct?: DataGoogleStorageInsightsDatasetConfigIncludeCloudStorageLocations): any;
export declare class DataGoogleStorageInsightsDatasetConfigIncludeCloudStorageLocationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageInsightsDatasetConfigIncludeCloudStorageLocations | undefined;
    set internalValue(value: DataGoogleStorageInsightsDatasetConfigIncludeCloudStorageLocations | undefined);
    get locations(): string[];
}
export declare class DataGoogleStorageInsightsDatasetConfigIncludeCloudStorageLocationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageInsightsDatasetConfigIncludeCloudStorageLocationsOutputReference;
}
export interface DataGoogleStorageInsightsDatasetConfigLink {
}
export declare function dataGoogleStorageInsightsDatasetConfigLinkToTerraform(struct?: DataGoogleStorageInsightsDatasetConfigLink): any;
export declare function dataGoogleStorageInsightsDatasetConfigLinkToHclTerraform(struct?: DataGoogleStorageInsightsDatasetConfigLink): any;
export declare class DataGoogleStorageInsightsDatasetConfigLinkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageInsightsDatasetConfigLink | undefined;
    set internalValue(value: DataGoogleStorageInsightsDatasetConfigLink | undefined);
    get dataset(): string;
    get linked(): cdktn.IResolvable;
}
export declare class DataGoogleStorageInsightsDatasetConfigLinkList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageInsightsDatasetConfigLinkOutputReference;
}
export interface DataGoogleStorageInsightsDatasetConfigSourceFolders {
}
export declare function dataGoogleStorageInsightsDatasetConfigSourceFoldersToTerraform(struct?: DataGoogleStorageInsightsDatasetConfigSourceFolders): any;
export declare function dataGoogleStorageInsightsDatasetConfigSourceFoldersToHclTerraform(struct?: DataGoogleStorageInsightsDatasetConfigSourceFolders): any;
export declare class DataGoogleStorageInsightsDatasetConfigSourceFoldersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageInsightsDatasetConfigSourceFolders | undefined;
    set internalValue(value: DataGoogleStorageInsightsDatasetConfigSourceFolders | undefined);
    get folderNumbers(): string[];
}
export declare class DataGoogleStorageInsightsDatasetConfigSourceFoldersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageInsightsDatasetConfigSourceFoldersOutputReference;
}
export interface DataGoogleStorageInsightsDatasetConfigSourceProjects {
}
export declare function dataGoogleStorageInsightsDatasetConfigSourceProjectsToTerraform(struct?: DataGoogleStorageInsightsDatasetConfigSourceProjects): any;
export declare function dataGoogleStorageInsightsDatasetConfigSourceProjectsToHclTerraform(struct?: DataGoogleStorageInsightsDatasetConfigSourceProjects): any;
export declare class DataGoogleStorageInsightsDatasetConfigSourceProjectsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageInsightsDatasetConfigSourceProjects | undefined;
    set internalValue(value: DataGoogleStorageInsightsDatasetConfigSourceProjects | undefined);
    get projectNumbers(): string[];
}
export declare class DataGoogleStorageInsightsDatasetConfigSourceProjectsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageInsightsDatasetConfigSourceProjectsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_storage_insights_dataset_config google_storage_insights_dataset_config}
*/
export declare class DataGoogleStorageInsightsDatasetConfig extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_storage_insights_dataset_config";
    /**
    * Generates CDKTN code for importing a DataGoogleStorageInsightsDatasetConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleStorageInsightsDatasetConfig to import
    * @param importFromId The id of the existing DataGoogleStorageInsightsDatasetConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_storage_insights_dataset_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleStorageInsightsDatasetConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_storage_insights_dataset_config google_storage_insights_dataset_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleStorageInsightsDatasetConfigConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleStorageInsightsDatasetConfigConfig);
    get activityDataRetentionPeriodDays(): number;
    get createTime(): string;
    private _datasetConfigId?;
    get datasetConfigId(): string;
    set datasetConfigId(value: string);
    get datasetConfigIdInput(): string | undefined;
    get datasetConfigState(): string;
    get deletionPolicy(): string;
    get description(): string;
    private _excludeCloudStorageBuckets;
    get excludeCloudStorageBuckets(): DataGoogleStorageInsightsDatasetConfigExcludeCloudStorageBucketsList;
    private _excludeCloudStorageLocations;
    get excludeCloudStorageLocations(): DataGoogleStorageInsightsDatasetConfigExcludeCloudStorageLocationsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identity;
    get identity(): DataGoogleStorageInsightsDatasetConfigIdentityList;
    private _includeCloudStorageBuckets;
    get includeCloudStorageBuckets(): DataGoogleStorageInsightsDatasetConfigIncludeCloudStorageBucketsList;
    private _includeCloudStorageLocations;
    get includeCloudStorageLocations(): DataGoogleStorageInsightsDatasetConfigIncludeCloudStorageLocationsList;
    get includeNewlyCreatedBuckets(): cdktn.IResolvable;
    private _link;
    get link(): DataGoogleStorageInsightsDatasetConfigLinkList;
    get linkDataset(): cdktn.IResolvable;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    get organizationNumber(): string;
    get organizationScope(): cdktn.IResolvable;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get retentionPeriodDays(): number;
    private _sourceFolders;
    get sourceFolders(): DataGoogleStorageInsightsDatasetConfigSourceFoldersList;
    private _sourceProjects;
    get sourceProjects(): DataGoogleStorageInsightsDatasetConfigSourceProjectsList;
    get uid(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
