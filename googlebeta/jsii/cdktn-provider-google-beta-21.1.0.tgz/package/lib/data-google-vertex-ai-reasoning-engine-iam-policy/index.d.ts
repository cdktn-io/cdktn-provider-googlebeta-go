/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleVertexAiReasoningEngineIamPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vertex_ai_reasoning_engine_iam_policy#id DataGoogleVertexAiReasoningEngineIamPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vertex_ai_reasoning_engine_iam_policy#project DataGoogleVertexAiReasoningEngineIamPolicy#project}
    */
    readonly project?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vertex_ai_reasoning_engine_iam_policy#reasoning_engine DataGoogleVertexAiReasoningEngineIamPolicy#reasoning_engine}
    */
    readonly reasoningEngine: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vertex_ai_reasoning_engine_iam_policy#region DataGoogleVertexAiReasoningEngineIamPolicy#region}
    */
    readonly region?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vertex_ai_reasoning_engine_iam_policy google_vertex_ai_reasoning_engine_iam_policy}
*/
export declare class DataGoogleVertexAiReasoningEngineIamPolicy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_vertex_ai_reasoning_engine_iam_policy";
    /**
    * Generates CDKTN code for importing a DataGoogleVertexAiReasoningEngineIamPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleVertexAiReasoningEngineIamPolicy to import
    * @param importFromId The id of the existing DataGoogleVertexAiReasoningEngineIamPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vertex_ai_reasoning_engine_iam_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleVertexAiReasoningEngineIamPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vertex_ai_reasoning_engine_iam_policy google_vertex_ai_reasoning_engine_iam_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleVertexAiReasoningEngineIamPolicyConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleVertexAiReasoningEngineIamPolicyConfig);
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get policyData(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _reasoningEngine?;
    get reasoningEngine(): string;
    set reasoningEngine(value: string);
    get reasoningEngineInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
