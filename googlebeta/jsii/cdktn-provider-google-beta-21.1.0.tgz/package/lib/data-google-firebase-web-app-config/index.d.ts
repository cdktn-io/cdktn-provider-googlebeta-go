/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleFirebaseWebAppConfigAConfig extends cdktn.TerraformMetaArguments {
    /**
    * The project id of the Firebase web App.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_firebase_web_app_config#project DataGoogleFirebaseWebAppConfigA#project}
    */
    readonly project?: string;
    /**
    * The id of the Firebase web App.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_firebase_web_app_config#web_app_id DataGoogleFirebaseWebAppConfigA#web_app_id}
    */
    readonly webAppId: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_firebase_web_app_config google_firebase_web_app_config}
*/
export declare class DataGoogleFirebaseWebAppConfigA extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_firebase_web_app_config";
    /**
    * Generates CDKTN code for importing a DataGoogleFirebaseWebAppConfigA resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleFirebaseWebAppConfigA to import
    * @param importFromId The id of the existing DataGoogleFirebaseWebAppConfigA that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_firebase_web_app_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleFirebaseWebAppConfigA to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_firebase_web_app_config google_firebase_web_app_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleFirebaseWebAppConfigAConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleFirebaseWebAppConfigAConfig);
    get apiKey(): string;
    get authDomain(): string;
    get databaseUrl(): string;
    get id(): string;
    get locationId(): string;
    get measurementId(): string;
    get messagingSenderId(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get storageBucket(): string;
    private _webAppId?;
    get webAppId(): string;
    set webAppId(value: string);
    get webAppIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
