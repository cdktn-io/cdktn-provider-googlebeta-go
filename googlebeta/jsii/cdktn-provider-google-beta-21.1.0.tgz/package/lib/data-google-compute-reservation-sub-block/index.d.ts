/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleComputeReservationSubBlockConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_reservation_sub_block#id DataGoogleComputeReservationSubBlock#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the reservation sub-block.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_reservation_sub_block#name DataGoogleComputeReservationSubBlock#name}
    */
    readonly name: string;
    /**
    * The project in which the resource belongs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_reservation_sub_block#project DataGoogleComputeReservationSubBlock#project}
    */
    readonly project?: string;
    /**
    * The name of the parent reservation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_reservation_sub_block#reservation DataGoogleComputeReservationSubBlock#reservation}
    */
    readonly reservation: string;
    /**
    * The name of the parent reservation block.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_reservation_sub_block#reservation_block DataGoogleComputeReservationSubBlock#reservation_block}
    */
    readonly reservationBlock: string;
    /**
    * The zone where the reservation sub-block resides.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_reservation_sub_block#zone DataGoogleComputeReservationSubBlock#zone}
    */
    readonly zone?: string;
}
export interface DataGoogleComputeReservationSubBlockHealthInfo {
}
export declare function dataGoogleComputeReservationSubBlockHealthInfoToTerraform(struct?: DataGoogleComputeReservationSubBlockHealthInfo): any;
export declare function dataGoogleComputeReservationSubBlockHealthInfoToHclTerraform(struct?: DataGoogleComputeReservationSubBlockHealthInfo): any;
export declare class DataGoogleComputeReservationSubBlockHealthInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeReservationSubBlockHealthInfo | undefined;
    set internalValue(value: DataGoogleComputeReservationSubBlockHealthInfo | undefined);
    get degradedHostCount(): number;
    get degradedInfraCount(): number;
    get healthStatus(): string;
    get healthyHostCount(): number;
    get healthyInfraCount(): number;
}
export declare class DataGoogleComputeReservationSubBlockHealthInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeReservationSubBlockHealthInfoOutputReference;
}
export interface DataGoogleComputeReservationSubBlockPhysicalTopology {
}
export declare function dataGoogleComputeReservationSubBlockPhysicalTopologyToTerraform(struct?: DataGoogleComputeReservationSubBlockPhysicalTopology): any;
export declare function dataGoogleComputeReservationSubBlockPhysicalTopologyToHclTerraform(struct?: DataGoogleComputeReservationSubBlockPhysicalTopology): any;
export declare class DataGoogleComputeReservationSubBlockPhysicalTopologyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeReservationSubBlockPhysicalTopology | undefined;
    set internalValue(value: DataGoogleComputeReservationSubBlockPhysicalTopology | undefined);
    get block(): string;
    get cluster(): string;
    get subBlock(): string;
}
export declare class DataGoogleComputeReservationSubBlockPhysicalTopologyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeReservationSubBlockPhysicalTopologyOutputReference;
}
export interface DataGoogleComputeReservationSubBlockReservationSubBlockMaintenance {
}
export declare function dataGoogleComputeReservationSubBlockReservationSubBlockMaintenanceToTerraform(struct?: DataGoogleComputeReservationSubBlockReservationSubBlockMaintenance): any;
export declare function dataGoogleComputeReservationSubBlockReservationSubBlockMaintenanceToHclTerraform(struct?: DataGoogleComputeReservationSubBlockReservationSubBlockMaintenance): any;
export declare class DataGoogleComputeReservationSubBlockReservationSubBlockMaintenanceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeReservationSubBlockReservationSubBlockMaintenance | undefined;
    set internalValue(value: DataGoogleComputeReservationSubBlockReservationSubBlockMaintenance | undefined);
    get instanceMaintenanceOngoingCount(): number;
    get instanceMaintenancePendingCount(): number;
    get maintenanceOngoingCount(): number;
    get maintenancePendingCount(): number;
    get schedulingType(): string;
    get subblockInfraMaintenanceOngoingCount(): number;
    get subblockInfraMaintenancePendingCount(): number;
}
export declare class DataGoogleComputeReservationSubBlockReservationSubBlockMaintenanceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeReservationSubBlockReservationSubBlockMaintenanceOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_reservation_sub_block google_compute_reservation_sub_block}
*/
export declare class DataGoogleComputeReservationSubBlock extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_compute_reservation_sub_block";
    /**
    * Generates CDKTN code for importing a DataGoogleComputeReservationSubBlock resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleComputeReservationSubBlock to import
    * @param importFromId The id of the existing DataGoogleComputeReservationSubBlock that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_reservation_sub_block#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleComputeReservationSubBlock to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_reservation_sub_block google_compute_reservation_sub_block} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleComputeReservationSubBlockConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleComputeReservationSubBlockConfig);
    get creationTimestamp(): string;
    private _healthInfo;
    get healthInfo(): DataGoogleComputeReservationSubBlockHealthInfoList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get inUseCount(): number;
    get kind(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _physicalTopology;
    get physicalTopology(): DataGoogleComputeReservationSubBlockPhysicalTopologyList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _reservation?;
    get reservation(): string;
    set reservation(value: string);
    get reservationInput(): string | undefined;
    private _reservationBlock?;
    get reservationBlock(): string;
    set reservationBlock(value: string);
    get reservationBlockInput(): string | undefined;
    private _reservationSubBlockMaintenance;
    get reservationSubBlockMaintenance(): DataGoogleComputeReservationSubBlockReservationSubBlockMaintenanceList;
    get resourceId(): string;
    get selfLink(): string;
    get selfLinkWithId(): string;
    get status(): string;
    get subBlockCount(): number;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    resetZone(): void;
    get zoneInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
