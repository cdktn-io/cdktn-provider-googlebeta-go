/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleNetworkServicesGatewayConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_network_services_gateway#id DataGoogleNetworkServicesGateway#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the gateway.
    * The default value is 'global'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_network_services_gateway#location DataGoogleNetworkServicesGateway#location}
    */
    readonly location: string;
    /**
    * Name of the Gateway resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_network_services_gateway#name DataGoogleNetworkServicesGateway#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_network_services_gateway#project DataGoogleNetworkServicesGateway#project}
    */
    readonly project?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_network_services_gateway google_network_services_gateway}
*/
export declare class DataGoogleNetworkServicesGateway extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_network_services_gateway";
    /**
    * Generates CDKTN code for importing a DataGoogleNetworkServicesGateway resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleNetworkServicesGateway to import
    * @param importFromId The id of the existing DataGoogleNetworkServicesGateway that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_network_services_gateway#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleNetworkServicesGateway to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_network_services_gateway google_network_services_gateway} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleNetworkServicesGatewayConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleNetworkServicesGatewayConfig);
    get addresses(): string[];
    get allPorts(): cdktn.IResolvable;
    get allowGlobalAccess(): cdktn.IResolvable;
    get certificateUrls(): string[];
    get createTime(): string;
    get deleteSwgAutogenRouterOnDestroy(): cdktn.IResolvable;
    get deletionPolicy(): string;
    get description(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get envoyHeaders(): string;
    get gatewaySecurityPolicy(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ipVersion(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get network(): string;
    get ports(): number[];
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get routingMode(): string;
    get scope(): string;
    get selfLink(): string;
    get serverTlsPolicy(): string;
    get subnetwork(): string;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get type(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
