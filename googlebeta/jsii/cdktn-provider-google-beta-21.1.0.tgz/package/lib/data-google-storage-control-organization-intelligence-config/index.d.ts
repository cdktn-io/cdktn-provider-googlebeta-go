/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleStorageControlOrganizationIntelligenceConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_storage_control_organization_intelligence_config#id DataGoogleStorageControlOrganizationIntelligenceConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Identifier of the GCP Organization. For GCP org, this field should be organization number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_storage_control_organization_intelligence_config#name DataGoogleStorageControlOrganizationIntelligenceConfig#name}
    */
    readonly name: string;
}
export interface DataGoogleStorageControlOrganizationIntelligenceConfigEffectiveIntelligenceConfig {
}
export declare function dataGoogleStorageControlOrganizationIntelligenceConfigEffectiveIntelligenceConfigToTerraform(struct?: DataGoogleStorageControlOrganizationIntelligenceConfigEffectiveIntelligenceConfig): any;
export declare function dataGoogleStorageControlOrganizationIntelligenceConfigEffectiveIntelligenceConfigToHclTerraform(struct?: DataGoogleStorageControlOrganizationIntelligenceConfigEffectiveIntelligenceConfig): any;
export declare class DataGoogleStorageControlOrganizationIntelligenceConfigEffectiveIntelligenceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlOrganizationIntelligenceConfigEffectiveIntelligenceConfig | undefined;
    set internalValue(value: DataGoogleStorageControlOrganizationIntelligenceConfigEffectiveIntelligenceConfig | undefined);
    get effectiveEdition(): string;
    get intelligenceConfig(): string;
}
export declare class DataGoogleStorageControlOrganizationIntelligenceConfigEffectiveIntelligenceConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlOrganizationIntelligenceConfigEffectiveIntelligenceConfigOutputReference;
}
export interface DataGoogleStorageControlOrganizationIntelligenceConfigFilterExcludedCloudStorageBuckets {
}
export declare function dataGoogleStorageControlOrganizationIntelligenceConfigFilterExcludedCloudStorageBucketsToTerraform(struct?: DataGoogleStorageControlOrganizationIntelligenceConfigFilterExcludedCloudStorageBuckets): any;
export declare function dataGoogleStorageControlOrganizationIntelligenceConfigFilterExcludedCloudStorageBucketsToHclTerraform(struct?: DataGoogleStorageControlOrganizationIntelligenceConfigFilterExcludedCloudStorageBuckets): any;
export declare class DataGoogleStorageControlOrganizationIntelligenceConfigFilterExcludedCloudStorageBucketsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlOrganizationIntelligenceConfigFilterExcludedCloudStorageBuckets | undefined;
    set internalValue(value: DataGoogleStorageControlOrganizationIntelligenceConfigFilterExcludedCloudStorageBuckets | undefined);
    get bucketIdRegexes(): string[];
}
export declare class DataGoogleStorageControlOrganizationIntelligenceConfigFilterExcludedCloudStorageBucketsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlOrganizationIntelligenceConfigFilterExcludedCloudStorageBucketsOutputReference;
}
export interface DataGoogleStorageControlOrganizationIntelligenceConfigFilterExcludedCloudStorageLocations {
}
export declare function dataGoogleStorageControlOrganizationIntelligenceConfigFilterExcludedCloudStorageLocationsToTerraform(struct?: DataGoogleStorageControlOrganizationIntelligenceConfigFilterExcludedCloudStorageLocations): any;
export declare function dataGoogleStorageControlOrganizationIntelligenceConfigFilterExcludedCloudStorageLocationsToHclTerraform(struct?: DataGoogleStorageControlOrganizationIntelligenceConfigFilterExcludedCloudStorageLocations): any;
export declare class DataGoogleStorageControlOrganizationIntelligenceConfigFilterExcludedCloudStorageLocationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlOrganizationIntelligenceConfigFilterExcludedCloudStorageLocations | undefined;
    set internalValue(value: DataGoogleStorageControlOrganizationIntelligenceConfigFilterExcludedCloudStorageLocations | undefined);
    get locations(): string[];
}
export declare class DataGoogleStorageControlOrganizationIntelligenceConfigFilterExcludedCloudStorageLocationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlOrganizationIntelligenceConfigFilterExcludedCloudStorageLocationsOutputReference;
}
export interface DataGoogleStorageControlOrganizationIntelligenceConfigFilterIncludedCloudStorageBuckets {
}
export declare function dataGoogleStorageControlOrganizationIntelligenceConfigFilterIncludedCloudStorageBucketsToTerraform(struct?: DataGoogleStorageControlOrganizationIntelligenceConfigFilterIncludedCloudStorageBuckets): any;
export declare function dataGoogleStorageControlOrganizationIntelligenceConfigFilterIncludedCloudStorageBucketsToHclTerraform(struct?: DataGoogleStorageControlOrganizationIntelligenceConfigFilterIncludedCloudStorageBuckets): any;
export declare class DataGoogleStorageControlOrganizationIntelligenceConfigFilterIncludedCloudStorageBucketsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlOrganizationIntelligenceConfigFilterIncludedCloudStorageBuckets | undefined;
    set internalValue(value: DataGoogleStorageControlOrganizationIntelligenceConfigFilterIncludedCloudStorageBuckets | undefined);
    get bucketIdRegexes(): string[];
}
export declare class DataGoogleStorageControlOrganizationIntelligenceConfigFilterIncludedCloudStorageBucketsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlOrganizationIntelligenceConfigFilterIncludedCloudStorageBucketsOutputReference;
}
export interface DataGoogleStorageControlOrganizationIntelligenceConfigFilterIncludedCloudStorageLocations {
}
export declare function dataGoogleStorageControlOrganizationIntelligenceConfigFilterIncludedCloudStorageLocationsToTerraform(struct?: DataGoogleStorageControlOrganizationIntelligenceConfigFilterIncludedCloudStorageLocations): any;
export declare function dataGoogleStorageControlOrganizationIntelligenceConfigFilterIncludedCloudStorageLocationsToHclTerraform(struct?: DataGoogleStorageControlOrganizationIntelligenceConfigFilterIncludedCloudStorageLocations): any;
export declare class DataGoogleStorageControlOrganizationIntelligenceConfigFilterIncludedCloudStorageLocationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlOrganizationIntelligenceConfigFilterIncludedCloudStorageLocations | undefined;
    set internalValue(value: DataGoogleStorageControlOrganizationIntelligenceConfigFilterIncludedCloudStorageLocations | undefined);
    get locations(): string[];
}
export declare class DataGoogleStorageControlOrganizationIntelligenceConfigFilterIncludedCloudStorageLocationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlOrganizationIntelligenceConfigFilterIncludedCloudStorageLocationsOutputReference;
}
export interface DataGoogleStorageControlOrganizationIntelligenceConfigFilter {
}
export declare function dataGoogleStorageControlOrganizationIntelligenceConfigFilterToTerraform(struct?: DataGoogleStorageControlOrganizationIntelligenceConfigFilter): any;
export declare function dataGoogleStorageControlOrganizationIntelligenceConfigFilterToHclTerraform(struct?: DataGoogleStorageControlOrganizationIntelligenceConfigFilter): any;
export declare class DataGoogleStorageControlOrganizationIntelligenceConfigFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlOrganizationIntelligenceConfigFilter | undefined;
    set internalValue(value: DataGoogleStorageControlOrganizationIntelligenceConfigFilter | undefined);
    private _excludedCloudStorageBuckets;
    get excludedCloudStorageBuckets(): DataGoogleStorageControlOrganizationIntelligenceConfigFilterExcludedCloudStorageBucketsList;
    private _excludedCloudStorageLocations;
    get excludedCloudStorageLocations(): DataGoogleStorageControlOrganizationIntelligenceConfigFilterExcludedCloudStorageLocationsList;
    private _includedCloudStorageBuckets;
    get includedCloudStorageBuckets(): DataGoogleStorageControlOrganizationIntelligenceConfigFilterIncludedCloudStorageBucketsList;
    private _includedCloudStorageLocations;
    get includedCloudStorageLocations(): DataGoogleStorageControlOrganizationIntelligenceConfigFilterIncludedCloudStorageLocationsList;
}
export declare class DataGoogleStorageControlOrganizationIntelligenceConfigFilterList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlOrganizationIntelligenceConfigFilterOutputReference;
}
export interface DataGoogleStorageControlOrganizationIntelligenceConfigTrialConfig {
}
export declare function dataGoogleStorageControlOrganizationIntelligenceConfigTrialConfigToTerraform(struct?: DataGoogleStorageControlOrganizationIntelligenceConfigTrialConfig): any;
export declare function dataGoogleStorageControlOrganizationIntelligenceConfigTrialConfigToHclTerraform(struct?: DataGoogleStorageControlOrganizationIntelligenceConfigTrialConfig): any;
export declare class DataGoogleStorageControlOrganizationIntelligenceConfigTrialConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlOrganizationIntelligenceConfigTrialConfig | undefined;
    set internalValue(value: DataGoogleStorageControlOrganizationIntelligenceConfigTrialConfig | undefined);
    get expireTime(): string;
}
export declare class DataGoogleStorageControlOrganizationIntelligenceConfigTrialConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlOrganizationIntelligenceConfigTrialConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_storage_control_organization_intelligence_config google_storage_control_organization_intelligence_config}
*/
export declare class DataGoogleStorageControlOrganizationIntelligenceConfig extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_storage_control_organization_intelligence_config";
    /**
    * Generates CDKTN code for importing a DataGoogleStorageControlOrganizationIntelligenceConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleStorageControlOrganizationIntelligenceConfig to import
    * @param importFromId The id of the existing DataGoogleStorageControlOrganizationIntelligenceConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_storage_control_organization_intelligence_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleStorageControlOrganizationIntelligenceConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_storage_control_organization_intelligence_config google_storage_control_organization_intelligence_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleStorageControlOrganizationIntelligenceConfigConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleStorageControlOrganizationIntelligenceConfigConfig);
    get editionConfig(): string;
    private _effectiveIntelligenceConfig;
    get effectiveIntelligenceConfig(): DataGoogleStorageControlOrganizationIntelligenceConfigEffectiveIntelligenceConfigList;
    private _filter;
    get filter(): DataGoogleStorageControlOrganizationIntelligenceConfigFilterList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _trialConfig;
    get trialConfig(): DataGoogleStorageControlOrganizationIntelligenceConfigTrialConfigList;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
