/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleComputeInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_instance#id DataGoogleComputeInstance#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the instance. One of name or self_link must be provided.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_instance#name DataGoogleComputeInstance#name}
    */
    readonly name?: string;
    /**
    * The ID of the project in which the resource belongs. If self_link is provided, this value is ignored. If neither self_link nor project are provided, the provider project is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_instance#project DataGoogleComputeInstance#project}
    */
    readonly project?: string;
    /**
    * The URI of the created resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_instance#self_link DataGoogleComputeInstance#self_link}
    */
    readonly selfLink?: string;
    /**
    * The zone of the instance. If self_link is provided, this value is ignored. If neither self_link nor zone are provided, the provider zone is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_instance#zone DataGoogleComputeInstance#zone}
    */
    readonly zone?: string;
}
export interface DataGoogleComputeInstanceAdvancedMachineFeatures {
}
export declare function dataGoogleComputeInstanceAdvancedMachineFeaturesToTerraform(struct?: DataGoogleComputeInstanceAdvancedMachineFeatures): any;
export declare function dataGoogleComputeInstanceAdvancedMachineFeaturesToHclTerraform(struct?: DataGoogleComputeInstanceAdvancedMachineFeatures): any;
export declare class DataGoogleComputeInstanceAdvancedMachineFeaturesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceAdvancedMachineFeatures | undefined;
    set internalValue(value: DataGoogleComputeInstanceAdvancedMachineFeatures | undefined);
    get enableNestedVirtualization(): cdktn.IResolvable;
    get enableUefiNetworking(): cdktn.IResolvable;
    get performanceMonitoringUnit(): string;
    get threadsPerCore(): number;
    get turboMode(): string;
    get visibleCoreCount(): number;
}
export declare class DataGoogleComputeInstanceAdvancedMachineFeaturesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceAdvancedMachineFeaturesOutputReference;
}
export interface DataGoogleComputeInstanceAttachedDisk {
}
export declare function dataGoogleComputeInstanceAttachedDiskToTerraform(struct?: DataGoogleComputeInstanceAttachedDisk): any;
export declare function dataGoogleComputeInstanceAttachedDiskToHclTerraform(struct?: DataGoogleComputeInstanceAttachedDisk): any;
export declare class DataGoogleComputeInstanceAttachedDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceAttachedDisk | undefined;
    set internalValue(value: DataGoogleComputeInstanceAttachedDisk | undefined);
    get deviceName(): string;
    get diskEncryptionKeyRaw(): string;
    get diskEncryptionKeyRsa(): string;
    get diskEncryptionKeySha256(): string;
    get diskEncryptionServiceAccount(): string;
    get forceAttach(): cdktn.IResolvable;
    get kmsKeySelfLink(): string;
    get mode(): string;
    get source(): string;
}
export declare class DataGoogleComputeInstanceAttachedDiskList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceAttachedDiskOutputReference;
}
export interface DataGoogleComputeInstanceBootDiskInitializeParamsSourceImageEncryptionKey {
}
export declare function dataGoogleComputeInstanceBootDiskInitializeParamsSourceImageEncryptionKeyToTerraform(struct?: DataGoogleComputeInstanceBootDiskInitializeParamsSourceImageEncryptionKey): any;
export declare function dataGoogleComputeInstanceBootDiskInitializeParamsSourceImageEncryptionKeyToHclTerraform(struct?: DataGoogleComputeInstanceBootDiskInitializeParamsSourceImageEncryptionKey): any;
export declare class DataGoogleComputeInstanceBootDiskInitializeParamsSourceImageEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceBootDiskInitializeParamsSourceImageEncryptionKey | undefined;
    set internalValue(value: DataGoogleComputeInstanceBootDiskInitializeParamsSourceImageEncryptionKey | undefined);
    get kmsKeySelfLink(): string;
    get kmsKeyServiceAccount(): string;
    get rawKey(): string;
    get rsaEncryptedKey(): string;
    get sha256(): string;
}
export declare class DataGoogleComputeInstanceBootDiskInitializeParamsSourceImageEncryptionKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceBootDiskInitializeParamsSourceImageEncryptionKeyOutputReference;
}
export interface DataGoogleComputeInstanceBootDiskInitializeParamsSourceSnapshotEncryptionKey {
}
export declare function dataGoogleComputeInstanceBootDiskInitializeParamsSourceSnapshotEncryptionKeyToTerraform(struct?: DataGoogleComputeInstanceBootDiskInitializeParamsSourceSnapshotEncryptionKey): any;
export declare function dataGoogleComputeInstanceBootDiskInitializeParamsSourceSnapshotEncryptionKeyToHclTerraform(struct?: DataGoogleComputeInstanceBootDiskInitializeParamsSourceSnapshotEncryptionKey): any;
export declare class DataGoogleComputeInstanceBootDiskInitializeParamsSourceSnapshotEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceBootDiskInitializeParamsSourceSnapshotEncryptionKey | undefined;
    set internalValue(value: DataGoogleComputeInstanceBootDiskInitializeParamsSourceSnapshotEncryptionKey | undefined);
    get kmsKeySelfLink(): string;
    get kmsKeyServiceAccount(): string;
    get rawKey(): string;
    get rsaEncryptedKey(): string;
    get sha256(): string;
}
export declare class DataGoogleComputeInstanceBootDiskInitializeParamsSourceSnapshotEncryptionKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceBootDiskInitializeParamsSourceSnapshotEncryptionKeyOutputReference;
}
export interface DataGoogleComputeInstanceBootDiskInitializeParams {
}
export declare function dataGoogleComputeInstanceBootDiskInitializeParamsToTerraform(struct?: DataGoogleComputeInstanceBootDiskInitializeParams): any;
export declare function dataGoogleComputeInstanceBootDiskInitializeParamsToHclTerraform(struct?: DataGoogleComputeInstanceBootDiskInitializeParams): any;
export declare class DataGoogleComputeInstanceBootDiskInitializeParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceBootDiskInitializeParams | undefined;
    set internalValue(value: DataGoogleComputeInstanceBootDiskInitializeParams | undefined);
    get architecture(): string;
    get enableConfidentialCompute(): cdktn.IResolvable;
    get image(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    get provisionedIops(): number;
    get provisionedThroughput(): number;
    get replicaZones(): string[];
    private _resourceManagerTags;
    get resourceManagerTags(): cdktn.StringMap;
    get resourcePolicies(): string[];
    get size(): number;
    get snapshot(): string;
    private _sourceImageEncryptionKey;
    get sourceImageEncryptionKey(): DataGoogleComputeInstanceBootDiskInitializeParamsSourceImageEncryptionKeyList;
    private _sourceSnapshotEncryptionKey;
    get sourceSnapshotEncryptionKey(): DataGoogleComputeInstanceBootDiskInitializeParamsSourceSnapshotEncryptionKeyList;
    get storagePool(): string;
    get type(): string;
}
export declare class DataGoogleComputeInstanceBootDiskInitializeParamsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceBootDiskInitializeParamsOutputReference;
}
export interface DataGoogleComputeInstanceBootDisk {
}
export declare function dataGoogleComputeInstanceBootDiskToTerraform(struct?: DataGoogleComputeInstanceBootDisk): any;
export declare function dataGoogleComputeInstanceBootDiskToHclTerraform(struct?: DataGoogleComputeInstanceBootDisk): any;
export declare class DataGoogleComputeInstanceBootDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceBootDisk | undefined;
    set internalValue(value: DataGoogleComputeInstanceBootDisk | undefined);
    get autoDelete(): cdktn.IResolvable;
    get deviceName(): string;
    get diskEncryptionKeyRaw(): string;
    get diskEncryptionKeyRsa(): string;
    get diskEncryptionKeySha256(): string;
    get diskEncryptionServiceAccount(): string;
    get forceAttach(): cdktn.IResolvable;
    get guestOsFeatures(): string[];
    private _initializeParams;
    get initializeParams(): DataGoogleComputeInstanceBootDiskInitializeParamsList;
    get interface(): string;
    get kmsKeySelfLink(): string;
    get mode(): string;
    get source(): string;
}
export declare class DataGoogleComputeInstanceBootDiskList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceBootDiskOutputReference;
}
export interface DataGoogleComputeInstanceConfidentialInstanceConfig {
}
export declare function dataGoogleComputeInstanceConfidentialInstanceConfigToTerraform(struct?: DataGoogleComputeInstanceConfidentialInstanceConfig): any;
export declare function dataGoogleComputeInstanceConfidentialInstanceConfigToHclTerraform(struct?: DataGoogleComputeInstanceConfidentialInstanceConfig): any;
export declare class DataGoogleComputeInstanceConfidentialInstanceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceConfidentialInstanceConfig | undefined;
    set internalValue(value: DataGoogleComputeInstanceConfidentialInstanceConfig | undefined);
    get confidentialInstanceType(): string;
    get enableConfidentialCompute(): cdktn.IResolvable;
}
export declare class DataGoogleComputeInstanceConfidentialInstanceConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceConfidentialInstanceConfigOutputReference;
}
export interface DataGoogleComputeInstanceGuestAccelerator {
}
export declare function dataGoogleComputeInstanceGuestAcceleratorToTerraform(struct?: DataGoogleComputeInstanceGuestAccelerator): any;
export declare function dataGoogleComputeInstanceGuestAcceleratorToHclTerraform(struct?: DataGoogleComputeInstanceGuestAccelerator): any;
export declare class DataGoogleComputeInstanceGuestAcceleratorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceGuestAccelerator | undefined;
    set internalValue(value: DataGoogleComputeInstanceGuestAccelerator | undefined);
    get count(): number;
    get type(): string;
}
export declare class DataGoogleComputeInstanceGuestAcceleratorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceGuestAcceleratorOutputReference;
}
export interface DataGoogleComputeInstanceInstanceEncryptionKey {
}
export declare function dataGoogleComputeInstanceInstanceEncryptionKeyToTerraform(struct?: DataGoogleComputeInstanceInstanceEncryptionKey): any;
export declare function dataGoogleComputeInstanceInstanceEncryptionKeyToHclTerraform(struct?: DataGoogleComputeInstanceInstanceEncryptionKey): any;
export declare class DataGoogleComputeInstanceInstanceEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceInstanceEncryptionKey | undefined;
    set internalValue(value: DataGoogleComputeInstanceInstanceEncryptionKey | undefined);
    get kmsKeySelfLink(): string;
    get kmsKeyServiceAccount(): string;
    get sha256(): string;
}
export declare class DataGoogleComputeInstanceInstanceEncryptionKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceInstanceEncryptionKeyOutputReference;
}
export interface DataGoogleComputeInstanceNetworkInterfaceAccessConfig {
}
export declare function dataGoogleComputeInstanceNetworkInterfaceAccessConfigToTerraform(struct?: DataGoogleComputeInstanceNetworkInterfaceAccessConfig): any;
export declare function dataGoogleComputeInstanceNetworkInterfaceAccessConfigToHclTerraform(struct?: DataGoogleComputeInstanceNetworkInterfaceAccessConfig): any;
export declare class DataGoogleComputeInstanceNetworkInterfaceAccessConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceNetworkInterfaceAccessConfig | undefined;
    set internalValue(value: DataGoogleComputeInstanceNetworkInterfaceAccessConfig | undefined);
    get natIp(): string;
    get networkTier(): string;
    get publicPtrDomainName(): string;
    get securityPolicy(): string;
}
export declare class DataGoogleComputeInstanceNetworkInterfaceAccessConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceNetworkInterfaceAccessConfigOutputReference;
}
export interface DataGoogleComputeInstanceNetworkInterfaceAliasIpRange {
}
export declare function dataGoogleComputeInstanceNetworkInterfaceAliasIpRangeToTerraform(struct?: DataGoogleComputeInstanceNetworkInterfaceAliasIpRange): any;
export declare function dataGoogleComputeInstanceNetworkInterfaceAliasIpRangeToHclTerraform(struct?: DataGoogleComputeInstanceNetworkInterfaceAliasIpRange): any;
export declare class DataGoogleComputeInstanceNetworkInterfaceAliasIpRangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceNetworkInterfaceAliasIpRange | undefined;
    set internalValue(value: DataGoogleComputeInstanceNetworkInterfaceAliasIpRange | undefined);
    get ipCidrRange(): string;
    get subnetworkRangeName(): string;
}
export declare class DataGoogleComputeInstanceNetworkInterfaceAliasIpRangeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceNetworkInterfaceAliasIpRangeOutputReference;
}
export interface DataGoogleComputeInstanceNetworkInterfaceAliasIpv6Range {
}
export declare function dataGoogleComputeInstanceNetworkInterfaceAliasIpv6RangeToTerraform(struct?: DataGoogleComputeInstanceNetworkInterfaceAliasIpv6Range): any;
export declare function dataGoogleComputeInstanceNetworkInterfaceAliasIpv6RangeToHclTerraform(struct?: DataGoogleComputeInstanceNetworkInterfaceAliasIpv6Range): any;
export declare class DataGoogleComputeInstanceNetworkInterfaceAliasIpv6RangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceNetworkInterfaceAliasIpv6Range | undefined;
    set internalValue(value: DataGoogleComputeInstanceNetworkInterfaceAliasIpv6Range | undefined);
    get ipCidrRange(): string;
    get subnetworkRangeName(): string;
}
export declare class DataGoogleComputeInstanceNetworkInterfaceAliasIpv6RangeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceNetworkInterfaceAliasIpv6RangeOutputReference;
}
export interface DataGoogleComputeInstanceNetworkInterfaceIpv6AccessConfig {
}
export declare function dataGoogleComputeInstanceNetworkInterfaceIpv6AccessConfigToTerraform(struct?: DataGoogleComputeInstanceNetworkInterfaceIpv6AccessConfig): any;
export declare function dataGoogleComputeInstanceNetworkInterfaceIpv6AccessConfigToHclTerraform(struct?: DataGoogleComputeInstanceNetworkInterfaceIpv6AccessConfig): any;
export declare class DataGoogleComputeInstanceNetworkInterfaceIpv6AccessConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceNetworkInterfaceIpv6AccessConfig | undefined;
    set internalValue(value: DataGoogleComputeInstanceNetworkInterfaceIpv6AccessConfig | undefined);
    get externalIpv6(): string;
    get externalIpv6PrefixLength(): string;
    get name(): string;
    get networkTier(): string;
    get publicPtrDomainName(): string;
    get securityPolicy(): string;
}
export declare class DataGoogleComputeInstanceNetworkInterfaceIpv6AccessConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceNetworkInterfaceIpv6AccessConfigOutputReference;
}
export interface DataGoogleComputeInstanceNetworkInterface {
}
export declare function dataGoogleComputeInstanceNetworkInterfaceToTerraform(struct?: DataGoogleComputeInstanceNetworkInterface): any;
export declare function dataGoogleComputeInstanceNetworkInterfaceToHclTerraform(struct?: DataGoogleComputeInstanceNetworkInterface): any;
export declare class DataGoogleComputeInstanceNetworkInterfaceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceNetworkInterface | undefined;
    set internalValue(value: DataGoogleComputeInstanceNetworkInterface | undefined);
    private _accessConfig;
    get accessConfig(): DataGoogleComputeInstanceNetworkInterfaceAccessConfigList;
    private _aliasIpRange;
    get aliasIpRange(): DataGoogleComputeInstanceNetworkInterfaceAliasIpRangeList;
    private _aliasIpv6Range;
    get aliasIpv6Range(): DataGoogleComputeInstanceNetworkInterfaceAliasIpv6RangeList;
    get enableVpcScopedDns(): cdktn.IResolvable;
    get igmpQuery(): string;
    get internalIpv6PrefixLength(): number;
    private _ipv6AccessConfig;
    get ipv6AccessConfig(): DataGoogleComputeInstanceNetworkInterfaceIpv6AccessConfigList;
    get ipv6AccessType(): string;
    get ipv6Address(): string;
    get macAddress(): string;
    get name(): string;
    get network(): string;
    get networkAttachment(): string;
    get networkIp(): string;
    get nicType(): string;
    get parentNicName(): string;
    get queueCount(): number;
    get securityPolicy(): string;
    get serviceClassId(): string;
    get stackType(): string;
    get subnetwork(): string;
    get subnetworkProject(): string;
    get vlan(): number;
}
export declare class DataGoogleComputeInstanceNetworkInterfaceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceNetworkInterfaceOutputReference;
}
export interface DataGoogleComputeInstanceNetworkPerformanceConfig {
}
export declare function dataGoogleComputeInstanceNetworkPerformanceConfigToTerraform(struct?: DataGoogleComputeInstanceNetworkPerformanceConfig): any;
export declare function dataGoogleComputeInstanceNetworkPerformanceConfigToHclTerraform(struct?: DataGoogleComputeInstanceNetworkPerformanceConfig): any;
export declare class DataGoogleComputeInstanceNetworkPerformanceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceNetworkPerformanceConfig | undefined;
    set internalValue(value: DataGoogleComputeInstanceNetworkPerformanceConfig | undefined);
    get totalEgressBandwidthTier(): string;
}
export declare class DataGoogleComputeInstanceNetworkPerformanceConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceNetworkPerformanceConfigOutputReference;
}
export interface DataGoogleComputeInstanceParams {
}
export declare function dataGoogleComputeInstanceParamsToTerraform(struct?: DataGoogleComputeInstanceParams): any;
export declare function dataGoogleComputeInstanceParamsToHclTerraform(struct?: DataGoogleComputeInstanceParams): any;
export declare class DataGoogleComputeInstanceParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceParams | undefined;
    set internalValue(value: DataGoogleComputeInstanceParams | undefined);
    private _resourceManagerTags;
    get resourceManagerTags(): cdktn.StringMap;
}
export declare class DataGoogleComputeInstanceParamsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceParamsOutputReference;
}
export interface DataGoogleComputeInstanceReservationAffinitySpecificReservation {
}
export declare function dataGoogleComputeInstanceReservationAffinitySpecificReservationToTerraform(struct?: DataGoogleComputeInstanceReservationAffinitySpecificReservation): any;
export declare function dataGoogleComputeInstanceReservationAffinitySpecificReservationToHclTerraform(struct?: DataGoogleComputeInstanceReservationAffinitySpecificReservation): any;
export declare class DataGoogleComputeInstanceReservationAffinitySpecificReservationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceReservationAffinitySpecificReservation | undefined;
    set internalValue(value: DataGoogleComputeInstanceReservationAffinitySpecificReservation | undefined);
    get key(): string;
    get values(): string[];
}
export declare class DataGoogleComputeInstanceReservationAffinitySpecificReservationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceReservationAffinitySpecificReservationOutputReference;
}
export interface DataGoogleComputeInstanceReservationAffinity {
}
export declare function dataGoogleComputeInstanceReservationAffinityToTerraform(struct?: DataGoogleComputeInstanceReservationAffinity): any;
export declare function dataGoogleComputeInstanceReservationAffinityToHclTerraform(struct?: DataGoogleComputeInstanceReservationAffinity): any;
export declare class DataGoogleComputeInstanceReservationAffinityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceReservationAffinity | undefined;
    set internalValue(value: DataGoogleComputeInstanceReservationAffinity | undefined);
    private _specificReservation;
    get specificReservation(): DataGoogleComputeInstanceReservationAffinitySpecificReservationList;
    get type(): string;
}
export declare class DataGoogleComputeInstanceReservationAffinityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceReservationAffinityOutputReference;
}
export interface DataGoogleComputeInstanceSchedulingGracefulShutdownMaxDuration {
}
export declare function dataGoogleComputeInstanceSchedulingGracefulShutdownMaxDurationToTerraform(struct?: DataGoogleComputeInstanceSchedulingGracefulShutdownMaxDuration): any;
export declare function dataGoogleComputeInstanceSchedulingGracefulShutdownMaxDurationToHclTerraform(struct?: DataGoogleComputeInstanceSchedulingGracefulShutdownMaxDuration): any;
export declare class DataGoogleComputeInstanceSchedulingGracefulShutdownMaxDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceSchedulingGracefulShutdownMaxDuration | undefined;
    set internalValue(value: DataGoogleComputeInstanceSchedulingGracefulShutdownMaxDuration | undefined);
    get nanos(): number;
    get seconds(): number;
}
export declare class DataGoogleComputeInstanceSchedulingGracefulShutdownMaxDurationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceSchedulingGracefulShutdownMaxDurationOutputReference;
}
export interface DataGoogleComputeInstanceSchedulingGracefulShutdown {
}
export declare function dataGoogleComputeInstanceSchedulingGracefulShutdownToTerraform(struct?: DataGoogleComputeInstanceSchedulingGracefulShutdown): any;
export declare function dataGoogleComputeInstanceSchedulingGracefulShutdownToHclTerraform(struct?: DataGoogleComputeInstanceSchedulingGracefulShutdown): any;
export declare class DataGoogleComputeInstanceSchedulingGracefulShutdownOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceSchedulingGracefulShutdown | undefined;
    set internalValue(value: DataGoogleComputeInstanceSchedulingGracefulShutdown | undefined);
    get enabled(): cdktn.IResolvable;
    private _maxDuration;
    get maxDuration(): DataGoogleComputeInstanceSchedulingGracefulShutdownMaxDurationList;
}
export declare class DataGoogleComputeInstanceSchedulingGracefulShutdownList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceSchedulingGracefulShutdownOutputReference;
}
export interface DataGoogleComputeInstanceSchedulingLocalSsdRecoveryTimeout {
}
export declare function dataGoogleComputeInstanceSchedulingLocalSsdRecoveryTimeoutToTerraform(struct?: DataGoogleComputeInstanceSchedulingLocalSsdRecoveryTimeout): any;
export declare function dataGoogleComputeInstanceSchedulingLocalSsdRecoveryTimeoutToHclTerraform(struct?: DataGoogleComputeInstanceSchedulingLocalSsdRecoveryTimeout): any;
export declare class DataGoogleComputeInstanceSchedulingLocalSsdRecoveryTimeoutOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceSchedulingLocalSsdRecoveryTimeout | undefined;
    set internalValue(value: DataGoogleComputeInstanceSchedulingLocalSsdRecoveryTimeout | undefined);
    get nanos(): number;
    get seconds(): number;
}
export declare class DataGoogleComputeInstanceSchedulingLocalSsdRecoveryTimeoutList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceSchedulingLocalSsdRecoveryTimeoutOutputReference;
}
export interface DataGoogleComputeInstanceSchedulingMaxRunDuration {
}
export declare function dataGoogleComputeInstanceSchedulingMaxRunDurationToTerraform(struct?: DataGoogleComputeInstanceSchedulingMaxRunDuration): any;
export declare function dataGoogleComputeInstanceSchedulingMaxRunDurationToHclTerraform(struct?: DataGoogleComputeInstanceSchedulingMaxRunDuration): any;
export declare class DataGoogleComputeInstanceSchedulingMaxRunDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceSchedulingMaxRunDuration | undefined;
    set internalValue(value: DataGoogleComputeInstanceSchedulingMaxRunDuration | undefined);
    get nanos(): number;
    get seconds(): number;
}
export declare class DataGoogleComputeInstanceSchedulingMaxRunDurationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceSchedulingMaxRunDurationOutputReference;
}
export interface DataGoogleComputeInstanceSchedulingNodeAffinities {
}
export declare function dataGoogleComputeInstanceSchedulingNodeAffinitiesToTerraform(struct?: DataGoogleComputeInstanceSchedulingNodeAffinities): any;
export declare function dataGoogleComputeInstanceSchedulingNodeAffinitiesToHclTerraform(struct?: DataGoogleComputeInstanceSchedulingNodeAffinities): any;
export declare class DataGoogleComputeInstanceSchedulingNodeAffinitiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceSchedulingNodeAffinities | undefined;
    set internalValue(value: DataGoogleComputeInstanceSchedulingNodeAffinities | undefined);
    get key(): string;
    get operator(): string;
    get values(): string[];
}
export declare class DataGoogleComputeInstanceSchedulingNodeAffinitiesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceSchedulingNodeAffinitiesOutputReference;
}
export interface DataGoogleComputeInstanceSchedulingOnInstanceStopAction {
}
export declare function dataGoogleComputeInstanceSchedulingOnInstanceStopActionToTerraform(struct?: DataGoogleComputeInstanceSchedulingOnInstanceStopAction): any;
export declare function dataGoogleComputeInstanceSchedulingOnInstanceStopActionToHclTerraform(struct?: DataGoogleComputeInstanceSchedulingOnInstanceStopAction): any;
export declare class DataGoogleComputeInstanceSchedulingOnInstanceStopActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceSchedulingOnInstanceStopAction | undefined;
    set internalValue(value: DataGoogleComputeInstanceSchedulingOnInstanceStopAction | undefined);
    get discardLocalSsd(): cdktn.IResolvable;
}
export declare class DataGoogleComputeInstanceSchedulingOnInstanceStopActionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceSchedulingOnInstanceStopActionOutputReference;
}
export interface DataGoogleComputeInstanceSchedulingPreemptionNoticeDuration {
}
export declare function dataGoogleComputeInstanceSchedulingPreemptionNoticeDurationToTerraform(struct?: DataGoogleComputeInstanceSchedulingPreemptionNoticeDuration): any;
export declare function dataGoogleComputeInstanceSchedulingPreemptionNoticeDurationToHclTerraform(struct?: DataGoogleComputeInstanceSchedulingPreemptionNoticeDuration): any;
export declare class DataGoogleComputeInstanceSchedulingPreemptionNoticeDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceSchedulingPreemptionNoticeDuration | undefined;
    set internalValue(value: DataGoogleComputeInstanceSchedulingPreemptionNoticeDuration | undefined);
    get nanos(): number;
    get seconds(): number;
}
export declare class DataGoogleComputeInstanceSchedulingPreemptionNoticeDurationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceSchedulingPreemptionNoticeDurationOutputReference;
}
export interface DataGoogleComputeInstanceScheduling {
}
export declare function dataGoogleComputeInstanceSchedulingToTerraform(struct?: DataGoogleComputeInstanceScheduling): any;
export declare function dataGoogleComputeInstanceSchedulingToHclTerraform(struct?: DataGoogleComputeInstanceScheduling): any;
export declare class DataGoogleComputeInstanceSchedulingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceScheduling | undefined;
    set internalValue(value: DataGoogleComputeInstanceScheduling | undefined);
    get automaticRestart(): cdktn.IResolvable;
    get availabilityDomain(): number;
    private _gracefulShutdown;
    get gracefulShutdown(): DataGoogleComputeInstanceSchedulingGracefulShutdownList;
    get hostErrorTimeoutSeconds(): number;
    get instanceTerminationAction(): string;
    private _localSsdRecoveryTimeout;
    get localSsdRecoveryTimeout(): DataGoogleComputeInstanceSchedulingLocalSsdRecoveryTimeoutList;
    get maintenanceInterval(): string;
    private _maxRunDuration;
    get maxRunDuration(): DataGoogleComputeInstanceSchedulingMaxRunDurationList;
    get minNodeCpus(): number;
    private _nodeAffinities;
    get nodeAffinities(): DataGoogleComputeInstanceSchedulingNodeAffinitiesList;
    get onHostMaintenance(): string;
    private _onInstanceStopAction;
    get onInstanceStopAction(): DataGoogleComputeInstanceSchedulingOnInstanceStopActionList;
    get preemptible(): cdktn.IResolvable;
    private _preemptionNoticeDuration;
    get preemptionNoticeDuration(): DataGoogleComputeInstanceSchedulingPreemptionNoticeDurationList;
    get provisioningModel(): string;
    get skipGuestOsShutdown(): cdktn.IResolvable;
    get terminationTime(): string;
}
export declare class DataGoogleComputeInstanceSchedulingList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceSchedulingOutputReference;
}
export interface DataGoogleComputeInstanceScratchDisk {
}
export declare function dataGoogleComputeInstanceScratchDiskToTerraform(struct?: DataGoogleComputeInstanceScratchDisk): any;
export declare function dataGoogleComputeInstanceScratchDiskToHclTerraform(struct?: DataGoogleComputeInstanceScratchDisk): any;
export declare class DataGoogleComputeInstanceScratchDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceScratchDisk | undefined;
    set internalValue(value: DataGoogleComputeInstanceScratchDisk | undefined);
    get deviceName(): string;
    get interface(): string;
    get size(): number;
}
export declare class DataGoogleComputeInstanceScratchDiskList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceScratchDiskOutputReference;
}
export interface DataGoogleComputeInstanceServiceAccount {
}
export declare function dataGoogleComputeInstanceServiceAccountToTerraform(struct?: DataGoogleComputeInstanceServiceAccount): any;
export declare function dataGoogleComputeInstanceServiceAccountToHclTerraform(struct?: DataGoogleComputeInstanceServiceAccount): any;
export declare class DataGoogleComputeInstanceServiceAccountOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceServiceAccount | undefined;
    set internalValue(value: DataGoogleComputeInstanceServiceAccount | undefined);
    get email(): string;
    get scopes(): string[];
}
export declare class DataGoogleComputeInstanceServiceAccountList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceServiceAccountOutputReference;
}
export interface DataGoogleComputeInstanceShieldedInstanceConfig {
}
export declare function dataGoogleComputeInstanceShieldedInstanceConfigToTerraform(struct?: DataGoogleComputeInstanceShieldedInstanceConfig): any;
export declare function dataGoogleComputeInstanceShieldedInstanceConfigToHclTerraform(struct?: DataGoogleComputeInstanceShieldedInstanceConfig): any;
export declare class DataGoogleComputeInstanceShieldedInstanceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceShieldedInstanceConfig | undefined;
    set internalValue(value: DataGoogleComputeInstanceShieldedInstanceConfig | undefined);
    get enableIntegrityMonitoring(): cdktn.IResolvable;
    get enableSecureBoot(): cdktn.IResolvable;
    get enableVtpm(): cdktn.IResolvable;
}
export declare class DataGoogleComputeInstanceShieldedInstanceConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceShieldedInstanceConfigOutputReference;
}
export interface DataGoogleComputeInstanceWorkloadIdentityConfig {
}
export declare function dataGoogleComputeInstanceWorkloadIdentityConfigToTerraform(struct?: DataGoogleComputeInstanceWorkloadIdentityConfig): any;
export declare function dataGoogleComputeInstanceWorkloadIdentityConfigToHclTerraform(struct?: DataGoogleComputeInstanceWorkloadIdentityConfig): any;
export declare class DataGoogleComputeInstanceWorkloadIdentityConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceWorkloadIdentityConfig | undefined;
    set internalValue(value: DataGoogleComputeInstanceWorkloadIdentityConfig | undefined);
    get identity(): string;
    get identityCertificateEnabled(): cdktn.IResolvable;
}
export declare class DataGoogleComputeInstanceWorkloadIdentityConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceWorkloadIdentityConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_instance google_compute_instance}
*/
export declare class DataGoogleComputeInstance extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_compute_instance";
    /**
    * Generates CDKTN code for importing a DataGoogleComputeInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleComputeInstance to import
    * @param importFromId The id of the existing DataGoogleComputeInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleComputeInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_instance google_compute_instance} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleComputeInstanceConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGoogleComputeInstanceConfig);
    private _advancedMachineFeatures;
    get advancedMachineFeatures(): DataGoogleComputeInstanceAdvancedMachineFeaturesList;
    get allowStoppingForUpdate(): cdktn.IResolvable;
    private _attachedDisk;
    get attachedDisk(): DataGoogleComputeInstanceAttachedDiskList;
    private _bootDisk;
    get bootDisk(): DataGoogleComputeInstanceBootDiskList;
    get canIpForward(): cdktn.IResolvable;
    private _confidentialInstanceConfig;
    get confidentialInstanceConfig(): DataGoogleComputeInstanceConfidentialInstanceConfigList;
    get cpuPlatform(): string;
    get creationTimestamp(): string;
    get currentStatus(): string;
    get deletionPolicy(): string;
    get deletionProtection(): cdktn.IResolvable;
    get description(): string;
    get desiredStatus(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get enableDisplay(): cdktn.IResolvable;
    get eraseWindowsVssSignature(): cdktn.IResolvable;
    private _guestAccelerator;
    get guestAccelerator(): DataGoogleComputeInstanceGuestAcceleratorList;
    get hostname(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceEncryptionKey;
    get instanceEncryptionKey(): DataGoogleComputeInstanceInstanceEncryptionKeyList;
    get instanceId(): string;
    get keyRevocationActionType(): string;
    get labelFingerprint(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    get machineType(): string;
    private _metadata;
    get metadata(): cdktn.StringMap;
    get metadataFingerprint(): string;
    get metadataStartupScript(): string;
    get minCpuPlatform(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _networkInterface;
    get networkInterface(): DataGoogleComputeInstanceNetworkInterfaceList;
    private _networkPerformanceConfig;
    get networkPerformanceConfig(): DataGoogleComputeInstanceNetworkPerformanceConfigList;
    private _params;
    get params(): DataGoogleComputeInstanceParamsList;
    private _partnerMetadata;
    get partnerMetadata(): cdktn.StringMap;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _reservationAffinity;
    get reservationAffinity(): DataGoogleComputeInstanceReservationAffinityList;
    get resourcePolicies(): string[];
    private _scheduling;
    get scheduling(): DataGoogleComputeInstanceSchedulingList;
    private _scratchDisk;
    get scratchDisk(): DataGoogleComputeInstanceScratchDiskList;
    private _selfLink?;
    get selfLink(): string;
    set selfLink(value: string);
    resetSelfLink(): void;
    get selfLinkInput(): string | undefined;
    private _serviceAccount;
    get serviceAccount(): DataGoogleComputeInstanceServiceAccountList;
    private _shieldedInstanceConfig;
    get shieldedInstanceConfig(): DataGoogleComputeInstanceShieldedInstanceConfigList;
    get tags(): string[];
    get tagsFingerprint(): string;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _workloadIdentityConfig;
    get workloadIdentityConfig(): DataGoogleComputeInstanceWorkloadIdentityConfigList;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    resetZone(): void;
    get zoneInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
