/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleVertexAiReasoningEngineQueryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Class method to be used for the query. It is optional and defaults to "query" if unspecified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vertex_ai_reasoning_engine_query#class_method DataGoogleVertexAiReasoningEngineQuery#class_method}
    */
    readonly classMethod?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vertex_ai_reasoning_engine_query#id DataGoogleVertexAiReasoningEngineQuery#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Input content provided by users in JSON object format. Examples include text query, function calling parameters, media bytes, etc..
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vertex_ai_reasoning_engine_query#input DataGoogleVertexAiReasoningEngineQuery#input}
    */
    readonly input?: string;
    /**
    * The project of the resource. If not provided, the provider default project is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vertex_ai_reasoning_engine_query#project DataGoogleVertexAiReasoningEngineQuery#project}
    */
    readonly project?: string;
    /**
    * The id of the Vertex Agent Engine to query.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vertex_ai_reasoning_engine_query#reasoning_engine_id DataGoogleVertexAiReasoningEngineQuery#reasoning_engine_id}
    */
    readonly reasoningEngineId: string;
    /**
    * The location of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vertex_ai_reasoning_engine_query#region DataGoogleVertexAiReasoningEngineQuery#region}
    */
    readonly region: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vertex_ai_reasoning_engine_query google_vertex_ai_reasoning_engine_query}
*/
export declare class DataGoogleVertexAiReasoningEngineQuery extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_vertex_ai_reasoning_engine_query";
    /**
    * Generates CDKTN code for importing a DataGoogleVertexAiReasoningEngineQuery resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleVertexAiReasoningEngineQuery to import
    * @param importFromId The id of the existing DataGoogleVertexAiReasoningEngineQuery that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vertex_ai_reasoning_engine_query#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleVertexAiReasoningEngineQuery to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vertex_ai_reasoning_engine_query google_vertex_ai_reasoning_engine_query} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleVertexAiReasoningEngineQueryConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleVertexAiReasoningEngineQueryConfig);
    private _classMethod?;
    get classMethod(): string;
    set classMethod(value: string);
    resetClassMethod(): void;
    get classMethodInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _input?;
    get input(): string;
    set input(value: string);
    resetInput(): void;
    get inputInput(): string | undefined;
    get output(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _reasoningEngineId?;
    get reasoningEngineId(): string;
    set reasoningEngineId(value: string);
    get reasoningEngineIdInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
