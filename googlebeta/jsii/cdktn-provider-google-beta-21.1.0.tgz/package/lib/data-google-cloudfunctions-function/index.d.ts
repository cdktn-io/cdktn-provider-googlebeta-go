/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleCloudfunctionsFunctionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloudfunctions_function#id DataGoogleCloudfunctionsFunction#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * A user-defined name of the function. Function names must be unique globally.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloudfunctions_function#name DataGoogleCloudfunctionsFunction#name}
    */
    readonly name: string;
    /**
    * Project of the function. If it is not provided, the provider project is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloudfunctions_function#project DataGoogleCloudfunctionsFunction#project}
    */
    readonly project?: string;
    /**
    * Region of function. If it is not provided, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloudfunctions_function#region DataGoogleCloudfunctionsFunction#region}
    */
    readonly region?: string;
}
export interface DataGoogleCloudfunctionsFunctionAutomaticUpdatePolicy {
}
export declare function dataGoogleCloudfunctionsFunctionAutomaticUpdatePolicyToTerraform(struct?: DataGoogleCloudfunctionsFunctionAutomaticUpdatePolicy): any;
export declare function dataGoogleCloudfunctionsFunctionAutomaticUpdatePolicyToHclTerraform(struct?: DataGoogleCloudfunctionsFunctionAutomaticUpdatePolicy): any;
export declare class DataGoogleCloudfunctionsFunctionAutomaticUpdatePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudfunctionsFunctionAutomaticUpdatePolicy | undefined;
    set internalValue(value: DataGoogleCloudfunctionsFunctionAutomaticUpdatePolicy | undefined);
}
export declare class DataGoogleCloudfunctionsFunctionAutomaticUpdatePolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudfunctionsFunctionAutomaticUpdatePolicyOutputReference;
}
export interface DataGoogleCloudfunctionsFunctionEventTriggerFailurePolicy {
}
export declare function dataGoogleCloudfunctionsFunctionEventTriggerFailurePolicyToTerraform(struct?: DataGoogleCloudfunctionsFunctionEventTriggerFailurePolicy): any;
export declare function dataGoogleCloudfunctionsFunctionEventTriggerFailurePolicyToHclTerraform(struct?: DataGoogleCloudfunctionsFunctionEventTriggerFailurePolicy): any;
export declare class DataGoogleCloudfunctionsFunctionEventTriggerFailurePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudfunctionsFunctionEventTriggerFailurePolicy | undefined;
    set internalValue(value: DataGoogleCloudfunctionsFunctionEventTriggerFailurePolicy | undefined);
    get retry(): cdktn.IResolvable;
}
export declare class DataGoogleCloudfunctionsFunctionEventTriggerFailurePolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudfunctionsFunctionEventTriggerFailurePolicyOutputReference;
}
export interface DataGoogleCloudfunctionsFunctionEventTrigger {
}
export declare function dataGoogleCloudfunctionsFunctionEventTriggerToTerraform(struct?: DataGoogleCloudfunctionsFunctionEventTrigger): any;
export declare function dataGoogleCloudfunctionsFunctionEventTriggerToHclTerraform(struct?: DataGoogleCloudfunctionsFunctionEventTrigger): any;
export declare class DataGoogleCloudfunctionsFunctionEventTriggerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudfunctionsFunctionEventTrigger | undefined;
    set internalValue(value: DataGoogleCloudfunctionsFunctionEventTrigger | undefined);
    get eventType(): string;
    private _failurePolicy;
    get failurePolicy(): DataGoogleCloudfunctionsFunctionEventTriggerFailurePolicyList;
    get resource(): string;
}
export declare class DataGoogleCloudfunctionsFunctionEventTriggerList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudfunctionsFunctionEventTriggerOutputReference;
}
export interface DataGoogleCloudfunctionsFunctionOnDeployUpdatePolicy {
}
export declare function dataGoogleCloudfunctionsFunctionOnDeployUpdatePolicyToTerraform(struct?: DataGoogleCloudfunctionsFunctionOnDeployUpdatePolicy): any;
export declare function dataGoogleCloudfunctionsFunctionOnDeployUpdatePolicyToHclTerraform(struct?: DataGoogleCloudfunctionsFunctionOnDeployUpdatePolicy): any;
export declare class DataGoogleCloudfunctionsFunctionOnDeployUpdatePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudfunctionsFunctionOnDeployUpdatePolicy | undefined;
    set internalValue(value: DataGoogleCloudfunctionsFunctionOnDeployUpdatePolicy | undefined);
    get runtimeVersion(): string;
}
export declare class DataGoogleCloudfunctionsFunctionOnDeployUpdatePolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudfunctionsFunctionOnDeployUpdatePolicyOutputReference;
}
export interface DataGoogleCloudfunctionsFunctionSecretEnvironmentVariables {
}
export declare function dataGoogleCloudfunctionsFunctionSecretEnvironmentVariablesToTerraform(struct?: DataGoogleCloudfunctionsFunctionSecretEnvironmentVariables): any;
export declare function dataGoogleCloudfunctionsFunctionSecretEnvironmentVariablesToHclTerraform(struct?: DataGoogleCloudfunctionsFunctionSecretEnvironmentVariables): any;
export declare class DataGoogleCloudfunctionsFunctionSecretEnvironmentVariablesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudfunctionsFunctionSecretEnvironmentVariables | undefined;
    set internalValue(value: DataGoogleCloudfunctionsFunctionSecretEnvironmentVariables | undefined);
    get key(): string;
    get projectId(): string;
    get secret(): string;
    get version(): string;
}
export declare class DataGoogleCloudfunctionsFunctionSecretEnvironmentVariablesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudfunctionsFunctionSecretEnvironmentVariablesOutputReference;
}
export interface DataGoogleCloudfunctionsFunctionSecretVolumesVersions {
}
export declare function dataGoogleCloudfunctionsFunctionSecretVolumesVersionsToTerraform(struct?: DataGoogleCloudfunctionsFunctionSecretVolumesVersions): any;
export declare function dataGoogleCloudfunctionsFunctionSecretVolumesVersionsToHclTerraform(struct?: DataGoogleCloudfunctionsFunctionSecretVolumesVersions): any;
export declare class DataGoogleCloudfunctionsFunctionSecretVolumesVersionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudfunctionsFunctionSecretVolumesVersions | undefined;
    set internalValue(value: DataGoogleCloudfunctionsFunctionSecretVolumesVersions | undefined);
    get path(): string;
    get version(): string;
}
export declare class DataGoogleCloudfunctionsFunctionSecretVolumesVersionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudfunctionsFunctionSecretVolumesVersionsOutputReference;
}
export interface DataGoogleCloudfunctionsFunctionSecretVolumes {
}
export declare function dataGoogleCloudfunctionsFunctionSecretVolumesToTerraform(struct?: DataGoogleCloudfunctionsFunctionSecretVolumes): any;
export declare function dataGoogleCloudfunctionsFunctionSecretVolumesToHclTerraform(struct?: DataGoogleCloudfunctionsFunctionSecretVolumes): any;
export declare class DataGoogleCloudfunctionsFunctionSecretVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudfunctionsFunctionSecretVolumes | undefined;
    set internalValue(value: DataGoogleCloudfunctionsFunctionSecretVolumes | undefined);
    get mountPath(): string;
    get projectId(): string;
    get secret(): string;
    private _versions;
    get versions(): DataGoogleCloudfunctionsFunctionSecretVolumesVersionsList;
}
export declare class DataGoogleCloudfunctionsFunctionSecretVolumesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudfunctionsFunctionSecretVolumesOutputReference;
}
export interface DataGoogleCloudfunctionsFunctionSourceRepository {
}
export declare function dataGoogleCloudfunctionsFunctionSourceRepositoryToTerraform(struct?: DataGoogleCloudfunctionsFunctionSourceRepository): any;
export declare function dataGoogleCloudfunctionsFunctionSourceRepositoryToHclTerraform(struct?: DataGoogleCloudfunctionsFunctionSourceRepository): any;
export declare class DataGoogleCloudfunctionsFunctionSourceRepositoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudfunctionsFunctionSourceRepository | undefined;
    set internalValue(value: DataGoogleCloudfunctionsFunctionSourceRepository | undefined);
    get deployedUrl(): string;
    get url(): string;
}
export declare class DataGoogleCloudfunctionsFunctionSourceRepositoryList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudfunctionsFunctionSourceRepositoryOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloudfunctions_function google_cloudfunctions_function}
*/
export declare class DataGoogleCloudfunctionsFunction extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_cloudfunctions_function";
    /**
    * Generates CDKTN code for importing a DataGoogleCloudfunctionsFunction resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleCloudfunctionsFunction to import
    * @param importFromId The id of the existing DataGoogleCloudfunctionsFunction that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloudfunctions_function#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleCloudfunctionsFunction to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloudfunctions_function google_cloudfunctions_function} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleCloudfunctionsFunctionConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleCloudfunctionsFunctionConfig);
    private _automaticUpdatePolicy;
    get automaticUpdatePolicy(): DataGoogleCloudfunctionsFunctionAutomaticUpdatePolicyList;
    get availableMemoryMb(): number;
    private _buildEnvironmentVariables;
    get buildEnvironmentVariables(): cdktn.StringMap;
    get buildServiceAccount(): string;
    get buildWorkerPool(): string;
    get deletionPolicy(): string;
    get description(): string;
    get dockerRegistry(): string;
    get dockerRepository(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get entryPoint(): string;
    private _environmentVariables;
    get environmentVariables(): cdktn.StringMap;
    private _eventTrigger;
    get eventTrigger(): DataGoogleCloudfunctionsFunctionEventTriggerList;
    get httpsTriggerSecurityLevel(): string;
    get httpsTriggerUrl(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ingressSettings(): string;
    get kmsKeyName(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    get maxInstances(): number;
    get minInstances(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _onDeployUpdatePolicy;
    get onDeployUpdatePolicy(): DataGoogleCloudfunctionsFunctionOnDeployUpdatePolicyList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get runtime(): string;
    private _secretEnvironmentVariables;
    get secretEnvironmentVariables(): DataGoogleCloudfunctionsFunctionSecretEnvironmentVariablesList;
    private _secretVolumes;
    get secretVolumes(): DataGoogleCloudfunctionsFunctionSecretVolumesList;
    get serviceAccountEmail(): string;
    get sourceArchiveBucket(): string;
    get sourceArchiveObject(): string;
    private _sourceRepository;
    get sourceRepository(): DataGoogleCloudfunctionsFunctionSourceRepositoryList;
    get status(): string;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get timeout(): number;
    get triggerHttp(): cdktn.IResolvable;
    get versionId(): string;
    get vpcConnector(): string;
    get vpcConnectorEgressSettings(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
