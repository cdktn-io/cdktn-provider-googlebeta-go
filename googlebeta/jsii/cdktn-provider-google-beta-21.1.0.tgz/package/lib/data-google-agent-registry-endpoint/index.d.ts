/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleAgentRegistryEndpointConfig extends cdktn.TerraformMetaArguments {
    /**
    * The unique identifier for the Endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_agent_registry_endpoint#endpoint_id DataGoogleAgentRegistryEndpoint#endpoint_id}
    */
    readonly endpointId?: string;
    /**
    * A filter string that identifies a unique endpoint.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_agent_registry_endpoint#filter DataGoogleAgentRegistryEndpoint#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_agent_registry_endpoint#id DataGoogleAgentRegistryEndpoint#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_agent_registry_endpoint#location DataGoogleAgentRegistryEndpoint#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_agent_registry_endpoint#project DataGoogleAgentRegistryEndpoint#project}
    */
    readonly project?: string;
}
export interface DataGoogleAgentRegistryEndpointInterfaces {
}
export declare function dataGoogleAgentRegistryEndpointInterfacesToTerraform(struct?: DataGoogleAgentRegistryEndpointInterfaces): any;
export declare function dataGoogleAgentRegistryEndpointInterfacesToHclTerraform(struct?: DataGoogleAgentRegistryEndpointInterfaces): any;
export declare class DataGoogleAgentRegistryEndpointInterfacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAgentRegistryEndpointInterfaces | undefined;
    set internalValue(value: DataGoogleAgentRegistryEndpointInterfaces | undefined);
    get protocolBinding(): string;
    get url(): string;
}
export declare class DataGoogleAgentRegistryEndpointInterfacesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAgentRegistryEndpointInterfacesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_agent_registry_endpoint google_agent_registry_endpoint}
*/
export declare class DataGoogleAgentRegistryEndpoint extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_agent_registry_endpoint";
    /**
    * Generates CDKTN code for importing a DataGoogleAgentRegistryEndpoint resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleAgentRegistryEndpoint to import
    * @param importFromId The id of the existing DataGoogleAgentRegistryEndpoint that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_agent_registry_endpoint#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleAgentRegistryEndpoint to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_agent_registry_endpoint google_agent_registry_endpoint} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleAgentRegistryEndpointConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleAgentRegistryEndpointConfig);
    private _attributes;
    get attributes(): cdktn.StringMap;
    get createTime(): string;
    get description(): string;
    get displayName(): string;
    private _endpointId?;
    get endpointId(): string;
    set endpointId(value: string);
    resetEndpointId(): void;
    get endpointIdInput(): string | undefined;
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _interfaces;
    get interfaces(): DataGoogleAgentRegistryEndpointInterfacesList;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get updateTime(): string;
    get urn(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
