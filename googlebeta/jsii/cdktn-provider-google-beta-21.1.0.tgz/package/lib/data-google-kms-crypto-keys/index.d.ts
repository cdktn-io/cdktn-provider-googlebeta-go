/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleKmsCryptoKeysConfig extends cdktn.TerraformMetaArguments {
    /**
    *
    * 					The filter argument is used to add a filter query parameter that limits which keys are retrieved by the data source: ?filter={{filter}}.
    * 					Example values:
    *
    * 					* "name:my-key-" will retrieve keys that contain "my-key-" anywhere in their name. Note: names take the form projects/{{project}}/locations/{{location}}/keyRings/{{keyRing}}/cryptoKeys/{{cryptoKey}}.
    * 					* "name=projects/my-project/locations/global/keyRings/my-key-ring/cryptoKeys/my-key-1" will only retrieve a key with that exact name.
    *
    * 					[See the documentation about using filters](https://cloud.google.com/kms/docs/sorting-and-filtering)
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_crypto_keys#filter DataGoogleKmsCryptoKeys#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_crypto_keys#id DataGoogleKmsCryptoKeys#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The key ring that the keys belongs to. Format: 'projects/{{project}}/locations/{{location}}/keyRings/{{keyRing}}'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_crypto_keys#key_ring DataGoogleKmsCryptoKeys#key_ring}
    */
    readonly keyRing: string;
}
export interface DataGoogleKmsCryptoKeysKeysKeyAccessJustificationsPolicy {
}
export declare function dataGoogleKmsCryptoKeysKeysKeyAccessJustificationsPolicyToTerraform(struct?: DataGoogleKmsCryptoKeysKeysKeyAccessJustificationsPolicy): any;
export declare function dataGoogleKmsCryptoKeysKeysKeyAccessJustificationsPolicyToHclTerraform(struct?: DataGoogleKmsCryptoKeysKeysKeyAccessJustificationsPolicy): any;
export declare class DataGoogleKmsCryptoKeysKeysKeyAccessJustificationsPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleKmsCryptoKeysKeysKeyAccessJustificationsPolicy | undefined;
    set internalValue(value: DataGoogleKmsCryptoKeysKeysKeyAccessJustificationsPolicy | undefined);
    get allowedAccessReasons(): string[];
}
export declare class DataGoogleKmsCryptoKeysKeysKeyAccessJustificationsPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleKmsCryptoKeysKeysKeyAccessJustificationsPolicyOutputReference;
}
export interface DataGoogleKmsCryptoKeysKeysPrimary {
}
export declare function dataGoogleKmsCryptoKeysKeysPrimaryToTerraform(struct?: DataGoogleKmsCryptoKeysKeysPrimary): any;
export declare function dataGoogleKmsCryptoKeysKeysPrimaryToHclTerraform(struct?: DataGoogleKmsCryptoKeysKeysPrimary): any;
export declare class DataGoogleKmsCryptoKeysKeysPrimaryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleKmsCryptoKeysKeysPrimary | undefined;
    set internalValue(value: DataGoogleKmsCryptoKeysKeysPrimary | undefined);
    get name(): string;
    get state(): string;
}
export declare class DataGoogleKmsCryptoKeysKeysPrimaryList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleKmsCryptoKeysKeysPrimaryOutputReference;
}
export interface DataGoogleKmsCryptoKeysKeysVersionTemplate {
}
export declare function dataGoogleKmsCryptoKeysKeysVersionTemplateToTerraform(struct?: DataGoogleKmsCryptoKeysKeysVersionTemplate): any;
export declare function dataGoogleKmsCryptoKeysKeysVersionTemplateToHclTerraform(struct?: DataGoogleKmsCryptoKeysKeysVersionTemplate): any;
export declare class DataGoogleKmsCryptoKeysKeysVersionTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleKmsCryptoKeysKeysVersionTemplate | undefined;
    set internalValue(value: DataGoogleKmsCryptoKeysKeysVersionTemplate | undefined);
    get algorithm(): string;
    get protectionLevel(): string;
}
export declare class DataGoogleKmsCryptoKeysKeysVersionTemplateList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleKmsCryptoKeysKeysVersionTemplateOutputReference;
}
export interface DataGoogleKmsCryptoKeysKeys {
}
export declare function dataGoogleKmsCryptoKeysKeysToTerraform(struct?: DataGoogleKmsCryptoKeysKeys): any;
export declare function dataGoogleKmsCryptoKeysKeysToHclTerraform(struct?: DataGoogleKmsCryptoKeysKeys): any;
export declare class DataGoogleKmsCryptoKeysKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleKmsCryptoKeysKeys | undefined;
    set internalValue(value: DataGoogleKmsCryptoKeysKeys | undefined);
    get cryptoKeyBackend(): string;
    get deletionPolicy(): string;
    get destroyScheduledDuration(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get id(): string;
    get importOnly(): cdktn.IResolvable;
    private _keyAccessJustificationsPolicy;
    get keyAccessJustificationsPolicy(): DataGoogleKmsCryptoKeysKeysKeyAccessJustificationsPolicyList;
    get keyRing(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    get name(): string;
    private _primary;
    get primary(): DataGoogleKmsCryptoKeysKeysPrimaryList;
    get purpose(): string;
    get rotationPeriod(): string;
    get skipInitialVersionCreation(): cdktn.IResolvable;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _versionTemplate;
    get versionTemplate(): DataGoogleKmsCryptoKeysKeysVersionTemplateList;
}
export declare class DataGoogleKmsCryptoKeysKeysList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleKmsCryptoKeysKeysOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_crypto_keys google_kms_crypto_keys}
*/
export declare class DataGoogleKmsCryptoKeys extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_kms_crypto_keys";
    /**
    * Generates CDKTN code for importing a DataGoogleKmsCryptoKeys resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleKmsCryptoKeys to import
    * @param importFromId The id of the existing DataGoogleKmsCryptoKeys that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_crypto_keys#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleKmsCryptoKeys to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_crypto_keys google_kms_crypto_keys} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleKmsCryptoKeysConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleKmsCryptoKeysConfig);
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keyRing?;
    get keyRing(): string;
    set keyRing(value: string);
    get keyRingInput(): string | undefined;
    private _keys;
    get keys(): DataGoogleKmsCryptoKeysKeysList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
