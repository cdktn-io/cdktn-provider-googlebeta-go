/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleParameterManagerRegionalParametersConfig extends cdktn.TerraformMetaArguments {
    /**
    * Filter string, adhering to the rules in List-operation filtering. List only parameters matching the filter.
    * If filter is empty, all regional parameters are listed from specific location.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_parameter_manager_regional_parameters#filter DataGoogleParameterManagerRegionalParameters#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_parameter_manager_regional_parameters#id DataGoogleParameterManagerRegionalParameters#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_parameter_manager_regional_parameters#location DataGoogleParameterManagerRegionalParameters#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_parameter_manager_regional_parameters#project DataGoogleParameterManagerRegionalParameters#project}
    */
    readonly project?: string;
}
export interface DataGoogleParameterManagerRegionalParametersParametersPolicyMember {
}
export declare function dataGoogleParameterManagerRegionalParametersParametersPolicyMemberToTerraform(struct?: DataGoogleParameterManagerRegionalParametersParametersPolicyMember): any;
export declare function dataGoogleParameterManagerRegionalParametersParametersPolicyMemberToHclTerraform(struct?: DataGoogleParameterManagerRegionalParametersParametersPolicyMember): any;
export declare class DataGoogleParameterManagerRegionalParametersParametersPolicyMemberOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleParameterManagerRegionalParametersParametersPolicyMember | undefined;
    set internalValue(value: DataGoogleParameterManagerRegionalParametersParametersPolicyMember | undefined);
    get iamPolicyNamePrincipal(): string;
    get iamPolicyUidPrincipal(): string;
}
export declare class DataGoogleParameterManagerRegionalParametersParametersPolicyMemberList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleParameterManagerRegionalParametersParametersPolicyMemberOutputReference;
}
export interface DataGoogleParameterManagerRegionalParametersParameters {
}
export declare function dataGoogleParameterManagerRegionalParametersParametersToTerraform(struct?: DataGoogleParameterManagerRegionalParametersParameters): any;
export declare function dataGoogleParameterManagerRegionalParametersParametersToHclTerraform(struct?: DataGoogleParameterManagerRegionalParametersParameters): any;
export declare class DataGoogleParameterManagerRegionalParametersParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleParameterManagerRegionalParametersParameters | undefined;
    set internalValue(value: DataGoogleParameterManagerRegionalParametersParameters | undefined);
    get createTime(): string;
    get deletionPolicy(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get format(): string;
    get kmsKey(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    get location(): string;
    get name(): string;
    get parameterId(): string;
    private _policyMember;
    get policyMember(): DataGoogleParameterManagerRegionalParametersParametersPolicyMemberList;
    get project(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get updateTime(): string;
}
export declare class DataGoogleParameterManagerRegionalParametersParametersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleParameterManagerRegionalParametersParametersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_parameter_manager_regional_parameters google_parameter_manager_regional_parameters}
*/
export declare class DataGoogleParameterManagerRegionalParameters extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_parameter_manager_regional_parameters";
    /**
    * Generates CDKTN code for importing a DataGoogleParameterManagerRegionalParameters resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleParameterManagerRegionalParameters to import
    * @param importFromId The id of the existing DataGoogleParameterManagerRegionalParameters that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_parameter_manager_regional_parameters#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleParameterManagerRegionalParameters to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_parameter_manager_regional_parameters google_parameter_manager_regional_parameters} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleParameterManagerRegionalParametersConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleParameterManagerRegionalParametersConfig);
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _parameters;
    get parameters(): DataGoogleParameterManagerRegionalParametersParametersList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
