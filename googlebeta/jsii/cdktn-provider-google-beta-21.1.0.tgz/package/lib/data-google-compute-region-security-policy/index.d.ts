/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleComputeRegionSecurityPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_region_security_policy#id DataGoogleComputeRegionSecurityPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the resource. Provided by the client when the resource is created. The name must be 1-63 characters long, and comply with RFC1035.
    * Specifically, the name must be 1-63 characters long and match the regular expression [a-z]([-a-z0-9]*[a-z0-9])? which means the first character must be a lowercase letter, and all following characters must be a dash, lowercase letter, or digit, except the last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_region_security_policy#name DataGoogleComputeRegionSecurityPolicy#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_region_security_policy#project DataGoogleComputeRegionSecurityPolicy#project}
    */
    readonly project?: string;
    /**
    * The Region in which the created Region Security Policy should reside.
    * If it is not provided, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_region_security_policy#region DataGoogleComputeRegionSecurityPolicy#region}
    */
    readonly region?: string;
}
export interface DataGoogleComputeRegionSecurityPolicyAdvancedOptionsConfigJsonCustomConfig {
}
export declare function dataGoogleComputeRegionSecurityPolicyAdvancedOptionsConfigJsonCustomConfigToTerraform(struct?: DataGoogleComputeRegionSecurityPolicyAdvancedOptionsConfigJsonCustomConfig): any;
export declare function dataGoogleComputeRegionSecurityPolicyAdvancedOptionsConfigJsonCustomConfigToHclTerraform(struct?: DataGoogleComputeRegionSecurityPolicyAdvancedOptionsConfigJsonCustomConfig): any;
export declare class DataGoogleComputeRegionSecurityPolicyAdvancedOptionsConfigJsonCustomConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionSecurityPolicyAdvancedOptionsConfigJsonCustomConfig | undefined;
    set internalValue(value: DataGoogleComputeRegionSecurityPolicyAdvancedOptionsConfigJsonCustomConfig | undefined);
    get contentTypes(): string[];
}
export declare class DataGoogleComputeRegionSecurityPolicyAdvancedOptionsConfigJsonCustomConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionSecurityPolicyAdvancedOptionsConfigJsonCustomConfigOutputReference;
}
export interface DataGoogleComputeRegionSecurityPolicyAdvancedOptionsConfig {
}
export declare function dataGoogleComputeRegionSecurityPolicyAdvancedOptionsConfigToTerraform(struct?: DataGoogleComputeRegionSecurityPolicyAdvancedOptionsConfig): any;
export declare function dataGoogleComputeRegionSecurityPolicyAdvancedOptionsConfigToHclTerraform(struct?: DataGoogleComputeRegionSecurityPolicyAdvancedOptionsConfig): any;
export declare class DataGoogleComputeRegionSecurityPolicyAdvancedOptionsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionSecurityPolicyAdvancedOptionsConfig | undefined;
    set internalValue(value: DataGoogleComputeRegionSecurityPolicyAdvancedOptionsConfig | undefined);
    private _jsonCustomConfig;
    get jsonCustomConfig(): DataGoogleComputeRegionSecurityPolicyAdvancedOptionsConfigJsonCustomConfigList;
    get jsonParsing(): string;
    get logLevel(): string;
    get requestBodyInspectionSize(): string;
    get userIpRequestHeaders(): string[];
}
export declare class DataGoogleComputeRegionSecurityPolicyAdvancedOptionsConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionSecurityPolicyAdvancedOptionsConfigOutputReference;
}
export interface DataGoogleComputeRegionSecurityPolicyDdosProtectionConfig {
}
export declare function dataGoogleComputeRegionSecurityPolicyDdosProtectionConfigToTerraform(struct?: DataGoogleComputeRegionSecurityPolicyDdosProtectionConfig): any;
export declare function dataGoogleComputeRegionSecurityPolicyDdosProtectionConfigToHclTerraform(struct?: DataGoogleComputeRegionSecurityPolicyDdosProtectionConfig): any;
export declare class DataGoogleComputeRegionSecurityPolicyDdosProtectionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionSecurityPolicyDdosProtectionConfig | undefined;
    set internalValue(value: DataGoogleComputeRegionSecurityPolicyDdosProtectionConfig | undefined);
    get ddosProtection(): string;
}
export declare class DataGoogleComputeRegionSecurityPolicyDdosProtectionConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionSecurityPolicyDdosProtectionConfigOutputReference;
}
export interface DataGoogleComputeRegionSecurityPolicyRulesMatchConfig {
}
export declare function dataGoogleComputeRegionSecurityPolicyRulesMatchConfigToTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesMatchConfig): any;
export declare function dataGoogleComputeRegionSecurityPolicyRulesMatchConfigToHclTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesMatchConfig): any;
export declare class DataGoogleComputeRegionSecurityPolicyRulesMatchConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionSecurityPolicyRulesMatchConfig | undefined;
    set internalValue(value: DataGoogleComputeRegionSecurityPolicyRulesMatchConfig | undefined);
    get srcIpRanges(): string[];
}
export declare class DataGoogleComputeRegionSecurityPolicyRulesMatchConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionSecurityPolicyRulesMatchConfigOutputReference;
}
export interface DataGoogleComputeRegionSecurityPolicyRulesMatchExpr {
}
export declare function dataGoogleComputeRegionSecurityPolicyRulesMatchExprToTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesMatchExpr): any;
export declare function dataGoogleComputeRegionSecurityPolicyRulesMatchExprToHclTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesMatchExpr): any;
export declare class DataGoogleComputeRegionSecurityPolicyRulesMatchExprOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionSecurityPolicyRulesMatchExpr | undefined;
    set internalValue(value: DataGoogleComputeRegionSecurityPolicyRulesMatchExpr | undefined);
    get expression(): string;
}
export declare class DataGoogleComputeRegionSecurityPolicyRulesMatchExprList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionSecurityPolicyRulesMatchExprOutputReference;
}
export interface DataGoogleComputeRegionSecurityPolicyRulesMatch {
}
export declare function dataGoogleComputeRegionSecurityPolicyRulesMatchToTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesMatch): any;
export declare function dataGoogleComputeRegionSecurityPolicyRulesMatchToHclTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesMatch): any;
export declare class DataGoogleComputeRegionSecurityPolicyRulesMatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionSecurityPolicyRulesMatch | undefined;
    set internalValue(value: DataGoogleComputeRegionSecurityPolicyRulesMatch | undefined);
    private _config;
    get config(): DataGoogleComputeRegionSecurityPolicyRulesMatchConfigList;
    private _expr;
    get expr(): DataGoogleComputeRegionSecurityPolicyRulesMatchExprList;
    get versionedExpr(): string;
}
export declare class DataGoogleComputeRegionSecurityPolicyRulesMatchList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionSecurityPolicyRulesMatchOutputReference;
}
export interface DataGoogleComputeRegionSecurityPolicyRulesNetworkMatchUserDefinedFields {
}
export declare function dataGoogleComputeRegionSecurityPolicyRulesNetworkMatchUserDefinedFieldsToTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesNetworkMatchUserDefinedFields): any;
export declare function dataGoogleComputeRegionSecurityPolicyRulesNetworkMatchUserDefinedFieldsToHclTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesNetworkMatchUserDefinedFields): any;
export declare class DataGoogleComputeRegionSecurityPolicyRulesNetworkMatchUserDefinedFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionSecurityPolicyRulesNetworkMatchUserDefinedFields | undefined;
    set internalValue(value: DataGoogleComputeRegionSecurityPolicyRulesNetworkMatchUserDefinedFields | undefined);
    get name(): string;
    get values(): string[];
}
export declare class DataGoogleComputeRegionSecurityPolicyRulesNetworkMatchUserDefinedFieldsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionSecurityPolicyRulesNetworkMatchUserDefinedFieldsOutputReference;
}
export interface DataGoogleComputeRegionSecurityPolicyRulesNetworkMatch {
}
export declare function dataGoogleComputeRegionSecurityPolicyRulesNetworkMatchToTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesNetworkMatch): any;
export declare function dataGoogleComputeRegionSecurityPolicyRulesNetworkMatchToHclTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesNetworkMatch): any;
export declare class DataGoogleComputeRegionSecurityPolicyRulesNetworkMatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionSecurityPolicyRulesNetworkMatch | undefined;
    set internalValue(value: DataGoogleComputeRegionSecurityPolicyRulesNetworkMatch | undefined);
    get destIpRanges(): string[];
    get destPorts(): string[];
    get ipProtocols(): string[];
    get srcAsns(): number[];
    get srcIpRanges(): string[];
    get srcPorts(): string[];
    get srcRegionCodes(): string[];
    private _userDefinedFields;
    get userDefinedFields(): DataGoogleComputeRegionSecurityPolicyRulesNetworkMatchUserDefinedFieldsList;
}
export declare class DataGoogleComputeRegionSecurityPolicyRulesNetworkMatchList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionSecurityPolicyRulesNetworkMatchOutputReference;
}
export interface DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestBody {
}
export declare function dataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestBodyToTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestBody): any;
export declare function dataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestBodyToHclTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestBody): any;
export declare class DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestBodyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestBody | undefined;
    set internalValue(value: DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestBody | undefined);
    get operator(): string;
    get value(): string;
}
export declare class DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestBodyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestBodyOutputReference;
}
export interface DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestCookie {
}
export declare function dataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestCookieToTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestCookie): any;
export declare function dataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestCookieToHclTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestCookie): any;
export declare class DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestCookieOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestCookie | undefined;
    set internalValue(value: DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestCookie | undefined);
    get operator(): string;
    get value(): string;
}
export declare class DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestCookieList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestCookieOutputReference;
}
export interface DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestHeader {
}
export declare function dataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestHeaderToTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestHeader): any;
export declare function dataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestHeaderToHclTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestHeader): any;
export declare class DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestHeader | undefined;
    set internalValue(value: DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestHeader | undefined);
    get operator(): string;
    get value(): string;
}
export declare class DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestHeaderOutputReference;
}
export interface DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestQueryParam {
}
export declare function dataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestQueryParamToTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestQueryParam): any;
export declare function dataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestQueryParamToHclTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestQueryParam): any;
export declare class DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestQueryParamOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestQueryParam | undefined;
    set internalValue(value: DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestQueryParam | undefined);
    get operator(): string;
    get value(): string;
}
export declare class DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestQueryParamList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestQueryParamOutputReference;
}
export interface DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestUri {
}
export declare function dataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestUriToTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestUri): any;
export declare function dataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestUriToHclTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestUri): any;
export declare class DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestUriOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestUri | undefined;
    set internalValue(value: DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestUri | undefined);
    get operator(): string;
    get value(): string;
}
export declare class DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestUriList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestUriOutputReference;
}
export interface DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusion {
}
export declare function dataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionToTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusion): any;
export declare function dataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionToHclTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusion): any;
export declare class DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusion | undefined;
    set internalValue(value: DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusion | undefined);
    private _requestBody;
    get requestBody(): DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestBodyList;
    private _requestCookie;
    get requestCookie(): DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestCookieList;
    private _requestHeader;
    get requestHeader(): DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestHeaderList;
    private _requestQueryParam;
    get requestQueryParam(): DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestQueryParamList;
    private _requestUri;
    get requestUri(): DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionRequestUriList;
    get targetRuleIds(): string[];
    get targetRuleSet(): string;
}
export declare class DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionOutputReference;
}
export interface DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfig {
}
export declare function dataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigToTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfig): any;
export declare function dataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigToHclTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfig): any;
export declare class DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfig | undefined;
    set internalValue(value: DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfig | undefined);
    private _exclusion;
    get exclusion(): DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigExclusionList;
}
export declare class DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigOutputReference;
}
export interface DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsBanThreshold {
}
export declare function dataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsBanThresholdToTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsBanThreshold): any;
export declare function dataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsBanThresholdToHclTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsBanThreshold): any;
export declare class DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsBanThresholdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsBanThreshold | undefined;
    set internalValue(value: DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsBanThreshold | undefined);
    get count(): number;
    get intervalSec(): number;
}
export declare class DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsBanThresholdList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsBanThresholdOutputReference;
}
export interface DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsEnforceOnKeyConfigs {
}
export declare function dataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsEnforceOnKeyConfigsToTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsEnforceOnKeyConfigs): any;
export declare function dataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsEnforceOnKeyConfigsToHclTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsEnforceOnKeyConfigs): any;
export declare class DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsEnforceOnKeyConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsEnforceOnKeyConfigs | undefined;
    set internalValue(value: DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsEnforceOnKeyConfigs | undefined);
    get enforceOnKeyName(): string;
    get enforceOnKeyType(): string;
}
export declare class DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsEnforceOnKeyConfigsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsEnforceOnKeyConfigsOutputReference;
}
export interface DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsRateLimitThreshold {
}
export declare function dataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsRateLimitThresholdToTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsRateLimitThreshold): any;
export declare function dataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsRateLimitThresholdToHclTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsRateLimitThreshold): any;
export declare class DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsRateLimitThresholdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsRateLimitThreshold | undefined;
    set internalValue(value: DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsRateLimitThreshold | undefined);
    get count(): number;
    get intervalSec(): number;
}
export declare class DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsRateLimitThresholdList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsRateLimitThresholdOutputReference;
}
export interface DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptions {
}
export declare function dataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsToTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptions): any;
export declare function dataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsToHclTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptions): any;
export declare class DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptions | undefined;
    set internalValue(value: DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptions | undefined);
    get banDurationSec(): number;
    private _banThreshold;
    get banThreshold(): DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsBanThresholdList;
    get conformAction(): string;
    get enforceOnKey(): string;
    private _enforceOnKeyConfigs;
    get enforceOnKeyConfigs(): DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsEnforceOnKeyConfigsList;
    get enforceOnKeyName(): string;
    get exceedAction(): string;
    private _rateLimitThreshold;
    get rateLimitThreshold(): DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsRateLimitThresholdList;
}
export declare class DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsOutputReference;
}
export interface DataGoogleComputeRegionSecurityPolicyRules {
}
export declare function dataGoogleComputeRegionSecurityPolicyRulesToTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRules): any;
export declare function dataGoogleComputeRegionSecurityPolicyRulesToHclTerraform(struct?: DataGoogleComputeRegionSecurityPolicyRules): any;
export declare class DataGoogleComputeRegionSecurityPolicyRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionSecurityPolicyRules | undefined;
    set internalValue(value: DataGoogleComputeRegionSecurityPolicyRules | undefined);
    get action(): string;
    get description(): string;
    private _match;
    get match(): DataGoogleComputeRegionSecurityPolicyRulesMatchList;
    private _networkMatch;
    get networkMatch(): DataGoogleComputeRegionSecurityPolicyRulesNetworkMatchList;
    private _preconfiguredWafConfig;
    get preconfiguredWafConfig(): DataGoogleComputeRegionSecurityPolicyRulesPreconfiguredWafConfigList;
    get preview(): cdktn.IResolvable;
    get priority(): number;
    private _rateLimitOptions;
    get rateLimitOptions(): DataGoogleComputeRegionSecurityPolicyRulesRateLimitOptionsList;
}
export declare class DataGoogleComputeRegionSecurityPolicyRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionSecurityPolicyRulesOutputReference;
}
export interface DataGoogleComputeRegionSecurityPolicyUserDefinedFields {
}
export declare function dataGoogleComputeRegionSecurityPolicyUserDefinedFieldsToTerraform(struct?: DataGoogleComputeRegionSecurityPolicyUserDefinedFields): any;
export declare function dataGoogleComputeRegionSecurityPolicyUserDefinedFieldsToHclTerraform(struct?: DataGoogleComputeRegionSecurityPolicyUserDefinedFields): any;
export declare class DataGoogleComputeRegionSecurityPolicyUserDefinedFieldsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionSecurityPolicyUserDefinedFields | undefined;
    set internalValue(value: DataGoogleComputeRegionSecurityPolicyUserDefinedFields | undefined);
    get base(): string;
    get mask(): string;
    get name(): string;
    get offset(): number;
    get size(): number;
}
export declare class DataGoogleComputeRegionSecurityPolicyUserDefinedFieldsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionSecurityPolicyUserDefinedFieldsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_region_security_policy google_compute_region_security_policy}
*/
export declare class DataGoogleComputeRegionSecurityPolicy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_compute_region_security_policy";
    /**
    * Generates CDKTN code for importing a DataGoogleComputeRegionSecurityPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleComputeRegionSecurityPolicy to import
    * @param importFromId The id of the existing DataGoogleComputeRegionSecurityPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_region_security_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleComputeRegionSecurityPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_region_security_policy google_compute_region_security_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleComputeRegionSecurityPolicyConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleComputeRegionSecurityPolicyConfig);
    private _advancedOptionsConfig;
    get advancedOptionsConfig(): DataGoogleComputeRegionSecurityPolicyAdvancedOptionsConfigList;
    private _ddosProtectionConfig;
    get ddosProtectionConfig(): DataGoogleComputeRegionSecurityPolicyDdosProtectionConfigList;
    get deletionPolicy(): string;
    get description(): string;
    get fingerprint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get policyId(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _rules;
    get rules(): DataGoogleComputeRegionSecurityPolicyRulesList;
    get selfLink(): string;
    get selfLinkWithPolicyId(): string;
    get type(): string;
    private _userDefinedFields;
    get userDefinedFields(): DataGoogleComputeRegionSecurityPolicyUserDefinedFieldsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
