/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleVmwareengineDatastoreConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vmwareengine_datastore#id DataGoogleVmwareengineDatastore#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vmwareengine_datastore#location DataGoogleVmwareengineDatastore#location}
    */
    readonly location: string;
    /**
    * The user-provided identifier of the datastore to be created.
    * This identifier must be unique among each 'Datastore' within the parent
    * and becomes the final token in the name URI.
    * The identifier must meet the following requirements:
    *
    * * Only contains 1-63 alphanumeric characters and hyphens
    * * Begins with an alphabetical character
    * * Ends with a non-hyphen character
    * * Not formatted as a UUID
    * * Complies with [RFC 1034](https://datatracker.ietf.org/doc/html/rfc1034)
    * (section 3.5)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vmwareengine_datastore#name DataGoogleVmwareengineDatastore#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vmwareengine_datastore#project DataGoogleVmwareengineDatastore#project}
    */
    readonly project?: string;
}
export interface DataGoogleVmwareengineDatastoreNfsDatastoreGoogleFileService {
}
export declare function dataGoogleVmwareengineDatastoreNfsDatastoreGoogleFileServiceToTerraform(struct?: DataGoogleVmwareengineDatastoreNfsDatastoreGoogleFileService): any;
export declare function dataGoogleVmwareengineDatastoreNfsDatastoreGoogleFileServiceToHclTerraform(struct?: DataGoogleVmwareengineDatastoreNfsDatastoreGoogleFileService): any;
export declare class DataGoogleVmwareengineDatastoreNfsDatastoreGoogleFileServiceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleVmwareengineDatastoreNfsDatastoreGoogleFileService | undefined;
    set internalValue(value: DataGoogleVmwareengineDatastoreNfsDatastoreGoogleFileService | undefined);
    get filestoreInstance(): string;
    get netappVolume(): string;
}
export declare class DataGoogleVmwareengineDatastoreNfsDatastoreGoogleFileServiceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleVmwareengineDatastoreNfsDatastoreGoogleFileServiceOutputReference;
}
export interface DataGoogleVmwareengineDatastoreNfsDatastoreThirdPartyFileService {
}
export declare function dataGoogleVmwareengineDatastoreNfsDatastoreThirdPartyFileServiceToTerraform(struct?: DataGoogleVmwareengineDatastoreNfsDatastoreThirdPartyFileService): any;
export declare function dataGoogleVmwareengineDatastoreNfsDatastoreThirdPartyFileServiceToHclTerraform(struct?: DataGoogleVmwareengineDatastoreNfsDatastoreThirdPartyFileService): any;
export declare class DataGoogleVmwareengineDatastoreNfsDatastoreThirdPartyFileServiceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleVmwareengineDatastoreNfsDatastoreThirdPartyFileService | undefined;
    set internalValue(value: DataGoogleVmwareengineDatastoreNfsDatastoreThirdPartyFileService | undefined);
    get fileShare(): string;
    get network(): string;
    get servers(): string[];
}
export declare class DataGoogleVmwareengineDatastoreNfsDatastoreThirdPartyFileServiceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleVmwareengineDatastoreNfsDatastoreThirdPartyFileServiceOutputReference;
}
export interface DataGoogleVmwareengineDatastoreNfsDatastore {
}
export declare function dataGoogleVmwareengineDatastoreNfsDatastoreToTerraform(struct?: DataGoogleVmwareengineDatastoreNfsDatastore): any;
export declare function dataGoogleVmwareengineDatastoreNfsDatastoreToHclTerraform(struct?: DataGoogleVmwareengineDatastoreNfsDatastore): any;
export declare class DataGoogleVmwareengineDatastoreNfsDatastoreOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleVmwareengineDatastoreNfsDatastore | undefined;
    set internalValue(value: DataGoogleVmwareengineDatastoreNfsDatastore | undefined);
    private _googleFileService;
    get googleFileService(): DataGoogleVmwareengineDatastoreNfsDatastoreGoogleFileServiceList;
    private _thirdPartyFileService;
    get thirdPartyFileService(): DataGoogleVmwareengineDatastoreNfsDatastoreThirdPartyFileServiceList;
}
export declare class DataGoogleVmwareengineDatastoreNfsDatastoreList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleVmwareengineDatastoreNfsDatastoreOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vmwareengine_datastore google_vmwareengine_datastore}
*/
export declare class DataGoogleVmwareengineDatastore extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_vmwareengine_datastore";
    /**
    * Generates CDKTN code for importing a DataGoogleVmwareengineDatastore resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleVmwareengineDatastore to import
    * @param importFromId The id of the existing DataGoogleVmwareengineDatastore that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vmwareengine_datastore#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleVmwareengineDatastore to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vmwareengine_datastore google_vmwareengine_datastore} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleVmwareengineDatastoreConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleVmwareengineDatastoreConfig);
    get clusters(): string[];
    get createTime(): string;
    get deletionPolicy(): string;
    get description(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nfsDatastore;
    get nfsDatastore(): DataGoogleVmwareengineDatastoreNfsDatastoreList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get state(): string;
    get uid(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
