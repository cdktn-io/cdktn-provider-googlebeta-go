/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleArtifactRegistryDockerImagesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_docker_images#id DataGoogleArtifactRegistryDockerImages#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_docker_images#location DataGoogleArtifactRegistryDockerImages#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_docker_images#project DataGoogleArtifactRegistryDockerImages#project}
    */
    readonly project?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_docker_images#repository_id DataGoogleArtifactRegistryDockerImages#repository_id}
    */
    readonly repositoryId: string;
}
export interface DataGoogleArtifactRegistryDockerImagesDockerImages {
}
export declare function dataGoogleArtifactRegistryDockerImagesDockerImagesToTerraform(struct?: DataGoogleArtifactRegistryDockerImagesDockerImages): any;
export declare function dataGoogleArtifactRegistryDockerImagesDockerImagesToHclTerraform(struct?: DataGoogleArtifactRegistryDockerImagesDockerImages): any;
export declare class DataGoogleArtifactRegistryDockerImagesDockerImagesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleArtifactRegistryDockerImagesDockerImages | undefined;
    set internalValue(value: DataGoogleArtifactRegistryDockerImagesDockerImages | undefined);
    get buildTime(): string;
    get imageName(): string;
    get imageSizeBytes(): string;
    get mediaType(): string;
    get name(): string;
    get selfLink(): string;
    get tags(): string[];
    get updateTime(): string;
    get uploadTime(): string;
}
export declare class DataGoogleArtifactRegistryDockerImagesDockerImagesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleArtifactRegistryDockerImagesDockerImagesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_docker_images google_artifact_registry_docker_images}
*/
export declare class DataGoogleArtifactRegistryDockerImages extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_artifact_registry_docker_images";
    /**
    * Generates CDKTN code for importing a DataGoogleArtifactRegistryDockerImages resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleArtifactRegistryDockerImages to import
    * @param importFromId The id of the existing DataGoogleArtifactRegistryDockerImages that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_docker_images#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleArtifactRegistryDockerImages to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_artifact_registry_docker_images google_artifact_registry_docker_images} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleArtifactRegistryDockerImagesConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleArtifactRegistryDockerImagesConfig);
    private _dockerImages;
    get dockerImages(): DataGoogleArtifactRegistryDockerImagesDockerImagesList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _repositoryId?;
    get repositoryId(): string;
    set repositoryId(value: string);
    get repositoryIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
