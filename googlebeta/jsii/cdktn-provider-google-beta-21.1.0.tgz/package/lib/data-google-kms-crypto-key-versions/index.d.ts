/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleKmsCryptoKeyVersionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_crypto_key_versions#crypto_key DataGoogleKmsCryptoKeyVersions#crypto_key}
    */
    readonly cryptoKey: string;
    /**
    *
    * 					The filter argument is used to add a filter query parameter that limits which cryptoKeyVersions are retrieved by the data source: ?filter={{filter}}.
    * 					Example values:
    *
    * 					* "name:my-cryptokey-version-" will retrieve cryptoKeyVersions that contain "my-key-" anywhere in their name. Note: names take the form projects/{{project}}/locations/{{location}}/keyRings/{{keyRing}}/cryptoKeys/{{cryptoKey}}/cryptoKeyVersions/{{cryptoKeyVersion}}.
    * 					* "name=projects/my-project/locations/global/keyRings/my-key-ring/cryptoKeys/my-key-1/cryptoKeyVersions/1" will only retrieve a key with that exact name.
    *
    * 					[See the documentation about using filters](https://cloud.google.com/kms/docs/sorting-and-filtering)
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_crypto_key_versions#filter DataGoogleKmsCryptoKeyVersions#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_crypto_key_versions#id DataGoogleKmsCryptoKeyVersions#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataGoogleKmsCryptoKeyVersionsPublicKey {
}
export declare function dataGoogleKmsCryptoKeyVersionsPublicKeyToTerraform(struct?: DataGoogleKmsCryptoKeyVersionsPublicKey): any;
export declare function dataGoogleKmsCryptoKeyVersionsPublicKeyToHclTerraform(struct?: DataGoogleKmsCryptoKeyVersionsPublicKey): any;
export declare class DataGoogleKmsCryptoKeyVersionsPublicKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleKmsCryptoKeyVersionsPublicKey | undefined;
    set internalValue(value: DataGoogleKmsCryptoKeyVersionsPublicKey | undefined);
    get algorithm(): string;
    get pem(): string;
}
export declare class DataGoogleKmsCryptoKeyVersionsPublicKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleKmsCryptoKeyVersionsPublicKeyOutputReference;
}
export interface DataGoogleKmsCryptoKeyVersionsVersionsPublicKey {
}
export declare function dataGoogleKmsCryptoKeyVersionsVersionsPublicKeyToTerraform(struct?: DataGoogleKmsCryptoKeyVersionsVersionsPublicKey): any;
export declare function dataGoogleKmsCryptoKeyVersionsVersionsPublicKeyToHclTerraform(struct?: DataGoogleKmsCryptoKeyVersionsVersionsPublicKey): any;
export declare class DataGoogleKmsCryptoKeyVersionsVersionsPublicKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleKmsCryptoKeyVersionsVersionsPublicKey | undefined;
    set internalValue(value: DataGoogleKmsCryptoKeyVersionsVersionsPublicKey | undefined);
    get algorithm(): string;
    get pem(): string;
}
export declare class DataGoogleKmsCryptoKeyVersionsVersionsPublicKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleKmsCryptoKeyVersionsVersionsPublicKeyOutputReference;
}
export interface DataGoogleKmsCryptoKeyVersionsVersions {
}
export declare function dataGoogleKmsCryptoKeyVersionsVersionsToTerraform(struct?: DataGoogleKmsCryptoKeyVersionsVersions): any;
export declare function dataGoogleKmsCryptoKeyVersionsVersionsToHclTerraform(struct?: DataGoogleKmsCryptoKeyVersionsVersions): any;
export declare class DataGoogleKmsCryptoKeyVersionsVersionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleKmsCryptoKeyVersionsVersions | undefined;
    set internalValue(value: DataGoogleKmsCryptoKeyVersionsVersions | undefined);
    get algorithm(): string;
    get cryptoKey(): string;
    get id(): string;
    get name(): string;
    get protectionLevel(): string;
    private _publicKey;
    get publicKey(): DataGoogleKmsCryptoKeyVersionsVersionsPublicKeyList;
    get state(): string;
    get version(): number;
}
export declare class DataGoogleKmsCryptoKeyVersionsVersionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleKmsCryptoKeyVersionsVersionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_crypto_key_versions google_kms_crypto_key_versions}
*/
export declare class DataGoogleKmsCryptoKeyVersions extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_kms_crypto_key_versions";
    /**
    * Generates CDKTN code for importing a DataGoogleKmsCryptoKeyVersions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleKmsCryptoKeyVersions to import
    * @param importFromId The id of the existing DataGoogleKmsCryptoKeyVersions that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_crypto_key_versions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleKmsCryptoKeyVersions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_crypto_key_versions google_kms_crypto_key_versions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleKmsCryptoKeyVersionsConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleKmsCryptoKeyVersionsConfig);
    private _cryptoKey?;
    get cryptoKey(): string;
    set cryptoKey(value: string);
    get cryptoKeyInput(): string | undefined;
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _publicKey;
    get publicKey(): DataGoogleKmsCryptoKeyVersionsPublicKeyList;
    private _versions;
    get versions(): DataGoogleKmsCryptoKeyVersionsVersionsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
