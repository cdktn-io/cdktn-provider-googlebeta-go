/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleComputeRegionBackendServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_region_backend_service#id DataGoogleComputeRegionBackendService#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the resource. Provided by the client when the resource is
    * created. The name must be 1-63 characters long, and comply with
    * RFC1035. Specifically, the name must be 1-63 characters long and match
    * the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the
    * first character must be a lowercase letter, and all following
    * characters must be a dash, lowercase letter, or digit, except the last
    * character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_region_backend_service#name DataGoogleComputeRegionBackendService#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_region_backend_service#project DataGoogleComputeRegionBackendService#project}
    */
    readonly project?: string;
    /**
    * The Region in which the created backend service should reside.
    * If it is not provided, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_region_backend_service#region DataGoogleComputeRegionBackendService#region}
    */
    readonly region?: string;
}
export interface DataGoogleComputeRegionBackendServiceBackendCustomMetrics {
}
export declare function dataGoogleComputeRegionBackendServiceBackendCustomMetricsToTerraform(struct?: DataGoogleComputeRegionBackendServiceBackendCustomMetrics): any;
export declare function dataGoogleComputeRegionBackendServiceBackendCustomMetricsToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceBackendCustomMetrics): any;
export declare class DataGoogleComputeRegionBackendServiceBackendCustomMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceBackendCustomMetrics | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceBackendCustomMetrics | undefined);
    get dryRun(): cdktn.IResolvable;
    get maxUtilization(): number;
    get name(): string;
}
export declare class DataGoogleComputeRegionBackendServiceBackendCustomMetricsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceBackendCustomMetricsOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceBackend {
}
export declare function dataGoogleComputeRegionBackendServiceBackendToTerraform(struct?: DataGoogleComputeRegionBackendServiceBackend): any;
export declare function dataGoogleComputeRegionBackendServiceBackendToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceBackend): any;
export declare class DataGoogleComputeRegionBackendServiceBackendOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceBackend | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceBackend | undefined);
    get balancingMode(): string;
    get capacityScaler(): number;
    private _customMetrics;
    get customMetrics(): DataGoogleComputeRegionBackendServiceBackendCustomMetricsList;
    get description(): string;
    get failover(): cdktn.IResolvable;
    get group(): string;
    get maxConnections(): number;
    get maxConnectionsPerEndpoint(): number;
    get maxConnectionsPerInstance(): number;
    get maxInFlightRequests(): number;
    get maxInFlightRequestsPerEndpoint(): number;
    get maxInFlightRequestsPerInstance(): number;
    get maxRate(): number;
    get maxRatePerEndpoint(): number;
    get maxRatePerInstance(): number;
    get maxUtilization(): number;
    get trafficDuration(): string;
}
export declare class DataGoogleComputeRegionBackendServiceBackendList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceBackendOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceCdnPolicyCacheKeyPolicy {
}
export declare function dataGoogleComputeRegionBackendServiceCdnPolicyCacheKeyPolicyToTerraform(struct?: DataGoogleComputeRegionBackendServiceCdnPolicyCacheKeyPolicy): any;
export declare function dataGoogleComputeRegionBackendServiceCdnPolicyCacheKeyPolicyToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceCdnPolicyCacheKeyPolicy): any;
export declare class DataGoogleComputeRegionBackendServiceCdnPolicyCacheKeyPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceCdnPolicyCacheKeyPolicy | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceCdnPolicyCacheKeyPolicy | undefined);
    get includeHost(): cdktn.IResolvable;
    get includeNamedCookies(): string[];
    get includeProtocol(): cdktn.IResolvable;
    get includeQueryString(): cdktn.IResolvable;
    get queryStringBlacklist(): string[];
    get queryStringWhitelist(): string[];
}
export declare class DataGoogleComputeRegionBackendServiceCdnPolicyCacheKeyPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceCdnPolicyCacheKeyPolicyOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceCdnPolicyNegativeCachingPolicy {
}
export declare function dataGoogleComputeRegionBackendServiceCdnPolicyNegativeCachingPolicyToTerraform(struct?: DataGoogleComputeRegionBackendServiceCdnPolicyNegativeCachingPolicy): any;
export declare function dataGoogleComputeRegionBackendServiceCdnPolicyNegativeCachingPolicyToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceCdnPolicyNegativeCachingPolicy): any;
export declare class DataGoogleComputeRegionBackendServiceCdnPolicyNegativeCachingPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceCdnPolicyNegativeCachingPolicy | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceCdnPolicyNegativeCachingPolicy | undefined);
    get code(): number;
    get ttl(): number;
}
export declare class DataGoogleComputeRegionBackendServiceCdnPolicyNegativeCachingPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceCdnPolicyNegativeCachingPolicyOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceCdnPolicy {
}
export declare function dataGoogleComputeRegionBackendServiceCdnPolicyToTerraform(struct?: DataGoogleComputeRegionBackendServiceCdnPolicy): any;
export declare function dataGoogleComputeRegionBackendServiceCdnPolicyToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceCdnPolicy): any;
export declare class DataGoogleComputeRegionBackendServiceCdnPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceCdnPolicy | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceCdnPolicy | undefined);
    private _cacheKeyPolicy;
    get cacheKeyPolicy(): DataGoogleComputeRegionBackendServiceCdnPolicyCacheKeyPolicyList;
    get cacheMode(): string;
    get clientTtl(): number;
    get defaultTtl(): number;
    get maxTtl(): number;
    get negativeCaching(): cdktn.IResolvable;
    private _negativeCachingPolicy;
    get negativeCachingPolicy(): DataGoogleComputeRegionBackendServiceCdnPolicyNegativeCachingPolicyList;
    get serveWhileStale(): number;
    get signedUrlCacheMaxAgeSec(): number;
}
export declare class DataGoogleComputeRegionBackendServiceCdnPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceCdnPolicyOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceCircuitBreakersConnectTimeout {
}
export declare function dataGoogleComputeRegionBackendServiceCircuitBreakersConnectTimeoutToTerraform(struct?: DataGoogleComputeRegionBackendServiceCircuitBreakersConnectTimeout): any;
export declare function dataGoogleComputeRegionBackendServiceCircuitBreakersConnectTimeoutToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceCircuitBreakersConnectTimeout): any;
export declare class DataGoogleComputeRegionBackendServiceCircuitBreakersConnectTimeoutOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceCircuitBreakersConnectTimeout | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceCircuitBreakersConnectTimeout | undefined);
    get nanos(): number;
    get seconds(): number;
}
export declare class DataGoogleComputeRegionBackendServiceCircuitBreakersConnectTimeoutList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceCircuitBreakersConnectTimeoutOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceCircuitBreakers {
}
export declare function dataGoogleComputeRegionBackendServiceCircuitBreakersToTerraform(struct?: DataGoogleComputeRegionBackendServiceCircuitBreakers): any;
export declare function dataGoogleComputeRegionBackendServiceCircuitBreakersToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceCircuitBreakers): any;
export declare class DataGoogleComputeRegionBackendServiceCircuitBreakersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceCircuitBreakers | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceCircuitBreakers | undefined);
    private _connectTimeout;
    get connectTimeout(): DataGoogleComputeRegionBackendServiceCircuitBreakersConnectTimeoutList;
    get maxConnections(): number;
    get maxPendingRequests(): number;
    get maxRequests(): number;
    get maxRequestsPerConnection(): number;
    get maxRetries(): number;
}
export declare class DataGoogleComputeRegionBackendServiceCircuitBreakersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceCircuitBreakersOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceConnectionTrackingPolicy {
}
export declare function dataGoogleComputeRegionBackendServiceConnectionTrackingPolicyToTerraform(struct?: DataGoogleComputeRegionBackendServiceConnectionTrackingPolicy): any;
export declare function dataGoogleComputeRegionBackendServiceConnectionTrackingPolicyToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceConnectionTrackingPolicy): any;
export declare class DataGoogleComputeRegionBackendServiceConnectionTrackingPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceConnectionTrackingPolicy | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceConnectionTrackingPolicy | undefined);
    get connectionPersistenceOnUnhealthyBackends(): string;
    get enableStrongAffinity(): cdktn.IResolvable;
    get idleTimeoutSec(): number;
    get trackingMode(): string;
}
export declare class DataGoogleComputeRegionBackendServiceConnectionTrackingPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceConnectionTrackingPolicyOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceConsistentHashHttpCookieTtl {
}
export declare function dataGoogleComputeRegionBackendServiceConsistentHashHttpCookieTtlToTerraform(struct?: DataGoogleComputeRegionBackendServiceConsistentHashHttpCookieTtl): any;
export declare function dataGoogleComputeRegionBackendServiceConsistentHashHttpCookieTtlToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceConsistentHashHttpCookieTtl): any;
export declare class DataGoogleComputeRegionBackendServiceConsistentHashHttpCookieTtlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceConsistentHashHttpCookieTtl | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceConsistentHashHttpCookieTtl | undefined);
    get nanos(): number;
    get seconds(): number;
}
export declare class DataGoogleComputeRegionBackendServiceConsistentHashHttpCookieTtlList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceConsistentHashHttpCookieTtlOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceConsistentHashHttpCookie {
}
export declare function dataGoogleComputeRegionBackendServiceConsistentHashHttpCookieToTerraform(struct?: DataGoogleComputeRegionBackendServiceConsistentHashHttpCookie): any;
export declare function dataGoogleComputeRegionBackendServiceConsistentHashHttpCookieToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceConsistentHashHttpCookie): any;
export declare class DataGoogleComputeRegionBackendServiceConsistentHashHttpCookieOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceConsistentHashHttpCookie | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceConsistentHashHttpCookie | undefined);
    get name(): string;
    get path(): string;
    private _ttl;
    get ttl(): DataGoogleComputeRegionBackendServiceConsistentHashHttpCookieTtlList;
}
export declare class DataGoogleComputeRegionBackendServiceConsistentHashHttpCookieList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceConsistentHashHttpCookieOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceConsistentHash {
}
export declare function dataGoogleComputeRegionBackendServiceConsistentHashToTerraform(struct?: DataGoogleComputeRegionBackendServiceConsistentHash): any;
export declare function dataGoogleComputeRegionBackendServiceConsistentHashToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceConsistentHash): any;
export declare class DataGoogleComputeRegionBackendServiceConsistentHashOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceConsistentHash | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceConsistentHash | undefined);
    private _httpCookie;
    get httpCookie(): DataGoogleComputeRegionBackendServiceConsistentHashHttpCookieList;
    get httpHeaderName(): string;
    get minimumRingSize(): number;
}
export declare class DataGoogleComputeRegionBackendServiceConsistentHashList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceConsistentHashOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceCustomMetrics {
}
export declare function dataGoogleComputeRegionBackendServiceCustomMetricsToTerraform(struct?: DataGoogleComputeRegionBackendServiceCustomMetrics): any;
export declare function dataGoogleComputeRegionBackendServiceCustomMetricsToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceCustomMetrics): any;
export declare class DataGoogleComputeRegionBackendServiceCustomMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceCustomMetrics | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceCustomMetrics | undefined);
    get dryRun(): cdktn.IResolvable;
    get name(): string;
}
export declare class DataGoogleComputeRegionBackendServiceCustomMetricsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceCustomMetricsOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceDynamicForwardingForwardProxy {
}
export declare function dataGoogleComputeRegionBackendServiceDynamicForwardingForwardProxyToTerraform(struct?: DataGoogleComputeRegionBackendServiceDynamicForwardingForwardProxy): any;
export declare function dataGoogleComputeRegionBackendServiceDynamicForwardingForwardProxyToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceDynamicForwardingForwardProxy): any;
export declare class DataGoogleComputeRegionBackendServiceDynamicForwardingForwardProxyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceDynamicForwardingForwardProxy | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceDynamicForwardingForwardProxy | undefined);
    get enabled(): cdktn.IResolvable;
    get proxyMode(): string;
}
export declare class DataGoogleComputeRegionBackendServiceDynamicForwardingForwardProxyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceDynamicForwardingForwardProxyOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceDynamicForwardingIpPortSelection {
}
export declare function dataGoogleComputeRegionBackendServiceDynamicForwardingIpPortSelectionToTerraform(struct?: DataGoogleComputeRegionBackendServiceDynamicForwardingIpPortSelection): any;
export declare function dataGoogleComputeRegionBackendServiceDynamicForwardingIpPortSelectionToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceDynamicForwardingIpPortSelection): any;
export declare class DataGoogleComputeRegionBackendServiceDynamicForwardingIpPortSelectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceDynamicForwardingIpPortSelection | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceDynamicForwardingIpPortSelection | undefined);
    get enabled(): cdktn.IResolvable;
}
export declare class DataGoogleComputeRegionBackendServiceDynamicForwardingIpPortSelectionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceDynamicForwardingIpPortSelectionOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceDynamicForwarding {
}
export declare function dataGoogleComputeRegionBackendServiceDynamicForwardingToTerraform(struct?: DataGoogleComputeRegionBackendServiceDynamicForwarding): any;
export declare function dataGoogleComputeRegionBackendServiceDynamicForwardingToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceDynamicForwarding): any;
export declare class DataGoogleComputeRegionBackendServiceDynamicForwardingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceDynamicForwarding | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceDynamicForwarding | undefined);
    private _forwardProxy;
    get forwardProxy(): DataGoogleComputeRegionBackendServiceDynamicForwardingForwardProxyList;
    private _ipPortSelection;
    get ipPortSelection(): DataGoogleComputeRegionBackendServiceDynamicForwardingIpPortSelectionList;
}
export declare class DataGoogleComputeRegionBackendServiceDynamicForwardingList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceDynamicForwardingOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceFailoverPolicy {
}
export declare function dataGoogleComputeRegionBackendServiceFailoverPolicyToTerraform(struct?: DataGoogleComputeRegionBackendServiceFailoverPolicy): any;
export declare function dataGoogleComputeRegionBackendServiceFailoverPolicyToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceFailoverPolicy): any;
export declare class DataGoogleComputeRegionBackendServiceFailoverPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceFailoverPolicy | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceFailoverPolicy | undefined);
    get disableConnectionDrainOnFailover(): cdktn.IResolvable;
    get dropTrafficIfUnhealthy(): cdktn.IResolvable;
    get failoverRatio(): number;
}
export declare class DataGoogleComputeRegionBackendServiceFailoverPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceFailoverPolicyOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceHaPolicyLeaderNetworkEndpoint {
}
export declare function dataGoogleComputeRegionBackendServiceHaPolicyLeaderNetworkEndpointToTerraform(struct?: DataGoogleComputeRegionBackendServiceHaPolicyLeaderNetworkEndpoint): any;
export declare function dataGoogleComputeRegionBackendServiceHaPolicyLeaderNetworkEndpointToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceHaPolicyLeaderNetworkEndpoint): any;
export declare class DataGoogleComputeRegionBackendServiceHaPolicyLeaderNetworkEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceHaPolicyLeaderNetworkEndpoint | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceHaPolicyLeaderNetworkEndpoint | undefined);
    get instance(): string;
}
export declare class DataGoogleComputeRegionBackendServiceHaPolicyLeaderNetworkEndpointList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceHaPolicyLeaderNetworkEndpointOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceHaPolicyLeader {
}
export declare function dataGoogleComputeRegionBackendServiceHaPolicyLeaderToTerraform(struct?: DataGoogleComputeRegionBackendServiceHaPolicyLeader): any;
export declare function dataGoogleComputeRegionBackendServiceHaPolicyLeaderToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceHaPolicyLeader): any;
export declare class DataGoogleComputeRegionBackendServiceHaPolicyLeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceHaPolicyLeader | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceHaPolicyLeader | undefined);
    get backendGroup(): string;
    private _networkEndpoint;
    get networkEndpoint(): DataGoogleComputeRegionBackendServiceHaPolicyLeaderNetworkEndpointList;
}
export declare class DataGoogleComputeRegionBackendServiceHaPolicyLeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceHaPolicyLeaderOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceHaPolicy {
}
export declare function dataGoogleComputeRegionBackendServiceHaPolicyToTerraform(struct?: DataGoogleComputeRegionBackendServiceHaPolicy): any;
export declare function dataGoogleComputeRegionBackendServiceHaPolicyToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceHaPolicy): any;
export declare class DataGoogleComputeRegionBackendServiceHaPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceHaPolicy | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceHaPolicy | undefined);
    get fastIpMove(): string;
    private _leader;
    get leader(): DataGoogleComputeRegionBackendServiceHaPolicyLeaderList;
}
export declare class DataGoogleComputeRegionBackendServiceHaPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceHaPolicyOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceIap {
}
export declare function dataGoogleComputeRegionBackendServiceIapToTerraform(struct?: DataGoogleComputeRegionBackendServiceIap): any;
export declare function dataGoogleComputeRegionBackendServiceIapToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceIap): any;
export declare class DataGoogleComputeRegionBackendServiceIapOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceIap | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceIap | undefined);
    get enabled(): cdktn.IResolvable;
    get oauth2ClientId(): string;
    get oauth2ClientSecret(): string;
    get oauth2ClientSecretSha256(): string;
}
export declare class DataGoogleComputeRegionBackendServiceIapList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceIapOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceLogConfigRequestHeaders {
}
export declare function dataGoogleComputeRegionBackendServiceLogConfigRequestHeadersToTerraform(struct?: DataGoogleComputeRegionBackendServiceLogConfigRequestHeaders): any;
export declare function dataGoogleComputeRegionBackendServiceLogConfigRequestHeadersToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceLogConfigRequestHeaders): any;
export declare class DataGoogleComputeRegionBackendServiceLogConfigRequestHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceLogConfigRequestHeaders | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceLogConfigRequestHeaders | undefined);
    get headerName(): string;
}
export declare class DataGoogleComputeRegionBackendServiceLogConfigRequestHeadersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceLogConfigRequestHeadersOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceLogConfigResponseHeaders {
}
export declare function dataGoogleComputeRegionBackendServiceLogConfigResponseHeadersToTerraform(struct?: DataGoogleComputeRegionBackendServiceLogConfigResponseHeaders): any;
export declare function dataGoogleComputeRegionBackendServiceLogConfigResponseHeadersToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceLogConfigResponseHeaders): any;
export declare class DataGoogleComputeRegionBackendServiceLogConfigResponseHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceLogConfigResponseHeaders | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceLogConfigResponseHeaders | undefined);
    get headerName(): string;
}
export declare class DataGoogleComputeRegionBackendServiceLogConfigResponseHeadersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceLogConfigResponseHeadersOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceLogConfig {
}
export declare function dataGoogleComputeRegionBackendServiceLogConfigToTerraform(struct?: DataGoogleComputeRegionBackendServiceLogConfig): any;
export declare function dataGoogleComputeRegionBackendServiceLogConfigToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceLogConfig): any;
export declare class DataGoogleComputeRegionBackendServiceLogConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceLogConfig | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceLogConfig | undefined);
    get enable(): cdktn.IResolvable;
    get optionalFields(): string[];
    get optionalMode(): string;
    private _requestHeaders;
    get requestHeaders(): DataGoogleComputeRegionBackendServiceLogConfigRequestHeadersList;
    private _responseHeaders;
    get responseHeaders(): DataGoogleComputeRegionBackendServiceLogConfigResponseHeadersList;
    get sampleRate(): number;
}
export declare class DataGoogleComputeRegionBackendServiceLogConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceLogConfigOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinity {
}
export declare function dataGoogleComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinityToTerraform(struct?: DataGoogleComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinity): any;
export declare function dataGoogleComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinityToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinity): any;
export declare class DataGoogleComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinity | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinity | undefined);
    get spillover(): string;
    get spilloverRatio(): number;
}
export declare class DataGoogleComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinityOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicy {
}
export declare function dataGoogleComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyToTerraform(struct?: DataGoogleComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicy): any;
export declare function dataGoogleComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicy): any;
export declare class DataGoogleComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicy | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicy | undefined);
    private _zonalAffinity;
    get zonalAffinity(): DataGoogleComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinityList;
}
export declare class DataGoogleComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceOutlierDetectionBaseEjectionTime {
}
export declare function dataGoogleComputeRegionBackendServiceOutlierDetectionBaseEjectionTimeToTerraform(struct?: DataGoogleComputeRegionBackendServiceOutlierDetectionBaseEjectionTime): any;
export declare function dataGoogleComputeRegionBackendServiceOutlierDetectionBaseEjectionTimeToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceOutlierDetectionBaseEjectionTime): any;
export declare class DataGoogleComputeRegionBackendServiceOutlierDetectionBaseEjectionTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceOutlierDetectionBaseEjectionTime | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceOutlierDetectionBaseEjectionTime | undefined);
    get nanos(): number;
    get seconds(): number;
}
export declare class DataGoogleComputeRegionBackendServiceOutlierDetectionBaseEjectionTimeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceOutlierDetectionBaseEjectionTimeOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceOutlierDetectionInterval {
}
export declare function dataGoogleComputeRegionBackendServiceOutlierDetectionIntervalToTerraform(struct?: DataGoogleComputeRegionBackendServiceOutlierDetectionInterval): any;
export declare function dataGoogleComputeRegionBackendServiceOutlierDetectionIntervalToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceOutlierDetectionInterval): any;
export declare class DataGoogleComputeRegionBackendServiceOutlierDetectionIntervalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceOutlierDetectionInterval | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceOutlierDetectionInterval | undefined);
    get nanos(): number;
    get seconds(): number;
}
export declare class DataGoogleComputeRegionBackendServiceOutlierDetectionIntervalList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceOutlierDetectionIntervalOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceOutlierDetection {
}
export declare function dataGoogleComputeRegionBackendServiceOutlierDetectionToTerraform(struct?: DataGoogleComputeRegionBackendServiceOutlierDetection): any;
export declare function dataGoogleComputeRegionBackendServiceOutlierDetectionToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceOutlierDetection): any;
export declare class DataGoogleComputeRegionBackendServiceOutlierDetectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceOutlierDetection | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceOutlierDetection | undefined);
    private _baseEjectionTime;
    get baseEjectionTime(): DataGoogleComputeRegionBackendServiceOutlierDetectionBaseEjectionTimeList;
    get consecutiveErrors(): number;
    get consecutiveGatewayFailure(): number;
    get enforcingConsecutiveErrors(): number;
    get enforcingConsecutiveGatewayFailure(): number;
    get enforcingSuccessRate(): number;
    private _interval;
    get interval(): DataGoogleComputeRegionBackendServiceOutlierDetectionIntervalList;
    get maxEjectionPercent(): number;
    get successRateMinimumHosts(): number;
    get successRateRequestVolume(): number;
    get successRateStdevFactor(): number;
}
export declare class DataGoogleComputeRegionBackendServiceOutlierDetectionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceOutlierDetectionOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceParams {
}
export declare function dataGoogleComputeRegionBackendServiceParamsToTerraform(struct?: DataGoogleComputeRegionBackendServiceParams): any;
export declare function dataGoogleComputeRegionBackendServiceParamsToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceParams): any;
export declare class DataGoogleComputeRegionBackendServiceParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceParams | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceParams | undefined);
    private _resourceManagerTags;
    get resourceManagerTags(): cdktn.StringMap;
}
export declare class DataGoogleComputeRegionBackendServiceParamsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceParamsOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceStrongSessionAffinityCookieTtl {
}
export declare function dataGoogleComputeRegionBackendServiceStrongSessionAffinityCookieTtlToTerraform(struct?: DataGoogleComputeRegionBackendServiceStrongSessionAffinityCookieTtl): any;
export declare function dataGoogleComputeRegionBackendServiceStrongSessionAffinityCookieTtlToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceStrongSessionAffinityCookieTtl): any;
export declare class DataGoogleComputeRegionBackendServiceStrongSessionAffinityCookieTtlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceStrongSessionAffinityCookieTtl | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceStrongSessionAffinityCookieTtl | undefined);
    get nanos(): number;
    get seconds(): number;
}
export declare class DataGoogleComputeRegionBackendServiceStrongSessionAffinityCookieTtlList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceStrongSessionAffinityCookieTtlOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceStrongSessionAffinityCookie {
}
export declare function dataGoogleComputeRegionBackendServiceStrongSessionAffinityCookieToTerraform(struct?: DataGoogleComputeRegionBackendServiceStrongSessionAffinityCookie): any;
export declare function dataGoogleComputeRegionBackendServiceStrongSessionAffinityCookieToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceStrongSessionAffinityCookie): any;
export declare class DataGoogleComputeRegionBackendServiceStrongSessionAffinityCookieOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceStrongSessionAffinityCookie | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceStrongSessionAffinityCookie | undefined);
    get name(): string;
    get path(): string;
    private _ttl;
    get ttl(): DataGoogleComputeRegionBackendServiceStrongSessionAffinityCookieTtlList;
}
export declare class DataGoogleComputeRegionBackendServiceStrongSessionAffinityCookieList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceStrongSessionAffinityCookieOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceSubsetting {
}
export declare function dataGoogleComputeRegionBackendServiceSubsettingToTerraform(struct?: DataGoogleComputeRegionBackendServiceSubsetting): any;
export declare function dataGoogleComputeRegionBackendServiceSubsettingToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceSubsetting): any;
export declare class DataGoogleComputeRegionBackendServiceSubsettingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceSubsetting | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceSubsetting | undefined);
    get policy(): string;
    get subsetSize(): number;
}
export declare class DataGoogleComputeRegionBackendServiceSubsettingList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceSubsettingOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceTlsSettingsSubjectAltNames {
}
export declare function dataGoogleComputeRegionBackendServiceTlsSettingsSubjectAltNamesToTerraform(struct?: DataGoogleComputeRegionBackendServiceTlsSettingsSubjectAltNames): any;
export declare function dataGoogleComputeRegionBackendServiceTlsSettingsSubjectAltNamesToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceTlsSettingsSubjectAltNames): any;
export declare class DataGoogleComputeRegionBackendServiceTlsSettingsSubjectAltNamesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceTlsSettingsSubjectAltNames | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceTlsSettingsSubjectAltNames | undefined);
    get dnsName(): string;
    get uniformResourceIdentifier(): string;
}
export declare class DataGoogleComputeRegionBackendServiceTlsSettingsSubjectAltNamesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceTlsSettingsSubjectAltNamesOutputReference;
}
export interface DataGoogleComputeRegionBackendServiceTlsSettings {
}
export declare function dataGoogleComputeRegionBackendServiceTlsSettingsToTerraform(struct?: DataGoogleComputeRegionBackendServiceTlsSettings): any;
export declare function dataGoogleComputeRegionBackendServiceTlsSettingsToHclTerraform(struct?: DataGoogleComputeRegionBackendServiceTlsSettings): any;
export declare class DataGoogleComputeRegionBackendServiceTlsSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionBackendServiceTlsSettings | undefined;
    set internalValue(value: DataGoogleComputeRegionBackendServiceTlsSettings | undefined);
    get authenticationConfig(): string;
    get identity(): string;
    get sni(): string;
    private _subjectAltNames;
    get subjectAltNames(): DataGoogleComputeRegionBackendServiceTlsSettingsSubjectAltNamesList;
}
export declare class DataGoogleComputeRegionBackendServiceTlsSettingsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionBackendServiceTlsSettingsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_region_backend_service google_compute_region_backend_service}
*/
export declare class DataGoogleComputeRegionBackendService extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_compute_region_backend_service";
    /**
    * Generates CDKTN code for importing a DataGoogleComputeRegionBackendService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleComputeRegionBackendService to import
    * @param importFromId The id of the existing DataGoogleComputeRegionBackendService that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_region_backend_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleComputeRegionBackendService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_region_backend_service google_compute_region_backend_service} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleComputeRegionBackendServiceConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleComputeRegionBackendServiceConfig);
    get affinityCookieTtlSec(): number;
    private _backend;
    get backend(): DataGoogleComputeRegionBackendServiceBackendList;
    private _cdnPolicy;
    get cdnPolicy(): DataGoogleComputeRegionBackendServiceCdnPolicyList;
    private _circuitBreakers;
    get circuitBreakers(): DataGoogleComputeRegionBackendServiceCircuitBreakersList;
    get connectionDrainingTimeoutSec(): number;
    private _connectionTrackingPolicy;
    get connectionTrackingPolicy(): DataGoogleComputeRegionBackendServiceConnectionTrackingPolicyList;
    private _consistentHash;
    get consistentHash(): DataGoogleComputeRegionBackendServiceConsistentHashList;
    get creationTimestamp(): string;
    private _customMetrics;
    get customMetrics(): DataGoogleComputeRegionBackendServiceCustomMetricsList;
    get deletionPolicy(): string;
    get description(): string;
    private _dynamicForwarding;
    get dynamicForwarding(): DataGoogleComputeRegionBackendServiceDynamicForwardingList;
    get enableCdn(): cdktn.IResolvable;
    private _failoverPolicy;
    get failoverPolicy(): DataGoogleComputeRegionBackendServiceFailoverPolicyList;
    get fingerprint(): string;
    get generatedId(): number;
    private _haPolicy;
    get haPolicy(): DataGoogleComputeRegionBackendServiceHaPolicyList;
    get healthChecks(): string[];
    private _iap;
    get iap(): DataGoogleComputeRegionBackendServiceIapList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ipAddressSelectionPolicy(): string;
    get loadBalancingScheme(): string;
    get localityLbPolicy(): string;
    private _logConfig;
    get logConfig(): DataGoogleComputeRegionBackendServiceLogConfigList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get network(): string;
    private _networkPassThroughLbTrafficPolicy;
    get networkPassThroughLbTrafficPolicy(): DataGoogleComputeRegionBackendServiceNetworkPassThroughLbTrafficPolicyList;
    private _outlierDetection;
    get outlierDetection(): DataGoogleComputeRegionBackendServiceOutlierDetectionList;
    private _params;
    get params(): DataGoogleComputeRegionBackendServiceParamsList;
    get portName(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get protocol(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get securityPolicy(): string;
    get selfLink(): string;
    get serviceLbPolicy(): string;
    get sessionAffinity(): string;
    private _strongSessionAffinityCookie;
    get strongSessionAffinityCookie(): DataGoogleComputeRegionBackendServiceStrongSessionAffinityCookieList;
    private _subsetting;
    get subsetting(): DataGoogleComputeRegionBackendServiceSubsettingList;
    get timeoutSec(): number;
    private _tlsSettings;
    get tlsSettings(): DataGoogleComputeRegionBackendServiceTlsSettingsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
