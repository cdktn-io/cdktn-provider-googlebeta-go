/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleVpcAccessConnectorConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vpc_access_connector#id DataGoogleVpcAccessConnector#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the resource (Max 25 characters).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vpc_access_connector#name DataGoogleVpcAccessConnector#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vpc_access_connector#project DataGoogleVpcAccessConnector#project}
    */
    readonly project?: string;
    /**
    * Region where the VPC Access connector resides. If it is not provided, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vpc_access_connector#region DataGoogleVpcAccessConnector#region}
    */
    readonly region?: string;
}
export interface DataGoogleVpcAccessConnectorSubnet {
}
export declare function dataGoogleVpcAccessConnectorSubnetToTerraform(struct?: DataGoogleVpcAccessConnectorSubnet): any;
export declare function dataGoogleVpcAccessConnectorSubnetToHclTerraform(struct?: DataGoogleVpcAccessConnectorSubnet): any;
export declare class DataGoogleVpcAccessConnectorSubnetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleVpcAccessConnectorSubnet | undefined;
    set internalValue(value: DataGoogleVpcAccessConnectorSubnet | undefined);
    get name(): string;
    get projectId(): string;
}
export declare class DataGoogleVpcAccessConnectorSubnetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleVpcAccessConnectorSubnetOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vpc_access_connector google_vpc_access_connector}
*/
export declare class DataGoogleVpcAccessConnector extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_vpc_access_connector";
    /**
    * Generates CDKTN code for importing a DataGoogleVpcAccessConnector resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleVpcAccessConnector to import
    * @param importFromId The id of the existing DataGoogleVpcAccessConnector that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vpc_access_connector#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleVpcAccessConnector to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vpc_access_connector google_vpc_access_connector} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleVpcAccessConnectorConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleVpcAccessConnectorConfig);
    get connectedProjects(): string[];
    get deletionPolicy(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ipCidrRange(): string;
    get machineType(): string;
    get maxInstances(): number;
    get maxThroughput(): number;
    get minInstances(): number;
    get minThroughput(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get network(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get selfLink(): string;
    get state(): string;
    private _subnet;
    get subnet(): DataGoogleVpcAccessConnectorSubnetList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
