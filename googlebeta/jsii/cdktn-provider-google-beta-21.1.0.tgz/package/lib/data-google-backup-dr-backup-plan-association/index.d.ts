/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleBackupDrBackupPlanAssociationConfig extends cdktn.TerraformMetaArguments {
    /**
    * The id of backupplan association
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_backup_dr_backup_plan_association#backup_plan_association_id DataGoogleBackupDrBackupPlanAssociation#backup_plan_association_id}
    */
    readonly backupPlanAssociationId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_backup_dr_backup_plan_association#id DataGoogleBackupDrBackupPlanAssociation#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location for the backupplan association
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_backup_dr_backup_plan_association#location DataGoogleBackupDrBackupPlanAssociation#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_backup_dr_backup_plan_association#project DataGoogleBackupDrBackupPlanAssociation#project}
    */
    readonly project?: string;
}
export interface DataGoogleBackupDrBackupPlanAssociationRulesConfigInfoLastBackupError {
}
export declare function dataGoogleBackupDrBackupPlanAssociationRulesConfigInfoLastBackupErrorToTerraform(struct?: DataGoogleBackupDrBackupPlanAssociationRulesConfigInfoLastBackupError): any;
export declare function dataGoogleBackupDrBackupPlanAssociationRulesConfigInfoLastBackupErrorToHclTerraform(struct?: DataGoogleBackupDrBackupPlanAssociationRulesConfigInfoLastBackupError): any;
export declare class DataGoogleBackupDrBackupPlanAssociationRulesConfigInfoLastBackupErrorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrBackupPlanAssociationRulesConfigInfoLastBackupError | undefined;
    set internalValue(value: DataGoogleBackupDrBackupPlanAssociationRulesConfigInfoLastBackupError | undefined);
    get code(): number;
    get message(): string;
}
export declare class DataGoogleBackupDrBackupPlanAssociationRulesConfigInfoLastBackupErrorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrBackupPlanAssociationRulesConfigInfoLastBackupErrorOutputReference;
}
export interface DataGoogleBackupDrBackupPlanAssociationRulesConfigInfo {
}
export declare function dataGoogleBackupDrBackupPlanAssociationRulesConfigInfoToTerraform(struct?: DataGoogleBackupDrBackupPlanAssociationRulesConfigInfo): any;
export declare function dataGoogleBackupDrBackupPlanAssociationRulesConfigInfoToHclTerraform(struct?: DataGoogleBackupDrBackupPlanAssociationRulesConfigInfo): any;
export declare class DataGoogleBackupDrBackupPlanAssociationRulesConfigInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrBackupPlanAssociationRulesConfigInfo | undefined;
    set internalValue(value: DataGoogleBackupDrBackupPlanAssociationRulesConfigInfo | undefined);
    private _lastBackupError;
    get lastBackupError(): DataGoogleBackupDrBackupPlanAssociationRulesConfigInfoLastBackupErrorList;
    get lastBackupState(): string;
    get lastSuccessfulBackupConsistencyTime(): string;
    get ruleId(): string;
}
export declare class DataGoogleBackupDrBackupPlanAssociationRulesConfigInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrBackupPlanAssociationRulesConfigInfoOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_backup_dr_backup_plan_association google_backup_dr_backup_plan_association}
*/
export declare class DataGoogleBackupDrBackupPlanAssociation extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_backup_dr_backup_plan_association";
    /**
    * Generates CDKTN code for importing a DataGoogleBackupDrBackupPlanAssociation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleBackupDrBackupPlanAssociation to import
    * @param importFromId The id of the existing DataGoogleBackupDrBackupPlanAssociation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_backup_dr_backup_plan_association#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleBackupDrBackupPlanAssociation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_backup_dr_backup_plan_association google_backup_dr_backup_plan_association} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleBackupDrBackupPlanAssociationConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleBackupDrBackupPlanAssociationConfig);
    get backupPlan(): string;
    private _backupPlanAssociationId?;
    get backupPlanAssociationId(): string;
    set backupPlanAssociationId(value: string);
    get backupPlanAssociationIdInput(): string | undefined;
    get createTime(): string;
    get dataSource(): string;
    get deletionPolicy(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get resource(): string;
    get resourceType(): string;
    private _rulesConfigInfo;
    get rulesConfigInfo(): DataGoogleBackupDrBackupPlanAssociationRulesConfigInfoList;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
