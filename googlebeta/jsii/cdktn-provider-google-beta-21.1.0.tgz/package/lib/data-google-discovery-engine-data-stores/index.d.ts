/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleDiscoveryEngineDataStoresConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_discovery_engine_data_stores#id DataGoogleDiscoveryEngineDataStores#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The geographic location where the data stores reside. The value can only be one of "global", "us" and "eu".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_discovery_engine_data_stores#location DataGoogleDiscoveryEngineDataStores#location}
    */
    readonly location?: string;
    /**
    * The ID of the project in which the resource belongs. If it is not provided, the provider project is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_discovery_engine_data_stores#project DataGoogleDiscoveryEngineDataStores#project}
    */
    readonly project?: string;
}
export interface DataGoogleDiscoveryEngineDataStoresDataStores {
}
export declare function dataGoogleDiscoveryEngineDataStoresDataStoresToTerraform(struct?: DataGoogleDiscoveryEngineDataStoresDataStores): any;
export declare function dataGoogleDiscoveryEngineDataStoresDataStoresToHclTerraform(struct?: DataGoogleDiscoveryEngineDataStoresDataStores): any;
export declare class DataGoogleDiscoveryEngineDataStoresDataStoresOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleDiscoveryEngineDataStoresDataStores | undefined;
    set internalValue(value: DataGoogleDiscoveryEngineDataStoresDataStores | undefined);
    get contentConfig(): string;
    get createTime(): string;
    get dataStoreId(): string;
    get defaultSchemaId(): string;
    get displayName(): string;
    get industryVertical(): string;
    get name(): string;
    get solutionTypes(): string[];
}
export declare class DataGoogleDiscoveryEngineDataStoresDataStoresList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleDiscoveryEngineDataStoresDataStoresOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_discovery_engine_data_stores google_discovery_engine_data_stores}
*/
export declare class DataGoogleDiscoveryEngineDataStores extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_discovery_engine_data_stores";
    /**
    * Generates CDKTN code for importing a DataGoogleDiscoveryEngineDataStores resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleDiscoveryEngineDataStores to import
    * @param importFromId The id of the existing DataGoogleDiscoveryEngineDataStores that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_discovery_engine_data_stores#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleDiscoveryEngineDataStores to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_discovery_engine_data_stores google_discovery_engine_data_stores} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleDiscoveryEngineDataStoresConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGoogleDiscoveryEngineDataStoresConfig);
    private _dataStores;
    get dataStores(): DataGoogleDiscoveryEngineDataStoresDataStoresList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
