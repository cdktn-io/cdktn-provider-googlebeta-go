/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleOracleDatabaseCloudExadataInfrastructuresConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_oracle_database_cloud_exadata_infrastructures#id DataGoogleOracleDatabaseCloudExadataInfrastructures#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * location
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_oracle_database_cloud_exadata_infrastructures#location DataGoogleOracleDatabaseCloudExadataInfrastructures#location}
    */
    readonly location: string;
    /**
    * The ID of the project in which the dataset is located. If it is not provided, the provider project is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_oracle_database_cloud_exadata_infrastructures#project DataGoogleOracleDatabaseCloudExadataInfrastructures#project}
    */
    readonly project?: string;
}
export interface DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesCustomerContacts {
}
export declare function dataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesCustomerContactsToTerraform(struct?: DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesCustomerContacts): any;
export declare function dataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesCustomerContactsToHclTerraform(struct?: DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesCustomerContacts): any;
export declare class DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesCustomerContactsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesCustomerContacts | undefined;
    set internalValue(value: DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesCustomerContacts | undefined);
    get email(): string;
}
export declare class DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesCustomerContactsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesCustomerContactsOutputReference;
}
export interface DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesExascaleConfig {
}
export declare function dataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesExascaleConfigToTerraform(struct?: DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesExascaleConfig): any;
export declare function dataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesExascaleConfigToHclTerraform(struct?: DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesExascaleConfig): any;
export declare class DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesExascaleConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesExascaleConfig | undefined;
    set internalValue(value: DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesExascaleConfig | undefined);
    get availableStorageSizeGb(): number;
    get availableVmStorageSizeGb(): number;
    get totalStorageSizeGb(): number;
    get totalVmStorageSizeGb(): number;
}
export declare class DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesExascaleConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesExascaleConfigOutputReference;
}
export interface DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesMaintenanceWindow {
}
export declare function dataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesMaintenanceWindowToTerraform(struct?: DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesMaintenanceWindow): any;
export declare function dataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesMaintenanceWindowToHclTerraform(struct?: DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesMaintenanceWindow): any;
export declare class DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesMaintenanceWindow | undefined;
    set internalValue(value: DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesMaintenanceWindow | undefined);
    get customActionTimeoutMins(): number;
    get daysOfWeek(): string[];
    get hoursOfDay(): number[];
    get isCustomActionTimeoutEnabled(): cdktn.IResolvable;
    get leadTimeWeek(): number;
    get months(): string[];
    get patchingMode(): string;
    get preference(): string;
    get weeksOfMonth(): number[];
}
export declare class DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesMaintenanceWindowList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesMaintenanceWindowOutputReference;
}
export interface DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresProperties {
}
export declare function dataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesToTerraform(struct?: DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresProperties): any;
export declare function dataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesToHclTerraform(struct?: DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresProperties): any;
export declare class DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresProperties | undefined;
    set internalValue(value: DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresProperties | undefined);
    get activatedStorageCount(): number;
    get additionalStorageCount(): number;
    get availableStorageSizeGb(): number;
    get computeCount(): number;
    get cpuCount(): number;
    private _customerContacts;
    get customerContacts(): DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesCustomerContactsList;
    get dataStorageSizeTb(): number;
    get dbNodeStorageSizeGb(): number;
    get dbServerVersion(): string;
    private _exascaleConfig;
    get exascaleConfig(): DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesExascaleConfigList;
    private _maintenanceWindow;
    get maintenanceWindow(): DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesMaintenanceWindowList;
    get maxCpuCount(): number;
    get maxDataStorageTb(): number;
    get maxDbNodeStorageSizeGb(): number;
    get maxMemoryGb(): number;
    get memorySizeGb(): number;
    get monthlyDbServerVersion(): string;
    get monthlyStorageServerVersion(): string;
    get nextMaintenanceRunId(): string;
    get nextMaintenanceRunTime(): string;
    get nextSecurityMaintenanceRunTime(): string;
    get ociUrl(): string;
    get ocid(): string;
    get shape(): string;
    get state(): string;
    get storageCount(): number;
    get storageServerVersion(): string;
    get totalStorageSizeGb(): number;
}
export declare class DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesOutputReference;
}
export interface DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructures {
}
export declare function dataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresToTerraform(struct?: DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructures): any;
export declare function dataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresToHclTerraform(struct?: DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructures): any;
export declare class DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructures | undefined;
    set internalValue(value: DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructures | undefined);
    get cloudExadataInfrastructureId(): string;
    get createTime(): string;
    get deletionPolicy(): string;
    get deletionProtection(): cdktn.IResolvable;
    get displayName(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get entitlementId(): string;
    get gcpOracleZone(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    get location(): string;
    get name(): string;
    get project(): string;
    private _properties;
    get properties(): DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresPropertiesList;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
}
export declare class DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_oracle_database_cloud_exadata_infrastructures google_oracle_database_cloud_exadata_infrastructures}
*/
export declare class DataGoogleOracleDatabaseCloudExadataInfrastructures extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_oracle_database_cloud_exadata_infrastructures";
    /**
    * Generates CDKTN code for importing a DataGoogleOracleDatabaseCloudExadataInfrastructures resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleOracleDatabaseCloudExadataInfrastructures to import
    * @param importFromId The id of the existing DataGoogleOracleDatabaseCloudExadataInfrastructures that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_oracle_database_cloud_exadata_infrastructures#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleOracleDatabaseCloudExadataInfrastructures to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_oracle_database_cloud_exadata_infrastructures google_oracle_database_cloud_exadata_infrastructures} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleOracleDatabaseCloudExadataInfrastructuresConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleOracleDatabaseCloudExadataInfrastructuresConfig);
    private _cloudExadataInfrastructures;
    get cloudExadataInfrastructures(): DataGoogleOracleDatabaseCloudExadataInfrastructuresCloudExadataInfrastructuresList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
