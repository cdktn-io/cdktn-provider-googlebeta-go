/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleComputeSecurityPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_security_policy#id DataGoogleComputeSecurityPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the security policy.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_security_policy#name DataGoogleComputeSecurityPolicy#name}
    */
    readonly name?: string;
    /**
    * The project in which the resource belongs. If it is not provided, the provider project is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_security_policy#project DataGoogleComputeSecurityPolicy#project}
    */
    readonly project?: string;
    /**
    * The URI of the created resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_security_policy#self_link DataGoogleComputeSecurityPolicy#self_link}
    */
    readonly selfLink?: string;
}
export interface DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigAutoDeployConfig {
}
export declare function dataGoogleComputeSecurityPolicyAdaptiveProtectionConfigAutoDeployConfigToTerraform(struct?: DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigAutoDeployConfig): any;
export declare function dataGoogleComputeSecurityPolicyAdaptiveProtectionConfigAutoDeployConfigToHclTerraform(struct?: DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigAutoDeployConfig): any;
export declare class DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigAutoDeployConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigAutoDeployConfig | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigAutoDeployConfig | undefined);
    get confidenceThreshold(): number;
    get expirationSec(): number;
    get impactedBaselineThreshold(): number;
    get loadThreshold(): number;
}
export declare class DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigAutoDeployConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigAutoDeployConfigOutputReference;
}
export interface DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsTrafficGranularityConfigs {
}
export declare function dataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsTrafficGranularityConfigsToTerraform(struct?: DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsTrafficGranularityConfigs): any;
export declare function dataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsTrafficGranularityConfigsToHclTerraform(struct?: DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsTrafficGranularityConfigs): any;
export declare class DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsTrafficGranularityConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsTrafficGranularityConfigs | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsTrafficGranularityConfigs | undefined);
    get enableEachUniqueValue(): cdktn.IResolvable;
    get type(): string;
    get value(): string;
}
export declare class DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsTrafficGranularityConfigsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsTrafficGranularityConfigsOutputReference;
}
export interface DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigs {
}
export declare function dataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsToTerraform(struct?: DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigs): any;
export declare function dataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsToHclTerraform(struct?: DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigs): any;
export declare class DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigs | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigs | undefined);
    get autoDeployConfidenceThreshold(): number;
    get autoDeployExpirationSec(): number;
    get autoDeployImpactedBaselineThreshold(): number;
    get autoDeployLoadThreshold(): number;
    get detectionAbsoluteQps(): number;
    get detectionLoadThreshold(): number;
    get detectionRelativeToBaselineQps(): number;
    get name(): string;
    private _trafficGranularityConfigs;
    get trafficGranularityConfigs(): DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsTrafficGranularityConfigsList;
}
export declare class DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsOutputReference;
}
export interface DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfig {
}
export declare function dataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigToTerraform(struct?: DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfig): any;
export declare function dataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigToHclTerraform(struct?: DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfig): any;
export declare class DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfig | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfig | undefined);
    get enable(): cdktn.IResolvable;
    get ruleVisibility(): string;
    private _thresholdConfigs;
    get thresholdConfigs(): DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigThresholdConfigsList;
}
export declare class DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigOutputReference;
}
export interface DataGoogleComputeSecurityPolicyAdaptiveProtectionConfig {
}
export declare function dataGoogleComputeSecurityPolicyAdaptiveProtectionConfigToTerraform(struct?: DataGoogleComputeSecurityPolicyAdaptiveProtectionConfig): any;
export declare function dataGoogleComputeSecurityPolicyAdaptiveProtectionConfigToHclTerraform(struct?: DataGoogleComputeSecurityPolicyAdaptiveProtectionConfig): any;
export declare class DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyAdaptiveProtectionConfig | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyAdaptiveProtectionConfig | undefined);
    private _autoDeployConfig;
    get autoDeployConfig(): DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigAutoDeployConfigList;
    private _layer7DdosDefenseConfig;
    get layer7DdosDefenseConfig(): DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigLayer7DdosDefenseConfigList;
}
export declare class DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigOutputReference;
}
export interface DataGoogleComputeSecurityPolicyAdvancedOptionsConfigJsonCustomConfig {
}
export declare function dataGoogleComputeSecurityPolicyAdvancedOptionsConfigJsonCustomConfigToTerraform(struct?: DataGoogleComputeSecurityPolicyAdvancedOptionsConfigJsonCustomConfig): any;
export declare function dataGoogleComputeSecurityPolicyAdvancedOptionsConfigJsonCustomConfigToHclTerraform(struct?: DataGoogleComputeSecurityPolicyAdvancedOptionsConfigJsonCustomConfig): any;
export declare class DataGoogleComputeSecurityPolicyAdvancedOptionsConfigJsonCustomConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyAdvancedOptionsConfigJsonCustomConfig | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyAdvancedOptionsConfigJsonCustomConfig | undefined);
    get contentTypes(): string[];
}
export declare class DataGoogleComputeSecurityPolicyAdvancedOptionsConfigJsonCustomConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyAdvancedOptionsConfigJsonCustomConfigOutputReference;
}
export interface DataGoogleComputeSecurityPolicyAdvancedOptionsConfig {
}
export declare function dataGoogleComputeSecurityPolicyAdvancedOptionsConfigToTerraform(struct?: DataGoogleComputeSecurityPolicyAdvancedOptionsConfig): any;
export declare function dataGoogleComputeSecurityPolicyAdvancedOptionsConfigToHclTerraform(struct?: DataGoogleComputeSecurityPolicyAdvancedOptionsConfig): any;
export declare class DataGoogleComputeSecurityPolicyAdvancedOptionsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyAdvancedOptionsConfig | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyAdvancedOptionsConfig | undefined);
    private _jsonCustomConfig;
    get jsonCustomConfig(): DataGoogleComputeSecurityPolicyAdvancedOptionsConfigJsonCustomConfigList;
    get jsonParsing(): string;
    get logLevel(): string;
    get requestBodyInspectionSize(): string;
    get userIpRequestHeaders(): string[];
}
export declare class DataGoogleComputeSecurityPolicyAdvancedOptionsConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyAdvancedOptionsConfigOutputReference;
}
export interface DataGoogleComputeSecurityPolicyRecaptchaOptionsConfig {
}
export declare function dataGoogleComputeSecurityPolicyRecaptchaOptionsConfigToTerraform(struct?: DataGoogleComputeSecurityPolicyRecaptchaOptionsConfig): any;
export declare function dataGoogleComputeSecurityPolicyRecaptchaOptionsConfigToHclTerraform(struct?: DataGoogleComputeSecurityPolicyRecaptchaOptionsConfig): any;
export declare class DataGoogleComputeSecurityPolicyRecaptchaOptionsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyRecaptchaOptionsConfig | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyRecaptchaOptionsConfig | undefined);
    get redirectSiteKey(): string;
}
export declare class DataGoogleComputeSecurityPolicyRecaptchaOptionsConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyRecaptchaOptionsConfigOutputReference;
}
export interface DataGoogleComputeSecurityPolicyRuleHeaderActionRequestHeadersToAdds {
}
export declare function dataGoogleComputeSecurityPolicyRuleHeaderActionRequestHeadersToAddsToTerraform(struct?: DataGoogleComputeSecurityPolicyRuleHeaderActionRequestHeadersToAdds): any;
export declare function dataGoogleComputeSecurityPolicyRuleHeaderActionRequestHeadersToAddsToHclTerraform(struct?: DataGoogleComputeSecurityPolicyRuleHeaderActionRequestHeadersToAdds): any;
export declare class DataGoogleComputeSecurityPolicyRuleHeaderActionRequestHeadersToAddsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyRuleHeaderActionRequestHeadersToAdds | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyRuleHeaderActionRequestHeadersToAdds | undefined);
    get headerName(): string;
    get headerValue(): string;
}
export declare class DataGoogleComputeSecurityPolicyRuleHeaderActionRequestHeadersToAddsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyRuleHeaderActionRequestHeadersToAddsOutputReference;
}
export interface DataGoogleComputeSecurityPolicyRuleHeaderAction {
}
export declare function dataGoogleComputeSecurityPolicyRuleHeaderActionToTerraform(struct?: DataGoogleComputeSecurityPolicyRuleHeaderAction): any;
export declare function dataGoogleComputeSecurityPolicyRuleHeaderActionToHclTerraform(struct?: DataGoogleComputeSecurityPolicyRuleHeaderAction): any;
export declare class DataGoogleComputeSecurityPolicyRuleHeaderActionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyRuleHeaderAction | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyRuleHeaderAction | undefined);
    private _requestHeadersToAdds;
    get requestHeadersToAdds(): DataGoogleComputeSecurityPolicyRuleHeaderActionRequestHeadersToAddsList;
}
export declare class DataGoogleComputeSecurityPolicyRuleHeaderActionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyRuleHeaderActionOutputReference;
}
export interface DataGoogleComputeSecurityPolicyRuleMatchConfig {
}
export declare function dataGoogleComputeSecurityPolicyRuleMatchConfigToTerraform(struct?: DataGoogleComputeSecurityPolicyRuleMatchConfig): any;
export declare function dataGoogleComputeSecurityPolicyRuleMatchConfigToHclTerraform(struct?: DataGoogleComputeSecurityPolicyRuleMatchConfig): any;
export declare class DataGoogleComputeSecurityPolicyRuleMatchConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyRuleMatchConfig | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyRuleMatchConfig | undefined);
    get srcIpRanges(): string[];
}
export declare class DataGoogleComputeSecurityPolicyRuleMatchConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyRuleMatchConfigOutputReference;
}
export interface DataGoogleComputeSecurityPolicyRuleMatchExpr {
}
export declare function dataGoogleComputeSecurityPolicyRuleMatchExprToTerraform(struct?: DataGoogleComputeSecurityPolicyRuleMatchExpr): any;
export declare function dataGoogleComputeSecurityPolicyRuleMatchExprToHclTerraform(struct?: DataGoogleComputeSecurityPolicyRuleMatchExpr): any;
export declare class DataGoogleComputeSecurityPolicyRuleMatchExprOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyRuleMatchExpr | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyRuleMatchExpr | undefined);
    get expression(): string;
}
export declare class DataGoogleComputeSecurityPolicyRuleMatchExprList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyRuleMatchExprOutputReference;
}
export interface DataGoogleComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptions {
}
export declare function dataGoogleComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptionsToTerraform(struct?: DataGoogleComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptions): any;
export declare function dataGoogleComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptionsToHclTerraform(struct?: DataGoogleComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptions): any;
export declare class DataGoogleComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptions | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptions | undefined);
    get actionTokenSiteKeys(): string[];
    get sessionTokenSiteKeys(): string[];
}
export declare class DataGoogleComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptionsOutputReference;
}
export interface DataGoogleComputeSecurityPolicyRuleMatchExprOptions {
}
export declare function dataGoogleComputeSecurityPolicyRuleMatchExprOptionsToTerraform(struct?: DataGoogleComputeSecurityPolicyRuleMatchExprOptions): any;
export declare function dataGoogleComputeSecurityPolicyRuleMatchExprOptionsToHclTerraform(struct?: DataGoogleComputeSecurityPolicyRuleMatchExprOptions): any;
export declare class DataGoogleComputeSecurityPolicyRuleMatchExprOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyRuleMatchExprOptions | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyRuleMatchExprOptions | undefined);
    private _recaptchaOptions;
    get recaptchaOptions(): DataGoogleComputeSecurityPolicyRuleMatchExprOptionsRecaptchaOptionsList;
}
export declare class DataGoogleComputeSecurityPolicyRuleMatchExprOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyRuleMatchExprOptionsOutputReference;
}
export interface DataGoogleComputeSecurityPolicyRuleMatch {
}
export declare function dataGoogleComputeSecurityPolicyRuleMatchToTerraform(struct?: DataGoogleComputeSecurityPolicyRuleMatch): any;
export declare function dataGoogleComputeSecurityPolicyRuleMatchToHclTerraform(struct?: DataGoogleComputeSecurityPolicyRuleMatch): any;
export declare class DataGoogleComputeSecurityPolicyRuleMatchOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyRuleMatch | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyRuleMatch | undefined);
    private _config;
    get config(): DataGoogleComputeSecurityPolicyRuleMatchConfigList;
    private _expr;
    get expr(): DataGoogleComputeSecurityPolicyRuleMatchExprList;
    private _exprOptions;
    get exprOptions(): DataGoogleComputeSecurityPolicyRuleMatchExprOptionsList;
    get versionedExpr(): string;
}
export declare class DataGoogleComputeSecurityPolicyRuleMatchList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyRuleMatchOutputReference;
}
export interface DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestBody {
}
export declare function dataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestBodyToTerraform(struct?: DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestBody): any;
export declare function dataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestBodyToHclTerraform(struct?: DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestBody): any;
export declare class DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestBodyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestBody | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestBody | undefined);
    get operator(): string;
    get value(): string;
}
export declare class DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestBodyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestBodyOutputReference;
}
export interface DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie {
}
export declare function dataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieToTerraform(struct?: DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie): any;
export declare function dataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieToHclTerraform(struct?: DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie): any;
export declare class DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookie | undefined);
    get operator(): string;
    get value(): string;
}
export declare class DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieOutputReference;
}
export interface DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader {
}
export declare function dataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderToTerraform(struct?: DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader): any;
export declare function dataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderToHclTerraform(struct?: DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader): any;
export declare class DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeader | undefined);
    get operator(): string;
    get value(): string;
}
export declare class DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderOutputReference;
}
export interface DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam {
}
export declare function dataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamToTerraform(struct?: DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam): any;
export declare function dataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamToHclTerraform(struct?: DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam): any;
export declare class DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParam | undefined);
    get operator(): string;
    get value(): string;
}
export declare class DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamOutputReference;
}
export interface DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri {
}
export declare function dataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriToTerraform(struct?: DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri): any;
export declare function dataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriToHclTerraform(struct?: DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri): any;
export declare class DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUri | undefined);
    get operator(): string;
    get value(): string;
}
export declare class DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriOutputReference;
}
export interface DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusion {
}
export declare function dataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionToTerraform(struct?: DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusion): any;
export declare function dataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionToHclTerraform(struct?: DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusion): any;
export declare class DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusion | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusion | undefined);
    private _requestBody;
    get requestBody(): DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestBodyList;
    private _requestCookie;
    get requestCookie(): DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestCookieList;
    private _requestHeader;
    get requestHeader(): DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestHeaderList;
    private _requestQueryParam;
    get requestQueryParam(): DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestQueryParamList;
    private _requestUri;
    get requestUri(): DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionRequestUriList;
    get targetRuleIds(): string[];
    get targetRuleSet(): string;
}
export declare class DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionOutputReference;
}
export interface DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfig {
}
export declare function dataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigToTerraform(struct?: DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfig): any;
export declare function dataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigToHclTerraform(struct?: DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfig): any;
export declare class DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfig | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfig | undefined);
    private _exclusion;
    get exclusion(): DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigExclusionList;
}
export declare class DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigOutputReference;
}
export interface DataGoogleComputeSecurityPolicyRuleRateLimitOptionsBanThreshold {
}
export declare function dataGoogleComputeSecurityPolicyRuleRateLimitOptionsBanThresholdToTerraform(struct?: DataGoogleComputeSecurityPolicyRuleRateLimitOptionsBanThreshold): any;
export declare function dataGoogleComputeSecurityPolicyRuleRateLimitOptionsBanThresholdToHclTerraform(struct?: DataGoogleComputeSecurityPolicyRuleRateLimitOptionsBanThreshold): any;
export declare class DataGoogleComputeSecurityPolicyRuleRateLimitOptionsBanThresholdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyRuleRateLimitOptionsBanThreshold | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyRuleRateLimitOptionsBanThreshold | undefined);
    get count(): number;
    get intervalSec(): number;
}
export declare class DataGoogleComputeSecurityPolicyRuleRateLimitOptionsBanThresholdList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyRuleRateLimitOptionsBanThresholdOutputReference;
}
export interface DataGoogleComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigs {
}
export declare function dataGoogleComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsToTerraform(struct?: DataGoogleComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigs): any;
export declare function dataGoogleComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsToHclTerraform(struct?: DataGoogleComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigs): any;
export declare class DataGoogleComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigs | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigs | undefined);
    get enforceOnKeyName(): string;
    get enforceOnKeyType(): string;
}
export declare class DataGoogleComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsOutputReference;
}
export interface DataGoogleComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptions {
}
export declare function dataGoogleComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptionsToTerraform(struct?: DataGoogleComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptions): any;
export declare function dataGoogleComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptionsToHclTerraform(struct?: DataGoogleComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptions): any;
export declare class DataGoogleComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptions | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptions | undefined);
    get target(): string;
    get type(): string;
}
export declare class DataGoogleComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptionsOutputReference;
}
export interface DataGoogleComputeSecurityPolicyRuleRateLimitOptionsRateLimitThreshold {
}
export declare function dataGoogleComputeSecurityPolicyRuleRateLimitOptionsRateLimitThresholdToTerraform(struct?: DataGoogleComputeSecurityPolicyRuleRateLimitOptionsRateLimitThreshold): any;
export declare function dataGoogleComputeSecurityPolicyRuleRateLimitOptionsRateLimitThresholdToHclTerraform(struct?: DataGoogleComputeSecurityPolicyRuleRateLimitOptionsRateLimitThreshold): any;
export declare class DataGoogleComputeSecurityPolicyRuleRateLimitOptionsRateLimitThresholdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyRuleRateLimitOptionsRateLimitThreshold | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyRuleRateLimitOptionsRateLimitThreshold | undefined);
    get count(): number;
    get intervalSec(): number;
}
export declare class DataGoogleComputeSecurityPolicyRuleRateLimitOptionsRateLimitThresholdList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyRuleRateLimitOptionsRateLimitThresholdOutputReference;
}
export interface DataGoogleComputeSecurityPolicyRuleRateLimitOptions {
}
export declare function dataGoogleComputeSecurityPolicyRuleRateLimitOptionsToTerraform(struct?: DataGoogleComputeSecurityPolicyRuleRateLimitOptions): any;
export declare function dataGoogleComputeSecurityPolicyRuleRateLimitOptionsToHclTerraform(struct?: DataGoogleComputeSecurityPolicyRuleRateLimitOptions): any;
export declare class DataGoogleComputeSecurityPolicyRuleRateLimitOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyRuleRateLimitOptions | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyRuleRateLimitOptions | undefined);
    get banDurationSec(): number;
    private _banThreshold;
    get banThreshold(): DataGoogleComputeSecurityPolicyRuleRateLimitOptionsBanThresholdList;
    get conformAction(): string;
    get enforceOnKey(): string;
    private _enforceOnKeyConfigs;
    get enforceOnKeyConfigs(): DataGoogleComputeSecurityPolicyRuleRateLimitOptionsEnforceOnKeyConfigsList;
    get enforceOnKeyName(): string;
    get exceedAction(): string;
    private _exceedRedirectOptions;
    get exceedRedirectOptions(): DataGoogleComputeSecurityPolicyRuleRateLimitOptionsExceedRedirectOptionsList;
    private _rateLimitThreshold;
    get rateLimitThreshold(): DataGoogleComputeSecurityPolicyRuleRateLimitOptionsRateLimitThresholdList;
}
export declare class DataGoogleComputeSecurityPolicyRuleRateLimitOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyRuleRateLimitOptionsOutputReference;
}
export interface DataGoogleComputeSecurityPolicyRuleRedirectOptions {
}
export declare function dataGoogleComputeSecurityPolicyRuleRedirectOptionsToTerraform(struct?: DataGoogleComputeSecurityPolicyRuleRedirectOptions): any;
export declare function dataGoogleComputeSecurityPolicyRuleRedirectOptionsToHclTerraform(struct?: DataGoogleComputeSecurityPolicyRuleRedirectOptions): any;
export declare class DataGoogleComputeSecurityPolicyRuleRedirectOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyRuleRedirectOptions | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyRuleRedirectOptions | undefined);
    get target(): string;
    get type(): string;
}
export declare class DataGoogleComputeSecurityPolicyRuleRedirectOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyRuleRedirectOptionsOutputReference;
}
export interface DataGoogleComputeSecurityPolicyRule {
}
export declare function dataGoogleComputeSecurityPolicyRuleToTerraform(struct?: DataGoogleComputeSecurityPolicyRule): any;
export declare function dataGoogleComputeSecurityPolicyRuleToHclTerraform(struct?: DataGoogleComputeSecurityPolicyRule): any;
export declare class DataGoogleComputeSecurityPolicyRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeSecurityPolicyRule | undefined;
    set internalValue(value: DataGoogleComputeSecurityPolicyRule | undefined);
    get action(): string;
    get description(): string;
    private _headerAction;
    get headerAction(): DataGoogleComputeSecurityPolicyRuleHeaderActionList;
    private _match;
    get match(): DataGoogleComputeSecurityPolicyRuleMatchList;
    private _preconfiguredWafConfig;
    get preconfiguredWafConfig(): DataGoogleComputeSecurityPolicyRulePreconfiguredWafConfigList;
    get preview(): cdktn.IResolvable;
    get priority(): number;
    private _rateLimitOptions;
    get rateLimitOptions(): DataGoogleComputeSecurityPolicyRuleRateLimitOptionsList;
    private _redirectOptions;
    get redirectOptions(): DataGoogleComputeSecurityPolicyRuleRedirectOptionsList;
}
export declare class DataGoogleComputeSecurityPolicyRuleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeSecurityPolicyRuleOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_security_policy google_compute_security_policy}
*/
export declare class DataGoogleComputeSecurityPolicy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_compute_security_policy";
    /**
    * Generates CDKTN code for importing a DataGoogleComputeSecurityPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleComputeSecurityPolicy to import
    * @param importFromId The id of the existing DataGoogleComputeSecurityPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_security_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleComputeSecurityPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_security_policy google_compute_security_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleComputeSecurityPolicyConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGoogleComputeSecurityPolicyConfig);
    private _adaptiveProtectionConfig;
    get adaptiveProtectionConfig(): DataGoogleComputeSecurityPolicyAdaptiveProtectionConfigList;
    private _advancedOptionsConfig;
    get advancedOptionsConfig(): DataGoogleComputeSecurityPolicyAdvancedOptionsConfigList;
    get deletionPolicy(): string;
    get description(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get fingerprint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get labelFingerprint(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _recaptchaOptionsConfig;
    get recaptchaOptionsConfig(): DataGoogleComputeSecurityPolicyRecaptchaOptionsConfigList;
    private _rule;
    get rule(): DataGoogleComputeSecurityPolicyRuleList;
    private _selfLink?;
    get selfLink(): string;
    set selfLink(value: string);
    resetSelfLink(): void;
    get selfLinkInput(): string | undefined;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
