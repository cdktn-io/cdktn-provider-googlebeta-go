/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleIamWorkloadIdentityPoolConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_iam_workload_identity_pool#id DataGoogleIamWorkloadIdentityPool#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_iam_workload_identity_pool#project DataGoogleIamWorkloadIdentityPool#project}
    */
    readonly project?: string;
    /**
    * The ID to use for the pool, which becomes the final component of the resource name. This
    * value should be 4-32 characters, and may contain the characters [a-z0-9-]. The prefix
    * 'gcp-' is reserved for use by Google, and may not be specified.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_iam_workload_identity_pool#workload_identity_pool_id DataGoogleIamWorkloadIdentityPool#workload_identity_pool_id}
    */
    readonly workloadIdentityPoolId: string;
}
export interface DataGoogleIamWorkloadIdentityPoolAttestationRules {
}
export declare function dataGoogleIamWorkloadIdentityPoolAttestationRulesToTerraform(struct?: DataGoogleIamWorkloadIdentityPoolAttestationRules): any;
export declare function dataGoogleIamWorkloadIdentityPoolAttestationRulesToHclTerraform(struct?: DataGoogleIamWorkloadIdentityPoolAttestationRules): any;
export declare class DataGoogleIamWorkloadIdentityPoolAttestationRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleIamWorkloadIdentityPoolAttestationRules | undefined;
    set internalValue(value: DataGoogleIamWorkloadIdentityPoolAttestationRules | undefined);
    get googleCloudResource(): string;
}
export declare class DataGoogleIamWorkloadIdentityPoolAttestationRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleIamWorkloadIdentityPoolAttestationRulesOutputReference;
}
export interface DataGoogleIamWorkloadIdentityPoolInlineCertificateIssuanceConfig {
}
export declare function dataGoogleIamWorkloadIdentityPoolInlineCertificateIssuanceConfigToTerraform(struct?: DataGoogleIamWorkloadIdentityPoolInlineCertificateIssuanceConfig): any;
export declare function dataGoogleIamWorkloadIdentityPoolInlineCertificateIssuanceConfigToHclTerraform(struct?: DataGoogleIamWorkloadIdentityPoolInlineCertificateIssuanceConfig): any;
export declare class DataGoogleIamWorkloadIdentityPoolInlineCertificateIssuanceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleIamWorkloadIdentityPoolInlineCertificateIssuanceConfig | undefined;
    set internalValue(value: DataGoogleIamWorkloadIdentityPoolInlineCertificateIssuanceConfig | undefined);
    private _caPools;
    get caPools(): cdktn.StringMap;
    get keyAlgorithm(): string;
    get lifetime(): string;
    get rotationWindowPercentage(): number;
    get useDefaultSharedCa(): cdktn.IResolvable;
}
export declare class DataGoogleIamWorkloadIdentityPoolInlineCertificateIssuanceConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleIamWorkloadIdentityPoolInlineCertificateIssuanceConfigOutputReference;
}
export interface DataGoogleIamWorkloadIdentityPoolInlineTrustConfigAdditionalTrustBundlesTrustAnchors {
}
export declare function dataGoogleIamWorkloadIdentityPoolInlineTrustConfigAdditionalTrustBundlesTrustAnchorsToTerraform(struct?: DataGoogleIamWorkloadIdentityPoolInlineTrustConfigAdditionalTrustBundlesTrustAnchors): any;
export declare function dataGoogleIamWorkloadIdentityPoolInlineTrustConfigAdditionalTrustBundlesTrustAnchorsToHclTerraform(struct?: DataGoogleIamWorkloadIdentityPoolInlineTrustConfigAdditionalTrustBundlesTrustAnchors): any;
export declare class DataGoogleIamWorkloadIdentityPoolInlineTrustConfigAdditionalTrustBundlesTrustAnchorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleIamWorkloadIdentityPoolInlineTrustConfigAdditionalTrustBundlesTrustAnchors | undefined;
    set internalValue(value: DataGoogleIamWorkloadIdentityPoolInlineTrustConfigAdditionalTrustBundlesTrustAnchors | undefined);
    get pemCertificate(): string;
}
export declare class DataGoogleIamWorkloadIdentityPoolInlineTrustConfigAdditionalTrustBundlesTrustAnchorsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleIamWorkloadIdentityPoolInlineTrustConfigAdditionalTrustBundlesTrustAnchorsOutputReference;
}
export interface DataGoogleIamWorkloadIdentityPoolInlineTrustConfigAdditionalTrustBundles {
}
export declare function dataGoogleIamWorkloadIdentityPoolInlineTrustConfigAdditionalTrustBundlesToTerraform(struct?: DataGoogleIamWorkloadIdentityPoolInlineTrustConfigAdditionalTrustBundles): any;
export declare function dataGoogleIamWorkloadIdentityPoolInlineTrustConfigAdditionalTrustBundlesToHclTerraform(struct?: DataGoogleIamWorkloadIdentityPoolInlineTrustConfigAdditionalTrustBundles): any;
export declare class DataGoogleIamWorkloadIdentityPoolInlineTrustConfigAdditionalTrustBundlesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleIamWorkloadIdentityPoolInlineTrustConfigAdditionalTrustBundles | undefined;
    set internalValue(value: DataGoogleIamWorkloadIdentityPoolInlineTrustConfigAdditionalTrustBundles | undefined);
    private _trustAnchors;
    get trustAnchors(): DataGoogleIamWorkloadIdentityPoolInlineTrustConfigAdditionalTrustBundlesTrustAnchorsList;
    get trustDefaultSharedCa(): cdktn.IResolvable;
    get trustDomain(): string;
}
export declare class DataGoogleIamWorkloadIdentityPoolInlineTrustConfigAdditionalTrustBundlesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleIamWorkloadIdentityPoolInlineTrustConfigAdditionalTrustBundlesOutputReference;
}
export interface DataGoogleIamWorkloadIdentityPoolInlineTrustConfig {
}
export declare function dataGoogleIamWorkloadIdentityPoolInlineTrustConfigToTerraform(struct?: DataGoogleIamWorkloadIdentityPoolInlineTrustConfig): any;
export declare function dataGoogleIamWorkloadIdentityPoolInlineTrustConfigToHclTerraform(struct?: DataGoogleIamWorkloadIdentityPoolInlineTrustConfig): any;
export declare class DataGoogleIamWorkloadIdentityPoolInlineTrustConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleIamWorkloadIdentityPoolInlineTrustConfig | undefined;
    set internalValue(value: DataGoogleIamWorkloadIdentityPoolInlineTrustConfig | undefined);
    private _additionalTrustBundles;
    get additionalTrustBundles(): DataGoogleIamWorkloadIdentityPoolInlineTrustConfigAdditionalTrustBundlesList;
}
export declare class DataGoogleIamWorkloadIdentityPoolInlineTrustConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleIamWorkloadIdentityPoolInlineTrustConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_iam_workload_identity_pool google_iam_workload_identity_pool}
*/
export declare class DataGoogleIamWorkloadIdentityPool extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_iam_workload_identity_pool";
    /**
    * Generates CDKTN code for importing a DataGoogleIamWorkloadIdentityPool resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleIamWorkloadIdentityPool to import
    * @param importFromId The id of the existing DataGoogleIamWorkloadIdentityPool that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_iam_workload_identity_pool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleIamWorkloadIdentityPool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_iam_workload_identity_pool google_iam_workload_identity_pool} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleIamWorkloadIdentityPoolConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleIamWorkloadIdentityPoolConfig);
    private _attestationRules;
    get attestationRules(): DataGoogleIamWorkloadIdentityPoolAttestationRulesList;
    get deletionPolicy(): string;
    get description(): string;
    get disabled(): cdktn.IResolvable;
    get displayName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _inlineCertificateIssuanceConfig;
    get inlineCertificateIssuanceConfig(): DataGoogleIamWorkloadIdentityPoolInlineCertificateIssuanceConfigList;
    private _inlineTrustConfig;
    get inlineTrustConfig(): DataGoogleIamWorkloadIdentityPoolInlineTrustConfigList;
    get mode(): string;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get state(): string;
    private _workloadIdentityPoolId?;
    get workloadIdentityPoolId(): string;
    set workloadIdentityPoolId(value: string);
    get workloadIdentityPoolIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
