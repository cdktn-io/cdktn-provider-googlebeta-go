/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleNetworkSecurityAddressGroupsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_network_security_address_groups#id DataGoogleNetworkSecurityAddressGroups#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_network_security_address_groups#location DataGoogleNetworkSecurityAddressGroups#location}
    */
    readonly location: string;
    /**
    * The parent of the Address Group. Use "organizations/{organization_id}" for organization-level address groups or "projects/{project_id}" for project-level address groups.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_network_security_address_groups#parent DataGoogleNetworkSecurityAddressGroups#parent}
    */
    readonly parent?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_network_security_address_groups#project DataGoogleNetworkSecurityAddressGroups#project}
    */
    readonly project?: string;
}
export interface DataGoogleNetworkSecurityAddressGroupsAddressGroups {
}
export declare function dataGoogleNetworkSecurityAddressGroupsAddressGroupsToTerraform(struct?: DataGoogleNetworkSecurityAddressGroupsAddressGroups): any;
export declare function dataGoogleNetworkSecurityAddressGroupsAddressGroupsToHclTerraform(struct?: DataGoogleNetworkSecurityAddressGroupsAddressGroups): any;
export declare class DataGoogleNetworkSecurityAddressGroupsAddressGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleNetworkSecurityAddressGroupsAddressGroups | undefined;
    set internalValue(value: DataGoogleNetworkSecurityAddressGroupsAddressGroups | undefined);
    get capacity(): number;
    get items(): string[];
    get location(): string;
    get name(): string;
}
export declare class DataGoogleNetworkSecurityAddressGroupsAddressGroupsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleNetworkSecurityAddressGroupsAddressGroupsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_network_security_address_groups google_network_security_address_groups}
*/
export declare class DataGoogleNetworkSecurityAddressGroups extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_network_security_address_groups";
    /**
    * Generates CDKTN code for importing a DataGoogleNetworkSecurityAddressGroups resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleNetworkSecurityAddressGroups to import
    * @param importFromId The id of the existing DataGoogleNetworkSecurityAddressGroups that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_network_security_address_groups#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleNetworkSecurityAddressGroups to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_network_security_address_groups google_network_security_address_groups} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleNetworkSecurityAddressGroupsConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleNetworkSecurityAddressGroupsConfig);
    private _addressGroups;
    get addressGroups(): DataGoogleNetworkSecurityAddressGroupsAddressGroupsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    resetParent(): void;
    get parentInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
