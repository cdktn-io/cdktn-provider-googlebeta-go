/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleGkeHubMembershipBindingConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_gke_hub_membership_binding#id DataGoogleGkeHubMembershipBinding#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Location of the membership
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_gke_hub_membership_binding#location DataGoogleGkeHubMembershipBinding#location}
    */
    readonly location: string;
    /**
    * The client-provided identifier of the membership binding.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_gke_hub_membership_binding#membership_binding_id DataGoogleGkeHubMembershipBinding#membership_binding_id}
    */
    readonly membershipBindingId: string;
    /**
    * Id of the membership
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_gke_hub_membership_binding#membership_id DataGoogleGkeHubMembershipBinding#membership_id}
    */
    readonly membershipId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_gke_hub_membership_binding#project DataGoogleGkeHubMembershipBinding#project}
    */
    readonly project?: string;
}
export interface DataGoogleGkeHubMembershipBindingState {
}
export declare function dataGoogleGkeHubMembershipBindingStateToTerraform(struct?: DataGoogleGkeHubMembershipBindingState): any;
export declare function dataGoogleGkeHubMembershipBindingStateToHclTerraform(struct?: DataGoogleGkeHubMembershipBindingState): any;
export declare class DataGoogleGkeHubMembershipBindingStateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubMembershipBindingState | undefined;
    set internalValue(value: DataGoogleGkeHubMembershipBindingState | undefined);
    get code(): string;
}
export declare class DataGoogleGkeHubMembershipBindingStateList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubMembershipBindingStateOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_gke_hub_membership_binding google_gke_hub_membership_binding}
*/
export declare class DataGoogleGkeHubMembershipBinding extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_gke_hub_membership_binding";
    /**
    * Generates CDKTN code for importing a DataGoogleGkeHubMembershipBinding resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleGkeHubMembershipBinding to import
    * @param importFromId The id of the existing DataGoogleGkeHubMembershipBinding that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_gke_hub_membership_binding#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleGkeHubMembershipBinding to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_gke_hub_membership_binding google_gke_hub_membership_binding} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleGkeHubMembershipBindingConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleGkeHubMembershipBindingConfig);
    get createTime(): string;
    get deleteTime(): string;
    get deletionPolicy(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels;
    get labels(): cdktn.StringMap;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _membershipBindingId?;
    get membershipBindingId(): string;
    set membershipBindingId(value: string);
    get membershipBindingIdInput(): string | undefined;
    private _membershipId?;
    get membershipId(): string;
    set membershipId(value: string);
    get membershipIdInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get scope(): string;
    private _state;
    get state(): DataGoogleGkeHubMembershipBindingStateList;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get uid(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
