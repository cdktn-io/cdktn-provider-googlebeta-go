/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleProjectOrganizationPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the Constraint the Policy is configuring, for example, serviceuser.services.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_project_organization_policy#constraint DataGoogleProjectOrganizationPolicy#constraint}
    */
    readonly constraint: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_project_organization_policy#id DataGoogleProjectOrganizationPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The project ID.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_project_organization_policy#project DataGoogleProjectOrganizationPolicy#project}
    */
    readonly project: string;
}
export interface DataGoogleProjectOrganizationPolicyBooleanPolicy {
}
export declare function dataGoogleProjectOrganizationPolicyBooleanPolicyToTerraform(struct?: DataGoogleProjectOrganizationPolicyBooleanPolicy): any;
export declare function dataGoogleProjectOrganizationPolicyBooleanPolicyToHclTerraform(struct?: DataGoogleProjectOrganizationPolicyBooleanPolicy): any;
export declare class DataGoogleProjectOrganizationPolicyBooleanPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleProjectOrganizationPolicyBooleanPolicy | undefined;
    set internalValue(value: DataGoogleProjectOrganizationPolicyBooleanPolicy | undefined);
    get enforced(): cdktn.IResolvable;
}
export declare class DataGoogleProjectOrganizationPolicyBooleanPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleProjectOrganizationPolicyBooleanPolicyOutputReference;
}
export interface DataGoogleProjectOrganizationPolicyListPolicyAllow {
}
export declare function dataGoogleProjectOrganizationPolicyListPolicyAllowToTerraform(struct?: DataGoogleProjectOrganizationPolicyListPolicyAllow): any;
export declare function dataGoogleProjectOrganizationPolicyListPolicyAllowToHclTerraform(struct?: DataGoogleProjectOrganizationPolicyListPolicyAllow): any;
export declare class DataGoogleProjectOrganizationPolicyListPolicyAllowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleProjectOrganizationPolicyListPolicyAllow | undefined;
    set internalValue(value: DataGoogleProjectOrganizationPolicyListPolicyAllow | undefined);
    get all(): cdktn.IResolvable;
    get values(): string[];
}
export declare class DataGoogleProjectOrganizationPolicyListPolicyAllowList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleProjectOrganizationPolicyListPolicyAllowOutputReference;
}
export interface DataGoogleProjectOrganizationPolicyListPolicyDeny {
}
export declare function dataGoogleProjectOrganizationPolicyListPolicyDenyToTerraform(struct?: DataGoogleProjectOrganizationPolicyListPolicyDeny): any;
export declare function dataGoogleProjectOrganizationPolicyListPolicyDenyToHclTerraform(struct?: DataGoogleProjectOrganizationPolicyListPolicyDeny): any;
export declare class DataGoogleProjectOrganizationPolicyListPolicyDenyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleProjectOrganizationPolicyListPolicyDeny | undefined;
    set internalValue(value: DataGoogleProjectOrganizationPolicyListPolicyDeny | undefined);
    get all(): cdktn.IResolvable;
    get values(): string[];
}
export declare class DataGoogleProjectOrganizationPolicyListPolicyDenyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleProjectOrganizationPolicyListPolicyDenyOutputReference;
}
export interface DataGoogleProjectOrganizationPolicyListPolicy {
}
export declare function dataGoogleProjectOrganizationPolicyListPolicyToTerraform(struct?: DataGoogleProjectOrganizationPolicyListPolicy): any;
export declare function dataGoogleProjectOrganizationPolicyListPolicyToHclTerraform(struct?: DataGoogleProjectOrganizationPolicyListPolicy): any;
export declare class DataGoogleProjectOrganizationPolicyListPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleProjectOrganizationPolicyListPolicy | undefined;
    set internalValue(value: DataGoogleProjectOrganizationPolicyListPolicy | undefined);
    private _allow;
    get allow(): DataGoogleProjectOrganizationPolicyListPolicyAllowList;
    private _deny;
    get deny(): DataGoogleProjectOrganizationPolicyListPolicyDenyList;
    get inheritFromParent(): cdktn.IResolvable;
    get suggestedValue(): string;
}
export declare class DataGoogleProjectOrganizationPolicyListPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleProjectOrganizationPolicyListPolicyOutputReference;
}
export interface DataGoogleProjectOrganizationPolicyRestorePolicy {
}
export declare function dataGoogleProjectOrganizationPolicyRestorePolicyToTerraform(struct?: DataGoogleProjectOrganizationPolicyRestorePolicy): any;
export declare function dataGoogleProjectOrganizationPolicyRestorePolicyToHclTerraform(struct?: DataGoogleProjectOrganizationPolicyRestorePolicy): any;
export declare class DataGoogleProjectOrganizationPolicyRestorePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleProjectOrganizationPolicyRestorePolicy | undefined;
    set internalValue(value: DataGoogleProjectOrganizationPolicyRestorePolicy | undefined);
    get default(): cdktn.IResolvable;
}
export declare class DataGoogleProjectOrganizationPolicyRestorePolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleProjectOrganizationPolicyRestorePolicyOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_project_organization_policy google_project_organization_policy}
*/
export declare class DataGoogleProjectOrganizationPolicy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_project_organization_policy";
    /**
    * Generates CDKTN code for importing a DataGoogleProjectOrganizationPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleProjectOrganizationPolicy to import
    * @param importFromId The id of the existing DataGoogleProjectOrganizationPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_project_organization_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleProjectOrganizationPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_project_organization_policy google_project_organization_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleProjectOrganizationPolicyConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleProjectOrganizationPolicyConfig);
    private _booleanPolicy;
    get booleanPolicy(): DataGoogleProjectOrganizationPolicyBooleanPolicyList;
    private _constraint?;
    get constraint(): string;
    set constraint(value: string);
    get constraintInput(): string | undefined;
    get deletionPolicy(): string;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _listPolicy;
    get listPolicy(): DataGoogleProjectOrganizationPolicyListPolicyList;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _restorePolicy;
    get restorePolicy(): DataGoogleProjectOrganizationPolicyRestorePolicyList;
    get updateTime(): string;
    get version(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
