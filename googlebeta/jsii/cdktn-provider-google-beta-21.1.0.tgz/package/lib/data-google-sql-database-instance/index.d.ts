/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleSqlDatabaseInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_sql_database_instance#id DataGoogleSqlDatabaseInstance#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the instance. If the name is left blank, Terraform will randomly generate one when the instance is first created. This is done because after a name is used, it cannot be reused for up to one week.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_sql_database_instance#name DataGoogleSqlDatabaseInstance#name}
    */
    readonly name: string;
    /**
    * The ID of the project in which the resource belongs. If it is not provided, the provider project is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_sql_database_instance#project DataGoogleSqlDatabaseInstance#project}
    */
    readonly project?: string;
}
export interface DataGoogleSqlDatabaseInstanceBlueGreenDeploymentTargetInstanceIpAddresses {
}
export declare function dataGoogleSqlDatabaseInstanceBlueGreenDeploymentTargetInstanceIpAddressesToTerraform(struct?: DataGoogleSqlDatabaseInstanceBlueGreenDeploymentTargetInstanceIpAddresses): any;
export declare function dataGoogleSqlDatabaseInstanceBlueGreenDeploymentTargetInstanceIpAddressesToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceBlueGreenDeploymentTargetInstanceIpAddresses): any;
export declare class DataGoogleSqlDatabaseInstanceBlueGreenDeploymentTargetInstanceIpAddressesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceBlueGreenDeploymentTargetInstanceIpAddresses | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceBlueGreenDeploymentTargetInstanceIpAddresses | undefined);
    get ipAddress(): string;
    get timeToRetire(): string;
    get type(): string;
}
export declare class DataGoogleSqlDatabaseInstanceBlueGreenDeploymentTargetInstanceIpAddressesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceBlueGreenDeploymentTargetInstanceIpAddressesOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceBlueGreenDeployment {
}
export declare function dataGoogleSqlDatabaseInstanceBlueGreenDeploymentToTerraform(struct?: DataGoogleSqlDatabaseInstanceBlueGreenDeployment): any;
export declare function dataGoogleSqlDatabaseInstanceBlueGreenDeploymentToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceBlueGreenDeployment): any;
export declare class DataGoogleSqlDatabaseInstanceBlueGreenDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceBlueGreenDeployment | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceBlueGreenDeployment | undefined);
    get activeEnvironment(): string;
    get deleteOldSourceOnDestroy(): cdktn.IResolvable;
    get deploymentName(): string;
    get oldSourceInstanceConnectionName(): string;
    get oldSourceInstanceName(): string;
    get targetDatabaseVersion(): string;
    get targetInstanceConnectionName(): string;
    private _targetInstanceIpAddresses;
    get targetInstanceIpAddresses(): DataGoogleSqlDatabaseInstanceBlueGreenDeploymentTargetInstanceIpAddressesList;
    get targetInstanceName(): string;
}
export declare class DataGoogleSqlDatabaseInstanceBlueGreenDeploymentList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceBlueGreenDeploymentOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceClone {
}
export declare function dataGoogleSqlDatabaseInstanceCloneToTerraform(struct?: DataGoogleSqlDatabaseInstanceClone): any;
export declare function dataGoogleSqlDatabaseInstanceCloneToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceClone): any;
export declare class DataGoogleSqlDatabaseInstanceCloneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceClone | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceClone | undefined);
    get allocatedIpRange(): string;
    get databaseNames(): string[];
    get pointInTime(): string;
    get preferredZone(): string;
    get sourceInstanceDeletionTime(): string;
    get sourceInstanceName(): string;
    get sourceProject(): string;
}
export declare class DataGoogleSqlDatabaseInstanceCloneList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceCloneOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceDnsNames {
}
export declare function dataGoogleSqlDatabaseInstanceDnsNamesToTerraform(struct?: DataGoogleSqlDatabaseInstanceDnsNames): any;
export declare function dataGoogleSqlDatabaseInstanceDnsNamesToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceDnsNames): any;
export declare class DataGoogleSqlDatabaseInstanceDnsNamesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceDnsNames | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceDnsNames | undefined);
    get connectionType(): string;
    get dnsScope(): string;
    get name(): string;
}
export declare class DataGoogleSqlDatabaseInstanceDnsNamesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceDnsNamesOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceIpAddress {
}
export declare function dataGoogleSqlDatabaseInstanceIpAddressToTerraform(struct?: DataGoogleSqlDatabaseInstanceIpAddress): any;
export declare function dataGoogleSqlDatabaseInstanceIpAddressToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceIpAddress): any;
export declare class DataGoogleSqlDatabaseInstanceIpAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceIpAddress | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceIpAddress | undefined);
    get ipAddress(): string;
    get timeToRetire(): string;
    get type(): string;
}
export declare class DataGoogleSqlDatabaseInstanceIpAddressList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceIpAddressOutputReference;
}
export interface DataGoogleSqlDatabaseInstancePointInTimeRestoreContext {
}
export declare function dataGoogleSqlDatabaseInstancePointInTimeRestoreContextToTerraform(struct?: DataGoogleSqlDatabaseInstancePointInTimeRestoreContext): any;
export declare function dataGoogleSqlDatabaseInstancePointInTimeRestoreContextToHclTerraform(struct?: DataGoogleSqlDatabaseInstancePointInTimeRestoreContext): any;
export declare class DataGoogleSqlDatabaseInstancePointInTimeRestoreContextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancePointInTimeRestoreContext | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancePointInTimeRestoreContext | undefined);
    get allocatedIpRange(): string;
    get datasource(): string;
    get pointInTime(): string;
    get preferredZone(): string;
    get region(): string;
    get targetInstance(): string;
}
export declare class DataGoogleSqlDatabaseInstancePointInTimeRestoreContextList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancePointInTimeRestoreContextOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceReplicaConfiguration {
}
export declare function dataGoogleSqlDatabaseInstanceReplicaConfigurationToTerraform(struct?: DataGoogleSqlDatabaseInstanceReplicaConfiguration): any;
export declare function dataGoogleSqlDatabaseInstanceReplicaConfigurationToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceReplicaConfiguration): any;
export declare class DataGoogleSqlDatabaseInstanceReplicaConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceReplicaConfiguration | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceReplicaConfiguration | undefined);
    get caCertificate(): string;
    get cascadableReplica(): cdktn.IResolvable;
    get clientCertificate(): string;
    get clientKey(): string;
    get connectRetryInterval(): number;
    get dumpFilePath(): string;
    get failoverTarget(): cdktn.IResolvable;
    get masterHeartbeatPeriod(): number;
    get password(): string;
    get sslCipher(): string;
    get username(): string;
    get verifyServerCertificate(): cdktn.IResolvable;
}
export declare class DataGoogleSqlDatabaseInstanceReplicaConfigurationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceReplicaConfigurationOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceReplicationCluster {
}
export declare function dataGoogleSqlDatabaseInstanceReplicationClusterToTerraform(struct?: DataGoogleSqlDatabaseInstanceReplicationCluster): any;
export declare function dataGoogleSqlDatabaseInstanceReplicationClusterToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceReplicationCluster): any;
export declare class DataGoogleSqlDatabaseInstanceReplicationClusterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceReplicationCluster | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceReplicationCluster | undefined);
    get drReplica(): cdktn.IResolvable;
    get failoverDrReplicaName(): string;
    get psaWriteEndpoint(): string;
}
export declare class DataGoogleSqlDatabaseInstanceReplicationClusterList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceReplicationClusterOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceRestoreBackupContext {
}
export declare function dataGoogleSqlDatabaseInstanceRestoreBackupContextToTerraform(struct?: DataGoogleSqlDatabaseInstanceRestoreBackupContext): any;
export declare function dataGoogleSqlDatabaseInstanceRestoreBackupContextToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceRestoreBackupContext): any;
export declare class DataGoogleSqlDatabaseInstanceRestoreBackupContextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceRestoreBackupContext | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceRestoreBackupContext | undefined);
    get backupRunId(): number;
    get instanceId(): string;
    get project(): string;
}
export declare class DataGoogleSqlDatabaseInstanceRestoreBackupContextList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceRestoreBackupContextOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceServerCaCert {
}
export declare function dataGoogleSqlDatabaseInstanceServerCaCertToTerraform(struct?: DataGoogleSqlDatabaseInstanceServerCaCert): any;
export declare function dataGoogleSqlDatabaseInstanceServerCaCertToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceServerCaCert): any;
export declare class DataGoogleSqlDatabaseInstanceServerCaCertOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceServerCaCert | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceServerCaCert | undefined);
    get cert(): string;
    get commonName(): string;
    get createTime(): string;
    get expirationTime(): string;
    get sha1Fingerprint(): string;
}
export declare class DataGoogleSqlDatabaseInstanceServerCaCertList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceServerCaCertOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceSettingsActiveDirectoryConfig {
}
export declare function dataGoogleSqlDatabaseInstanceSettingsActiveDirectoryConfigToTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsActiveDirectoryConfig): any;
export declare function dataGoogleSqlDatabaseInstanceSettingsActiveDirectoryConfigToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsActiveDirectoryConfig): any;
export declare class DataGoogleSqlDatabaseInstanceSettingsActiveDirectoryConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceSettingsActiveDirectoryConfig | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceSettingsActiveDirectoryConfig | undefined);
    get adminCredentialSecretName(): string;
    get dnsServers(): string[];
    get domain(): string;
    get mode(): string;
    get organizationalUnit(): string;
}
export declare class DataGoogleSqlDatabaseInstanceSettingsActiveDirectoryConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceSettingsActiveDirectoryConfigOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceSettingsAdvancedMachineFeatures {
}
export declare function dataGoogleSqlDatabaseInstanceSettingsAdvancedMachineFeaturesToTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsAdvancedMachineFeatures): any;
export declare function dataGoogleSqlDatabaseInstanceSettingsAdvancedMachineFeaturesToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsAdvancedMachineFeatures): any;
export declare class DataGoogleSqlDatabaseInstanceSettingsAdvancedMachineFeaturesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceSettingsAdvancedMachineFeatures | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceSettingsAdvancedMachineFeatures | undefined);
    get threadsPerCore(): number;
}
export declare class DataGoogleSqlDatabaseInstanceSettingsAdvancedMachineFeaturesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceSettingsAdvancedMachineFeaturesOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceSettingsBackupConfigurationBackupRetentionSettings {
}
export declare function dataGoogleSqlDatabaseInstanceSettingsBackupConfigurationBackupRetentionSettingsToTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsBackupConfigurationBackupRetentionSettings): any;
export declare function dataGoogleSqlDatabaseInstanceSettingsBackupConfigurationBackupRetentionSettingsToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsBackupConfigurationBackupRetentionSettings): any;
export declare class DataGoogleSqlDatabaseInstanceSettingsBackupConfigurationBackupRetentionSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceSettingsBackupConfigurationBackupRetentionSettings | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceSettingsBackupConfigurationBackupRetentionSettings | undefined);
    get retainedBackups(): number;
    get retentionUnit(): string;
}
export declare class DataGoogleSqlDatabaseInstanceSettingsBackupConfigurationBackupRetentionSettingsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceSettingsBackupConfigurationBackupRetentionSettingsOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceSettingsBackupConfiguration {
}
export declare function dataGoogleSqlDatabaseInstanceSettingsBackupConfigurationToTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsBackupConfiguration): any;
export declare function dataGoogleSqlDatabaseInstanceSettingsBackupConfigurationToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsBackupConfiguration): any;
export declare class DataGoogleSqlDatabaseInstanceSettingsBackupConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceSettingsBackupConfiguration | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceSettingsBackupConfiguration | undefined);
    private _backupRetentionSettings;
    get backupRetentionSettings(): DataGoogleSqlDatabaseInstanceSettingsBackupConfigurationBackupRetentionSettingsList;
    get backupTier(): string;
    get binaryLogEnabled(): cdktn.IResolvable;
    get enabled(): cdktn.IResolvable;
    get location(): string;
    get pointInTimeRecoveryEnabled(): cdktn.IResolvable;
    get startTime(): string;
    get transactionLogRetentionDays(): number;
}
export declare class DataGoogleSqlDatabaseInstanceSettingsBackupConfigurationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceSettingsBackupConfigurationOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceSettingsConnectionPoolConfigFlags {
}
export declare function dataGoogleSqlDatabaseInstanceSettingsConnectionPoolConfigFlagsToTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsConnectionPoolConfigFlags): any;
export declare function dataGoogleSqlDatabaseInstanceSettingsConnectionPoolConfigFlagsToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsConnectionPoolConfigFlags): any;
export declare class DataGoogleSqlDatabaseInstanceSettingsConnectionPoolConfigFlagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceSettingsConnectionPoolConfigFlags | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceSettingsConnectionPoolConfigFlags | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataGoogleSqlDatabaseInstanceSettingsConnectionPoolConfigFlagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceSettingsConnectionPoolConfigFlagsOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceSettingsConnectionPoolConfig {
}
export declare function dataGoogleSqlDatabaseInstanceSettingsConnectionPoolConfigToTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsConnectionPoolConfig): any;
export declare function dataGoogleSqlDatabaseInstanceSettingsConnectionPoolConfigToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsConnectionPoolConfig): any;
export declare class DataGoogleSqlDatabaseInstanceSettingsConnectionPoolConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceSettingsConnectionPoolConfig | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceSettingsConnectionPoolConfig | undefined);
    get connectionPoolingEnabled(): cdktn.IResolvable;
    private _flags;
    get flags(): DataGoogleSqlDatabaseInstanceSettingsConnectionPoolConfigFlagsList;
}
export declare class DataGoogleSqlDatabaseInstanceSettingsConnectionPoolConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceSettingsConnectionPoolConfigOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceSettingsDataCacheConfig {
}
export declare function dataGoogleSqlDatabaseInstanceSettingsDataCacheConfigToTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsDataCacheConfig): any;
export declare function dataGoogleSqlDatabaseInstanceSettingsDataCacheConfigToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsDataCacheConfig): any;
export declare class DataGoogleSqlDatabaseInstanceSettingsDataCacheConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceSettingsDataCacheConfig | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceSettingsDataCacheConfig | undefined);
    get dataCacheEnabled(): cdktn.IResolvable;
}
export declare class DataGoogleSqlDatabaseInstanceSettingsDataCacheConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceSettingsDataCacheConfigOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceSettingsDatabaseFlags {
}
export declare function dataGoogleSqlDatabaseInstanceSettingsDatabaseFlagsToTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsDatabaseFlags): any;
export declare function dataGoogleSqlDatabaseInstanceSettingsDatabaseFlagsToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsDatabaseFlags): any;
export declare class DataGoogleSqlDatabaseInstanceSettingsDatabaseFlagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceSettingsDatabaseFlags | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceSettingsDatabaseFlags | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataGoogleSqlDatabaseInstanceSettingsDatabaseFlagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceSettingsDatabaseFlagsOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceSettingsDenyMaintenancePeriod {
}
export declare function dataGoogleSqlDatabaseInstanceSettingsDenyMaintenancePeriodToTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsDenyMaintenancePeriod): any;
export declare function dataGoogleSqlDatabaseInstanceSettingsDenyMaintenancePeriodToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsDenyMaintenancePeriod): any;
export declare class DataGoogleSqlDatabaseInstanceSettingsDenyMaintenancePeriodOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceSettingsDenyMaintenancePeriod | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceSettingsDenyMaintenancePeriod | undefined);
    get endDate(): string;
    get startDate(): string;
    get time(): string;
}
export declare class DataGoogleSqlDatabaseInstanceSettingsDenyMaintenancePeriodList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceSettingsDenyMaintenancePeriodOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceSettingsEntraidConfig {
}
export declare function dataGoogleSqlDatabaseInstanceSettingsEntraidConfigToTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsEntraidConfig): any;
export declare function dataGoogleSqlDatabaseInstanceSettingsEntraidConfigToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsEntraidConfig): any;
export declare class DataGoogleSqlDatabaseInstanceSettingsEntraidConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceSettingsEntraidConfig | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceSettingsEntraidConfig | undefined);
    get applicationId(): string;
    get tenantId(): string;
}
export declare class DataGoogleSqlDatabaseInstanceSettingsEntraidConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceSettingsEntraidConfigOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceSettingsFinalBackupConfig {
}
export declare function dataGoogleSqlDatabaseInstanceSettingsFinalBackupConfigToTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsFinalBackupConfig): any;
export declare function dataGoogleSqlDatabaseInstanceSettingsFinalBackupConfigToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsFinalBackupConfig): any;
export declare class DataGoogleSqlDatabaseInstanceSettingsFinalBackupConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceSettingsFinalBackupConfig | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceSettingsFinalBackupConfig | undefined);
    get enabled(): cdktn.IResolvable;
    get retentionDays(): number;
}
export declare class DataGoogleSqlDatabaseInstanceSettingsFinalBackupConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceSettingsFinalBackupConfigOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceSettingsInsightsConfig {
}
export declare function dataGoogleSqlDatabaseInstanceSettingsInsightsConfigToTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsInsightsConfig): any;
export declare function dataGoogleSqlDatabaseInstanceSettingsInsightsConfigToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsInsightsConfig): any;
export declare class DataGoogleSqlDatabaseInstanceSettingsInsightsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceSettingsInsightsConfig | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceSettingsInsightsConfig | undefined);
    get enhancedQueryInsightsEnabled(): cdktn.IResolvable;
    get queryInsightsEnabled(): cdktn.IResolvable;
    get queryPlansPerMinute(): number;
    get queryStringLength(): number;
    get recordApplicationTags(): cdktn.IResolvable;
    get recordClientAddress(): cdktn.IResolvable;
}
export declare class DataGoogleSqlDatabaseInstanceSettingsInsightsConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceSettingsInsightsConfigOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceSettingsIpConfigurationAuthorizedNetworks {
}
export declare function dataGoogleSqlDatabaseInstanceSettingsIpConfigurationAuthorizedNetworksToTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsIpConfigurationAuthorizedNetworks): any;
export declare function dataGoogleSqlDatabaseInstanceSettingsIpConfigurationAuthorizedNetworksToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsIpConfigurationAuthorizedNetworks): any;
export declare class DataGoogleSqlDatabaseInstanceSettingsIpConfigurationAuthorizedNetworksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceSettingsIpConfigurationAuthorizedNetworks | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceSettingsIpConfigurationAuthorizedNetworks | undefined);
    get expirationTime(): string;
    get name(): string;
    get value(): string;
}
export declare class DataGoogleSqlDatabaseInstanceSettingsIpConfigurationAuthorizedNetworksList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceSettingsIpConfigurationAuthorizedNetworksOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceSettingsIpConfigurationPscConfigPscAutoConnections {
}
export declare function dataGoogleSqlDatabaseInstanceSettingsIpConfigurationPscConfigPscAutoConnectionsToTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsIpConfigurationPscConfigPscAutoConnections): any;
export declare function dataGoogleSqlDatabaseInstanceSettingsIpConfigurationPscConfigPscAutoConnectionsToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsIpConfigurationPscConfigPscAutoConnections): any;
export declare class DataGoogleSqlDatabaseInstanceSettingsIpConfigurationPscConfigPscAutoConnectionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceSettingsIpConfigurationPscConfigPscAutoConnections | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceSettingsIpConfigurationPscConfigPscAutoConnections | undefined);
    get consumerNetwork(): string;
    get consumerNetworkStatus(): string;
    get consumerServiceProjectId(): string;
    get instanceAutoDnsStatus(): string;
    get ipAddress(): string;
    get serviceConnectionPolicy(): string;
    get serviceConnectionPolicyCreationResult(): string;
    get status(): string;
    get writeEndpointAutoDnsStatus(): string;
}
export declare class DataGoogleSqlDatabaseInstanceSettingsIpConfigurationPscConfigPscAutoConnectionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceSettingsIpConfigurationPscConfigPscAutoConnectionsOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceSettingsIpConfigurationPscConfig {
}
export declare function dataGoogleSqlDatabaseInstanceSettingsIpConfigurationPscConfigToTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsIpConfigurationPscConfig): any;
export declare function dataGoogleSqlDatabaseInstanceSettingsIpConfigurationPscConfigToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsIpConfigurationPscConfig): any;
export declare class DataGoogleSqlDatabaseInstanceSettingsIpConfigurationPscConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceSettingsIpConfigurationPscConfig | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceSettingsIpConfigurationPscConfig | undefined);
    get allowedConsumerProjects(): string[];
    get networkAttachmentUri(): string;
    get pscAutoConnectionPolicyEnabled(): cdktn.IResolvable;
    private _pscAutoConnections;
    get pscAutoConnections(): DataGoogleSqlDatabaseInstanceSettingsIpConfigurationPscConfigPscAutoConnectionsList;
    get pscAutoDnsEnabled(): cdktn.IResolvable;
    get pscEnabled(): cdktn.IResolvable;
    get pscWriteEndpointDnsEnabled(): cdktn.IResolvable;
}
export declare class DataGoogleSqlDatabaseInstanceSettingsIpConfigurationPscConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceSettingsIpConfigurationPscConfigOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceSettingsIpConfiguration {
}
export declare function dataGoogleSqlDatabaseInstanceSettingsIpConfigurationToTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsIpConfiguration): any;
export declare function dataGoogleSqlDatabaseInstanceSettingsIpConfigurationToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsIpConfiguration): any;
export declare class DataGoogleSqlDatabaseInstanceSettingsIpConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceSettingsIpConfiguration | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceSettingsIpConfiguration | undefined);
    get allocatedIpRange(): string;
    private _authorizedNetworks;
    get authorizedNetworks(): DataGoogleSqlDatabaseInstanceSettingsIpConfigurationAuthorizedNetworksList;
    get customSubjectAlternativeNames(): string[];
    get enablePrivatePathForGoogleCloudServices(): cdktn.IResolvable;
    get ipv4Enabled(): cdktn.IResolvable;
    get privateNetwork(): string;
    private _pscConfig;
    get pscConfig(): DataGoogleSqlDatabaseInstanceSettingsIpConfigurationPscConfigList;
    get serverCaMode(): string;
    get serverCaPool(): string;
    get serverCertificateRotationMode(): string;
    get sslMode(): string;
}
export declare class DataGoogleSqlDatabaseInstanceSettingsIpConfigurationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceSettingsIpConfigurationOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceSettingsLocationPreference {
}
export declare function dataGoogleSqlDatabaseInstanceSettingsLocationPreferenceToTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsLocationPreference): any;
export declare function dataGoogleSqlDatabaseInstanceSettingsLocationPreferenceToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsLocationPreference): any;
export declare class DataGoogleSqlDatabaseInstanceSettingsLocationPreferenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceSettingsLocationPreference | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceSettingsLocationPreference | undefined);
    get followGaeApplication(): string;
    get secondaryZone(): string;
    get zone(): string;
}
export declare class DataGoogleSqlDatabaseInstanceSettingsLocationPreferenceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceSettingsLocationPreferenceOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceSettingsMaintenanceWindow {
}
export declare function dataGoogleSqlDatabaseInstanceSettingsMaintenanceWindowToTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsMaintenanceWindow): any;
export declare function dataGoogleSqlDatabaseInstanceSettingsMaintenanceWindowToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsMaintenanceWindow): any;
export declare class DataGoogleSqlDatabaseInstanceSettingsMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceSettingsMaintenanceWindow | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceSettingsMaintenanceWindow | undefined);
    get day(): number;
    get hour(): number;
    get updateTrack(): string;
}
export declare class DataGoogleSqlDatabaseInstanceSettingsMaintenanceWindowList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceSettingsMaintenanceWindowOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceSettingsPasswordValidationPolicy {
}
export declare function dataGoogleSqlDatabaseInstanceSettingsPasswordValidationPolicyToTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsPasswordValidationPolicy): any;
export declare function dataGoogleSqlDatabaseInstanceSettingsPasswordValidationPolicyToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsPasswordValidationPolicy): any;
export declare class DataGoogleSqlDatabaseInstanceSettingsPasswordValidationPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceSettingsPasswordValidationPolicy | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceSettingsPasswordValidationPolicy | undefined);
    get complexity(): string;
    get disallowUsernameSubstring(): cdktn.IResolvable;
    get enablePasswordPolicy(): cdktn.IResolvable;
    get minLength(): number;
    get passwordChangeInterval(): string;
    get reuseInterval(): number;
}
export declare class DataGoogleSqlDatabaseInstanceSettingsPasswordValidationPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceSettingsPasswordValidationPolicyOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceSettingsPerformanceCaptureConfig {
}
export declare function dataGoogleSqlDatabaseInstanceSettingsPerformanceCaptureConfigToTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsPerformanceCaptureConfig): any;
export declare function dataGoogleSqlDatabaseInstanceSettingsPerformanceCaptureConfigToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsPerformanceCaptureConfig): any;
export declare class DataGoogleSqlDatabaseInstanceSettingsPerformanceCaptureConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceSettingsPerformanceCaptureConfig | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceSettingsPerformanceCaptureConfig | undefined);
    get cpuUtilizationThresholdPercent(): number;
    get enabled(): cdktn.IResolvable;
    get historyListLengthThresholdCount(): number;
    get memoryUsageThresholdPercent(): number;
    get probeThreshold(): number;
    get probingIntervalSeconds(): number;
    get runningThreadsThreshold(): number;
    get secondsBehindSourceThreshold(): number;
    get semaphoreWaitThresholdCount(): number;
    get transactionDurationThreshold(): number;
    get transactionKillExcludedUserHosts(): string[];
    get transactionKillThresholdSeconds(): number;
    get transactionKillType(): string;
    get transactionLockWaitThresholdCount(): number;
}
export declare class DataGoogleSqlDatabaseInstanceSettingsPerformanceCaptureConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceSettingsPerformanceCaptureConfigOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceSettingsReadPoolAutoScaleConfigTargetMetrics {
}
export declare function dataGoogleSqlDatabaseInstanceSettingsReadPoolAutoScaleConfigTargetMetricsToTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsReadPoolAutoScaleConfigTargetMetrics): any;
export declare function dataGoogleSqlDatabaseInstanceSettingsReadPoolAutoScaleConfigTargetMetricsToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsReadPoolAutoScaleConfigTargetMetrics): any;
export declare class DataGoogleSqlDatabaseInstanceSettingsReadPoolAutoScaleConfigTargetMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceSettingsReadPoolAutoScaleConfigTargetMetrics | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceSettingsReadPoolAutoScaleConfigTargetMetrics | undefined);
    get metric(): string;
    get targetValue(): number;
}
export declare class DataGoogleSqlDatabaseInstanceSettingsReadPoolAutoScaleConfigTargetMetricsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceSettingsReadPoolAutoScaleConfigTargetMetricsOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceSettingsReadPoolAutoScaleConfig {
}
export declare function dataGoogleSqlDatabaseInstanceSettingsReadPoolAutoScaleConfigToTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsReadPoolAutoScaleConfig): any;
export declare function dataGoogleSqlDatabaseInstanceSettingsReadPoolAutoScaleConfigToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsReadPoolAutoScaleConfig): any;
export declare class DataGoogleSqlDatabaseInstanceSettingsReadPoolAutoScaleConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceSettingsReadPoolAutoScaleConfig | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceSettingsReadPoolAutoScaleConfig | undefined);
    get disableScaleIn(): cdktn.IResolvable;
    get enabled(): cdktn.IResolvable;
    get maxNodeCount(): number;
    get minNodeCount(): number;
    get scaleInCooldownSeconds(): number;
    get scaleOutCooldownSeconds(): number;
    private _targetMetrics;
    get targetMetrics(): DataGoogleSqlDatabaseInstanceSettingsReadPoolAutoScaleConfigTargetMetricsList;
}
export declare class DataGoogleSqlDatabaseInstanceSettingsReadPoolAutoScaleConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceSettingsReadPoolAutoScaleConfigOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceSettingsSqlServerAuditConfig {
}
export declare function dataGoogleSqlDatabaseInstanceSettingsSqlServerAuditConfigToTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsSqlServerAuditConfig): any;
export declare function dataGoogleSqlDatabaseInstanceSettingsSqlServerAuditConfigToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceSettingsSqlServerAuditConfig): any;
export declare class DataGoogleSqlDatabaseInstanceSettingsSqlServerAuditConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceSettingsSqlServerAuditConfig | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceSettingsSqlServerAuditConfig | undefined);
    get bucket(): string;
    get retentionInterval(): string;
    get uploadInterval(): string;
}
export declare class DataGoogleSqlDatabaseInstanceSettingsSqlServerAuditConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceSettingsSqlServerAuditConfigOutputReference;
}
export interface DataGoogleSqlDatabaseInstanceSettings {
}
export declare function dataGoogleSqlDatabaseInstanceSettingsToTerraform(struct?: DataGoogleSqlDatabaseInstanceSettings): any;
export declare function dataGoogleSqlDatabaseInstanceSettingsToHclTerraform(struct?: DataGoogleSqlDatabaseInstanceSettings): any;
export declare class DataGoogleSqlDatabaseInstanceSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstanceSettings | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstanceSettings | undefined);
    get activationPolicy(): string;
    private _activeDirectoryConfig;
    get activeDirectoryConfig(): DataGoogleSqlDatabaseInstanceSettingsActiveDirectoryConfigList;
    private _advancedMachineFeatures;
    get advancedMachineFeatures(): DataGoogleSqlDatabaseInstanceSettingsAdvancedMachineFeaturesList;
    get autoUpgradeEnabled(): cdktn.IResolvable;
    get availabilityType(): string;
    private _backupConfiguration;
    get backupConfiguration(): DataGoogleSqlDatabaseInstanceSettingsBackupConfigurationList;
    get collation(): string;
    private _connectionPoolConfig;
    get connectionPoolConfig(): DataGoogleSqlDatabaseInstanceSettingsConnectionPoolConfigList;
    get connectorEnforcement(): string;
    get dataApiAccess(): string;
    private _dataCacheConfig;
    get dataCacheConfig(): DataGoogleSqlDatabaseInstanceSettingsDataCacheConfigList;
    get dataDiskProvisionedIops(): number;
    get dataDiskProvisionedThroughput(): number;
    private _databaseFlags;
    get databaseFlags(): DataGoogleSqlDatabaseInstanceSettingsDatabaseFlagsList;
    get deletionProtectionEnabled(): cdktn.IResolvable;
    private _denyMaintenancePeriod;
    get denyMaintenancePeriod(): DataGoogleSqlDatabaseInstanceSettingsDenyMaintenancePeriodList;
    get diskAutoresize(): cdktn.IResolvable;
    get diskAutoresizeLimit(): number;
    get diskSize(): number;
    get diskType(): string;
    get edition(): string;
    get effectiveAvailabilityType(): string;
    get enableDataplexIntegration(): cdktn.IResolvable;
    get enableGoogleMlIntegration(): cdktn.IResolvable;
    private _entraidConfig;
    get entraidConfig(): DataGoogleSqlDatabaseInstanceSettingsEntraidConfigList;
    private _finalBackupConfig;
    get finalBackupConfig(): DataGoogleSqlDatabaseInstanceSettingsFinalBackupConfigList;
    private _insightsConfig;
    get insightsConfig(): DataGoogleSqlDatabaseInstanceSettingsInsightsConfigList;
    private _ipConfiguration;
    get ipConfiguration(): DataGoogleSqlDatabaseInstanceSettingsIpConfigurationList;
    private _locationPreference;
    get locationPreference(): DataGoogleSqlDatabaseInstanceSettingsLocationPreferenceList;
    private _maintenanceWindow;
    get maintenanceWindow(): DataGoogleSqlDatabaseInstanceSettingsMaintenanceWindowList;
    private _passwordValidationPolicy;
    get passwordValidationPolicy(): DataGoogleSqlDatabaseInstanceSettingsPasswordValidationPolicyList;
    private _performanceCaptureConfig;
    get performanceCaptureConfig(): DataGoogleSqlDatabaseInstanceSettingsPerformanceCaptureConfigList;
    get pricingPlan(): string;
    private _readPoolAutoScaleConfig;
    get readPoolAutoScaleConfig(): DataGoogleSqlDatabaseInstanceSettingsReadPoolAutoScaleConfigList;
    get replicationLagMaxSeconds(): number;
    get retainBackupsOnDelete(): cdktn.IResolvable;
    private _sqlServerAuditConfig;
    get sqlServerAuditConfig(): DataGoogleSqlDatabaseInstanceSettingsSqlServerAuditConfigList;
    get tier(): string;
    get timeZone(): string;
    private _userLabels;
    get userLabels(): cdktn.StringMap;
    get version(): number;
}
export declare class DataGoogleSqlDatabaseInstanceSettingsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstanceSettingsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_sql_database_instance google_sql_database_instance}
*/
export declare class DataGoogleSqlDatabaseInstance extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_sql_database_instance";
    /**
    * Generates CDKTN code for importing a DataGoogleSqlDatabaseInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleSqlDatabaseInstance to import
    * @param importFromId The id of the existing DataGoogleSqlDatabaseInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_sql_database_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleSqlDatabaseInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_sql_database_instance google_sql_database_instance} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleSqlDatabaseInstanceConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleSqlDatabaseInstanceConfig);
    get availableMaintenanceVersions(): string[];
    get backupdrBackup(): string;
    private _blueGreenDeployment;
    get blueGreenDeployment(): DataGoogleSqlDatabaseInstanceBlueGreenDeploymentList;
    private _clone;
    get clone(): DataGoogleSqlDatabaseInstanceCloneList;
    get connectionName(): string;
    get databaseVersion(): string;
    get deletionPolicy(): string;
    get deletionProtection(): cdktn.IResolvable;
    get dnsName(): string;
    private _dnsNames;
    get dnsNames(): DataGoogleSqlDatabaseInstanceDnsNamesList;
    get encryptionConfidentialMode(): cdktn.IResolvable;
    get encryptionKeyName(): string;
    get enforceNewSqlNetworkArchitecture(): cdktn.IResolvable;
    get finalBackupDescription(): string;
    get firstIpAddress(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get includeReplicasForMajorVersionUpgrade(): cdktn.IResolvable;
    get instanceType(): string;
    private _ipAddress;
    get ipAddress(): DataGoogleSqlDatabaseInstanceIpAddressList;
    get maintenanceVersion(): string;
    get masterInstanceName(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get nodeCount(): number;
    private _pointInTimeRestoreContext;
    get pointInTimeRestoreContext(): DataGoogleSqlDatabaseInstancePointInTimeRestoreContextList;
    get privateIpAddress(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get pscServiceAttachmentLink(): string;
    get publicIpAddress(): string;
    get region(): string;
    private _replicaConfiguration;
    get replicaConfiguration(): DataGoogleSqlDatabaseInstanceReplicaConfigurationList;
    get replicaNames(): string[];
    private _replicationCluster;
    get replicationCluster(): DataGoogleSqlDatabaseInstanceReplicationClusterList;
    private _restoreBackupContext;
    get restoreBackupContext(): DataGoogleSqlDatabaseInstanceRestoreBackupContextList;
    get rootPassword(): string;
    get rootPasswordWo(): string;
    get rootPasswordWoVersion(): string;
    get selfLink(): string;
    private _serverCaCert;
    get serverCaCert(): DataGoogleSqlDatabaseInstanceServerCaCertList;
    get serviceAccountEmailAddress(): string;
    private _settings;
    get settings(): DataGoogleSqlDatabaseInstanceSettingsList;
    get switchTransactionLogsToCloudStorageEnabled(): cdktn.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
