/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleMonitoringAppEngineServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_monitoring_app_engine_service#id DataGoogleMonitoringAppEngineService#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the App Engine module underlying this service.
    * Corresponds to the 'moduleId' resource label for a 'gae_app'
    * monitored resource(see https://cloud.google.com/monitoring/api/resources#tag_gae_app)
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_monitoring_app_engine_service#module_id DataGoogleMonitoringAppEngineService#module_id}
    */
    readonly moduleId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_monitoring_app_engine_service#project DataGoogleMonitoringAppEngineService#project}
    */
    readonly project?: string;
}
export interface DataGoogleMonitoringAppEngineServiceTelemetry {
}
export declare function dataGoogleMonitoringAppEngineServiceTelemetryToTerraform(struct?: DataGoogleMonitoringAppEngineServiceTelemetry): any;
export declare function dataGoogleMonitoringAppEngineServiceTelemetryToHclTerraform(struct?: DataGoogleMonitoringAppEngineServiceTelemetry): any;
export declare class DataGoogleMonitoringAppEngineServiceTelemetryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMonitoringAppEngineServiceTelemetry | undefined;
    set internalValue(value: DataGoogleMonitoringAppEngineServiceTelemetry | undefined);
    get resourceName(): string;
}
export declare class DataGoogleMonitoringAppEngineServiceTelemetryList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMonitoringAppEngineServiceTelemetryOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_monitoring_app_engine_service google_monitoring_app_engine_service}
*/
export declare class DataGoogleMonitoringAppEngineService extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_monitoring_app_engine_service";
    /**
    * Generates CDKTN code for importing a DataGoogleMonitoringAppEngineService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleMonitoringAppEngineService to import
    * @param importFromId The id of the existing DataGoogleMonitoringAppEngineService that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_monitoring_app_engine_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleMonitoringAppEngineService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_monitoring_app_engine_service google_monitoring_app_engine_service} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleMonitoringAppEngineServiceConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleMonitoringAppEngineServiceConfig);
    get deletionPolicy(): string;
    get displayName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _moduleId?;
    get moduleId(): string;
    set moduleId(value: string);
    get moduleIdInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get serviceId(): string;
    private _telemetry;
    get telemetry(): DataGoogleMonitoringAppEngineServiceTelemetryList;
    private _userLabels;
    get userLabels(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
