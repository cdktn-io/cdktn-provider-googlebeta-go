/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleParameterManagerParameterVersionRenderConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_parameter_manager_parameter_version_render#id DataGoogleParameterManagerParameterVersionRender#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_parameter_manager_parameter_version_render#parameter DataGoogleParameterManagerParameterVersionRender#parameter}
    */
    readonly parameter: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_parameter_manager_parameter_version_render#parameter_version_id DataGoogleParameterManagerParameterVersionRender#parameter_version_id}
    */
    readonly parameterVersionId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_parameter_manager_parameter_version_render#project DataGoogleParameterManagerParameterVersionRender#project}
    */
    readonly project?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_parameter_manager_parameter_version_render google_parameter_manager_parameter_version_render}
*/
export declare class DataGoogleParameterManagerParameterVersionRender extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_parameter_manager_parameter_version_render";
    /**
    * Generates CDKTN code for importing a DataGoogleParameterManagerParameterVersionRender resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleParameterManagerParameterVersionRender to import
    * @param importFromId The id of the existing DataGoogleParameterManagerParameterVersionRender that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_parameter_manager_parameter_version_render#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleParameterManagerParameterVersionRender to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_parameter_manager_parameter_version_render google_parameter_manager_parameter_version_render} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleParameterManagerParameterVersionRenderConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleParameterManagerParameterVersionRenderConfig);
    get disabled(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _parameter?;
    get parameter(): string;
    set parameter(value: string);
    get parameterInput(): string | undefined;
    get parameterData(): string;
    private _parameterVersionId?;
    get parameterVersionId(): string;
    set parameterVersionId(value: string);
    get parameterVersionIdInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get renderedParameterData(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
