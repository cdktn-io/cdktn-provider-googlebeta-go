/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleComputeRoutersConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_routers#id DataGoogleComputeRouters#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_routers#project DataGoogleComputeRouters#project}
    */
    readonly project?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_routers#region DataGoogleComputeRouters#region}
    */
    readonly region?: string;
}
export interface DataGoogleComputeRoutersRoutersBgpAdvertisedIpRanges {
}
export declare function dataGoogleComputeRoutersRoutersBgpAdvertisedIpRangesToTerraform(struct?: DataGoogleComputeRoutersRoutersBgpAdvertisedIpRanges): any;
export declare function dataGoogleComputeRoutersRoutersBgpAdvertisedIpRangesToHclTerraform(struct?: DataGoogleComputeRoutersRoutersBgpAdvertisedIpRanges): any;
export declare class DataGoogleComputeRoutersRoutersBgpAdvertisedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRoutersRoutersBgpAdvertisedIpRanges | undefined;
    set internalValue(value: DataGoogleComputeRoutersRoutersBgpAdvertisedIpRanges | undefined);
    get description(): string;
    get range(): string;
}
export declare class DataGoogleComputeRoutersRoutersBgpAdvertisedIpRangesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRoutersRoutersBgpAdvertisedIpRangesOutputReference;
}
export interface DataGoogleComputeRoutersRoutersBgp {
}
export declare function dataGoogleComputeRoutersRoutersBgpToTerraform(struct?: DataGoogleComputeRoutersRoutersBgp): any;
export declare function dataGoogleComputeRoutersRoutersBgpToHclTerraform(struct?: DataGoogleComputeRoutersRoutersBgp): any;
export declare class DataGoogleComputeRoutersRoutersBgpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRoutersRoutersBgp | undefined;
    set internalValue(value: DataGoogleComputeRoutersRoutersBgp | undefined);
    get advertiseMode(): string;
    get advertisedGroups(): string[];
    private _advertisedIpRanges;
    get advertisedIpRanges(): DataGoogleComputeRoutersRoutersBgpAdvertisedIpRangesList;
    get asn(): number;
    get keepaliveInterval(): number;
}
export declare class DataGoogleComputeRoutersRoutersBgpList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRoutersRoutersBgpOutputReference;
}
export interface DataGoogleComputeRoutersRoutersBgpPeers {
}
export declare function dataGoogleComputeRoutersRoutersBgpPeersToTerraform(struct?: DataGoogleComputeRoutersRoutersBgpPeers): any;
export declare function dataGoogleComputeRoutersRoutersBgpPeersToHclTerraform(struct?: DataGoogleComputeRoutersRoutersBgpPeers): any;
export declare class DataGoogleComputeRoutersRoutersBgpPeersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRoutersRoutersBgpPeers | undefined;
    set internalValue(value: DataGoogleComputeRoutersRoutersBgpPeers | undefined);
    get advertiseMode(): string;
    get advertisedRoutePriority(): number;
    get enable(): string;
    get enableIpv6(): cdktn.IResolvable;
    get interfaceName(): string;
    get ipAddress(): string;
    get managementType(): string;
    get name(): string;
    get peerAsn(): number;
    get peerIpAddress(): string;
}
export declare class DataGoogleComputeRoutersRoutersBgpPeersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRoutersRoutersBgpPeersOutputReference;
}
export interface DataGoogleComputeRoutersRoutersInterfaces {
}
export declare function dataGoogleComputeRoutersRoutersInterfacesToTerraform(struct?: DataGoogleComputeRoutersRoutersInterfaces): any;
export declare function dataGoogleComputeRoutersRoutersInterfacesToHclTerraform(struct?: DataGoogleComputeRoutersRoutersInterfaces): any;
export declare class DataGoogleComputeRoutersRoutersInterfacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRoutersRoutersInterfaces | undefined;
    set internalValue(value: DataGoogleComputeRoutersRoutersInterfaces | undefined);
    get ipRange(): string;
    get linkedInterconnectAttachment(): string;
    get linkedVpnTunnel(): string;
    get name(): string;
    get privateIpAddress(): string;
    get redundantInterface(): string;
    get subnetwork(): string;
}
export declare class DataGoogleComputeRoutersRoutersInterfacesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRoutersRoutersInterfacesOutputReference;
}
export interface DataGoogleComputeRoutersRoutersMd5AuthenticationKeys {
}
export declare function dataGoogleComputeRoutersRoutersMd5AuthenticationKeysToTerraform(struct?: DataGoogleComputeRoutersRoutersMd5AuthenticationKeys): any;
export declare function dataGoogleComputeRoutersRoutersMd5AuthenticationKeysToHclTerraform(struct?: DataGoogleComputeRoutersRoutersMd5AuthenticationKeys): any;
export declare class DataGoogleComputeRoutersRoutersMd5AuthenticationKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRoutersRoutersMd5AuthenticationKeys | undefined;
    set internalValue(value: DataGoogleComputeRoutersRoutersMd5AuthenticationKeys | undefined);
    get key(): string;
    get name(): string;
}
export declare class DataGoogleComputeRoutersRoutersMd5AuthenticationKeysList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRoutersRoutersMd5AuthenticationKeysOutputReference;
}
export interface DataGoogleComputeRoutersRoutersNats {
}
export declare function dataGoogleComputeRoutersRoutersNatsToTerraform(struct?: DataGoogleComputeRoutersRoutersNats): any;
export declare function dataGoogleComputeRoutersRoutersNatsToHclTerraform(struct?: DataGoogleComputeRoutersRoutersNats): any;
export declare class DataGoogleComputeRoutersRoutersNatsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRoutersRoutersNats | undefined;
    set internalValue(value: DataGoogleComputeRoutersRoutersNats | undefined);
    get enableEndpointIndependentMapping(): cdktn.IResolvable;
    get icmpIdleTimeoutSec(): number;
    get minPortsPerVm(): number;
    get name(): string;
    get natIpAllocateOption(): string;
    get natIps(): string[];
    get sourceSubnetworkIpRangesToNat(): string;
    get tcpEstablishedIdleTimeoutSec(): number;
    get tcpTransitoryIdleTimeoutSec(): number;
    get udpIdleTimeoutSec(): number;
}
export declare class DataGoogleComputeRoutersRoutersNatsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRoutersRoutersNatsOutputReference;
}
export interface DataGoogleComputeRoutersRouters {
}
export declare function dataGoogleComputeRoutersRoutersToTerraform(struct?: DataGoogleComputeRoutersRouters): any;
export declare function dataGoogleComputeRoutersRoutersToHclTerraform(struct?: DataGoogleComputeRoutersRouters): any;
export declare class DataGoogleComputeRoutersRoutersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRoutersRouters | undefined;
    set internalValue(value: DataGoogleComputeRoutersRouters | undefined);
    private _bgp;
    get bgp(): DataGoogleComputeRoutersRoutersBgpList;
    private _bgpPeers;
    get bgpPeers(): DataGoogleComputeRoutersRoutersBgpPeersList;
    get creationTimestamp(): string;
    get description(): string;
    get encryptedInterconnectRouter(): cdktn.IResolvable;
    private _interfaces;
    get interfaces(): DataGoogleComputeRoutersRoutersInterfacesList;
    private _md5AuthenticationKeys;
    get md5AuthenticationKeys(): DataGoogleComputeRoutersRoutersMd5AuthenticationKeysList;
    get name(): string;
    private _nats;
    get nats(): DataGoogleComputeRoutersRoutersNatsList;
    get network(): string;
    get selfLink(): string;
}
export declare class DataGoogleComputeRoutersRoutersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRoutersRoutersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_routers google_compute_routers}
*/
export declare class DataGoogleComputeRouters extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_compute_routers";
    /**
    * Generates CDKTN code for importing a DataGoogleComputeRouters resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleComputeRouters to import
    * @param importFromId The id of the existing DataGoogleComputeRouters that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_routers#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleComputeRouters to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_routers google_compute_routers} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleComputeRoutersConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGoogleComputeRoutersConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _routers;
    get routers(): DataGoogleComputeRoutersRoutersList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
