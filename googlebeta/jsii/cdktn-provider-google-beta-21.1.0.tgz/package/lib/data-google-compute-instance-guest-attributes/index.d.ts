/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleComputeInstanceGuestAttributesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_instance_guest_attributes#id DataGoogleComputeInstanceGuestAttributes#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_instance_guest_attributes#name DataGoogleComputeInstanceGuestAttributes#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_instance_guest_attributes#project DataGoogleComputeInstanceGuestAttributes#project}
    */
    readonly project?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_instance_guest_attributes#query_path DataGoogleComputeInstanceGuestAttributes#query_path}
    */
    readonly queryPath?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_instance_guest_attributes#region DataGoogleComputeInstanceGuestAttributes#region}
    */
    readonly region?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_instance_guest_attributes#variable_key DataGoogleComputeInstanceGuestAttributes#variable_key}
    */
    readonly variableKey?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_instance_guest_attributes#zone DataGoogleComputeInstanceGuestAttributes#zone}
    */
    readonly zone?: string;
}
export interface DataGoogleComputeInstanceGuestAttributesQueryValue {
}
export declare function dataGoogleComputeInstanceGuestAttributesQueryValueToTerraform(struct?: DataGoogleComputeInstanceGuestAttributesQueryValue): any;
export declare function dataGoogleComputeInstanceGuestAttributesQueryValueToHclTerraform(struct?: DataGoogleComputeInstanceGuestAttributesQueryValue): any;
export declare class DataGoogleComputeInstanceGuestAttributesQueryValueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceGuestAttributesQueryValue | undefined;
    set internalValue(value: DataGoogleComputeInstanceGuestAttributesQueryValue | undefined);
    get key(): string;
    get namespace(): string;
    get value(): string;
}
export declare class DataGoogleComputeInstanceGuestAttributesQueryValueList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceGuestAttributesQueryValueOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_instance_guest_attributes google_compute_instance_guest_attributes}
*/
export declare class DataGoogleComputeInstanceGuestAttributes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_compute_instance_guest_attributes";
    /**
    * Generates CDKTN code for importing a DataGoogleComputeInstanceGuestAttributes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleComputeInstanceGuestAttributes to import
    * @param importFromId The id of the existing DataGoogleComputeInstanceGuestAttributes that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_instance_guest_attributes#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleComputeInstanceGuestAttributes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_instance_guest_attributes google_compute_instance_guest_attributes} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleComputeInstanceGuestAttributesConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleComputeInstanceGuestAttributesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _queryPath?;
    get queryPath(): string;
    set queryPath(value: string);
    resetQueryPath(): void;
    get queryPathInput(): string | undefined;
    private _queryValue;
    get queryValue(): DataGoogleComputeInstanceGuestAttributesQueryValueList;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _variableKey?;
    get variableKey(): string;
    set variableKey(value: string);
    resetVariableKey(): void;
    get variableKeyInput(): string | undefined;
    get variableValue(): string;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    resetZone(): void;
    get zoneInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
