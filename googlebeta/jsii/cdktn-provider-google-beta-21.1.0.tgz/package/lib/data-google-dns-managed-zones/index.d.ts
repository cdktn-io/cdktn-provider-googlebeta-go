/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleDnsManagedZonesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_dns_managed_zones#project DataGoogleDnsManagedZones#project}
    */
    readonly project?: string;
}
export interface DataGoogleDnsManagedZonesManagedZones {
}
export declare function dataGoogleDnsManagedZonesManagedZonesToTerraform(struct?: DataGoogleDnsManagedZonesManagedZones): any;
export declare function dataGoogleDnsManagedZonesManagedZonesToHclTerraform(struct?: DataGoogleDnsManagedZonesManagedZones): any;
export declare class DataGoogleDnsManagedZonesManagedZonesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleDnsManagedZonesManagedZones | undefined;
    set internalValue(value: DataGoogleDnsManagedZonesManagedZones | undefined);
    get description(): string;
    get dnsName(): string;
    get id(): string;
    get managedZoneId(): number;
    get name(): string;
    get nameServers(): string[];
    get project(): string;
    get visibility(): string;
}
export declare class DataGoogleDnsManagedZonesManagedZonesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleDnsManagedZonesManagedZonesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_dns_managed_zones google_dns_managed_zones}
*/
export declare class DataGoogleDnsManagedZones extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_dns_managed_zones";
    /**
    * Generates CDKTN code for importing a DataGoogleDnsManagedZones resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleDnsManagedZones to import
    * @param importFromId The id of the existing DataGoogleDnsManagedZones that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_dns_managed_zones#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleDnsManagedZones to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_dns_managed_zones google_dns_managed_zones} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleDnsManagedZonesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGoogleDnsManagedZonesConfig);
    get id(): string;
    private _managedZones;
    get managedZones(): DataGoogleDnsManagedZonesManagedZonesList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
