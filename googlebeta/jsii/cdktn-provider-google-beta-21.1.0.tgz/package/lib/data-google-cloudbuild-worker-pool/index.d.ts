/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleCloudbuildWorkerPoolConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloudbuild_worker_pool#id DataGoogleCloudbuildWorkerPool#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location for the resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloudbuild_worker_pool#location DataGoogleCloudbuildWorkerPool#location}
    */
    readonly location: string;
    /**
    * User-defined name of the `WorkerPool`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloudbuild_worker_pool#name DataGoogleCloudbuildWorkerPool#name}
    */
    readonly name: string;
    /**
    * The project for the resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloudbuild_worker_pool#project DataGoogleCloudbuildWorkerPool#project}
    */
    readonly project?: string;
}
export interface DataGoogleCloudbuildWorkerPoolNetworkConfig {
}
export declare function dataGoogleCloudbuildWorkerPoolNetworkConfigToTerraform(struct?: DataGoogleCloudbuildWorkerPoolNetworkConfig): any;
export declare function dataGoogleCloudbuildWorkerPoolNetworkConfigToHclTerraform(struct?: DataGoogleCloudbuildWorkerPoolNetworkConfig): any;
export declare class DataGoogleCloudbuildWorkerPoolNetworkConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudbuildWorkerPoolNetworkConfig | undefined;
    set internalValue(value: DataGoogleCloudbuildWorkerPoolNetworkConfig | undefined);
    get peeredNetwork(): string;
    get peeredNetworkIpRange(): string;
}
export declare class DataGoogleCloudbuildWorkerPoolNetworkConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudbuildWorkerPoolNetworkConfigOutputReference;
}
export interface DataGoogleCloudbuildWorkerPoolPrivateServiceConnect {
}
export declare function dataGoogleCloudbuildWorkerPoolPrivateServiceConnectToTerraform(struct?: DataGoogleCloudbuildWorkerPoolPrivateServiceConnect): any;
export declare function dataGoogleCloudbuildWorkerPoolPrivateServiceConnectToHclTerraform(struct?: DataGoogleCloudbuildWorkerPoolPrivateServiceConnect): any;
export declare class DataGoogleCloudbuildWorkerPoolPrivateServiceConnectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudbuildWorkerPoolPrivateServiceConnect | undefined;
    set internalValue(value: DataGoogleCloudbuildWorkerPoolPrivateServiceConnect | undefined);
    get networkAttachment(): string;
    get routeAllTraffic(): cdktn.IResolvable;
}
export declare class DataGoogleCloudbuildWorkerPoolPrivateServiceConnectList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudbuildWorkerPoolPrivateServiceConnectOutputReference;
}
export interface DataGoogleCloudbuildWorkerPoolWorkerConfig {
}
export declare function dataGoogleCloudbuildWorkerPoolWorkerConfigToTerraform(struct?: DataGoogleCloudbuildWorkerPoolWorkerConfig): any;
export declare function dataGoogleCloudbuildWorkerPoolWorkerConfigToHclTerraform(struct?: DataGoogleCloudbuildWorkerPoolWorkerConfig): any;
export declare class DataGoogleCloudbuildWorkerPoolWorkerConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudbuildWorkerPoolWorkerConfig | undefined;
    set internalValue(value: DataGoogleCloudbuildWorkerPoolWorkerConfig | undefined);
    get diskSizeGb(): number;
    get enableNestedVirtualization(): cdktn.IResolvable;
    get machineType(): string;
    get noExternalIp(): cdktn.IResolvable;
}
export declare class DataGoogleCloudbuildWorkerPoolWorkerConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudbuildWorkerPoolWorkerConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloudbuild_worker_pool google_cloudbuild_worker_pool}
*/
export declare class DataGoogleCloudbuildWorkerPool extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_cloudbuild_worker_pool";
    /**
    * Generates CDKTN code for importing a DataGoogleCloudbuildWorkerPool resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleCloudbuildWorkerPool to import
    * @param importFromId The id of the existing DataGoogleCloudbuildWorkerPool that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloudbuild_worker_pool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleCloudbuildWorkerPool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloudbuild_worker_pool google_cloudbuild_worker_pool} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleCloudbuildWorkerPoolConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleCloudbuildWorkerPoolConfig);
    private _annotations;
    get annotations(): cdktn.StringMap;
    get createTime(): string;
    get deleteTime(): string;
    get deletionPolicy(): string;
    get displayName(): string;
    private _effectiveAnnotations;
    get effectiveAnnotations(): cdktn.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networkConfig;
    get networkConfig(): DataGoogleCloudbuildWorkerPoolNetworkConfigList;
    private _privateServiceConnect;
    get privateServiceConnect(): DataGoogleCloudbuildWorkerPoolPrivateServiceConnectList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get state(): string;
    get uid(): string;
    get updateTime(): string;
    private _workerConfig;
    get workerConfig(): DataGoogleCloudbuildWorkerPoolWorkerConfigList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
