/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleFilestoreInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_filestore_instance#id DataGoogleFilestoreInstance#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the location of the instance. This can be a region for ENTERPRISE tier instances.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_filestore_instance#location DataGoogleFilestoreInstance#location}
    */
    readonly location?: string;
    /**
    * The resource name of the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_filestore_instance#name DataGoogleFilestoreInstance#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_filestore_instance#project DataGoogleFilestoreInstance#project}
    */
    readonly project?: string;
}
export interface DataGoogleFilestoreInstanceDirectoryServicesLdap {
}
export declare function dataGoogleFilestoreInstanceDirectoryServicesLdapToTerraform(struct?: DataGoogleFilestoreInstanceDirectoryServicesLdap): any;
export declare function dataGoogleFilestoreInstanceDirectoryServicesLdapToHclTerraform(struct?: DataGoogleFilestoreInstanceDirectoryServicesLdap): any;
export declare class DataGoogleFilestoreInstanceDirectoryServicesLdapOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleFilestoreInstanceDirectoryServicesLdap | undefined;
    set internalValue(value: DataGoogleFilestoreInstanceDirectoryServicesLdap | undefined);
    get domain(): string;
    get groupsOu(): string;
    get servers(): string[];
    get usersOu(): string;
}
export declare class DataGoogleFilestoreInstanceDirectoryServicesLdapList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleFilestoreInstanceDirectoryServicesLdapOutputReference;
}
export interface DataGoogleFilestoreInstanceDirectoryServices {
}
export declare function dataGoogleFilestoreInstanceDirectoryServicesToTerraform(struct?: DataGoogleFilestoreInstanceDirectoryServices): any;
export declare function dataGoogleFilestoreInstanceDirectoryServicesToHclTerraform(struct?: DataGoogleFilestoreInstanceDirectoryServices): any;
export declare class DataGoogleFilestoreInstanceDirectoryServicesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleFilestoreInstanceDirectoryServices | undefined;
    set internalValue(value: DataGoogleFilestoreInstanceDirectoryServices | undefined);
    private _ldap;
    get ldap(): DataGoogleFilestoreInstanceDirectoryServicesLdapList;
}
export declare class DataGoogleFilestoreInstanceDirectoryServicesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleFilestoreInstanceDirectoryServicesOutputReference;
}
export interface DataGoogleFilestoreInstanceEffectiveReplicationReplicas {
}
export declare function dataGoogleFilestoreInstanceEffectiveReplicationReplicasToTerraform(struct?: DataGoogleFilestoreInstanceEffectiveReplicationReplicas): any;
export declare function dataGoogleFilestoreInstanceEffectiveReplicationReplicasToHclTerraform(struct?: DataGoogleFilestoreInstanceEffectiveReplicationReplicas): any;
export declare class DataGoogleFilestoreInstanceEffectiveReplicationReplicasOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleFilestoreInstanceEffectiveReplicationReplicas | undefined;
    set internalValue(value: DataGoogleFilestoreInstanceEffectiveReplicationReplicas | undefined);
    get lastActiveSyncTime(): string;
    get peerInstance(): string;
    get state(): string;
    get stateReasons(): string[];
}
export declare class DataGoogleFilestoreInstanceEffectiveReplicationReplicasList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleFilestoreInstanceEffectiveReplicationReplicasOutputReference;
}
export interface DataGoogleFilestoreInstanceEffectiveReplication {
}
export declare function dataGoogleFilestoreInstanceEffectiveReplicationToTerraform(struct?: DataGoogleFilestoreInstanceEffectiveReplication): any;
export declare function dataGoogleFilestoreInstanceEffectiveReplicationToHclTerraform(struct?: DataGoogleFilestoreInstanceEffectiveReplication): any;
export declare class DataGoogleFilestoreInstanceEffectiveReplicationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleFilestoreInstanceEffectiveReplication | undefined;
    set internalValue(value: DataGoogleFilestoreInstanceEffectiveReplication | undefined);
    private _replicas;
    get replicas(): DataGoogleFilestoreInstanceEffectiveReplicationReplicasList;
    get role(): string;
}
export declare class DataGoogleFilestoreInstanceEffectiveReplicationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleFilestoreInstanceEffectiveReplicationOutputReference;
}
export interface DataGoogleFilestoreInstanceFileSharesNfsExportOptions {
}
export declare function dataGoogleFilestoreInstanceFileSharesNfsExportOptionsToTerraform(struct?: DataGoogleFilestoreInstanceFileSharesNfsExportOptions): any;
export declare function dataGoogleFilestoreInstanceFileSharesNfsExportOptionsToHclTerraform(struct?: DataGoogleFilestoreInstanceFileSharesNfsExportOptions): any;
export declare class DataGoogleFilestoreInstanceFileSharesNfsExportOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleFilestoreInstanceFileSharesNfsExportOptions | undefined;
    set internalValue(value: DataGoogleFilestoreInstanceFileSharesNfsExportOptions | undefined);
    get accessMode(): string;
    get anonGid(): number;
    get anonUid(): number;
    get ipRanges(): string[];
    get network(): string;
    get squashMode(): string;
}
export declare class DataGoogleFilestoreInstanceFileSharesNfsExportOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleFilestoreInstanceFileSharesNfsExportOptionsOutputReference;
}
export interface DataGoogleFilestoreInstanceFileShares {
}
export declare function dataGoogleFilestoreInstanceFileSharesToTerraform(struct?: DataGoogleFilestoreInstanceFileShares): any;
export declare function dataGoogleFilestoreInstanceFileSharesToHclTerraform(struct?: DataGoogleFilestoreInstanceFileShares): any;
export declare class DataGoogleFilestoreInstanceFileSharesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleFilestoreInstanceFileShares | undefined;
    set internalValue(value: DataGoogleFilestoreInstanceFileShares | undefined);
    get capacityGb(): number;
    get name(): string;
    private _nfsExportOptions;
    get nfsExportOptions(): DataGoogleFilestoreInstanceFileSharesNfsExportOptionsList;
    get sourceBackup(): string;
    get sourceBackupdrBackup(): string;
}
export declare class DataGoogleFilestoreInstanceFileSharesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleFilestoreInstanceFileSharesOutputReference;
}
export interface DataGoogleFilestoreInstanceInitialReplicationReplicas {
}
export declare function dataGoogleFilestoreInstanceInitialReplicationReplicasToTerraform(struct?: DataGoogleFilestoreInstanceInitialReplicationReplicas): any;
export declare function dataGoogleFilestoreInstanceInitialReplicationReplicasToHclTerraform(struct?: DataGoogleFilestoreInstanceInitialReplicationReplicas): any;
export declare class DataGoogleFilestoreInstanceInitialReplicationReplicasOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleFilestoreInstanceInitialReplicationReplicas | undefined;
    set internalValue(value: DataGoogleFilestoreInstanceInitialReplicationReplicas | undefined);
    get peerInstance(): string;
}
export declare class DataGoogleFilestoreInstanceInitialReplicationReplicasList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleFilestoreInstanceInitialReplicationReplicasOutputReference;
}
export interface DataGoogleFilestoreInstanceInitialReplication {
}
export declare function dataGoogleFilestoreInstanceInitialReplicationToTerraform(struct?: DataGoogleFilestoreInstanceInitialReplication): any;
export declare function dataGoogleFilestoreInstanceInitialReplicationToHclTerraform(struct?: DataGoogleFilestoreInstanceInitialReplication): any;
export declare class DataGoogleFilestoreInstanceInitialReplicationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleFilestoreInstanceInitialReplication | undefined;
    set internalValue(value: DataGoogleFilestoreInstanceInitialReplication | undefined);
    private _replicas;
    get replicas(): DataGoogleFilestoreInstanceInitialReplicationReplicasList;
    get role(): string;
}
export declare class DataGoogleFilestoreInstanceInitialReplicationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleFilestoreInstanceInitialReplicationOutputReference;
}
export interface DataGoogleFilestoreInstanceNetworksPscConfig {
}
export declare function dataGoogleFilestoreInstanceNetworksPscConfigToTerraform(struct?: DataGoogleFilestoreInstanceNetworksPscConfig): any;
export declare function dataGoogleFilestoreInstanceNetworksPscConfigToHclTerraform(struct?: DataGoogleFilestoreInstanceNetworksPscConfig): any;
export declare class DataGoogleFilestoreInstanceNetworksPscConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleFilestoreInstanceNetworksPscConfig | undefined;
    set internalValue(value: DataGoogleFilestoreInstanceNetworksPscConfig | undefined);
    get endpointProject(): string;
}
export declare class DataGoogleFilestoreInstanceNetworksPscConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleFilestoreInstanceNetworksPscConfigOutputReference;
}
export interface DataGoogleFilestoreInstanceNetworks {
}
export declare function dataGoogleFilestoreInstanceNetworksToTerraform(struct?: DataGoogleFilestoreInstanceNetworks): any;
export declare function dataGoogleFilestoreInstanceNetworksToHclTerraform(struct?: DataGoogleFilestoreInstanceNetworks): any;
export declare class DataGoogleFilestoreInstanceNetworksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleFilestoreInstanceNetworks | undefined;
    set internalValue(value: DataGoogleFilestoreInstanceNetworks | undefined);
    get connectMode(): string;
    get ipAddresses(): string[];
    get modes(): string[];
    get network(): string;
    private _pscConfig;
    get pscConfig(): DataGoogleFilestoreInstanceNetworksPscConfigList;
    get reservedIpRange(): string;
}
export declare class DataGoogleFilestoreInstanceNetworksList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleFilestoreInstanceNetworksOutputReference;
}
export interface DataGoogleFilestoreInstancePerformanceConfigFixedIops {
}
export declare function dataGoogleFilestoreInstancePerformanceConfigFixedIopsToTerraform(struct?: DataGoogleFilestoreInstancePerformanceConfigFixedIops): any;
export declare function dataGoogleFilestoreInstancePerformanceConfigFixedIopsToHclTerraform(struct?: DataGoogleFilestoreInstancePerformanceConfigFixedIops): any;
export declare class DataGoogleFilestoreInstancePerformanceConfigFixedIopsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleFilestoreInstancePerformanceConfigFixedIops | undefined;
    set internalValue(value: DataGoogleFilestoreInstancePerformanceConfigFixedIops | undefined);
    get maxIops(): number;
}
export declare class DataGoogleFilestoreInstancePerformanceConfigFixedIopsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleFilestoreInstancePerformanceConfigFixedIopsOutputReference;
}
export interface DataGoogleFilestoreInstancePerformanceConfigIopsPerTb {
}
export declare function dataGoogleFilestoreInstancePerformanceConfigIopsPerTbToTerraform(struct?: DataGoogleFilestoreInstancePerformanceConfigIopsPerTb): any;
export declare function dataGoogleFilestoreInstancePerformanceConfigIopsPerTbToHclTerraform(struct?: DataGoogleFilestoreInstancePerformanceConfigIopsPerTb): any;
export declare class DataGoogleFilestoreInstancePerformanceConfigIopsPerTbOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleFilestoreInstancePerformanceConfigIopsPerTb | undefined;
    set internalValue(value: DataGoogleFilestoreInstancePerformanceConfigIopsPerTb | undefined);
    get maxIopsPerTb(): number;
}
export declare class DataGoogleFilestoreInstancePerformanceConfigIopsPerTbList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleFilestoreInstancePerformanceConfigIopsPerTbOutputReference;
}
export interface DataGoogleFilestoreInstancePerformanceConfig {
}
export declare function dataGoogleFilestoreInstancePerformanceConfigToTerraform(struct?: DataGoogleFilestoreInstancePerformanceConfig): any;
export declare function dataGoogleFilestoreInstancePerformanceConfigToHclTerraform(struct?: DataGoogleFilestoreInstancePerformanceConfig): any;
export declare class DataGoogleFilestoreInstancePerformanceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleFilestoreInstancePerformanceConfig | undefined;
    set internalValue(value: DataGoogleFilestoreInstancePerformanceConfig | undefined);
    private _fixedIops;
    get fixedIops(): DataGoogleFilestoreInstancePerformanceConfigFixedIopsList;
    private _iopsPerTb;
    get iopsPerTb(): DataGoogleFilestoreInstancePerformanceConfigIopsPerTbList;
}
export declare class DataGoogleFilestoreInstancePerformanceConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleFilestoreInstancePerformanceConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_filestore_instance google_filestore_instance}
*/
export declare class DataGoogleFilestoreInstance extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_filestore_instance";
    /**
    * Generates CDKTN code for importing a DataGoogleFilestoreInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleFilestoreInstance to import
    * @param importFromId The id of the existing DataGoogleFilestoreInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_filestore_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleFilestoreInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_filestore_instance google_filestore_instance} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleFilestoreInstanceConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleFilestoreInstanceConfig);
    get createTime(): string;
    get deletionPolicy(): string;
    get deletionProtectionEnabled(): cdktn.IResolvable;
    get deletionProtectionReason(): string;
    get description(): string;
    get desiredReplicaState(): string;
    private _directoryServices;
    get directoryServices(): DataGoogleFilestoreInstanceDirectoryServicesList;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _effectiveReplication;
    get effectiveReplication(): DataGoogleFilestoreInstanceEffectiveReplicationList;
    get etag(): string;
    private _fileShares;
    get fileShares(): DataGoogleFilestoreInstanceFileSharesList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _initialReplication;
    get initialReplication(): DataGoogleFilestoreInstanceInitialReplicationList;
    get kmsKeyName(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networks;
    get networks(): DataGoogleFilestoreInstanceNetworksList;
    private _performanceConfig;
    get performanceConfig(): DataGoogleFilestoreInstancePerformanceConfigList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get protocol(): string;
    private _tags;
    get tags(): cdktn.StringMap;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get tier(): string;
    get zone(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
