/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleOracleDatabaseDbServersConfig extends cdktn.TerraformMetaArguments {
    /**
    * exadata
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_oracle_database_db_servers#cloud_exadata_infrastructure DataGoogleOracleDatabaseDbServers#cloud_exadata_infrastructure}
    */
    readonly cloudExadataInfrastructure: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_oracle_database_db_servers#id DataGoogleOracleDatabaseDbServers#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * location
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_oracle_database_db_servers#location DataGoogleOracleDatabaseDbServers#location}
    */
    readonly location: string;
    /**
    * The ID of the project in which the dataset is located. If it is not provided, the provider project is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_oracle_database_db_servers#project DataGoogleOracleDatabaseDbServers#project}
    */
    readonly project?: string;
}
export interface DataGoogleOracleDatabaseDbServersDbServersProperties {
}
export declare function dataGoogleOracleDatabaseDbServersDbServersPropertiesToTerraform(struct?: DataGoogleOracleDatabaseDbServersDbServersProperties): any;
export declare function dataGoogleOracleDatabaseDbServersDbServersPropertiesToHclTerraform(struct?: DataGoogleOracleDatabaseDbServersDbServersProperties): any;
export declare class DataGoogleOracleDatabaseDbServersDbServersPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseDbServersDbServersProperties | undefined;
    set internalValue(value: DataGoogleOracleDatabaseDbServersDbServersProperties | undefined);
    get dbNodeIds(): string[];
    get dbNodeStorageSizeGb(): number;
    get maxDbNodeStorageSizeGb(): number;
    get maxMemorySizeGb(): number;
    get maxOcpuCount(): number;
    get memorySizeGb(): number;
    get ocid(): string;
    get ocpuCount(): number;
    get state(): string;
    get vmCount(): number;
}
export declare class DataGoogleOracleDatabaseDbServersDbServersPropertiesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseDbServersDbServersPropertiesOutputReference;
}
export interface DataGoogleOracleDatabaseDbServersDbServers {
}
export declare function dataGoogleOracleDatabaseDbServersDbServersToTerraform(struct?: DataGoogleOracleDatabaseDbServersDbServers): any;
export declare function dataGoogleOracleDatabaseDbServersDbServersToHclTerraform(struct?: DataGoogleOracleDatabaseDbServersDbServers): any;
export declare class DataGoogleOracleDatabaseDbServersDbServersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseDbServersDbServers | undefined;
    set internalValue(value: DataGoogleOracleDatabaseDbServersDbServers | undefined);
    get displayName(): string;
    private _properties;
    get properties(): DataGoogleOracleDatabaseDbServersDbServersPropertiesList;
}
export declare class DataGoogleOracleDatabaseDbServersDbServersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseDbServersDbServersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_oracle_database_db_servers google_oracle_database_db_servers}
*/
export declare class DataGoogleOracleDatabaseDbServers extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_oracle_database_db_servers";
    /**
    * Generates CDKTN code for importing a DataGoogleOracleDatabaseDbServers resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleOracleDatabaseDbServers to import
    * @param importFromId The id of the existing DataGoogleOracleDatabaseDbServers that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_oracle_database_db_servers#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleOracleDatabaseDbServers to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_oracle_database_db_servers google_oracle_database_db_servers} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleOracleDatabaseDbServersConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleOracleDatabaseDbServersConfig);
    private _cloudExadataInfrastructure?;
    get cloudExadataInfrastructure(): string;
    set cloudExadataInfrastructure(value: string);
    get cloudExadataInfrastructureInput(): string | undefined;
    private _dbServers;
    get dbServers(): DataGoogleOracleDatabaseDbServersDbServersList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
