/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleVmwareengineAnnouncementsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vmwareengine_announcements#id DataGoogleVmwareengineAnnouncements#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The resource name of the specific Announcements to retrieve. If provided, the 'announcements' list will contain only this announcement.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vmwareengine_announcements#name DataGoogleVmwareengineAnnouncements#name}
    */
    readonly name?: string;
    /**
    * Required. The resource name of the location to be queried for announcements. Resource names are schemeless URIs that follow the conventions in https://cloud.google.com/apis/design/resource_names. For example: projects/my-project/locations/us-west1-a
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vmwareengine_announcements#parent DataGoogleVmwareengineAnnouncements#parent}
    */
    readonly parent: string;
}
export interface DataGoogleVmwareengineAnnouncementsAnnouncements {
}
export declare function dataGoogleVmwareengineAnnouncementsAnnouncementsToTerraform(struct?: DataGoogleVmwareengineAnnouncementsAnnouncements): any;
export declare function dataGoogleVmwareengineAnnouncementsAnnouncementsToHclTerraform(struct?: DataGoogleVmwareengineAnnouncementsAnnouncements): any;
export declare class DataGoogleVmwareengineAnnouncementsAnnouncementsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleVmwareengineAnnouncementsAnnouncements | undefined;
    set internalValue(value: DataGoogleVmwareengineAnnouncementsAnnouncements | undefined);
    get code(): string;
    private _metadata;
    get metadata(): cdktn.StringMap;
    get name(): string;
    get targetResourceType(): string;
}
export declare class DataGoogleVmwareengineAnnouncementsAnnouncementsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleVmwareengineAnnouncementsAnnouncementsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vmwareengine_announcements google_vmwareengine_announcements}
*/
export declare class DataGoogleVmwareengineAnnouncements extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_vmwareengine_announcements";
    /**
    * Generates CDKTN code for importing a DataGoogleVmwareengineAnnouncements resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleVmwareengineAnnouncements to import
    * @param importFromId The id of the existing DataGoogleVmwareengineAnnouncements that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vmwareengine_announcements#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleVmwareengineAnnouncements to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vmwareengine_announcements google_vmwareengine_announcements} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleVmwareengineAnnouncementsConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleVmwareengineAnnouncementsConfig);
    private _announcements;
    get announcements(): DataGoogleVmwareengineAnnouncementsAnnouncementsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
