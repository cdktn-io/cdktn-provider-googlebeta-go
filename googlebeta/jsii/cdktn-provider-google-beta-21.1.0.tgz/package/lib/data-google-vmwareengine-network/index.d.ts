/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleVmwareengineNetworkConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vmwareengine_network#id DataGoogleVmwareengineNetwork#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location where the VMwareEngineNetwork should reside.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vmwareengine_network#location DataGoogleVmwareengineNetwork#location}
    */
    readonly location: string;
    /**
    * The ID of the VMwareEngineNetwork.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vmwareengine_network#name DataGoogleVmwareengineNetwork#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vmwareengine_network#project DataGoogleVmwareengineNetwork#project}
    */
    readonly project?: string;
}
export interface DataGoogleVmwareengineNetworkVpcNetworks {
}
export declare function dataGoogleVmwareengineNetworkVpcNetworksToTerraform(struct?: DataGoogleVmwareengineNetworkVpcNetworks): any;
export declare function dataGoogleVmwareengineNetworkVpcNetworksToHclTerraform(struct?: DataGoogleVmwareengineNetworkVpcNetworks): any;
export declare class DataGoogleVmwareengineNetworkVpcNetworksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleVmwareengineNetworkVpcNetworks | undefined;
    set internalValue(value: DataGoogleVmwareengineNetworkVpcNetworks | undefined);
    get network(): string;
    get type(): string;
}
export declare class DataGoogleVmwareengineNetworkVpcNetworksList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleVmwareengineNetworkVpcNetworksOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vmwareengine_network google_vmwareengine_network}
*/
export declare class DataGoogleVmwareengineNetwork extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_vmwareengine_network";
    /**
    * Generates CDKTN code for importing a DataGoogleVmwareengineNetwork resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleVmwareengineNetwork to import
    * @param importFromId The id of the existing DataGoogleVmwareengineNetwork that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vmwareengine_network#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleVmwareengineNetwork to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_vmwareengine_network google_vmwareengine_network} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleVmwareengineNetworkConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleVmwareengineNetworkConfig);
    get createTime(): string;
    get deletionPolicy(): string;
    get description(): string;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get state(): string;
    get type(): string;
    get uid(): string;
    get updateTime(): string;
    private _vpcNetworks;
    get vpcNetworks(): DataGoogleVmwareengineNetworkVpcNetworksList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
