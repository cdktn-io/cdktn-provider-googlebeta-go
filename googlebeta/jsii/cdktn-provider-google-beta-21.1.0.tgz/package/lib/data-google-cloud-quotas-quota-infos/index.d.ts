/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleCloudQuotasQuotaInfosConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloud_quotas_quota_infos#id DataGoogleCloudQuotasQuotaInfos#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloud_quotas_quota_infos#parent DataGoogleCloudQuotasQuotaInfos#parent}
    */
    readonly parent: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloud_quotas_quota_infos#service DataGoogleCloudQuotasQuotaInfos#service}
    */
    readonly service: string;
}
export interface DataGoogleCloudQuotasQuotaInfosQuotaInfosDimensionsInfosDetails {
}
export declare function dataGoogleCloudQuotasQuotaInfosQuotaInfosDimensionsInfosDetailsToTerraform(struct?: DataGoogleCloudQuotasQuotaInfosQuotaInfosDimensionsInfosDetails): any;
export declare function dataGoogleCloudQuotasQuotaInfosQuotaInfosDimensionsInfosDetailsToHclTerraform(struct?: DataGoogleCloudQuotasQuotaInfosQuotaInfosDimensionsInfosDetails): any;
export declare class DataGoogleCloudQuotasQuotaInfosQuotaInfosDimensionsInfosDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudQuotasQuotaInfosQuotaInfosDimensionsInfosDetails | undefined;
    set internalValue(value: DataGoogleCloudQuotasQuotaInfosQuotaInfosDimensionsInfosDetails | undefined);
    get value(): string;
}
export declare class DataGoogleCloudQuotasQuotaInfosQuotaInfosDimensionsInfosDetailsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudQuotasQuotaInfosQuotaInfosDimensionsInfosDetailsOutputReference;
}
export interface DataGoogleCloudQuotasQuotaInfosQuotaInfosDimensionsInfos {
}
export declare function dataGoogleCloudQuotasQuotaInfosQuotaInfosDimensionsInfosToTerraform(struct?: DataGoogleCloudQuotasQuotaInfosQuotaInfosDimensionsInfos): any;
export declare function dataGoogleCloudQuotasQuotaInfosQuotaInfosDimensionsInfosToHclTerraform(struct?: DataGoogleCloudQuotasQuotaInfosQuotaInfosDimensionsInfos): any;
export declare class DataGoogleCloudQuotasQuotaInfosQuotaInfosDimensionsInfosOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudQuotasQuotaInfosQuotaInfosDimensionsInfos | undefined;
    set internalValue(value: DataGoogleCloudQuotasQuotaInfosQuotaInfosDimensionsInfos | undefined);
    get applicableLocations(): string[];
    private _details;
    get details(): DataGoogleCloudQuotasQuotaInfosQuotaInfosDimensionsInfosDetailsList;
    private _dimensions;
    get dimensions(): cdktn.StringMap;
}
export declare class DataGoogleCloudQuotasQuotaInfosQuotaInfosDimensionsInfosList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudQuotasQuotaInfosQuotaInfosDimensionsInfosOutputReference;
}
export interface DataGoogleCloudQuotasQuotaInfosQuotaInfosQuotaIncreaseEligibility {
}
export declare function dataGoogleCloudQuotasQuotaInfosQuotaInfosQuotaIncreaseEligibilityToTerraform(struct?: DataGoogleCloudQuotasQuotaInfosQuotaInfosQuotaIncreaseEligibility): any;
export declare function dataGoogleCloudQuotasQuotaInfosQuotaInfosQuotaIncreaseEligibilityToHclTerraform(struct?: DataGoogleCloudQuotasQuotaInfosQuotaInfosQuotaIncreaseEligibility): any;
export declare class DataGoogleCloudQuotasQuotaInfosQuotaInfosQuotaIncreaseEligibilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudQuotasQuotaInfosQuotaInfosQuotaIncreaseEligibility | undefined;
    set internalValue(value: DataGoogleCloudQuotasQuotaInfosQuotaInfosQuotaIncreaseEligibility | undefined);
    get ineligibilityReason(): string;
    get isEligible(): cdktn.IResolvable;
}
export declare class DataGoogleCloudQuotasQuotaInfosQuotaInfosQuotaIncreaseEligibilityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudQuotasQuotaInfosQuotaInfosQuotaIncreaseEligibilityOutputReference;
}
export interface DataGoogleCloudQuotasQuotaInfosQuotaInfos {
}
export declare function dataGoogleCloudQuotasQuotaInfosQuotaInfosToTerraform(struct?: DataGoogleCloudQuotasQuotaInfosQuotaInfos): any;
export declare function dataGoogleCloudQuotasQuotaInfosQuotaInfosToHclTerraform(struct?: DataGoogleCloudQuotasQuotaInfosQuotaInfos): any;
export declare class DataGoogleCloudQuotasQuotaInfosQuotaInfosOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudQuotasQuotaInfosQuotaInfos | undefined;
    set internalValue(value: DataGoogleCloudQuotasQuotaInfosQuotaInfos | undefined);
    get containerType(): string;
    get dimensions(): string[];
    private _dimensionsInfos;
    get dimensionsInfos(): DataGoogleCloudQuotasQuotaInfosQuotaInfosDimensionsInfosList;
    get isConcurrent(): cdktn.IResolvable;
    get isFixed(): cdktn.IResolvable;
    get isPrecise(): cdktn.IResolvable;
    get metric(): string;
    get metricDisplayName(): string;
    get metricUnit(): string;
    get name(): string;
    get quotaDisplayName(): string;
    get quotaId(): string;
    private _quotaIncreaseEligibility;
    get quotaIncreaseEligibility(): DataGoogleCloudQuotasQuotaInfosQuotaInfosQuotaIncreaseEligibilityList;
    get refreshInterval(): string;
    get service(): string;
    get serviceRequestQuotaUri(): string;
}
export declare class DataGoogleCloudQuotasQuotaInfosQuotaInfosList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudQuotasQuotaInfosQuotaInfosOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloud_quotas_quota_infos google_cloud_quotas_quota_infos}
*/
export declare class DataGoogleCloudQuotasQuotaInfos extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_cloud_quotas_quota_infos";
    /**
    * Generates CDKTN code for importing a DataGoogleCloudQuotasQuotaInfos resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleCloudQuotasQuotaInfos to import
    * @param importFromId The id of the existing DataGoogleCloudQuotasQuotaInfos that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloud_quotas_quota_infos#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleCloudQuotasQuotaInfos to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_cloud_quotas_quota_infos google_cloud_quotas_quota_infos} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleCloudQuotasQuotaInfosConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleCloudQuotasQuotaInfosConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _quotaInfos;
    get quotaInfos(): DataGoogleCloudQuotasQuotaInfosQuotaInfosList;
    private _service?;
    get service(): string;
    set service(value: string);
    get serviceInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
