/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleMemcacheInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_memcache_instance#id DataGoogleMemcacheInstance#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The resource name of the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_memcache_instance#name DataGoogleMemcacheInstance#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_memcache_instance#project DataGoogleMemcacheInstance#project}
    */
    readonly project?: string;
    /**
    * The region of the Memcache instance. If it is not provided, the provider region is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_memcache_instance#region DataGoogleMemcacheInstance#region}
    */
    readonly region?: string;
}
export interface DataGoogleMemcacheInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTime {
}
export declare function dataGoogleMemcacheInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTimeToTerraform(struct?: DataGoogleMemcacheInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTime): any;
export declare function dataGoogleMemcacheInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTimeToHclTerraform(struct?: DataGoogleMemcacheInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTime): any;
export declare class DataGoogleMemcacheInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemcacheInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTime | undefined;
    set internalValue(value: DataGoogleMemcacheInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTime | undefined);
    get hours(): number;
    get minutes(): number;
    get nanos(): number;
    get seconds(): number;
}
export declare class DataGoogleMemcacheInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTimeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemcacheInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTimeOutputReference;
}
export interface DataGoogleMemcacheInstanceMaintenancePolicyWeeklyMaintenanceWindow {
}
export declare function dataGoogleMemcacheInstanceMaintenancePolicyWeeklyMaintenanceWindowToTerraform(struct?: DataGoogleMemcacheInstanceMaintenancePolicyWeeklyMaintenanceWindow): any;
export declare function dataGoogleMemcacheInstanceMaintenancePolicyWeeklyMaintenanceWindowToHclTerraform(struct?: DataGoogleMemcacheInstanceMaintenancePolicyWeeklyMaintenanceWindow): any;
export declare class DataGoogleMemcacheInstanceMaintenancePolicyWeeklyMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemcacheInstanceMaintenancePolicyWeeklyMaintenanceWindow | undefined;
    set internalValue(value: DataGoogleMemcacheInstanceMaintenancePolicyWeeklyMaintenanceWindow | undefined);
    get day(): string;
    get duration(): string;
    private _startTime;
    get startTime(): DataGoogleMemcacheInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTimeList;
}
export declare class DataGoogleMemcacheInstanceMaintenancePolicyWeeklyMaintenanceWindowList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemcacheInstanceMaintenancePolicyWeeklyMaintenanceWindowOutputReference;
}
export interface DataGoogleMemcacheInstanceMaintenancePolicy {
}
export declare function dataGoogleMemcacheInstanceMaintenancePolicyToTerraform(struct?: DataGoogleMemcacheInstanceMaintenancePolicy): any;
export declare function dataGoogleMemcacheInstanceMaintenancePolicyToHclTerraform(struct?: DataGoogleMemcacheInstanceMaintenancePolicy): any;
export declare class DataGoogleMemcacheInstanceMaintenancePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemcacheInstanceMaintenancePolicy | undefined;
    set internalValue(value: DataGoogleMemcacheInstanceMaintenancePolicy | undefined);
    get createTime(): string;
    get description(): string;
    get updateTime(): string;
    private _weeklyMaintenanceWindow;
    get weeklyMaintenanceWindow(): DataGoogleMemcacheInstanceMaintenancePolicyWeeklyMaintenanceWindowList;
}
export declare class DataGoogleMemcacheInstanceMaintenancePolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemcacheInstanceMaintenancePolicyOutputReference;
}
export interface DataGoogleMemcacheInstanceMaintenanceSchedule {
}
export declare function dataGoogleMemcacheInstanceMaintenanceScheduleToTerraform(struct?: DataGoogleMemcacheInstanceMaintenanceSchedule): any;
export declare function dataGoogleMemcacheInstanceMaintenanceScheduleToHclTerraform(struct?: DataGoogleMemcacheInstanceMaintenanceSchedule): any;
export declare class DataGoogleMemcacheInstanceMaintenanceScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemcacheInstanceMaintenanceSchedule | undefined;
    set internalValue(value: DataGoogleMemcacheInstanceMaintenanceSchedule | undefined);
    get endTime(): string;
    get scheduleDeadlineTime(): string;
    get startTime(): string;
}
export declare class DataGoogleMemcacheInstanceMaintenanceScheduleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemcacheInstanceMaintenanceScheduleOutputReference;
}
export interface DataGoogleMemcacheInstanceMemcacheNodes {
}
export declare function dataGoogleMemcacheInstanceMemcacheNodesToTerraform(struct?: DataGoogleMemcacheInstanceMemcacheNodes): any;
export declare function dataGoogleMemcacheInstanceMemcacheNodesToHclTerraform(struct?: DataGoogleMemcacheInstanceMemcacheNodes): any;
export declare class DataGoogleMemcacheInstanceMemcacheNodesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemcacheInstanceMemcacheNodes | undefined;
    set internalValue(value: DataGoogleMemcacheInstanceMemcacheNodes | undefined);
    get host(): string;
    get nodeId(): string;
    get port(): number;
    get state(): string;
    get zone(): string;
}
export declare class DataGoogleMemcacheInstanceMemcacheNodesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemcacheInstanceMemcacheNodesOutputReference;
}
export interface DataGoogleMemcacheInstanceMemcacheParameters {
}
export declare function dataGoogleMemcacheInstanceMemcacheParametersToTerraform(struct?: DataGoogleMemcacheInstanceMemcacheParameters): any;
export declare function dataGoogleMemcacheInstanceMemcacheParametersToHclTerraform(struct?: DataGoogleMemcacheInstanceMemcacheParameters): any;
export declare class DataGoogleMemcacheInstanceMemcacheParametersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemcacheInstanceMemcacheParameters | undefined;
    set internalValue(value: DataGoogleMemcacheInstanceMemcacheParameters | undefined);
    get id(): string;
    private _params;
    get params(): cdktn.StringMap;
}
export declare class DataGoogleMemcacheInstanceMemcacheParametersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemcacheInstanceMemcacheParametersOutputReference;
}
export interface DataGoogleMemcacheInstanceNodeConfig {
}
export declare function dataGoogleMemcacheInstanceNodeConfigToTerraform(struct?: DataGoogleMemcacheInstanceNodeConfig): any;
export declare function dataGoogleMemcacheInstanceNodeConfigToHclTerraform(struct?: DataGoogleMemcacheInstanceNodeConfig): any;
export declare class DataGoogleMemcacheInstanceNodeConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemcacheInstanceNodeConfig | undefined;
    set internalValue(value: DataGoogleMemcacheInstanceNodeConfig | undefined);
    get cpuCount(): number;
    get memorySizeMb(): number;
}
export declare class DataGoogleMemcacheInstanceNodeConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemcacheInstanceNodeConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_memcache_instance google_memcache_instance}
*/
export declare class DataGoogleMemcacheInstance extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_memcache_instance";
    /**
    * Generates CDKTN code for importing a DataGoogleMemcacheInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleMemcacheInstance to import
    * @param importFromId The id of the existing DataGoogleMemcacheInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_memcache_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleMemcacheInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_memcache_instance google_memcache_instance} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleMemcacheInstanceConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleMemcacheInstanceConfig);
    get authorizedNetwork(): string;
    get createTime(): string;
    get deletionPolicy(): string;
    get deletionProtection(): cdktn.IResolvable;
    get discoveryEndpoint(): string;
    get displayName(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels;
    get labels(): cdktn.StringMap;
    private _maintenancePolicy;
    get maintenancePolicy(): DataGoogleMemcacheInstanceMaintenancePolicyList;
    private _maintenanceSchedule;
    get maintenanceSchedule(): DataGoogleMemcacheInstanceMaintenanceScheduleList;
    get memcacheFullVersion(): string;
    private _memcacheNodes;
    get memcacheNodes(): DataGoogleMemcacheInstanceMemcacheNodesList;
    private _memcacheParameters;
    get memcacheParameters(): DataGoogleMemcacheInstanceMemcacheParametersList;
    get memcacheVersion(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nodeConfig;
    get nodeConfig(): DataGoogleMemcacheInstanceNodeConfigList;
    get nodeCount(): number;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get reservedIpRangeId(): string[];
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get zones(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
