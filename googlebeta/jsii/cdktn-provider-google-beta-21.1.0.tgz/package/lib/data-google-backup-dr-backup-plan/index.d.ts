/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleBackupDrBackupPlanConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the backup plan
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_backup_dr_backup_plan#backup_plan_id DataGoogleBackupDrBackupPlan#backup_plan_id}
    */
    readonly backupPlanId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_backup_dr_backup_plan#id DataGoogleBackupDrBackupPlan#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location for the backup plan
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_backup_dr_backup_plan#location DataGoogleBackupDrBackupPlan#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_backup_dr_backup_plan#project DataGoogleBackupDrBackupPlan#project}
    */
    readonly project?: string;
}
export interface DataGoogleBackupDrBackupPlanBackupRulesStandardScheduleBackupWindow {
}
export declare function dataGoogleBackupDrBackupPlanBackupRulesStandardScheduleBackupWindowToTerraform(struct?: DataGoogleBackupDrBackupPlanBackupRulesStandardScheduleBackupWindow): any;
export declare function dataGoogleBackupDrBackupPlanBackupRulesStandardScheduleBackupWindowToHclTerraform(struct?: DataGoogleBackupDrBackupPlanBackupRulesStandardScheduleBackupWindow): any;
export declare class DataGoogleBackupDrBackupPlanBackupRulesStandardScheduleBackupWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrBackupPlanBackupRulesStandardScheduleBackupWindow | undefined;
    set internalValue(value: DataGoogleBackupDrBackupPlanBackupRulesStandardScheduleBackupWindow | undefined);
    get endHourOfDay(): number;
    get startHourOfDay(): number;
}
export declare class DataGoogleBackupDrBackupPlanBackupRulesStandardScheduleBackupWindowList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrBackupPlanBackupRulesStandardScheduleBackupWindowOutputReference;
}
export interface DataGoogleBackupDrBackupPlanBackupRulesStandardScheduleWeekDayOfMonth {
}
export declare function dataGoogleBackupDrBackupPlanBackupRulesStandardScheduleWeekDayOfMonthToTerraform(struct?: DataGoogleBackupDrBackupPlanBackupRulesStandardScheduleWeekDayOfMonth): any;
export declare function dataGoogleBackupDrBackupPlanBackupRulesStandardScheduleWeekDayOfMonthToHclTerraform(struct?: DataGoogleBackupDrBackupPlanBackupRulesStandardScheduleWeekDayOfMonth): any;
export declare class DataGoogleBackupDrBackupPlanBackupRulesStandardScheduleWeekDayOfMonthOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrBackupPlanBackupRulesStandardScheduleWeekDayOfMonth | undefined;
    set internalValue(value: DataGoogleBackupDrBackupPlanBackupRulesStandardScheduleWeekDayOfMonth | undefined);
    get dayOfWeek(): string;
    get weekOfMonth(): string;
}
export declare class DataGoogleBackupDrBackupPlanBackupRulesStandardScheduleWeekDayOfMonthList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrBackupPlanBackupRulesStandardScheduleWeekDayOfMonthOutputReference;
}
export interface DataGoogleBackupDrBackupPlanBackupRulesStandardSchedule {
}
export declare function dataGoogleBackupDrBackupPlanBackupRulesStandardScheduleToTerraform(struct?: DataGoogleBackupDrBackupPlanBackupRulesStandardSchedule): any;
export declare function dataGoogleBackupDrBackupPlanBackupRulesStandardScheduleToHclTerraform(struct?: DataGoogleBackupDrBackupPlanBackupRulesStandardSchedule): any;
export declare class DataGoogleBackupDrBackupPlanBackupRulesStandardScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrBackupPlanBackupRulesStandardSchedule | undefined;
    set internalValue(value: DataGoogleBackupDrBackupPlanBackupRulesStandardSchedule | undefined);
    private _backupWindow;
    get backupWindow(): DataGoogleBackupDrBackupPlanBackupRulesStandardScheduleBackupWindowList;
    get daysOfMonth(): number[];
    get daysOfWeek(): string[];
    get hourlyFrequency(): number;
    get months(): string[];
    get recurrenceType(): string;
    get timeZone(): string;
    private _weekDayOfMonth;
    get weekDayOfMonth(): DataGoogleBackupDrBackupPlanBackupRulesStandardScheduleWeekDayOfMonthList;
}
export declare class DataGoogleBackupDrBackupPlanBackupRulesStandardScheduleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrBackupPlanBackupRulesStandardScheduleOutputReference;
}
export interface DataGoogleBackupDrBackupPlanBackupRules {
}
export declare function dataGoogleBackupDrBackupPlanBackupRulesToTerraform(struct?: DataGoogleBackupDrBackupPlanBackupRules): any;
export declare function dataGoogleBackupDrBackupPlanBackupRulesToHclTerraform(struct?: DataGoogleBackupDrBackupPlanBackupRules): any;
export declare class DataGoogleBackupDrBackupPlanBackupRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrBackupPlanBackupRules | undefined;
    set internalValue(value: DataGoogleBackupDrBackupPlanBackupRules | undefined);
    get backupRetentionDays(): number;
    get ruleId(): string;
    private _standardSchedule;
    get standardSchedule(): DataGoogleBackupDrBackupPlanBackupRulesStandardScheduleList;
}
export declare class DataGoogleBackupDrBackupPlanBackupRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrBackupPlanBackupRulesOutputReference;
}
export interface DataGoogleBackupDrBackupPlanComputeInstanceBackupPlanProperties {
}
export declare function dataGoogleBackupDrBackupPlanComputeInstanceBackupPlanPropertiesToTerraform(struct?: DataGoogleBackupDrBackupPlanComputeInstanceBackupPlanProperties): any;
export declare function dataGoogleBackupDrBackupPlanComputeInstanceBackupPlanPropertiesToHclTerraform(struct?: DataGoogleBackupDrBackupPlanComputeInstanceBackupPlanProperties): any;
export declare class DataGoogleBackupDrBackupPlanComputeInstanceBackupPlanPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrBackupPlanComputeInstanceBackupPlanProperties | undefined;
    set internalValue(value: DataGoogleBackupDrBackupPlanComputeInstanceBackupPlanProperties | undefined);
    get guestFlush(): cdktn.IResolvable;
}
export declare class DataGoogleBackupDrBackupPlanComputeInstanceBackupPlanPropertiesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrBackupPlanComputeInstanceBackupPlanPropertiesOutputReference;
}
export interface DataGoogleBackupDrBackupPlanDiskBackupPlanProperties {
}
export declare function dataGoogleBackupDrBackupPlanDiskBackupPlanPropertiesToTerraform(struct?: DataGoogleBackupDrBackupPlanDiskBackupPlanProperties): any;
export declare function dataGoogleBackupDrBackupPlanDiskBackupPlanPropertiesToHclTerraform(struct?: DataGoogleBackupDrBackupPlanDiskBackupPlanProperties): any;
export declare class DataGoogleBackupDrBackupPlanDiskBackupPlanPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrBackupPlanDiskBackupPlanProperties | undefined;
    set internalValue(value: DataGoogleBackupDrBackupPlanDiskBackupPlanProperties | undefined);
    get guestFlush(): cdktn.IResolvable;
}
export declare class DataGoogleBackupDrBackupPlanDiskBackupPlanPropertiesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrBackupPlanDiskBackupPlanPropertiesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_backup_dr_backup_plan google_backup_dr_backup_plan}
*/
export declare class DataGoogleBackupDrBackupPlan extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_backup_dr_backup_plan";
    /**
    * Generates CDKTN code for importing a DataGoogleBackupDrBackupPlan resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleBackupDrBackupPlan to import
    * @param importFromId The id of the existing DataGoogleBackupDrBackupPlan that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_backup_dr_backup_plan#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleBackupDrBackupPlan to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_backup_dr_backup_plan google_backup_dr_backup_plan} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleBackupDrBackupPlanConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleBackupDrBackupPlanConfig);
    private _backupPlanId?;
    get backupPlanId(): string;
    set backupPlanId(value: string);
    get backupPlanIdInput(): string | undefined;
    private _backupRules;
    get backupRules(): DataGoogleBackupDrBackupPlanBackupRulesList;
    get backupVault(): string;
    get backupVaultServiceAccount(): string;
    private _computeInstanceBackupPlanProperties;
    get computeInstanceBackupPlanProperties(): DataGoogleBackupDrBackupPlanComputeInstanceBackupPlanPropertiesList;
    get createTime(): string;
    get deletionPolicy(): string;
    get description(): string;
    private _diskBackupPlanProperties;
    get diskBackupPlanProperties(): DataGoogleBackupDrBackupPlanDiskBackupPlanPropertiesList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get logRetentionDays(): number;
    get maxCustomOnDemandRetentionDays(): number;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get resourceType(): string;
    get supportedResourceTypes(): string[];
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
