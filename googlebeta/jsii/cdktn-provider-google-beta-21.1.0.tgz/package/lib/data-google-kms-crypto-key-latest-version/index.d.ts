/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleKmsCryptoKeyLatestVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_crypto_key_latest_version#crypto_key DataGoogleKmsCryptoKeyLatestVersion#crypto_key}
    */
    readonly cryptoKey: string;
    /**
    *
    * 					The filter argument is used to add a filter query parameter that limits which type of cryptoKeyVersion is retrieved as the latest by the data source: ?filter={{filter}}. When no value is provided there is no filtering.
    *
    * 					Example filter values if filtering on state.
    *
    * 					* "state:ENABLED" will retrieve the latest cryptoKeyVersion that has the state "ENABLED".
    *
    * 					[See the documentation about using filters](https://cloud.google.com/kms/docs/sorting-and-filtering)
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_crypto_key_latest_version#filter DataGoogleKmsCryptoKeyLatestVersion#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_crypto_key_latest_version#id DataGoogleKmsCryptoKeyLatestVersion#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataGoogleKmsCryptoKeyLatestVersionPublicKey {
}
export declare function dataGoogleKmsCryptoKeyLatestVersionPublicKeyToTerraform(struct?: DataGoogleKmsCryptoKeyLatestVersionPublicKey): any;
export declare function dataGoogleKmsCryptoKeyLatestVersionPublicKeyToHclTerraform(struct?: DataGoogleKmsCryptoKeyLatestVersionPublicKey): any;
export declare class DataGoogleKmsCryptoKeyLatestVersionPublicKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleKmsCryptoKeyLatestVersionPublicKey | undefined;
    set internalValue(value: DataGoogleKmsCryptoKeyLatestVersionPublicKey | undefined);
    get algorithm(): string;
    get pem(): string;
}
export declare class DataGoogleKmsCryptoKeyLatestVersionPublicKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleKmsCryptoKeyLatestVersionPublicKeyOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_crypto_key_latest_version google_kms_crypto_key_latest_version}
*/
export declare class DataGoogleKmsCryptoKeyLatestVersion extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_kms_crypto_key_latest_version";
    /**
    * Generates CDKTN code for importing a DataGoogleKmsCryptoKeyLatestVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleKmsCryptoKeyLatestVersion to import
    * @param importFromId The id of the existing DataGoogleKmsCryptoKeyLatestVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_crypto_key_latest_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleKmsCryptoKeyLatestVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_crypto_key_latest_version google_kms_crypto_key_latest_version} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleKmsCryptoKeyLatestVersionConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleKmsCryptoKeyLatestVersionConfig);
    get algorithm(): string;
    private _cryptoKey?;
    get cryptoKey(): string;
    set cryptoKey(value: string);
    get cryptoKeyInput(): string | undefined;
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    get protectionLevel(): string;
    private _publicKey;
    get publicKey(): DataGoogleKmsCryptoKeyLatestVersionPublicKeyList;
    get state(): string;
    get version(): number;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
