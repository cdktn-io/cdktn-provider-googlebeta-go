/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleComputeStoragePoolConfig extends cdktn.TerraformMetaArguments {
    /**
    * Name of the resource. Provided by the client when the resource is created.
    * The name must be 1-63 characters long, and comply with RFC1035.
    * Specifically, the name must be 1-63 characters long and match
    * the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?'
    * which means the first character must be a lowercase letter,
    * and all following characters must be a dash, lowercase letter, or digit,
    * except the last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_storage_pool#name DataGoogleComputeStoragePool#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_storage_pool#project DataGoogleComputeStoragePool#project}
    */
    readonly project?: string;
    /**
    * A reference to the zone where the storage pool resides.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_storage_pool#zone DataGoogleComputeStoragePool#zone}
    */
    readonly zone: string;
}
export interface DataGoogleComputeStoragePoolParams {
}
export declare function dataGoogleComputeStoragePoolParamsToTerraform(struct?: DataGoogleComputeStoragePoolParams): any;
export declare function dataGoogleComputeStoragePoolParamsToHclTerraform(struct?: DataGoogleComputeStoragePoolParams): any;
export declare class DataGoogleComputeStoragePoolParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeStoragePoolParams | undefined;
    set internalValue(value: DataGoogleComputeStoragePoolParams | undefined);
    private _resourceManagerTags;
    get resourceManagerTags(): cdktn.StringMap;
}
export declare class DataGoogleComputeStoragePoolParamsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeStoragePoolParamsOutputReference;
}
export interface DataGoogleComputeStoragePoolResourceStatus {
}
export declare function dataGoogleComputeStoragePoolResourceStatusToTerraform(struct?: DataGoogleComputeStoragePoolResourceStatus): any;
export declare function dataGoogleComputeStoragePoolResourceStatusToHclTerraform(struct?: DataGoogleComputeStoragePoolResourceStatus): any;
export declare class DataGoogleComputeStoragePoolResourceStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeStoragePoolResourceStatus | undefined;
    set internalValue(value: DataGoogleComputeStoragePoolResourceStatus | undefined);
    get diskCount(): string;
    get lastResizeTimestamp(): string;
    get maxTotalProvisionedDiskCapacityGb(): string;
    get poolUsedCapacityBytes(): string;
    get poolUsedIops(): string;
    get poolUsedThroughput(): string;
    get poolUserWrittenBytes(): string;
    get totalProvisionedDiskCapacityGb(): string;
    get totalProvisionedDiskIops(): string;
    get totalProvisionedDiskThroughput(): string;
}
export declare class DataGoogleComputeStoragePoolResourceStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeStoragePoolResourceStatusOutputReference;
}
export interface DataGoogleComputeStoragePoolStatus {
}
export declare function dataGoogleComputeStoragePoolStatusToTerraform(struct?: DataGoogleComputeStoragePoolStatus): any;
export declare function dataGoogleComputeStoragePoolStatusToHclTerraform(struct?: DataGoogleComputeStoragePoolStatus): any;
export declare class DataGoogleComputeStoragePoolStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeStoragePoolStatus | undefined;
    set internalValue(value: DataGoogleComputeStoragePoolStatus | undefined);
    get diskCount(): string;
    get lastResizeTimestamp(): string;
    get maxTotalProvisionedDiskCapacityGb(): string;
    get poolUsedCapacityBytes(): string;
    get poolUsedIops(): string;
    get poolUsedThroughput(): string;
    get poolUserWrittenBytes(): string;
    get totalProvisionedDiskCapacityGb(): string;
    get totalProvisionedDiskIops(): string;
    get totalProvisionedDiskThroughput(): string;
}
export declare class DataGoogleComputeStoragePoolStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeStoragePoolStatusOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_storage_pool google_compute_storage_pool}
*/
export declare class DataGoogleComputeStoragePool extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_compute_storage_pool";
    /**
    * Generates CDKTN code for importing a DataGoogleComputeStoragePool resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleComputeStoragePool to import
    * @param importFromId The id of the existing DataGoogleComputeStoragePool that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_storage_pool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleComputeStoragePool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_compute_storage_pool google_compute_storage_pool} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleComputeStoragePoolConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleComputeStoragePoolConfig);
    get capacityProvisioningType(): string;
    get creationTimestamp(): string;
    get deletionPolicy(): string;
    get deletionProtection(): cdktn.IResolvable;
    get description(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get id(): string;
    get kind(): string;
    get labelFingerprint(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _params;
    get params(): DataGoogleComputeStoragePoolParamsList;
    get performanceProvisioningType(): string;
    get poolProvisionedCapacityGb(): string;
    get poolProvisionedIops(): string;
    get poolProvisionedThroughput(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _resourceStatus;
    get resourceStatus(): DataGoogleComputeStoragePoolResourceStatusList;
    private _status;
    get status(): DataGoogleComputeStoragePoolStatusList;
    get storagePoolType(): string;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    get zoneInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
