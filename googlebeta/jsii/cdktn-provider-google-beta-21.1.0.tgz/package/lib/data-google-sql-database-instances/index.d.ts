/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleSqlDatabaseInstancesConfig extends cdktn.TerraformMetaArguments {
    /**
    * To filter out the database instances which are of the specified database version.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_sql_database_instances#database_version DataGoogleSqlDatabaseInstances#database_version}
    */
    readonly databaseVersion?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_sql_database_instances#id DataGoogleSqlDatabaseInstances#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Project ID of the project that contains the instances.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_sql_database_instances#project DataGoogleSqlDatabaseInstances#project}
    */
    readonly project?: string;
    /**
    * To filter out the database instances which are located in this specified region.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_sql_database_instances#region DataGoogleSqlDatabaseInstances#region}
    */
    readonly region?: string;
    /**
    * To filter out the database instances based on the current state of the database instance, valid values include : "SQL_INSTANCE_STATE_UNSPECIFIED", "RUNNABLE", "SUSPENDED", "PENDING_DELETE", "PENDING_CREATE", "MAINTENANCE" and "FAILED".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_sql_database_instances#state DataGoogleSqlDatabaseInstances#state}
    */
    readonly state?: string;
    /**
    * To filter out the database instances based on the machine type.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_sql_database_instances#tier DataGoogleSqlDatabaseInstances#tier}
    */
    readonly tier?: string;
    /**
    * To filter out the database instances which are located in this specified zone.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_sql_database_instances#zone DataGoogleSqlDatabaseInstances#zone}
    */
    readonly zone?: string;
}
export interface DataGoogleSqlDatabaseInstancesInstancesBlueGreenDeploymentTargetInstanceIpAddresses {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesBlueGreenDeploymentTargetInstanceIpAddressesToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesBlueGreenDeploymentTargetInstanceIpAddresses): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesBlueGreenDeploymentTargetInstanceIpAddressesToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesBlueGreenDeploymentTargetInstanceIpAddresses): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesBlueGreenDeploymentTargetInstanceIpAddressesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesBlueGreenDeploymentTargetInstanceIpAddresses | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesBlueGreenDeploymentTargetInstanceIpAddresses | undefined);
    get ipAddress(): string;
    get timeToRetire(): string;
    get type(): string;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesBlueGreenDeploymentTargetInstanceIpAddressesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesBlueGreenDeploymentTargetInstanceIpAddressesOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesBlueGreenDeployment {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesBlueGreenDeploymentToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesBlueGreenDeployment): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesBlueGreenDeploymentToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesBlueGreenDeployment): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesBlueGreenDeploymentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesBlueGreenDeployment | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesBlueGreenDeployment | undefined);
    get activeEnvironment(): string;
    get deleteOldSourceOnDestroy(): cdktn.IResolvable;
    get deploymentName(): string;
    get oldSourceInstanceConnectionName(): string;
    get oldSourceInstanceName(): string;
    get targetDatabaseVersion(): string;
    get targetInstanceConnectionName(): string;
    private _targetInstanceIpAddresses;
    get targetInstanceIpAddresses(): DataGoogleSqlDatabaseInstancesInstancesBlueGreenDeploymentTargetInstanceIpAddressesList;
    get targetInstanceName(): string;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesBlueGreenDeploymentList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesBlueGreenDeploymentOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesClone {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesCloneToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesClone): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesCloneToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesClone): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesCloneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesClone | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesClone | undefined);
    get allocatedIpRange(): string;
    get databaseNames(): string[];
    get pointInTime(): string;
    get preferredZone(): string;
    get sourceInstanceDeletionTime(): string;
    get sourceInstanceName(): string;
    get sourceProject(): string;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesCloneList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesCloneOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesDnsNames {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesDnsNamesToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesDnsNames): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesDnsNamesToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesDnsNames): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesDnsNamesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesDnsNames | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesDnsNames | undefined);
    get connectionType(): string;
    get dnsScope(): string;
    get name(): string;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesDnsNamesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesDnsNamesOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesIpAddress {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesIpAddressToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesIpAddress): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesIpAddressToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesIpAddress): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesIpAddressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesIpAddress | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesIpAddress | undefined);
    get ipAddress(): string;
    get timeToRetire(): string;
    get type(): string;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesIpAddressList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesIpAddressOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesPointInTimeRestoreContext {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesPointInTimeRestoreContextToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesPointInTimeRestoreContext): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesPointInTimeRestoreContextToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesPointInTimeRestoreContext): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesPointInTimeRestoreContextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesPointInTimeRestoreContext | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesPointInTimeRestoreContext | undefined);
    get allocatedIpRange(): string;
    get datasource(): string;
    get pointInTime(): string;
    get preferredZone(): string;
    get region(): string;
    get targetInstance(): string;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesPointInTimeRestoreContextList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesPointInTimeRestoreContextOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesReplicaConfiguration {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesReplicaConfigurationToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesReplicaConfiguration): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesReplicaConfigurationToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesReplicaConfiguration): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesReplicaConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesReplicaConfiguration | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesReplicaConfiguration | undefined);
    get caCertificate(): string;
    get cascadableReplica(): cdktn.IResolvable;
    get clientCertificate(): string;
    get clientKey(): string;
    get connectRetryInterval(): number;
    get dumpFilePath(): string;
    get failoverTarget(): cdktn.IResolvable;
    get masterHeartbeatPeriod(): number;
    get password(): string;
    get sslCipher(): string;
    get username(): string;
    get verifyServerCertificate(): cdktn.IResolvable;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesReplicaConfigurationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesReplicaConfigurationOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesReplicationCluster {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesReplicationClusterToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesReplicationCluster): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesReplicationClusterToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesReplicationCluster): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesReplicationClusterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesReplicationCluster | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesReplicationCluster | undefined);
    get drReplica(): cdktn.IResolvable;
    get failoverDrReplicaName(): string;
    get psaWriteEndpoint(): string;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesReplicationClusterList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesReplicationClusterOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesRestoreBackupContext {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesRestoreBackupContextToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesRestoreBackupContext): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesRestoreBackupContextToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesRestoreBackupContext): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesRestoreBackupContextOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesRestoreBackupContext | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesRestoreBackupContext | undefined);
    get backupRunId(): number;
    get instanceId(): string;
    get project(): string;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesRestoreBackupContextList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesRestoreBackupContextOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesServerCaCert {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesServerCaCertToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesServerCaCert): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesServerCaCertToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesServerCaCert): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesServerCaCertOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesServerCaCert | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesServerCaCert | undefined);
    get cert(): string;
    get commonName(): string;
    get createTime(): string;
    get expirationTime(): string;
    get sha1Fingerprint(): string;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesServerCaCertList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesServerCaCertOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesSettingsActiveDirectoryConfig {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsActiveDirectoryConfigToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsActiveDirectoryConfig): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsActiveDirectoryConfigToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsActiveDirectoryConfig): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsActiveDirectoryConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesSettingsActiveDirectoryConfig | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesSettingsActiveDirectoryConfig | undefined);
    get adminCredentialSecretName(): string;
    get dnsServers(): string[];
    get domain(): string;
    get mode(): string;
    get organizationalUnit(): string;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsActiveDirectoryConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesSettingsActiveDirectoryConfigOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesSettingsAdvancedMachineFeatures {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsAdvancedMachineFeaturesToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsAdvancedMachineFeatures): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsAdvancedMachineFeaturesToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsAdvancedMachineFeatures): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsAdvancedMachineFeaturesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesSettingsAdvancedMachineFeatures | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesSettingsAdvancedMachineFeatures | undefined);
    get threadsPerCore(): number;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsAdvancedMachineFeaturesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesSettingsAdvancedMachineFeaturesOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesSettingsBackupConfigurationBackupRetentionSettings {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsBackupConfigurationBackupRetentionSettingsToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsBackupConfigurationBackupRetentionSettings): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsBackupConfigurationBackupRetentionSettingsToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsBackupConfigurationBackupRetentionSettings): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsBackupConfigurationBackupRetentionSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesSettingsBackupConfigurationBackupRetentionSettings | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesSettingsBackupConfigurationBackupRetentionSettings | undefined);
    get retainedBackups(): number;
    get retentionUnit(): string;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsBackupConfigurationBackupRetentionSettingsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesSettingsBackupConfigurationBackupRetentionSettingsOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesSettingsBackupConfiguration {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsBackupConfigurationToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsBackupConfiguration): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsBackupConfigurationToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsBackupConfiguration): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsBackupConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesSettingsBackupConfiguration | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesSettingsBackupConfiguration | undefined);
    private _backupRetentionSettings;
    get backupRetentionSettings(): DataGoogleSqlDatabaseInstancesInstancesSettingsBackupConfigurationBackupRetentionSettingsList;
    get backupTier(): string;
    get binaryLogEnabled(): cdktn.IResolvable;
    get enabled(): cdktn.IResolvable;
    get location(): string;
    get pointInTimeRecoveryEnabled(): cdktn.IResolvable;
    get startTime(): string;
    get transactionLogRetentionDays(): number;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsBackupConfigurationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesSettingsBackupConfigurationOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesSettingsConnectionPoolConfigFlags {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsConnectionPoolConfigFlagsToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsConnectionPoolConfigFlags): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsConnectionPoolConfigFlagsToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsConnectionPoolConfigFlags): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsConnectionPoolConfigFlagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesSettingsConnectionPoolConfigFlags | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesSettingsConnectionPoolConfigFlags | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsConnectionPoolConfigFlagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesSettingsConnectionPoolConfigFlagsOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesSettingsConnectionPoolConfig {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsConnectionPoolConfigToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsConnectionPoolConfig): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsConnectionPoolConfigToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsConnectionPoolConfig): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsConnectionPoolConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesSettingsConnectionPoolConfig | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesSettingsConnectionPoolConfig | undefined);
    get connectionPoolingEnabled(): cdktn.IResolvable;
    private _flags;
    get flags(): DataGoogleSqlDatabaseInstancesInstancesSettingsConnectionPoolConfigFlagsList;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsConnectionPoolConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesSettingsConnectionPoolConfigOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesSettingsDataCacheConfig {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsDataCacheConfigToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsDataCacheConfig): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsDataCacheConfigToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsDataCacheConfig): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsDataCacheConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesSettingsDataCacheConfig | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesSettingsDataCacheConfig | undefined);
    get dataCacheEnabled(): cdktn.IResolvable;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsDataCacheConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesSettingsDataCacheConfigOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesSettingsDatabaseFlags {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsDatabaseFlagsToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsDatabaseFlags): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsDatabaseFlagsToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsDatabaseFlags): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsDatabaseFlagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesSettingsDatabaseFlags | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesSettingsDatabaseFlags | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsDatabaseFlagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesSettingsDatabaseFlagsOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesSettingsDenyMaintenancePeriod {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsDenyMaintenancePeriodToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsDenyMaintenancePeriod): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsDenyMaintenancePeriodToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsDenyMaintenancePeriod): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsDenyMaintenancePeriodOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesSettingsDenyMaintenancePeriod | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesSettingsDenyMaintenancePeriod | undefined);
    get endDate(): string;
    get startDate(): string;
    get time(): string;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsDenyMaintenancePeriodList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesSettingsDenyMaintenancePeriodOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesSettingsEntraidConfig {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsEntraidConfigToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsEntraidConfig): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsEntraidConfigToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsEntraidConfig): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsEntraidConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesSettingsEntraidConfig | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesSettingsEntraidConfig | undefined);
    get applicationId(): string;
    get tenantId(): string;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsEntraidConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesSettingsEntraidConfigOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesSettingsFinalBackupConfig {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsFinalBackupConfigToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsFinalBackupConfig): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsFinalBackupConfigToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsFinalBackupConfig): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsFinalBackupConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesSettingsFinalBackupConfig | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesSettingsFinalBackupConfig | undefined);
    get enabled(): cdktn.IResolvable;
    get retentionDays(): number;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsFinalBackupConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesSettingsFinalBackupConfigOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesSettingsInsightsConfig {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsInsightsConfigToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsInsightsConfig): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsInsightsConfigToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsInsightsConfig): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsInsightsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesSettingsInsightsConfig | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesSettingsInsightsConfig | undefined);
    get enhancedQueryInsightsEnabled(): cdktn.IResolvable;
    get queryInsightsEnabled(): cdktn.IResolvable;
    get queryPlansPerMinute(): number;
    get queryStringLength(): number;
    get recordApplicationTags(): cdktn.IResolvable;
    get recordClientAddress(): cdktn.IResolvable;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsInsightsConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesSettingsInsightsConfigOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationAuthorizedNetworks {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationAuthorizedNetworksToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationAuthorizedNetworks): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationAuthorizedNetworksToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationAuthorizedNetworks): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationAuthorizedNetworksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationAuthorizedNetworks | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationAuthorizedNetworks | undefined);
    get expirationTime(): string;
    get name(): string;
    get value(): string;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationAuthorizedNetworksList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationAuthorizedNetworksOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationPscConfigPscAutoConnections {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationPscConfigPscAutoConnectionsToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationPscConfigPscAutoConnections): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationPscConfigPscAutoConnectionsToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationPscConfigPscAutoConnections): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationPscConfigPscAutoConnectionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationPscConfigPscAutoConnections | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationPscConfigPscAutoConnections | undefined);
    get consumerNetwork(): string;
    get consumerNetworkStatus(): string;
    get consumerServiceProjectId(): string;
    get instanceAutoDnsStatus(): string;
    get ipAddress(): string;
    get serviceConnectionPolicy(): string;
    get serviceConnectionPolicyCreationResult(): string;
    get status(): string;
    get writeEndpointAutoDnsStatus(): string;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationPscConfigPscAutoConnectionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationPscConfigPscAutoConnectionsOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationPscConfig {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationPscConfigToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationPscConfig): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationPscConfigToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationPscConfig): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationPscConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationPscConfig | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationPscConfig | undefined);
    get allowedConsumerProjects(): string[];
    get networkAttachmentUri(): string;
    get pscAutoConnectionPolicyEnabled(): cdktn.IResolvable;
    private _pscAutoConnections;
    get pscAutoConnections(): DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationPscConfigPscAutoConnectionsList;
    get pscAutoDnsEnabled(): cdktn.IResolvable;
    get pscEnabled(): cdktn.IResolvable;
    get pscWriteEndpointDnsEnabled(): cdktn.IResolvable;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationPscConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationPscConfigOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfiguration {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfiguration): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfiguration): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfiguration | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfiguration | undefined);
    get allocatedIpRange(): string;
    private _authorizedNetworks;
    get authorizedNetworks(): DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationAuthorizedNetworksList;
    get customSubjectAlternativeNames(): string[];
    get enablePrivatePathForGoogleCloudServices(): cdktn.IResolvable;
    get ipv4Enabled(): cdktn.IResolvable;
    get privateNetwork(): string;
    private _pscConfig;
    get pscConfig(): DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationPscConfigList;
    get serverCaMode(): string;
    get serverCaPool(): string;
    get serverCertificateRotationMode(): string;
    get sslMode(): string;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesSettingsLocationPreference {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsLocationPreferenceToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsLocationPreference): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsLocationPreferenceToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsLocationPreference): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsLocationPreferenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesSettingsLocationPreference | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesSettingsLocationPreference | undefined);
    get followGaeApplication(): string;
    get secondaryZone(): string;
    get zone(): string;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsLocationPreferenceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesSettingsLocationPreferenceOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesSettingsMaintenanceWindow {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsMaintenanceWindowToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsMaintenanceWindow): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsMaintenanceWindowToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsMaintenanceWindow): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesSettingsMaintenanceWindow | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesSettingsMaintenanceWindow | undefined);
    get day(): number;
    get hour(): number;
    get updateTrack(): string;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsMaintenanceWindowList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesSettingsMaintenanceWindowOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesSettingsPasswordValidationPolicy {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsPasswordValidationPolicyToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsPasswordValidationPolicy): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsPasswordValidationPolicyToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsPasswordValidationPolicy): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsPasswordValidationPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesSettingsPasswordValidationPolicy | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesSettingsPasswordValidationPolicy | undefined);
    get complexity(): string;
    get disallowUsernameSubstring(): cdktn.IResolvable;
    get enablePasswordPolicy(): cdktn.IResolvable;
    get minLength(): number;
    get passwordChangeInterval(): string;
    get reuseInterval(): number;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsPasswordValidationPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesSettingsPasswordValidationPolicyOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesSettingsPerformanceCaptureConfig {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsPerformanceCaptureConfigToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsPerformanceCaptureConfig): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsPerformanceCaptureConfigToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsPerformanceCaptureConfig): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsPerformanceCaptureConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesSettingsPerformanceCaptureConfig | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesSettingsPerformanceCaptureConfig | undefined);
    get cpuUtilizationThresholdPercent(): number;
    get enabled(): cdktn.IResolvable;
    get historyListLengthThresholdCount(): number;
    get memoryUsageThresholdPercent(): number;
    get probeThreshold(): number;
    get probingIntervalSeconds(): number;
    get runningThreadsThreshold(): number;
    get secondsBehindSourceThreshold(): number;
    get semaphoreWaitThresholdCount(): number;
    get transactionDurationThreshold(): number;
    get transactionKillExcludedUserHosts(): string[];
    get transactionKillThresholdSeconds(): number;
    get transactionKillType(): string;
    get transactionLockWaitThresholdCount(): number;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsPerformanceCaptureConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesSettingsPerformanceCaptureConfigOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesSettingsReadPoolAutoScaleConfigTargetMetrics {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsReadPoolAutoScaleConfigTargetMetricsToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsReadPoolAutoScaleConfigTargetMetrics): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsReadPoolAutoScaleConfigTargetMetricsToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsReadPoolAutoScaleConfigTargetMetrics): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsReadPoolAutoScaleConfigTargetMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesSettingsReadPoolAutoScaleConfigTargetMetrics | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesSettingsReadPoolAutoScaleConfigTargetMetrics | undefined);
    get metric(): string;
    get targetValue(): number;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsReadPoolAutoScaleConfigTargetMetricsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesSettingsReadPoolAutoScaleConfigTargetMetricsOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesSettingsReadPoolAutoScaleConfig {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsReadPoolAutoScaleConfigToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsReadPoolAutoScaleConfig): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsReadPoolAutoScaleConfigToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsReadPoolAutoScaleConfig): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsReadPoolAutoScaleConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesSettingsReadPoolAutoScaleConfig | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesSettingsReadPoolAutoScaleConfig | undefined);
    get disableScaleIn(): cdktn.IResolvable;
    get enabled(): cdktn.IResolvable;
    get maxNodeCount(): number;
    get minNodeCount(): number;
    get scaleInCooldownSeconds(): number;
    get scaleOutCooldownSeconds(): number;
    private _targetMetrics;
    get targetMetrics(): DataGoogleSqlDatabaseInstancesInstancesSettingsReadPoolAutoScaleConfigTargetMetricsList;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsReadPoolAutoScaleConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesSettingsReadPoolAutoScaleConfigOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesSettingsSqlServerAuditConfig {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsSqlServerAuditConfigToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsSqlServerAuditConfig): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsSqlServerAuditConfigToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettingsSqlServerAuditConfig): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsSqlServerAuditConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesSettingsSqlServerAuditConfig | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesSettingsSqlServerAuditConfig | undefined);
    get bucket(): string;
    get retentionInterval(): string;
    get uploadInterval(): string;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsSqlServerAuditConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesSettingsSqlServerAuditConfigOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstancesSettings {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettings): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesSettingsToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstancesSettings): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstancesSettings | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstancesSettings | undefined);
    get activationPolicy(): string;
    private _activeDirectoryConfig;
    get activeDirectoryConfig(): DataGoogleSqlDatabaseInstancesInstancesSettingsActiveDirectoryConfigList;
    private _advancedMachineFeatures;
    get advancedMachineFeatures(): DataGoogleSqlDatabaseInstancesInstancesSettingsAdvancedMachineFeaturesList;
    get autoUpgradeEnabled(): cdktn.IResolvable;
    get availabilityType(): string;
    private _backupConfiguration;
    get backupConfiguration(): DataGoogleSqlDatabaseInstancesInstancesSettingsBackupConfigurationList;
    get collation(): string;
    private _connectionPoolConfig;
    get connectionPoolConfig(): DataGoogleSqlDatabaseInstancesInstancesSettingsConnectionPoolConfigList;
    get connectorEnforcement(): string;
    get dataApiAccess(): string;
    private _dataCacheConfig;
    get dataCacheConfig(): DataGoogleSqlDatabaseInstancesInstancesSettingsDataCacheConfigList;
    get dataDiskProvisionedIops(): number;
    get dataDiskProvisionedThroughput(): number;
    private _databaseFlags;
    get databaseFlags(): DataGoogleSqlDatabaseInstancesInstancesSettingsDatabaseFlagsList;
    get deletionProtectionEnabled(): cdktn.IResolvable;
    private _denyMaintenancePeriod;
    get denyMaintenancePeriod(): DataGoogleSqlDatabaseInstancesInstancesSettingsDenyMaintenancePeriodList;
    get diskAutoresize(): cdktn.IResolvable;
    get diskAutoresizeLimit(): number;
    get diskSize(): number;
    get diskType(): string;
    get edition(): string;
    get effectiveAvailabilityType(): string;
    get enableDataplexIntegration(): cdktn.IResolvable;
    get enableGoogleMlIntegration(): cdktn.IResolvable;
    private _entraidConfig;
    get entraidConfig(): DataGoogleSqlDatabaseInstancesInstancesSettingsEntraidConfigList;
    private _finalBackupConfig;
    get finalBackupConfig(): DataGoogleSqlDatabaseInstancesInstancesSettingsFinalBackupConfigList;
    private _insightsConfig;
    get insightsConfig(): DataGoogleSqlDatabaseInstancesInstancesSettingsInsightsConfigList;
    private _ipConfiguration;
    get ipConfiguration(): DataGoogleSqlDatabaseInstancesInstancesSettingsIpConfigurationList;
    private _locationPreference;
    get locationPreference(): DataGoogleSqlDatabaseInstancesInstancesSettingsLocationPreferenceList;
    private _maintenanceWindow;
    get maintenanceWindow(): DataGoogleSqlDatabaseInstancesInstancesSettingsMaintenanceWindowList;
    private _passwordValidationPolicy;
    get passwordValidationPolicy(): DataGoogleSqlDatabaseInstancesInstancesSettingsPasswordValidationPolicyList;
    private _performanceCaptureConfig;
    get performanceCaptureConfig(): DataGoogleSqlDatabaseInstancesInstancesSettingsPerformanceCaptureConfigList;
    get pricingPlan(): string;
    private _readPoolAutoScaleConfig;
    get readPoolAutoScaleConfig(): DataGoogleSqlDatabaseInstancesInstancesSettingsReadPoolAutoScaleConfigList;
    get replicationLagMaxSeconds(): number;
    get retainBackupsOnDelete(): cdktn.IResolvable;
    private _sqlServerAuditConfig;
    get sqlServerAuditConfig(): DataGoogleSqlDatabaseInstancesInstancesSettingsSqlServerAuditConfigList;
    get tier(): string;
    get timeZone(): string;
    private _userLabels;
    get userLabels(): cdktn.StringMap;
    get version(): number;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesSettingsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesSettingsOutputReference;
}
export interface DataGoogleSqlDatabaseInstancesInstances {
}
export declare function dataGoogleSqlDatabaseInstancesInstancesToTerraform(struct?: DataGoogleSqlDatabaseInstancesInstances): any;
export declare function dataGoogleSqlDatabaseInstancesInstancesToHclTerraform(struct?: DataGoogleSqlDatabaseInstancesInstances): any;
export declare class DataGoogleSqlDatabaseInstancesInstancesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSqlDatabaseInstancesInstances | undefined;
    set internalValue(value: DataGoogleSqlDatabaseInstancesInstances | undefined);
    get availableMaintenanceVersions(): string[];
    get backupdrBackup(): string;
    private _blueGreenDeployment;
    get blueGreenDeployment(): DataGoogleSqlDatabaseInstancesInstancesBlueGreenDeploymentList;
    private _clone;
    get clone(): DataGoogleSqlDatabaseInstancesInstancesCloneList;
    get connectionName(): string;
    get databaseVersion(): string;
    get deletionPolicy(): string;
    get deletionProtection(): cdktn.IResolvable;
    get dnsName(): string;
    private _dnsNames;
    get dnsNames(): DataGoogleSqlDatabaseInstancesInstancesDnsNamesList;
    get encryptionConfidentialMode(): cdktn.IResolvable;
    get encryptionKeyName(): string;
    get enforceNewSqlNetworkArchitecture(): cdktn.IResolvable;
    get finalBackupDescription(): string;
    get firstIpAddress(): string;
    get includeReplicasForMajorVersionUpgrade(): cdktn.IResolvable;
    get instanceType(): string;
    private _ipAddress;
    get ipAddress(): DataGoogleSqlDatabaseInstancesInstancesIpAddressList;
    get maintenanceVersion(): string;
    get masterInstanceName(): string;
    get name(): string;
    get nodeCount(): number;
    private _pointInTimeRestoreContext;
    get pointInTimeRestoreContext(): DataGoogleSqlDatabaseInstancesInstancesPointInTimeRestoreContextList;
    get privateIpAddress(): string;
    get project(): string;
    get pscServiceAttachmentLink(): string;
    get publicIpAddress(): string;
    get region(): string;
    private _replicaConfiguration;
    get replicaConfiguration(): DataGoogleSqlDatabaseInstancesInstancesReplicaConfigurationList;
    get replicaNames(): string[];
    private _replicationCluster;
    get replicationCluster(): DataGoogleSqlDatabaseInstancesInstancesReplicationClusterList;
    private _restoreBackupContext;
    get restoreBackupContext(): DataGoogleSqlDatabaseInstancesInstancesRestoreBackupContextList;
    get rootPassword(): string;
    get rootPasswordWo(): string;
    get rootPasswordWoVersion(): string;
    get selfLink(): string;
    private _serverCaCert;
    get serverCaCert(): DataGoogleSqlDatabaseInstancesInstancesServerCaCertList;
    get serviceAccountEmailAddress(): string;
    private _settings;
    get settings(): DataGoogleSqlDatabaseInstancesInstancesSettingsList;
    get switchTransactionLogsToCloudStorageEnabled(): cdktn.IResolvable;
}
export declare class DataGoogleSqlDatabaseInstancesInstancesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSqlDatabaseInstancesInstancesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_sql_database_instances google_sql_database_instances}
*/
export declare class DataGoogleSqlDatabaseInstances extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_sql_database_instances";
    /**
    * Generates CDKTN code for importing a DataGoogleSqlDatabaseInstances resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleSqlDatabaseInstances to import
    * @param importFromId The id of the existing DataGoogleSqlDatabaseInstances that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_sql_database_instances#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleSqlDatabaseInstances to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_sql_database_instances google_sql_database_instances} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleSqlDatabaseInstancesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGoogleSqlDatabaseInstancesConfig);
    private _databaseVersion?;
    get databaseVersion(): string;
    set databaseVersion(value: string);
    resetDatabaseVersion(): void;
    get databaseVersionInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instances;
    get instances(): DataGoogleSqlDatabaseInstancesInstancesList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _state?;
    get state(): string;
    set state(value: string);
    resetState(): void;
    get stateInput(): string | undefined;
    private _tier?;
    get tier(): string;
    set tier(value: string);
    resetTier(): void;
    get tierInput(): string | undefined;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    resetZone(): void;
    get zoneInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
