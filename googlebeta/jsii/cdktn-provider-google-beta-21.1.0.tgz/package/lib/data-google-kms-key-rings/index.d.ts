/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleKmsKeyRingsConfig extends cdktn.TerraformMetaArguments {
    /**
    *
    * 					The filter argument is used to add a filter query parameter that limits which keys are retrieved by the data source: ?filter={{filter}}.
    * 					Example values:
    *
    * 					* "name:my-key-" will retrieve key rings that contain "my-key-" anywhere in their name. Note: names take the form projects/{{project}}/locations/{{location}}/keyRings/{{keyRing}}.
    * 					* "name=projects/my-project/locations/global/keyRings/my-key-ring" will only retrieve a key ring with that exact name.
    *
    * 					[See the documentation about using filters](https://cloud.google.com/kms/docs/sorting-and-filtering)
    *
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_key_rings#filter DataGoogleKmsKeyRings#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_key_rings#id DataGoogleKmsKeyRings#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The canonical id for the location. For example: "us-east1".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_key_rings#location DataGoogleKmsKeyRings#location}
    */
    readonly location: string;
    /**
    * Project ID of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_key_rings#project DataGoogleKmsKeyRings#project}
    */
    readonly project?: string;
}
export interface DataGoogleKmsKeyRingsKeyRings {
}
export declare function dataGoogleKmsKeyRingsKeyRingsToTerraform(struct?: DataGoogleKmsKeyRingsKeyRings): any;
export declare function dataGoogleKmsKeyRingsKeyRingsToHclTerraform(struct?: DataGoogleKmsKeyRingsKeyRings): any;
export declare class DataGoogleKmsKeyRingsKeyRingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleKmsKeyRingsKeyRings | undefined;
    set internalValue(value: DataGoogleKmsKeyRingsKeyRings | undefined);
    get id(): string;
    get name(): string;
}
export declare class DataGoogleKmsKeyRingsKeyRingsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleKmsKeyRingsKeyRingsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_key_rings google_kms_key_rings}
*/
export declare class DataGoogleKmsKeyRings extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_kms_key_rings";
    /**
    * Generates CDKTN code for importing a DataGoogleKmsKeyRings resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleKmsKeyRings to import
    * @param importFromId The id of the existing DataGoogleKmsKeyRings that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_key_rings#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleKmsKeyRings to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.7.0/docs/data-sources/google_kms_key_rings google_kms_key_rings} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleKmsKeyRingsConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleKmsKeyRingsConfig);
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _keyRings;
    get keyRings(): DataGoogleKmsKeyRingsKeyRingsList;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
