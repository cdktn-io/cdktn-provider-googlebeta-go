/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleMonitoringNotificationChannelConfig extends cdktn.TerraformMetaArguments {
    /**
    * An optional human-readable name for this notification channel. It is recommended that you specify a non-empty and unique name in order to make it easier to identify the channels in your project, though this is not enforced. The display name is limited to 512 Unicode characters.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_monitoring_notification_channel#display_name DataGoogleMonitoringNotificationChannel#display_name}
    */
    readonly displayName?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_monitoring_notification_channel#id DataGoogleMonitoringNotificationChannel#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Configuration fields that define the channel and its behavior. The
    * permissible and required labels are specified in the
    * NotificationChannelDescriptor corresponding to the type field.
    *
    * Labels with sensitive data are obfuscated by the API and therefore Terraform cannot
    * determine if there are upstream changes to these fields. They can also be configured via
    * the sensitive_labels block, but cannot be configured in both places.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_monitoring_notification_channel#labels DataGoogleMonitoringNotificationChannel#labels}
    */
    readonly labels?: {
        [key: string]: string;
    };
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_monitoring_notification_channel#project DataGoogleMonitoringNotificationChannel#project}
    */
    readonly project?: string;
    /**
    * The type of the notification channel. This field matches the value of the NotificationChannelDescriptor.type field. See https://cloud.google.com/monitoring/api/ref_v3/rest/v3/projects.notificationChannelDescriptors/list to get the list of valid values such as "email", "slack", etc...
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_monitoring_notification_channel#type DataGoogleMonitoringNotificationChannel#type}
    */
    readonly type?: string;
    /**
    * User-supplied key/value data that does not need to conform to the corresponding NotificationChannelDescriptor's schema, unlike the labels field. This field is intended to be used for organizing and identifying the NotificationChannel objects.The field can contain up to 64 entries. Each key and value is limited to 63 Unicode characters or 128 bytes, whichever is smaller. Labels and values can contain only lowercase letters, numerals, underscores, and dashes. Keys must begin with a letter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_monitoring_notification_channel#user_labels DataGoogleMonitoringNotificationChannel#user_labels}
    */
    readonly userLabels?: {
        [key: string]: string;
    };
}
export interface DataGoogleMonitoringNotificationChannelSensitiveLabels {
}
export declare function dataGoogleMonitoringNotificationChannelSensitiveLabelsToTerraform(struct?: DataGoogleMonitoringNotificationChannelSensitiveLabels): any;
export declare function dataGoogleMonitoringNotificationChannelSensitiveLabelsToHclTerraform(struct?: DataGoogleMonitoringNotificationChannelSensitiveLabels): any;
export declare class DataGoogleMonitoringNotificationChannelSensitiveLabelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMonitoringNotificationChannelSensitiveLabels | undefined;
    set internalValue(value: DataGoogleMonitoringNotificationChannelSensitiveLabels | undefined);
    get authToken(): string;
    get authTokenWo(): string;
    get authTokenWoVersion(): string;
    get password(): string;
    get passwordWo(): string;
    get passwordWoVersion(): string;
    get serviceKey(): string;
    get serviceKeyWo(): string;
    get serviceKeyWoVersion(): string;
}
export declare class DataGoogleMonitoringNotificationChannelSensitiveLabelsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMonitoringNotificationChannelSensitiveLabelsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_monitoring_notification_channel google_monitoring_notification_channel}
*/
export declare class DataGoogleMonitoringNotificationChannel extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_monitoring_notification_channel";
    /**
    * Generates CDKTN code for importing a DataGoogleMonitoringNotificationChannel resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleMonitoringNotificationChannel to import
    * @param importFromId The id of the existing DataGoogleMonitoringNotificationChannel that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_monitoring_notification_channel#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleMonitoringNotificationChannel to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_monitoring_notification_channel google_monitoring_notification_channel} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleMonitoringNotificationChannelConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGoogleMonitoringNotificationChannelConfig);
    get deletionPolicy(): string;
    get description(): string;
    private _displayName?;
    get displayName(): string;
    set displayName(value: string);
    resetDisplayName(): void;
    get displayNameInput(): string | undefined;
    get enabled(): cdktn.IResolvable;
    get forceDelete(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels?;
    get labels(): {
        [key: string]: string;
    };
    set labels(value: {
        [key: string]: string;
    });
    resetLabels(): void;
    get labelsInput(): {
        [key: string]: string;
    } | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _sensitiveLabels;
    get sensitiveLabels(): DataGoogleMonitoringNotificationChannelSensitiveLabelsList;
    private _type?;
    get type(): string;
    set type(value: string);
    resetType(): void;
    get typeInput(): string | undefined;
    private _userLabels?;
    get userLabels(): {
        [key: string]: string;
    };
    set userLabels(value: {
        [key: string]: string;
    });
    resetUserLabels(): void;
    get userLabelsInput(): {
        [key: string]: string;
    } | undefined;
    get verificationStatus(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
