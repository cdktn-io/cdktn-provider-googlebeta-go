/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleOracleDatabaseExascaleDbStorageVaultConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the ExascaleDbStorageVault to create. This value is
    * restricted to (^[a-z]([a-z0-9-]{0,61}[a-z0-9])?$) and must be a maximum of
    * 63 characters in length. The value must start with a letter and end with a
    * letter or a number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_exascale_db_storage_vault#exascale_db_storage_vault_id DataGoogleOracleDatabaseExascaleDbStorageVault#exascale_db_storage_vault_id}
    */
    readonly exascaleDbStorageVaultId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_exascale_db_storage_vault#id DataGoogleOracleDatabaseExascaleDbStorageVault#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_exascale_db_storage_vault#location DataGoogleOracleDatabaseExascaleDbStorageVault#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_exascale_db_storage_vault#project DataGoogleOracleDatabaseExascaleDbStorageVault#project}
    */
    readonly project?: string;
}
export interface DataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesExascaleDbStorageDetails {
}
export declare function dataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesExascaleDbStorageDetailsToTerraform(struct?: DataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesExascaleDbStorageDetails): any;
export declare function dataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesExascaleDbStorageDetailsToHclTerraform(struct?: DataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesExascaleDbStorageDetails): any;
export declare class DataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesExascaleDbStorageDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesExascaleDbStorageDetails | undefined;
    set internalValue(value: DataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesExascaleDbStorageDetails | undefined);
    get availableSizeGbs(): number;
    get totalSizeGbs(): number;
}
export declare class DataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesExascaleDbStorageDetailsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesExascaleDbStorageDetailsOutputReference;
}
export interface DataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesTimeZone {
}
export declare function dataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesTimeZoneToTerraform(struct?: DataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesTimeZone): any;
export declare function dataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesTimeZoneToHclTerraform(struct?: DataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesTimeZone): any;
export declare class DataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesTimeZoneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesTimeZone | undefined;
    set internalValue(value: DataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesTimeZone | undefined);
    get id(): string;
    get version(): string;
}
export declare class DataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesTimeZoneList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesTimeZoneOutputReference;
}
export interface DataGoogleOracleDatabaseExascaleDbStorageVaultProperties {
}
export declare function dataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesToTerraform(struct?: DataGoogleOracleDatabaseExascaleDbStorageVaultProperties): any;
export declare function dataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesToHclTerraform(struct?: DataGoogleOracleDatabaseExascaleDbStorageVaultProperties): any;
export declare class DataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseExascaleDbStorageVaultProperties | undefined;
    set internalValue(value: DataGoogleOracleDatabaseExascaleDbStorageVaultProperties | undefined);
    get additionalFlashCachePercent(): number;
    get attachedShapeAttributes(): string[];
    get availableShapeAttributes(): string[];
    private _exascaleDbStorageDetails;
    get exascaleDbStorageDetails(): DataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesExascaleDbStorageDetailsList;
    get ociUri(): string;
    get ocid(): string;
    get state(): string;
    private _timeZone;
    get timeZone(): DataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesTimeZoneList;
    get vmClusterCount(): number;
    get vmClusterIds(): string[];
}
export declare class DataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_exascale_db_storage_vault google_oracle_database_exascale_db_storage_vault}
*/
export declare class DataGoogleOracleDatabaseExascaleDbStorageVault extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_oracle_database_exascale_db_storage_vault";
    /**
    * Generates CDKTN code for importing a DataGoogleOracleDatabaseExascaleDbStorageVault resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleOracleDatabaseExascaleDbStorageVault to import
    * @param importFromId The id of the existing DataGoogleOracleDatabaseExascaleDbStorageVault that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_exascale_db_storage_vault#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleOracleDatabaseExascaleDbStorageVault to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_exascale_db_storage_vault google_oracle_database_exascale_db_storage_vault} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleOracleDatabaseExascaleDbStorageVaultConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleOracleDatabaseExascaleDbStorageVaultConfig);
    get createTime(): string;
    get deletionPolicy(): string;
    get deletionProtection(): cdktn.IResolvable;
    get displayName(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get entitlementId(): string;
    get exadataInfrastructure(): string;
    private _exascaleDbStorageVaultId?;
    get exascaleDbStorageVaultId(): string;
    set exascaleDbStorageVaultId(value: string);
    get exascaleDbStorageVaultIdInput(): string | undefined;
    get gcpOracleZone(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels;
    get labels(): cdktn.StringMap;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _properties;
    get properties(): DataGoogleOracleDatabaseExascaleDbStorageVaultPropertiesList;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
