/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleProjectAncestryConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_project_ancestry#id DataGoogleProjectAncestry#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_project_ancestry#project DataGoogleProjectAncestry#project}
    */
    readonly project?: string;
}
export interface DataGoogleProjectAncestryAncestors {
}
export declare function dataGoogleProjectAncestryAncestorsToTerraform(struct?: DataGoogleProjectAncestryAncestors): any;
export declare function dataGoogleProjectAncestryAncestorsToHclTerraform(struct?: DataGoogleProjectAncestryAncestors): any;
export declare class DataGoogleProjectAncestryAncestorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleProjectAncestryAncestors | undefined;
    set internalValue(value: DataGoogleProjectAncestryAncestors | undefined);
    get id(): string;
    get type(): string;
}
export declare class DataGoogleProjectAncestryAncestorsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleProjectAncestryAncestorsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_project_ancestry google_project_ancestry}
*/
export declare class DataGoogleProjectAncestry extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_project_ancestry";
    /**
    * Generates CDKTN code for importing a DataGoogleProjectAncestry resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleProjectAncestry to import
    * @param importFromId The id of the existing DataGoogleProjectAncestry that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_project_ancestry#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleProjectAncestry to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_project_ancestry google_project_ancestry} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleProjectAncestryConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGoogleProjectAncestryConfig);
    private _ancestors;
    get ancestors(): DataGoogleProjectAncestryAncestorsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get orgId(): string;
    get parentId(): string;
    get parentType(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
