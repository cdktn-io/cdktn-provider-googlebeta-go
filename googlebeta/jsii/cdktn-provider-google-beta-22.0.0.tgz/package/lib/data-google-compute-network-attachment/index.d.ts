/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleComputeNetworkAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Name of the resource. Provided by the client when the resource is created. The name must be 1-63 characters long, and comply with RFC1035. Specifically, the name must be 1-63 characters long and match the regular expression [a-z]([-a-z0-9]*[a-z0-9])? which means the first character must be a lowercase letter, and all following characters must be a dash, lowercase letter, or digit, except the last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_network_attachment#name DataGoogleComputeNetworkAttachment#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_network_attachment#project DataGoogleComputeNetworkAttachment#project}
    */
    readonly project?: string;
    /**
    * URL of the region where the network attachment resides. This field applies only to the region resource. You must specify this field as part of the HTTP request URL. It is not settable as a field in the request body.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_network_attachment#region DataGoogleComputeNetworkAttachment#region}
    */
    readonly region: string;
}
export interface DataGoogleComputeNetworkAttachmentConnectionEndpoints {
}
export declare function dataGoogleComputeNetworkAttachmentConnectionEndpointsToTerraform(struct?: DataGoogleComputeNetworkAttachmentConnectionEndpoints): any;
export declare function dataGoogleComputeNetworkAttachmentConnectionEndpointsToHclTerraform(struct?: DataGoogleComputeNetworkAttachmentConnectionEndpoints): any;
export declare class DataGoogleComputeNetworkAttachmentConnectionEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeNetworkAttachmentConnectionEndpoints | undefined;
    set internalValue(value: DataGoogleComputeNetworkAttachmentConnectionEndpoints | undefined);
    get ipAddress(): string;
    get projectIdOrNum(): string;
    get secondaryIpCidrRanges(): string;
    get status(): string;
    get subnetwork(): string;
}
export declare class DataGoogleComputeNetworkAttachmentConnectionEndpointsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeNetworkAttachmentConnectionEndpointsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_network_attachment google_compute_network_attachment}
*/
export declare class DataGoogleComputeNetworkAttachment extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_compute_network_attachment";
    /**
    * Generates CDKTN code for importing a DataGoogleComputeNetworkAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleComputeNetworkAttachment to import
    * @param importFromId The id of the existing DataGoogleComputeNetworkAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_network_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleComputeNetworkAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_network_attachment google_compute_network_attachment} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleComputeNetworkAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleComputeNetworkAttachmentConfig);
    private _connectionEndpoints;
    get connectionEndpoints(): DataGoogleComputeNetworkAttachmentConnectionEndpointsList;
    get connectionPreference(): string;
    get creationTimestamp(): string;
    get deletionPolicy(): string;
    get description(): string;
    get fingerprint(): string;
    get id(): string;
    get kind(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get network(): string;
    get producerAcceptLists(): string[];
    get producerRejectLists(): string[];
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    get regionInput(): string | undefined;
    get selfLink(): string;
    get selfLinkWithId(): string;
    get subnetworks(): string[];
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
