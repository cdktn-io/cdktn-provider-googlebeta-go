/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleBackupDrDataSourceReferencesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_source_references#id DataGoogleBackupDrDataSourceReferences#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location to list the data source references from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_source_references#location DataGoogleBackupDrDataSourceReferences#location}
    */
    readonly location: string;
    /**
    * The ID of the project in which the resource belongs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_source_references#project DataGoogleBackupDrDataSourceReferences#project}
    */
    readonly project?: string;
}
export interface DataGoogleBackupDrDataSourceReferencesDataSourceReferences {
}
export declare function dataGoogleBackupDrDataSourceReferencesDataSourceReferencesToTerraform(struct?: DataGoogleBackupDrDataSourceReferencesDataSourceReferences): any;
export declare function dataGoogleBackupDrDataSourceReferencesDataSourceReferencesToHclTerraform(struct?: DataGoogleBackupDrDataSourceReferencesDataSourceReferences): any;
export declare class DataGoogleBackupDrDataSourceReferencesDataSourceReferencesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrDataSourceReferencesDataSourceReferences | undefined;
    set internalValue(value: DataGoogleBackupDrDataSourceReferencesDataSourceReferences | undefined);
    get backupConfigState(): string;
    get backupCount(): number;
    get dataSource(): string;
    get gcpResourceName(): string;
    get lastBackupState(): string;
    get lastSuccessfulBackupTime(): string;
    get name(): string;
    get resourceType(): string;
}
export declare class DataGoogleBackupDrDataSourceReferencesDataSourceReferencesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrDataSourceReferencesDataSourceReferencesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_source_references google_backup_dr_data_source_references}
*/
export declare class DataGoogleBackupDrDataSourceReferences extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_backup_dr_data_source_references";
    /**
    * Generates CDKTN code for importing a DataGoogleBackupDrDataSourceReferences resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleBackupDrDataSourceReferences to import
    * @param importFromId The id of the existing DataGoogleBackupDrDataSourceReferences that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_source_references#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleBackupDrDataSourceReferences to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_source_references google_backup_dr_data_source_references} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleBackupDrDataSourceReferencesConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleBackupDrDataSourceReferencesConfig);
    private _dataSourceReferences;
    get dataSourceReferences(): DataGoogleBackupDrDataSourceReferencesDataSourceReferencesList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
