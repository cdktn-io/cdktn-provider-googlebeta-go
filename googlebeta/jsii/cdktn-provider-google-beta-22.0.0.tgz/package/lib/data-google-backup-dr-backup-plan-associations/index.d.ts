/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleBackupDrBackupPlanAssociationsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_backup_plan_associations#id DataGoogleBackupDrBackupPlanAssociations#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location to list the backup plan associations from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_backup_plan_associations#location DataGoogleBackupDrBackupPlanAssociations#location}
    */
    readonly location: string;
    /**
    * The ID of the project in which the resource belongs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_backup_plan_associations#project DataGoogleBackupDrBackupPlanAssociations#project}
    */
    readonly project?: string;
}
export interface DataGoogleBackupDrBackupPlanAssociationsAssociationsRulesConfigInfoLastBackupError {
}
export declare function dataGoogleBackupDrBackupPlanAssociationsAssociationsRulesConfigInfoLastBackupErrorToTerraform(struct?: DataGoogleBackupDrBackupPlanAssociationsAssociationsRulesConfigInfoLastBackupError): any;
export declare function dataGoogleBackupDrBackupPlanAssociationsAssociationsRulesConfigInfoLastBackupErrorToHclTerraform(struct?: DataGoogleBackupDrBackupPlanAssociationsAssociationsRulesConfigInfoLastBackupError): any;
export declare class DataGoogleBackupDrBackupPlanAssociationsAssociationsRulesConfigInfoLastBackupErrorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrBackupPlanAssociationsAssociationsRulesConfigInfoLastBackupError | undefined;
    set internalValue(value: DataGoogleBackupDrBackupPlanAssociationsAssociationsRulesConfigInfoLastBackupError | undefined);
    get code(): number;
    get message(): string;
}
export declare class DataGoogleBackupDrBackupPlanAssociationsAssociationsRulesConfigInfoLastBackupErrorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrBackupPlanAssociationsAssociationsRulesConfigInfoLastBackupErrorOutputReference;
}
export interface DataGoogleBackupDrBackupPlanAssociationsAssociationsRulesConfigInfo {
}
export declare function dataGoogleBackupDrBackupPlanAssociationsAssociationsRulesConfigInfoToTerraform(struct?: DataGoogleBackupDrBackupPlanAssociationsAssociationsRulesConfigInfo): any;
export declare function dataGoogleBackupDrBackupPlanAssociationsAssociationsRulesConfigInfoToHclTerraform(struct?: DataGoogleBackupDrBackupPlanAssociationsAssociationsRulesConfigInfo): any;
export declare class DataGoogleBackupDrBackupPlanAssociationsAssociationsRulesConfigInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrBackupPlanAssociationsAssociationsRulesConfigInfo | undefined;
    set internalValue(value: DataGoogleBackupDrBackupPlanAssociationsAssociationsRulesConfigInfo | undefined);
    private _lastBackupError;
    get lastBackupError(): DataGoogleBackupDrBackupPlanAssociationsAssociationsRulesConfigInfoLastBackupErrorList;
    get lastBackupState(): string;
    get lastSuccessfulBackupConsistencyTime(): string;
    get ruleId(): string;
}
export declare class DataGoogleBackupDrBackupPlanAssociationsAssociationsRulesConfigInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrBackupPlanAssociationsAssociationsRulesConfigInfoOutputReference;
}
export interface DataGoogleBackupDrBackupPlanAssociationsAssociations {
}
export declare function dataGoogleBackupDrBackupPlanAssociationsAssociationsToTerraform(struct?: DataGoogleBackupDrBackupPlanAssociationsAssociations): any;
export declare function dataGoogleBackupDrBackupPlanAssociationsAssociationsToHclTerraform(struct?: DataGoogleBackupDrBackupPlanAssociationsAssociations): any;
export declare class DataGoogleBackupDrBackupPlanAssociationsAssociationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrBackupPlanAssociationsAssociations | undefined;
    set internalValue(value: DataGoogleBackupDrBackupPlanAssociationsAssociations | undefined);
    get backupPlan(): string;
    get createTime(): string;
    get dataSource(): string;
    get name(): string;
    get resource(): string;
    private _rulesConfigInfo;
    get rulesConfigInfo(): DataGoogleBackupDrBackupPlanAssociationsAssociationsRulesConfigInfoList;
}
export declare class DataGoogleBackupDrBackupPlanAssociationsAssociationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrBackupPlanAssociationsAssociationsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_backup_plan_associations google_backup_dr_backup_plan_associations}
*/
export declare class DataGoogleBackupDrBackupPlanAssociations extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_backup_dr_backup_plan_associations";
    /**
    * Generates CDKTN code for importing a DataGoogleBackupDrBackupPlanAssociations resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleBackupDrBackupPlanAssociations to import
    * @param importFromId The id of the existing DataGoogleBackupDrBackupPlanAssociations that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_backup_plan_associations#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleBackupDrBackupPlanAssociations to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_backup_plan_associations google_backup_dr_backup_plan_associations} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleBackupDrBackupPlanAssociationsConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleBackupDrBackupPlanAssociationsConfig);
    private _associations;
    get associations(): DataGoogleBackupDrBackupPlanAssociationsAssociationsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
