/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleAccessContextManagerSupportedServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_access_context_manager_supported_service#id DataGoogleAccessContextManagerSupportedService#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the service to get information about. The names must be in the same format as used in defining a service perimeter, for example, `storage.googleapis.com`.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_access_context_manager_supported_service#service_name DataGoogleAccessContextManagerSupportedService#service_name}
    */
    readonly serviceName: string;
}
export interface DataGoogleAccessContextManagerSupportedServiceSupportedMethods {
}
export declare function dataGoogleAccessContextManagerSupportedServiceSupportedMethodsToTerraform(struct?: DataGoogleAccessContextManagerSupportedServiceSupportedMethods): any;
export declare function dataGoogleAccessContextManagerSupportedServiceSupportedMethodsToHclTerraform(struct?: DataGoogleAccessContextManagerSupportedServiceSupportedMethods): any;
export declare class DataGoogleAccessContextManagerSupportedServiceSupportedMethodsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAccessContextManagerSupportedServiceSupportedMethods | undefined;
    set internalValue(value: DataGoogleAccessContextManagerSupportedServiceSupportedMethods | undefined);
    get method(): string;
    get permission(): string;
}
export declare class DataGoogleAccessContextManagerSupportedServiceSupportedMethodsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAccessContextManagerSupportedServiceSupportedMethodsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_access_context_manager_supported_service google_access_context_manager_supported_service}
*/
export declare class DataGoogleAccessContextManagerSupportedService extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_access_context_manager_supported_service";
    /**
    * Generates CDKTN code for importing a DataGoogleAccessContextManagerSupportedService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleAccessContextManagerSupportedService to import
    * @param importFromId The id of the existing DataGoogleAccessContextManagerSupportedService that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_access_context_manager_supported_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleAccessContextManagerSupportedService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_access_context_manager_supported_service google_access_context_manager_supported_service} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleAccessContextManagerSupportedServiceConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleAccessContextManagerSupportedServiceConfig);
    get availableOnRestrictedVip(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get knownLimitations(): cdktn.IResolvable;
    private _serviceName?;
    get serviceName(): string;
    set serviceName(value: string);
    get serviceNameInput(): string | undefined;
    get serviceSupportStage(): string;
    get supportStage(): string;
    private _supportedMethods;
    get supportedMethods(): DataGoogleAccessContextManagerSupportedServiceSupportedMethodsList;
    get title(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
