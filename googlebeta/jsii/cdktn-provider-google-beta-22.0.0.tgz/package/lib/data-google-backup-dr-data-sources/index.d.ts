/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleBackupDrDataSourcesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_sources#backup_vault_id DataGoogleBackupDrDataSources#backup_vault_id}
    */
    readonly backupVaultId: string;
    /**
    * The filter to apply to list results.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_sources#filter DataGoogleBackupDrDataSources#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_sources#id DataGoogleBackupDrDataSources#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_sources#location DataGoogleBackupDrDataSources#location}
    */
    readonly location: string;
    /**
    * The order to sort results by.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_sources#order_by DataGoogleBackupDrDataSources#order_by}
    */
    readonly orderBy?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_sources#project DataGoogleBackupDrDataSources#project}
    */
    readonly project?: string;
}
export interface DataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoBackupApplianceBackupConfig {
}
export declare function dataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoBackupApplianceBackupConfigToTerraform(struct?: DataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoBackupApplianceBackupConfig): any;
export declare function dataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoBackupApplianceBackupConfigToHclTerraform(struct?: DataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoBackupApplianceBackupConfig): any;
export declare class DataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoBackupApplianceBackupConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoBackupApplianceBackupConfig | undefined;
    set internalValue(value: DataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoBackupApplianceBackupConfig | undefined);
    get applicationName(): string;
    get backupApplianceId(): string;
    get backupApplianceName(): string;
    get hostName(): string;
    get slaId(): string;
    get slpName(): string;
    get sltName(): string;
}
export declare class DataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoBackupApplianceBackupConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoBackupApplianceBackupConfigOutputReference;
}
export interface DataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoGcpBackupConfig {
}
export declare function dataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoGcpBackupConfigToTerraform(struct?: DataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoGcpBackupConfig): any;
export declare function dataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoGcpBackupConfigToHclTerraform(struct?: DataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoGcpBackupConfig): any;
export declare class DataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoGcpBackupConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoGcpBackupConfig | undefined;
    set internalValue(value: DataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoGcpBackupConfig | undefined);
    get backupPlan(): string;
    get backupPlanAssociation(): string;
    get backupPlanDescription(): string;
    get backupPlanRules(): string[];
}
export declare class DataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoGcpBackupConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoGcpBackupConfigOutputReference;
}
export interface DataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfo {
}
export declare function dataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoToTerraform(struct?: DataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfo): any;
export declare function dataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoToHclTerraform(struct?: DataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfo): any;
export declare class DataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfo | undefined;
    set internalValue(value: DataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfo | undefined);
    private _backupApplianceBackupConfig;
    get backupApplianceBackupConfig(): DataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoBackupApplianceBackupConfigList;
    private _gcpBackupConfig;
    get gcpBackupConfig(): DataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoGcpBackupConfigList;
    private _lastBackupError;
    get lastBackupError(): cdktn.StringMap;
    get lastBackupState(): string;
    get lastSuccessfulBackupConsistencyTime(): string;
}
export declare class DataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoOutputReference;
}
export interface DataGoogleBackupDrDataSourcesDataSourcesDataSourceBackupApplianceApplication {
}
export declare function dataGoogleBackupDrDataSourcesDataSourcesDataSourceBackupApplianceApplicationToTerraform(struct?: DataGoogleBackupDrDataSourcesDataSourcesDataSourceBackupApplianceApplication): any;
export declare function dataGoogleBackupDrDataSourcesDataSourcesDataSourceBackupApplianceApplicationToHclTerraform(struct?: DataGoogleBackupDrDataSourcesDataSourcesDataSourceBackupApplianceApplication): any;
export declare class DataGoogleBackupDrDataSourcesDataSourcesDataSourceBackupApplianceApplicationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrDataSourcesDataSourcesDataSourceBackupApplianceApplication | undefined;
    set internalValue(value: DataGoogleBackupDrDataSourcesDataSourcesDataSourceBackupApplianceApplication | undefined);
    get applianceId(): string;
    get applicationId(): string;
    get applicationName(): string;
    get backupAppliance(): string;
    get hostId(): string;
    get hostname(): string;
    get type(): string;
}
export declare class DataGoogleBackupDrDataSourcesDataSourcesDataSourceBackupApplianceApplicationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrDataSourcesDataSourcesDataSourceBackupApplianceApplicationOutputReference;
}
export interface DataGoogleBackupDrDataSourcesDataSourcesDataSourceGcpResourceComputeInstanceDataSourceProperties {
}
export declare function dataGoogleBackupDrDataSourcesDataSourcesDataSourceGcpResourceComputeInstanceDataSourcePropertiesToTerraform(struct?: DataGoogleBackupDrDataSourcesDataSourcesDataSourceGcpResourceComputeInstanceDataSourceProperties): any;
export declare function dataGoogleBackupDrDataSourcesDataSourcesDataSourceGcpResourceComputeInstanceDataSourcePropertiesToHclTerraform(struct?: DataGoogleBackupDrDataSourcesDataSourcesDataSourceGcpResourceComputeInstanceDataSourceProperties): any;
export declare class DataGoogleBackupDrDataSourcesDataSourcesDataSourceGcpResourceComputeInstanceDataSourcePropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrDataSourcesDataSourcesDataSourceGcpResourceComputeInstanceDataSourceProperties | undefined;
    set internalValue(value: DataGoogleBackupDrDataSourcesDataSourcesDataSourceGcpResourceComputeInstanceDataSourceProperties | undefined);
    get description(): string;
    get machineType(): string;
    get name(): string;
    get totalDiskCount(): string;
    get totalDiskSizeGb(): string;
}
export declare class DataGoogleBackupDrDataSourcesDataSourcesDataSourceGcpResourceComputeInstanceDataSourcePropertiesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrDataSourcesDataSourcesDataSourceGcpResourceComputeInstanceDataSourcePropertiesOutputReference;
}
export interface DataGoogleBackupDrDataSourcesDataSourcesDataSourceGcpResource {
}
export declare function dataGoogleBackupDrDataSourcesDataSourcesDataSourceGcpResourceToTerraform(struct?: DataGoogleBackupDrDataSourcesDataSourcesDataSourceGcpResource): any;
export declare function dataGoogleBackupDrDataSourcesDataSourcesDataSourceGcpResourceToHclTerraform(struct?: DataGoogleBackupDrDataSourcesDataSourcesDataSourceGcpResource): any;
export declare class DataGoogleBackupDrDataSourcesDataSourcesDataSourceGcpResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrDataSourcesDataSourcesDataSourceGcpResource | undefined;
    set internalValue(value: DataGoogleBackupDrDataSourcesDataSourcesDataSourceGcpResource | undefined);
    private _computeInstanceDataSourceProperties;
    get computeInstanceDataSourceProperties(): DataGoogleBackupDrDataSourcesDataSourcesDataSourceGcpResourceComputeInstanceDataSourcePropertiesList;
    get gcpResourcename(): string;
    get location(): string;
    get type(): string;
}
export declare class DataGoogleBackupDrDataSourcesDataSourcesDataSourceGcpResourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrDataSourcesDataSourcesDataSourceGcpResourceOutputReference;
}
export interface DataGoogleBackupDrDataSourcesDataSources {
}
export declare function dataGoogleBackupDrDataSourcesDataSourcesToTerraform(struct?: DataGoogleBackupDrDataSourcesDataSources): any;
export declare function dataGoogleBackupDrDataSourcesDataSourcesToHclTerraform(struct?: DataGoogleBackupDrDataSourcesDataSources): any;
export declare class DataGoogleBackupDrDataSourcesDataSourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrDataSourcesDataSources | undefined;
    set internalValue(value: DataGoogleBackupDrDataSourcesDataSources | undefined);
    get backupBlockedByVaultAccessRestriction(): cdktn.IResolvable;
    private _backupConfigInfo;
    get backupConfigInfo(): DataGoogleBackupDrDataSourcesDataSourcesBackupConfigInfoList;
    get backupCount(): string;
    get configState(): string;
    get createTime(): string;
    private _dataSourceBackupApplianceApplication;
    get dataSourceBackupApplianceApplication(): DataGoogleBackupDrDataSourcesDataSourcesDataSourceBackupApplianceApplicationList;
    private _dataSourceGcpResource;
    get dataSourceGcpResource(): DataGoogleBackupDrDataSourcesDataSourcesDataSourceGcpResourceList;
    get etag(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    get name(): string;
    get state(): string;
    get totalStoredBytes(): string;
    get updateTime(): string;
}
export declare class DataGoogleBackupDrDataSourcesDataSourcesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrDataSourcesDataSourcesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_sources google_backup_dr_data_sources}
*/
export declare class DataGoogleBackupDrDataSources extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_backup_dr_data_sources";
    /**
    * Generates CDKTN code for importing a DataGoogleBackupDrDataSources resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleBackupDrDataSources to import
    * @param importFromId The id of the existing DataGoogleBackupDrDataSources that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_sources#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleBackupDrDataSources to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_sources google_backup_dr_data_sources} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleBackupDrDataSourcesConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleBackupDrDataSourcesConfig);
    private _backupVaultId?;
    get backupVaultId(): string;
    set backupVaultId(value: string);
    get backupVaultIdInput(): string | undefined;
    private _dataSources;
    get dataSources(): DataGoogleBackupDrDataSourcesDataSourcesList;
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _orderBy?;
    get orderBy(): string;
    set orderBy(value: string);
    resetOrderBy(): void;
    get orderByInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
