/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleArtifactRegistryMavenArtifactsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_artifact_registry_maven_artifacts#id DataGoogleArtifactRegistryMavenArtifacts#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_artifact_registry_maven_artifacts#location DataGoogleArtifactRegistryMavenArtifacts#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_artifact_registry_maven_artifacts#project DataGoogleArtifactRegistryMavenArtifacts#project}
    */
    readonly project?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_artifact_registry_maven_artifacts#repository_id DataGoogleArtifactRegistryMavenArtifacts#repository_id}
    */
    readonly repositoryId: string;
}
export interface DataGoogleArtifactRegistryMavenArtifactsMavenArtifacts {
}
export declare function dataGoogleArtifactRegistryMavenArtifactsMavenArtifactsToTerraform(struct?: DataGoogleArtifactRegistryMavenArtifactsMavenArtifacts): any;
export declare function dataGoogleArtifactRegistryMavenArtifactsMavenArtifactsToHclTerraform(struct?: DataGoogleArtifactRegistryMavenArtifactsMavenArtifacts): any;
export declare class DataGoogleArtifactRegistryMavenArtifactsMavenArtifactsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleArtifactRegistryMavenArtifactsMavenArtifacts | undefined;
    set internalValue(value: DataGoogleArtifactRegistryMavenArtifactsMavenArtifacts | undefined);
    get artifactId(): string;
    get createTime(): string;
    get groupId(): string;
    get name(): string;
    get pomUri(): string;
    get updateTime(): string;
    get version(): string;
}
export declare class DataGoogleArtifactRegistryMavenArtifactsMavenArtifactsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleArtifactRegistryMavenArtifactsMavenArtifactsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_artifact_registry_maven_artifacts google_artifact_registry_maven_artifacts}
*/
export declare class DataGoogleArtifactRegistryMavenArtifacts extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_artifact_registry_maven_artifacts";
    /**
    * Generates CDKTN code for importing a DataGoogleArtifactRegistryMavenArtifacts resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleArtifactRegistryMavenArtifacts to import
    * @param importFromId The id of the existing DataGoogleArtifactRegistryMavenArtifacts that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_artifact_registry_maven_artifacts#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleArtifactRegistryMavenArtifacts to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_artifact_registry_maven_artifacts google_artifact_registry_maven_artifacts} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleArtifactRegistryMavenArtifactsConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleArtifactRegistryMavenArtifactsConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _mavenArtifacts;
    get mavenArtifacts(): DataGoogleArtifactRegistryMavenArtifactsMavenArtifactsList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _repositoryId?;
    get repositoryId(): string;
    set repositoryId(value: string);
    get repositoryIdInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
