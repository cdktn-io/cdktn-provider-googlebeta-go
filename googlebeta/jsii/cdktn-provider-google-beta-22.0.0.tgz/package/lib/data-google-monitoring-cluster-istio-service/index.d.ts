/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleMonitoringClusterIstioServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the Kubernetes cluster in which this Istio service is defined.
    *                         Corresponds to the clusterName resource label in k8s_cluster resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_monitoring_cluster_istio_service#cluster_name DataGoogleMonitoringClusterIstioService#cluster_name}
    */
    readonly clusterName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_monitoring_cluster_istio_service#id DataGoogleMonitoringClusterIstioService#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the Kubernetes cluster in which this Istio service is defined.
    *                         Corresponds to the location resource label in k8s_cluster resources.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_monitoring_cluster_istio_service#location DataGoogleMonitoringClusterIstioService#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_monitoring_cluster_istio_service#project DataGoogleMonitoringClusterIstioService#project}
    */
    readonly project?: string;
    /**
    * The name of the Istio service underlying this service.
    *                         Corresponds to the destination_service_name metric label in Istio metrics.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_monitoring_cluster_istio_service#service_name DataGoogleMonitoringClusterIstioService#service_name}
    */
    readonly serviceName: string;
    /**
    * The namespace of the Istio service underlying this service.
    *                         Corresponds to the destination_service_namespace metric label in Istio metrics.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_monitoring_cluster_istio_service#service_namespace DataGoogleMonitoringClusterIstioService#service_namespace}
    */
    readonly serviceNamespace: string;
}
export interface DataGoogleMonitoringClusterIstioServiceTelemetry {
}
export declare function dataGoogleMonitoringClusterIstioServiceTelemetryToTerraform(struct?: DataGoogleMonitoringClusterIstioServiceTelemetry): any;
export declare function dataGoogleMonitoringClusterIstioServiceTelemetryToHclTerraform(struct?: DataGoogleMonitoringClusterIstioServiceTelemetry): any;
export declare class DataGoogleMonitoringClusterIstioServiceTelemetryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMonitoringClusterIstioServiceTelemetry | undefined;
    set internalValue(value: DataGoogleMonitoringClusterIstioServiceTelemetry | undefined);
    get resourceName(): string;
}
export declare class DataGoogleMonitoringClusterIstioServiceTelemetryList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMonitoringClusterIstioServiceTelemetryOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_monitoring_cluster_istio_service google_monitoring_cluster_istio_service}
*/
export declare class DataGoogleMonitoringClusterIstioService extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_monitoring_cluster_istio_service";
    /**
    * Generates CDKTN code for importing a DataGoogleMonitoringClusterIstioService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleMonitoringClusterIstioService to import
    * @param importFromId The id of the existing DataGoogleMonitoringClusterIstioService that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_monitoring_cluster_istio_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleMonitoringClusterIstioService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_monitoring_cluster_istio_service google_monitoring_cluster_istio_service} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleMonitoringClusterIstioServiceConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleMonitoringClusterIstioServiceConfig);
    private _clusterName?;
    get clusterName(): string;
    set clusterName(value: string);
    get clusterNameInput(): string | undefined;
    get deletionPolicy(): string;
    get displayName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get serviceId(): string;
    private _serviceName?;
    get serviceName(): string;
    set serviceName(value: string);
    get serviceNameInput(): string | undefined;
    private _serviceNamespace?;
    get serviceNamespace(): string;
    set serviceNamespace(value: string);
    get serviceNamespaceInput(): string | undefined;
    private _telemetry;
    get telemetry(): DataGoogleMonitoringClusterIstioServiceTelemetryList;
    private _userLabels;
    get userLabels(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
