/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleVmwareengineClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_vmwareengine_cluster#id DataGoogleVmwareengineCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the Cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_vmwareengine_cluster#name DataGoogleVmwareengineCluster#name}
    */
    readonly name: string;
    /**
    * The resource name of the private cloud to create a new cluster in.
    * Resource names are schemeless URIs that follow the conventions in https://cloud.google.com/apis/design/resource_names.
    * For example: projects/my-project/locations/us-west1-a/privateClouds/my-cloud
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_vmwareengine_cluster#parent DataGoogleVmwareengineCluster#parent}
    */
    readonly parent: string;
}
export interface DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesConsumedMemoryThresholds {
}
export declare function dataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesConsumedMemoryThresholdsToTerraform(struct?: DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesConsumedMemoryThresholds): any;
export declare function dataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesConsumedMemoryThresholdsToHclTerraform(struct?: DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesConsumedMemoryThresholds): any;
export declare class DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesConsumedMemoryThresholdsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesConsumedMemoryThresholds | undefined;
    set internalValue(value: DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesConsumedMemoryThresholds | undefined);
    get scaleIn(): number;
    get scaleOut(): number;
}
export declare class DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesConsumedMemoryThresholdsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesConsumedMemoryThresholdsOutputReference;
}
export interface DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesCpuThresholds {
}
export declare function dataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesCpuThresholdsToTerraform(struct?: DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesCpuThresholds): any;
export declare function dataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesCpuThresholdsToHclTerraform(struct?: DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesCpuThresholds): any;
export declare class DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesCpuThresholdsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesCpuThresholds | undefined;
    set internalValue(value: DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesCpuThresholds | undefined);
    get scaleIn(): number;
    get scaleOut(): number;
}
export declare class DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesCpuThresholdsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesCpuThresholdsOutputReference;
}
export interface DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesStorageThresholds {
}
export declare function dataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesStorageThresholdsToTerraform(struct?: DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesStorageThresholds): any;
export declare function dataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesStorageThresholdsToHclTerraform(struct?: DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesStorageThresholds): any;
export declare class DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesStorageThresholdsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesStorageThresholds | undefined;
    set internalValue(value: DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesStorageThresholds | undefined);
    get scaleIn(): number;
    get scaleOut(): number;
}
export declare class DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesStorageThresholdsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesStorageThresholdsOutputReference;
}
export interface DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPolicies {
}
export declare function dataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesToTerraform(struct?: DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPolicies): any;
export declare function dataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesToHclTerraform(struct?: DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPolicies): any;
export declare class DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPolicies | undefined;
    set internalValue(value: DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPolicies | undefined);
    get autoscalePolicyId(): string;
    private _consumedMemoryThresholds;
    get consumedMemoryThresholds(): DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesConsumedMemoryThresholdsList;
    private _cpuThresholds;
    get cpuThresholds(): DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesCpuThresholdsList;
    get nodeTypeId(): string;
    get scaleOutSize(): number;
    private _storageThresholds;
    get storageThresholds(): DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesStorageThresholdsList;
}
export declare class DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesOutputReference;
}
export interface DataGoogleVmwareengineClusterAutoscalingSettings {
}
export declare function dataGoogleVmwareengineClusterAutoscalingSettingsToTerraform(struct?: DataGoogleVmwareengineClusterAutoscalingSettings): any;
export declare function dataGoogleVmwareengineClusterAutoscalingSettingsToHclTerraform(struct?: DataGoogleVmwareengineClusterAutoscalingSettings): any;
export declare class DataGoogleVmwareengineClusterAutoscalingSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleVmwareengineClusterAutoscalingSettings | undefined;
    set internalValue(value: DataGoogleVmwareengineClusterAutoscalingSettings | undefined);
    private _autoscalingPolicies;
    get autoscalingPolicies(): DataGoogleVmwareengineClusterAutoscalingSettingsAutoscalingPoliciesList;
    get coolDownPeriod(): string;
    get maxClusterNodeCount(): number;
    get minClusterNodeCount(): number;
}
export declare class DataGoogleVmwareengineClusterAutoscalingSettingsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleVmwareengineClusterAutoscalingSettingsOutputReference;
}
export interface DataGoogleVmwareengineClusterDatastoreMountConfigDatastoreNetwork {
}
export declare function dataGoogleVmwareengineClusterDatastoreMountConfigDatastoreNetworkToTerraform(struct?: DataGoogleVmwareengineClusterDatastoreMountConfigDatastoreNetwork): any;
export declare function dataGoogleVmwareengineClusterDatastoreMountConfigDatastoreNetworkToHclTerraform(struct?: DataGoogleVmwareengineClusterDatastoreMountConfigDatastoreNetwork): any;
export declare class DataGoogleVmwareengineClusterDatastoreMountConfigDatastoreNetworkOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleVmwareengineClusterDatastoreMountConfigDatastoreNetwork | undefined;
    set internalValue(value: DataGoogleVmwareengineClusterDatastoreMountConfigDatastoreNetwork | undefined);
    get connectionCount(): number;
    get mtu(): number;
    get networkPeering(): string;
    get subnet(): string;
}
export declare class DataGoogleVmwareengineClusterDatastoreMountConfigDatastoreNetworkList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleVmwareengineClusterDatastoreMountConfigDatastoreNetworkOutputReference;
}
export interface DataGoogleVmwareengineClusterDatastoreMountConfig {
}
export declare function dataGoogleVmwareengineClusterDatastoreMountConfigToTerraform(struct?: DataGoogleVmwareengineClusterDatastoreMountConfig): any;
export declare function dataGoogleVmwareengineClusterDatastoreMountConfigToHclTerraform(struct?: DataGoogleVmwareengineClusterDatastoreMountConfig): any;
export declare class DataGoogleVmwareengineClusterDatastoreMountConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleVmwareengineClusterDatastoreMountConfig | undefined;
    set internalValue(value: DataGoogleVmwareengineClusterDatastoreMountConfig | undefined);
    get accessMode(): string;
    get datastore(): string;
    private _datastoreNetwork;
    get datastoreNetwork(): DataGoogleVmwareengineClusterDatastoreMountConfigDatastoreNetworkList;
    get fileShare(): string;
    get ignoreColocation(): cdktn.IResolvable;
    get nfsVersion(): string;
    get servers(): string[];
}
export declare class DataGoogleVmwareengineClusterDatastoreMountConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleVmwareengineClusterDatastoreMountConfigOutputReference;
}
export interface DataGoogleVmwareengineClusterNodeTypeConfigs {
}
export declare function dataGoogleVmwareengineClusterNodeTypeConfigsToTerraform(struct?: DataGoogleVmwareengineClusterNodeTypeConfigs): any;
export declare function dataGoogleVmwareengineClusterNodeTypeConfigsToHclTerraform(struct?: DataGoogleVmwareengineClusterNodeTypeConfigs): any;
export declare class DataGoogleVmwareengineClusterNodeTypeConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleVmwareengineClusterNodeTypeConfigs | undefined;
    set internalValue(value: DataGoogleVmwareengineClusterNodeTypeConfigs | undefined);
    get customCoreCount(): number;
    get nodeCount(): number;
    get nodeTypeId(): string;
}
export declare class DataGoogleVmwareengineClusterNodeTypeConfigsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleVmwareengineClusterNodeTypeConfigsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_vmwareengine_cluster google_vmwareengine_cluster}
*/
export declare class DataGoogleVmwareengineCluster extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_vmwareengine_cluster";
    /**
    * Generates CDKTN code for importing a DataGoogleVmwareengineCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleVmwareengineCluster to import
    * @param importFromId The id of the existing DataGoogleVmwareengineCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_vmwareengine_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleVmwareengineCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_vmwareengine_cluster google_vmwareengine_cluster} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleVmwareengineClusterConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleVmwareengineClusterConfig);
    private _autoscalingSettings;
    get autoscalingSettings(): DataGoogleVmwareengineClusterAutoscalingSettingsList;
    get createTime(): string;
    private _datastoreMountConfig;
    get datastoreMountConfig(): DataGoogleVmwareengineClusterDatastoreMountConfigList;
    get deletionPolicy(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get management(): cdktn.IResolvable;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nodeTypeConfigs;
    get nodeTypeConfigs(): DataGoogleVmwareengineClusterNodeTypeConfigsList;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    get state(): string;
    get uid(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
