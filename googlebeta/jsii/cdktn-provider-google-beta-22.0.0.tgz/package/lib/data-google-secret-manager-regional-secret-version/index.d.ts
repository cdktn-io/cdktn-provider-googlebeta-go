/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleSecretManagerRegionalSecretVersionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_secret_manager_regional_secret_version#id DataGoogleSecretManagerRegionalSecretVersion#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_secret_manager_regional_secret_version#is_secret_data_base64 DataGoogleSecretManagerRegionalSecretVersion#is_secret_data_base64}
    */
    readonly isSecretDataBase64?: boolean | cdktn.IResolvable;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_secret_manager_regional_secret_version#location DataGoogleSecretManagerRegionalSecretVersion#location}
    */
    readonly location?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_secret_manager_regional_secret_version#project DataGoogleSecretManagerRegionalSecretVersion#project}
    */
    readonly project?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_secret_manager_regional_secret_version#secret DataGoogleSecretManagerRegionalSecretVersion#secret}
    */
    readonly secret: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_secret_manager_regional_secret_version#version DataGoogleSecretManagerRegionalSecretVersion#version}
    */
    readonly version?: string;
}
export interface DataGoogleSecretManagerRegionalSecretVersionCustomerManagedEncryption {
}
export declare function dataGoogleSecretManagerRegionalSecretVersionCustomerManagedEncryptionToTerraform(struct?: DataGoogleSecretManagerRegionalSecretVersionCustomerManagedEncryption): any;
export declare function dataGoogleSecretManagerRegionalSecretVersionCustomerManagedEncryptionToHclTerraform(struct?: DataGoogleSecretManagerRegionalSecretVersionCustomerManagedEncryption): any;
export declare class DataGoogleSecretManagerRegionalSecretVersionCustomerManagedEncryptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleSecretManagerRegionalSecretVersionCustomerManagedEncryption | undefined;
    set internalValue(value: DataGoogleSecretManagerRegionalSecretVersionCustomerManagedEncryption | undefined);
    get kmsKeyVersionName(): string;
}
export declare class DataGoogleSecretManagerRegionalSecretVersionCustomerManagedEncryptionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleSecretManagerRegionalSecretVersionCustomerManagedEncryptionOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_secret_manager_regional_secret_version google_secret_manager_regional_secret_version}
*/
export declare class DataGoogleSecretManagerRegionalSecretVersion extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_secret_manager_regional_secret_version";
    /**
    * Generates CDKTN code for importing a DataGoogleSecretManagerRegionalSecretVersion resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleSecretManagerRegionalSecretVersion to import
    * @param importFromId The id of the existing DataGoogleSecretManagerRegionalSecretVersion that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_secret_manager_regional_secret_version#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleSecretManagerRegionalSecretVersion to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_secret_manager_regional_secret_version google_secret_manager_regional_secret_version} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleSecretManagerRegionalSecretVersionConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleSecretManagerRegionalSecretVersionConfig);
    get createTime(): string;
    private _customerManagedEncryption;
    get customerManagedEncryption(): DataGoogleSecretManagerRegionalSecretVersionCustomerManagedEncryptionList;
    get destroyTime(): string;
    get enabled(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _isSecretDataBase64?;
    get isSecretDataBase64(): boolean | cdktn.IResolvable;
    set isSecretDataBase64(value: boolean | cdktn.IResolvable);
    resetIsSecretDataBase64(): void;
    get isSecretDataBase64Input(): boolean | cdktn.IResolvable | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _secret?;
    get secret(): string;
    set secret(value: string);
    get secretInput(): string | undefined;
    get secretData(): string;
    private _version?;
    get version(): string;
    set version(value: string);
    resetVersion(): void;
    get versionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
