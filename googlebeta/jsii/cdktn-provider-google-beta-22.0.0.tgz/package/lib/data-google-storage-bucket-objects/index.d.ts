/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleStorageBucketObjectsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_bucket_objects#bucket DataGoogleStorageBucketObjects#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_bucket_objects#id DataGoogleStorageBucketObjects#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_bucket_objects#match_glob DataGoogleStorageBucketObjects#match_glob}
    */
    readonly matchGlob?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_bucket_objects#prefix DataGoogleStorageBucketObjects#prefix}
    */
    readonly prefix?: string;
}
export interface DataGoogleStorageBucketObjectsBucketObjects {
}
export declare function dataGoogleStorageBucketObjectsBucketObjectsToTerraform(struct?: DataGoogleStorageBucketObjectsBucketObjects): any;
export declare function dataGoogleStorageBucketObjectsBucketObjectsToHclTerraform(struct?: DataGoogleStorageBucketObjectsBucketObjects): any;
export declare class DataGoogleStorageBucketObjectsBucketObjectsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageBucketObjectsBucketObjects | undefined;
    set internalValue(value: DataGoogleStorageBucketObjectsBucketObjects | undefined);
    get contentType(): string;
    get mediaLink(): string;
    get name(): string;
    get selfLink(): string;
    get storageClass(): string;
    get updated(): string;
}
export declare class DataGoogleStorageBucketObjectsBucketObjectsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageBucketObjectsBucketObjectsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_bucket_objects google_storage_bucket_objects}
*/
export declare class DataGoogleStorageBucketObjects extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_storage_bucket_objects";
    /**
    * Generates CDKTN code for importing a DataGoogleStorageBucketObjects resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleStorageBucketObjects to import
    * @param importFromId The id of the existing DataGoogleStorageBucketObjects that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_bucket_objects#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleStorageBucketObjects to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_bucket_objects google_storage_bucket_objects} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleStorageBucketObjectsConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleStorageBucketObjectsConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _bucketObjects;
    get bucketObjects(): DataGoogleStorageBucketObjectsBucketObjectsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _matchGlob?;
    get matchGlob(): string;
    set matchGlob(value: string);
    resetMatchGlob(): void;
    get matchGlobInput(): string | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    resetPrefix(): void;
    get prefixInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
