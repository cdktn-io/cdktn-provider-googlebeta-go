/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleNetworkManagementConnectivityTestsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Lists the ConnectivityTests that match the filter expression. A filter expression filters the resources listed in the response.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_network_management_connectivity_tests#filter DataGoogleNetworkManagementConnectivityTests#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_network_management_connectivity_tests#id DataGoogleNetworkManagementConnectivityTests#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_network_management_connectivity_tests#project DataGoogleNetworkManagementConnectivityTests#project}
    */
    readonly project?: string;
}
export interface DataGoogleNetworkManagementConnectivityTestsConnectivityTestsDestination {
}
export declare function dataGoogleNetworkManagementConnectivityTestsConnectivityTestsDestinationToTerraform(struct?: DataGoogleNetworkManagementConnectivityTestsConnectivityTestsDestination): any;
export declare function dataGoogleNetworkManagementConnectivityTestsConnectivityTestsDestinationToHclTerraform(struct?: DataGoogleNetworkManagementConnectivityTestsConnectivityTestsDestination): any;
export declare class DataGoogleNetworkManagementConnectivityTestsConnectivityTestsDestinationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleNetworkManagementConnectivityTestsConnectivityTestsDestination | undefined;
    set internalValue(value: DataGoogleNetworkManagementConnectivityTestsConnectivityTestsDestination | undefined);
    get cloudSqlInstance(): string;
    get forwardingRule(): string;
    get fqdn(): string;
    get gkeMasterCluster(): string;
    get gkePod(): string;
    get instance(): string;
    get ipAddress(): string;
    get network(): string;
    get networkType(): string;
    get port(): number;
    get projectId(): string;
    get redisCluster(): string;
    get redisInstance(): string;
}
export declare class DataGoogleNetworkManagementConnectivityTestsConnectivityTestsDestinationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleNetworkManagementConnectivityTestsConnectivityTestsDestinationOutputReference;
}
export interface DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceAppEngineVersion {
}
export declare function dataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceAppEngineVersionToTerraform(struct?: DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceAppEngineVersion): any;
export declare function dataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceAppEngineVersionToHclTerraform(struct?: DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceAppEngineVersion): any;
export declare class DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceAppEngineVersionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceAppEngineVersion | undefined;
    set internalValue(value: DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceAppEngineVersion | undefined);
    get uri(): string;
}
export declare class DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceAppEngineVersionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceAppEngineVersionOutputReference;
}
export interface DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceCloudFunction {
}
export declare function dataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceCloudFunctionToTerraform(struct?: DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceCloudFunction): any;
export declare function dataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceCloudFunctionToHclTerraform(struct?: DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceCloudFunction): any;
export declare class DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceCloudFunctionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceCloudFunction | undefined;
    set internalValue(value: DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceCloudFunction | undefined);
    get uri(): string;
}
export declare class DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceCloudFunctionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceCloudFunctionOutputReference;
}
export interface DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceCloudRunRevision {
}
export declare function dataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceCloudRunRevisionToTerraform(struct?: DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceCloudRunRevision): any;
export declare function dataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceCloudRunRevisionToHclTerraform(struct?: DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceCloudRunRevision): any;
export declare class DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceCloudRunRevisionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceCloudRunRevision | undefined;
    set internalValue(value: DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceCloudRunRevision | undefined);
    get uri(): string;
}
export declare class DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceCloudRunRevisionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceCloudRunRevisionOutputReference;
}
export interface DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSource {
}
export declare function dataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceToTerraform(struct?: DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSource): any;
export declare function dataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceToHclTerraform(struct?: DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSource): any;
export declare class DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSource | undefined;
    set internalValue(value: DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSource | undefined);
    private _appEngineVersion;
    get appEngineVersion(): DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceAppEngineVersionList;
    private _cloudFunction;
    get cloudFunction(): DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceCloudFunctionList;
    private _cloudRunRevision;
    get cloudRunRevision(): DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceCloudRunRevisionList;
    get cloudSqlInstance(): string;
    get gkeMasterCluster(): string;
    get instance(): string;
    get ipAddress(): string;
    get network(): string;
    get networkType(): string;
    get port(): number;
    get projectId(): string;
}
export declare class DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceOutputReference;
}
export interface DataGoogleNetworkManagementConnectivityTestsConnectivityTests {
}
export declare function dataGoogleNetworkManagementConnectivityTestsConnectivityTestsToTerraform(struct?: DataGoogleNetworkManagementConnectivityTestsConnectivityTests): any;
export declare function dataGoogleNetworkManagementConnectivityTestsConnectivityTestsToHclTerraform(struct?: DataGoogleNetworkManagementConnectivityTestsConnectivityTests): any;
export declare class DataGoogleNetworkManagementConnectivityTestsConnectivityTestsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleNetworkManagementConnectivityTestsConnectivityTests | undefined;
    set internalValue(value: DataGoogleNetworkManagementConnectivityTestsConnectivityTests | undefined);
    get bypassFirewallChecks(): cdktn.IResolvable;
    get deletionPolicy(): string;
    get description(): string;
    private _destination;
    get destination(): DataGoogleNetworkManagementConnectivityTestsConnectivityTestsDestinationList;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _labels;
    get labels(): cdktn.StringMap;
    get name(): string;
    get project(): string;
    get protocol(): string;
    get relatedProjects(): string[];
    get roundTrip(): cdktn.IResolvable;
    private _source;
    get source(): DataGoogleNetworkManagementConnectivityTestsConnectivityTestsSourceList;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
}
export declare class DataGoogleNetworkManagementConnectivityTestsConnectivityTestsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleNetworkManagementConnectivityTestsConnectivityTestsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_network_management_connectivity_tests google_network_management_connectivity_tests}
*/
export declare class DataGoogleNetworkManagementConnectivityTests extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_network_management_connectivity_tests";
    /**
    * Generates CDKTN code for importing a DataGoogleNetworkManagementConnectivityTests resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleNetworkManagementConnectivityTests to import
    * @param importFromId The id of the existing DataGoogleNetworkManagementConnectivityTests that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_network_management_connectivity_tests#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleNetworkManagementConnectivityTests to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_network_management_connectivity_tests google_network_management_connectivity_tests} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleNetworkManagementConnectivityTestsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGoogleNetworkManagementConnectivityTestsConfig);
    private _connectivityTests;
    get connectivityTests(): DataGoogleNetworkManagementConnectivityTestsConnectivityTestsList;
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
