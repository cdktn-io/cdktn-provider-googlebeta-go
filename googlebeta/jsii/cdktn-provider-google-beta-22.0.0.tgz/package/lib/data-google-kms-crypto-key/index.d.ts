/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleKmsCryptoKeyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_kms_crypto_key#id DataGoogleKmsCryptoKey#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The KeyRing that this key belongs to.
    * Format: ''projects/{{project}}/locations/{{location}}/keyRings/{{keyRing}}''.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_kms_crypto_key#key_ring DataGoogleKmsCryptoKey#key_ring}
    */
    readonly keyRing: string;
    /**
    * The resource name for the CryptoKey.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_kms_crypto_key#name DataGoogleKmsCryptoKey#name}
    */
    readonly name: string;
}
export interface DataGoogleKmsCryptoKeyKeyAccessJustificationsPolicy {
}
export declare function dataGoogleKmsCryptoKeyKeyAccessJustificationsPolicyToTerraform(struct?: DataGoogleKmsCryptoKeyKeyAccessJustificationsPolicy): any;
export declare function dataGoogleKmsCryptoKeyKeyAccessJustificationsPolicyToHclTerraform(struct?: DataGoogleKmsCryptoKeyKeyAccessJustificationsPolicy): any;
export declare class DataGoogleKmsCryptoKeyKeyAccessJustificationsPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleKmsCryptoKeyKeyAccessJustificationsPolicy | undefined;
    set internalValue(value: DataGoogleKmsCryptoKeyKeyAccessJustificationsPolicy | undefined);
    get allowedAccessReasons(): string[];
}
export declare class DataGoogleKmsCryptoKeyKeyAccessJustificationsPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleKmsCryptoKeyKeyAccessJustificationsPolicyOutputReference;
}
export interface DataGoogleKmsCryptoKeyPrimary {
}
export declare function dataGoogleKmsCryptoKeyPrimaryToTerraform(struct?: DataGoogleKmsCryptoKeyPrimary): any;
export declare function dataGoogleKmsCryptoKeyPrimaryToHclTerraform(struct?: DataGoogleKmsCryptoKeyPrimary): any;
export declare class DataGoogleKmsCryptoKeyPrimaryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleKmsCryptoKeyPrimary | undefined;
    set internalValue(value: DataGoogleKmsCryptoKeyPrimary | undefined);
    get name(): string;
    get state(): string;
}
export declare class DataGoogleKmsCryptoKeyPrimaryList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleKmsCryptoKeyPrimaryOutputReference;
}
export interface DataGoogleKmsCryptoKeyVersionTemplate {
}
export declare function dataGoogleKmsCryptoKeyVersionTemplateToTerraform(struct?: DataGoogleKmsCryptoKeyVersionTemplate): any;
export declare function dataGoogleKmsCryptoKeyVersionTemplateToHclTerraform(struct?: DataGoogleKmsCryptoKeyVersionTemplate): any;
export declare class DataGoogleKmsCryptoKeyVersionTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleKmsCryptoKeyVersionTemplate | undefined;
    set internalValue(value: DataGoogleKmsCryptoKeyVersionTemplate | undefined);
    get algorithm(): string;
    get protectionLevel(): string;
}
export declare class DataGoogleKmsCryptoKeyVersionTemplateList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleKmsCryptoKeyVersionTemplateOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_kms_crypto_key google_kms_crypto_key}
*/
export declare class DataGoogleKmsCryptoKey extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_kms_crypto_key";
    /**
    * Generates CDKTN code for importing a DataGoogleKmsCryptoKey resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleKmsCryptoKey to import
    * @param importFromId The id of the existing DataGoogleKmsCryptoKey that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_kms_crypto_key#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleKmsCryptoKey to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_kms_crypto_key google_kms_crypto_key} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleKmsCryptoKeyConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleKmsCryptoKeyConfig);
    get cryptoKeyBackend(): string;
    get deletionPolicy(): string;
    get destroyScheduledDuration(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get importOnly(): cdktn.IResolvable;
    private _keyAccessJustificationsPolicy;
    get keyAccessJustificationsPolicy(): DataGoogleKmsCryptoKeyKeyAccessJustificationsPolicyList;
    private _keyRing?;
    get keyRing(): string;
    set keyRing(value: string);
    get keyRingInput(): string | undefined;
    private _labels;
    get labels(): cdktn.StringMap;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _primary;
    get primary(): DataGoogleKmsCryptoKeyPrimaryList;
    get purpose(): string;
    get rotationPeriod(): string;
    get skipInitialVersionCreation(): cdktn.IResolvable;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _versionTemplate;
    get versionTemplate(): DataGoogleKmsCryptoKeyVersionTemplateList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
