/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGooglePubsubTopicConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_pubsub_topic#id DataGooglePubsubTopic#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the topic.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_pubsub_topic#name DataGooglePubsubTopic#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_pubsub_topic#project DataGooglePubsubTopic#project}
    */
    readonly project?: string;
}
export interface DataGooglePubsubTopicIngestionDataSourceSettingsAwsKinesis {
}
export declare function dataGooglePubsubTopicIngestionDataSourceSettingsAwsKinesisToTerraform(struct?: DataGooglePubsubTopicIngestionDataSourceSettingsAwsKinesis): any;
export declare function dataGooglePubsubTopicIngestionDataSourceSettingsAwsKinesisToHclTerraform(struct?: DataGooglePubsubTopicIngestionDataSourceSettingsAwsKinesis): any;
export declare class DataGooglePubsubTopicIngestionDataSourceSettingsAwsKinesisOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubTopicIngestionDataSourceSettingsAwsKinesis | undefined;
    set internalValue(value: DataGooglePubsubTopicIngestionDataSourceSettingsAwsKinesis | undefined);
    get awsRoleArn(): string;
    get consumerArn(): string;
    get gcpServiceAccount(): string;
    get streamArn(): string;
}
export declare class DataGooglePubsubTopicIngestionDataSourceSettingsAwsKinesisList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubTopicIngestionDataSourceSettingsAwsKinesisOutputReference;
}
export interface DataGooglePubsubTopicIngestionDataSourceSettingsAwsMsk {
}
export declare function dataGooglePubsubTopicIngestionDataSourceSettingsAwsMskToTerraform(struct?: DataGooglePubsubTopicIngestionDataSourceSettingsAwsMsk): any;
export declare function dataGooglePubsubTopicIngestionDataSourceSettingsAwsMskToHclTerraform(struct?: DataGooglePubsubTopicIngestionDataSourceSettingsAwsMsk): any;
export declare class DataGooglePubsubTopicIngestionDataSourceSettingsAwsMskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubTopicIngestionDataSourceSettingsAwsMsk | undefined;
    set internalValue(value: DataGooglePubsubTopicIngestionDataSourceSettingsAwsMsk | undefined);
    get awsRoleArn(): string;
    get clusterArn(): string;
    get gcpServiceAccount(): string;
    get topic(): string;
}
export declare class DataGooglePubsubTopicIngestionDataSourceSettingsAwsMskList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubTopicIngestionDataSourceSettingsAwsMskOutputReference;
}
export interface DataGooglePubsubTopicIngestionDataSourceSettingsAzureEventHubs {
}
export declare function dataGooglePubsubTopicIngestionDataSourceSettingsAzureEventHubsToTerraform(struct?: DataGooglePubsubTopicIngestionDataSourceSettingsAzureEventHubs): any;
export declare function dataGooglePubsubTopicIngestionDataSourceSettingsAzureEventHubsToHclTerraform(struct?: DataGooglePubsubTopicIngestionDataSourceSettingsAzureEventHubs): any;
export declare class DataGooglePubsubTopicIngestionDataSourceSettingsAzureEventHubsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubTopicIngestionDataSourceSettingsAzureEventHubs | undefined;
    set internalValue(value: DataGooglePubsubTopicIngestionDataSourceSettingsAzureEventHubs | undefined);
    get clientId(): string;
    get eventHub(): string;
    get gcpServiceAccount(): string;
    get namespace(): string;
    get resourceGroup(): string;
    get subscriptionId(): string;
    get tenantId(): string;
}
export declare class DataGooglePubsubTopicIngestionDataSourceSettingsAzureEventHubsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubTopicIngestionDataSourceSettingsAzureEventHubsOutputReference;
}
export interface DataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageAvroFormat {
}
export declare function dataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageAvroFormatToTerraform(struct?: DataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageAvroFormat): any;
export declare function dataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageAvroFormatToHclTerraform(struct?: DataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageAvroFormat): any;
export declare class DataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageAvroFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageAvroFormat | undefined;
    set internalValue(value: DataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageAvroFormat | undefined);
}
export declare class DataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageAvroFormatList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageAvroFormatOutputReference;
}
export interface DataGooglePubsubTopicIngestionDataSourceSettingsCloudStoragePubsubAvroFormat {
}
export declare function dataGooglePubsubTopicIngestionDataSourceSettingsCloudStoragePubsubAvroFormatToTerraform(struct?: DataGooglePubsubTopicIngestionDataSourceSettingsCloudStoragePubsubAvroFormat): any;
export declare function dataGooglePubsubTopicIngestionDataSourceSettingsCloudStoragePubsubAvroFormatToHclTerraform(struct?: DataGooglePubsubTopicIngestionDataSourceSettingsCloudStoragePubsubAvroFormat): any;
export declare class DataGooglePubsubTopicIngestionDataSourceSettingsCloudStoragePubsubAvroFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubTopicIngestionDataSourceSettingsCloudStoragePubsubAvroFormat | undefined;
    set internalValue(value: DataGooglePubsubTopicIngestionDataSourceSettingsCloudStoragePubsubAvroFormat | undefined);
}
export declare class DataGooglePubsubTopicIngestionDataSourceSettingsCloudStoragePubsubAvroFormatList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubTopicIngestionDataSourceSettingsCloudStoragePubsubAvroFormatOutputReference;
}
export interface DataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageTextFormat {
}
export declare function dataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageTextFormatToTerraform(struct?: DataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageTextFormat): any;
export declare function dataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageTextFormatToHclTerraform(struct?: DataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageTextFormat): any;
export declare class DataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageTextFormatOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageTextFormat | undefined;
    set internalValue(value: DataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageTextFormat | undefined);
    get delimiter(): string;
}
export declare class DataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageTextFormatList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageTextFormatOutputReference;
}
export interface DataGooglePubsubTopicIngestionDataSourceSettingsCloudStorage {
}
export declare function dataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageToTerraform(struct?: DataGooglePubsubTopicIngestionDataSourceSettingsCloudStorage): any;
export declare function dataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageToHclTerraform(struct?: DataGooglePubsubTopicIngestionDataSourceSettingsCloudStorage): any;
export declare class DataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubTopicIngestionDataSourceSettingsCloudStorage | undefined;
    set internalValue(value: DataGooglePubsubTopicIngestionDataSourceSettingsCloudStorage | undefined);
    private _avroFormat;
    get avroFormat(): DataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageAvroFormatList;
    get bucket(): string;
    get matchGlob(): string;
    get minimumObjectCreateTime(): string;
    private _pubsubAvroFormat;
    get pubsubAvroFormat(): DataGooglePubsubTopicIngestionDataSourceSettingsCloudStoragePubsubAvroFormatList;
    private _textFormat;
    get textFormat(): DataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageTextFormatList;
}
export declare class DataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageOutputReference;
}
export interface DataGooglePubsubTopicIngestionDataSourceSettingsConfluentCloud {
}
export declare function dataGooglePubsubTopicIngestionDataSourceSettingsConfluentCloudToTerraform(struct?: DataGooglePubsubTopicIngestionDataSourceSettingsConfluentCloud): any;
export declare function dataGooglePubsubTopicIngestionDataSourceSettingsConfluentCloudToHclTerraform(struct?: DataGooglePubsubTopicIngestionDataSourceSettingsConfluentCloud): any;
export declare class DataGooglePubsubTopicIngestionDataSourceSettingsConfluentCloudOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubTopicIngestionDataSourceSettingsConfluentCloud | undefined;
    set internalValue(value: DataGooglePubsubTopicIngestionDataSourceSettingsConfluentCloud | undefined);
    get bootstrapServer(): string;
    get clusterId(): string;
    get gcpServiceAccount(): string;
    get identityPoolId(): string;
    get topic(): string;
}
export declare class DataGooglePubsubTopicIngestionDataSourceSettingsConfluentCloudList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubTopicIngestionDataSourceSettingsConfluentCloudOutputReference;
}
export interface DataGooglePubsubTopicIngestionDataSourceSettingsPlatformLogsSettings {
}
export declare function dataGooglePubsubTopicIngestionDataSourceSettingsPlatformLogsSettingsToTerraform(struct?: DataGooglePubsubTopicIngestionDataSourceSettingsPlatformLogsSettings): any;
export declare function dataGooglePubsubTopicIngestionDataSourceSettingsPlatformLogsSettingsToHclTerraform(struct?: DataGooglePubsubTopicIngestionDataSourceSettingsPlatformLogsSettings): any;
export declare class DataGooglePubsubTopicIngestionDataSourceSettingsPlatformLogsSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubTopicIngestionDataSourceSettingsPlatformLogsSettings | undefined;
    set internalValue(value: DataGooglePubsubTopicIngestionDataSourceSettingsPlatformLogsSettings | undefined);
    get severity(): string;
}
export declare class DataGooglePubsubTopicIngestionDataSourceSettingsPlatformLogsSettingsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubTopicIngestionDataSourceSettingsPlatformLogsSettingsOutputReference;
}
export interface DataGooglePubsubTopicIngestionDataSourceSettings {
}
export declare function dataGooglePubsubTopicIngestionDataSourceSettingsToTerraform(struct?: DataGooglePubsubTopicIngestionDataSourceSettings): any;
export declare function dataGooglePubsubTopicIngestionDataSourceSettingsToHclTerraform(struct?: DataGooglePubsubTopicIngestionDataSourceSettings): any;
export declare class DataGooglePubsubTopicIngestionDataSourceSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubTopicIngestionDataSourceSettings | undefined;
    set internalValue(value: DataGooglePubsubTopicIngestionDataSourceSettings | undefined);
    private _awsKinesis;
    get awsKinesis(): DataGooglePubsubTopicIngestionDataSourceSettingsAwsKinesisList;
    private _awsMsk;
    get awsMsk(): DataGooglePubsubTopicIngestionDataSourceSettingsAwsMskList;
    private _azureEventHubs;
    get azureEventHubs(): DataGooglePubsubTopicIngestionDataSourceSettingsAzureEventHubsList;
    private _cloudStorage;
    get cloudStorage(): DataGooglePubsubTopicIngestionDataSourceSettingsCloudStorageList;
    private _confluentCloud;
    get confluentCloud(): DataGooglePubsubTopicIngestionDataSourceSettingsConfluentCloudList;
    private _platformLogsSettings;
    get platformLogsSettings(): DataGooglePubsubTopicIngestionDataSourceSettingsPlatformLogsSettingsList;
}
export declare class DataGooglePubsubTopicIngestionDataSourceSettingsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubTopicIngestionDataSourceSettingsOutputReference;
}
export interface DataGooglePubsubTopicMessageStoragePolicy {
}
export declare function dataGooglePubsubTopicMessageStoragePolicyToTerraform(struct?: DataGooglePubsubTopicMessageStoragePolicy): any;
export declare function dataGooglePubsubTopicMessageStoragePolicyToHclTerraform(struct?: DataGooglePubsubTopicMessageStoragePolicy): any;
export declare class DataGooglePubsubTopicMessageStoragePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubTopicMessageStoragePolicy | undefined;
    set internalValue(value: DataGooglePubsubTopicMessageStoragePolicy | undefined);
    get allowedPersistenceRegions(): string[];
    get enforceInTransit(): cdktn.IResolvable;
}
export declare class DataGooglePubsubTopicMessageStoragePolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubTopicMessageStoragePolicyOutputReference;
}
export interface DataGooglePubsubTopicMessageTransformsAiInferenceUnstructuredInference {
}
export declare function dataGooglePubsubTopicMessageTransformsAiInferenceUnstructuredInferenceToTerraform(struct?: DataGooglePubsubTopicMessageTransformsAiInferenceUnstructuredInference): any;
export declare function dataGooglePubsubTopicMessageTransformsAiInferenceUnstructuredInferenceToHclTerraform(struct?: DataGooglePubsubTopicMessageTransformsAiInferenceUnstructuredInference): any;
export declare class DataGooglePubsubTopicMessageTransformsAiInferenceUnstructuredInferenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubTopicMessageTransformsAiInferenceUnstructuredInference | undefined;
    set internalValue(value: DataGooglePubsubTopicMessageTransformsAiInferenceUnstructuredInference | undefined);
    private _parameters;
    get parameters(): cdktn.StringMap;
}
export declare class DataGooglePubsubTopicMessageTransformsAiInferenceUnstructuredInferenceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubTopicMessageTransformsAiInferenceUnstructuredInferenceOutputReference;
}
export interface DataGooglePubsubTopicMessageTransformsAiInference {
}
export declare function dataGooglePubsubTopicMessageTransformsAiInferenceToTerraform(struct?: DataGooglePubsubTopicMessageTransformsAiInference): any;
export declare function dataGooglePubsubTopicMessageTransformsAiInferenceToHclTerraform(struct?: DataGooglePubsubTopicMessageTransformsAiInference): any;
export declare class DataGooglePubsubTopicMessageTransformsAiInferenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubTopicMessageTransformsAiInference | undefined;
    set internalValue(value: DataGooglePubsubTopicMessageTransformsAiInference | undefined);
    get endpoint(): string;
    get serviceAccountEmail(): string;
    private _unstructuredInference;
    get unstructuredInference(): DataGooglePubsubTopicMessageTransformsAiInferenceUnstructuredInferenceList;
}
export declare class DataGooglePubsubTopicMessageTransformsAiInferenceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubTopicMessageTransformsAiInferenceOutputReference;
}
export interface DataGooglePubsubTopicMessageTransformsJavascriptUdf {
}
export declare function dataGooglePubsubTopicMessageTransformsJavascriptUdfToTerraform(struct?: DataGooglePubsubTopicMessageTransformsJavascriptUdf): any;
export declare function dataGooglePubsubTopicMessageTransformsJavascriptUdfToHclTerraform(struct?: DataGooglePubsubTopicMessageTransformsJavascriptUdf): any;
export declare class DataGooglePubsubTopicMessageTransformsJavascriptUdfOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubTopicMessageTransformsJavascriptUdf | undefined;
    set internalValue(value: DataGooglePubsubTopicMessageTransformsJavascriptUdf | undefined);
    get code(): string;
    get functionName(): string;
}
export declare class DataGooglePubsubTopicMessageTransformsJavascriptUdfList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubTopicMessageTransformsJavascriptUdfOutputReference;
}
export interface DataGooglePubsubTopicMessageTransforms {
}
export declare function dataGooglePubsubTopicMessageTransformsToTerraform(struct?: DataGooglePubsubTopicMessageTransforms): any;
export declare function dataGooglePubsubTopicMessageTransformsToHclTerraform(struct?: DataGooglePubsubTopicMessageTransforms): any;
export declare class DataGooglePubsubTopicMessageTransformsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubTopicMessageTransforms | undefined;
    set internalValue(value: DataGooglePubsubTopicMessageTransforms | undefined);
    private _aiInference;
    get aiInference(): DataGooglePubsubTopicMessageTransformsAiInferenceList;
    get disabled(): cdktn.IResolvable;
    private _javascriptUdf;
    get javascriptUdf(): DataGooglePubsubTopicMessageTransformsJavascriptUdfList;
}
export declare class DataGooglePubsubTopicMessageTransformsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubTopicMessageTransformsOutputReference;
}
export interface DataGooglePubsubTopicSchemaSettings {
}
export declare function dataGooglePubsubTopicSchemaSettingsToTerraform(struct?: DataGooglePubsubTopicSchemaSettings): any;
export declare function dataGooglePubsubTopicSchemaSettingsToHclTerraform(struct?: DataGooglePubsubTopicSchemaSettings): any;
export declare class DataGooglePubsubTopicSchemaSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubTopicSchemaSettings | undefined;
    set internalValue(value: DataGooglePubsubTopicSchemaSettings | undefined);
    get encoding(): string;
    get firstRevisionId(): string;
    get lastRevisionId(): string;
    get schema(): string;
}
export declare class DataGooglePubsubTopicSchemaSettingsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubTopicSchemaSettingsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_pubsub_topic google_pubsub_topic}
*/
export declare class DataGooglePubsubTopic extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_pubsub_topic";
    /**
    * Generates CDKTN code for importing a DataGooglePubsubTopic resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGooglePubsubTopic to import
    * @param importFromId The id of the existing DataGooglePubsubTopic that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_pubsub_topic#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGooglePubsubTopic to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_pubsub_topic google_pubsub_topic} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGooglePubsubTopicConfig
    */
    constructor(scope: Construct, id: string, config: DataGooglePubsubTopicConfig);
    get deletionPolicy(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ingestionDataSourceSettings;
    get ingestionDataSourceSettings(): DataGooglePubsubTopicIngestionDataSourceSettingsList;
    get kmsKeyName(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    get messageRetentionDuration(): string;
    private _messageStoragePolicy;
    get messageStoragePolicy(): DataGooglePubsubTopicMessageStoragePolicyList;
    private _messageTransforms;
    get messageTransforms(): DataGooglePubsubTopicMessageTransformsList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _schemaSettings;
    get schemaSettings(): DataGooglePubsubTopicSchemaSettingsList;
    private _tags;
    get tags(): cdktn.StringMap;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
