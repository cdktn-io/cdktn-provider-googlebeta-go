/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleAgentRegistryAgentConfig extends cdktn.TerraformMetaArguments {
    /**
    * The unique identifier for the Agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_agent_registry_agent#agent_id DataGoogleAgentRegistryAgent#agent_id}
    */
    readonly agentId?: string;
    /**
    * A filter string that identifies a unique Agent.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_agent_registry_agent#filter DataGoogleAgentRegistryAgent#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_agent_registry_agent#id DataGoogleAgentRegistryAgent#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_agent_registry_agent#location DataGoogleAgentRegistryAgent#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_agent_registry_agent#project DataGoogleAgentRegistryAgent#project}
    */
    readonly project?: string;
}
export interface DataGoogleAgentRegistryAgentProtocolsInterfaces {
}
export declare function dataGoogleAgentRegistryAgentProtocolsInterfacesToTerraform(struct?: DataGoogleAgentRegistryAgentProtocolsInterfaces): any;
export declare function dataGoogleAgentRegistryAgentProtocolsInterfacesToHclTerraform(struct?: DataGoogleAgentRegistryAgentProtocolsInterfaces): any;
export declare class DataGoogleAgentRegistryAgentProtocolsInterfacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAgentRegistryAgentProtocolsInterfaces | undefined;
    set internalValue(value: DataGoogleAgentRegistryAgentProtocolsInterfaces | undefined);
    get protocolBinding(): string;
    get url(): string;
}
export declare class DataGoogleAgentRegistryAgentProtocolsInterfacesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAgentRegistryAgentProtocolsInterfacesOutputReference;
}
export interface DataGoogleAgentRegistryAgentProtocols {
}
export declare function dataGoogleAgentRegistryAgentProtocolsToTerraform(struct?: DataGoogleAgentRegistryAgentProtocols): any;
export declare function dataGoogleAgentRegistryAgentProtocolsToHclTerraform(struct?: DataGoogleAgentRegistryAgentProtocols): any;
export declare class DataGoogleAgentRegistryAgentProtocolsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAgentRegistryAgentProtocols | undefined;
    set internalValue(value: DataGoogleAgentRegistryAgentProtocols | undefined);
    private _interfaces;
    get interfaces(): DataGoogleAgentRegistryAgentProtocolsInterfacesList;
    get protocolVersion(): string;
    get type(): string;
}
export declare class DataGoogleAgentRegistryAgentProtocolsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAgentRegistryAgentProtocolsOutputReference;
}
export interface DataGoogleAgentRegistryAgentSkills {
}
export declare function dataGoogleAgentRegistryAgentSkillsToTerraform(struct?: DataGoogleAgentRegistryAgentSkills): any;
export declare function dataGoogleAgentRegistryAgentSkillsToHclTerraform(struct?: DataGoogleAgentRegistryAgentSkills): any;
export declare class DataGoogleAgentRegistryAgentSkillsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAgentRegistryAgentSkills | undefined;
    set internalValue(value: DataGoogleAgentRegistryAgentSkills | undefined);
    get description(): string;
    get examples(): string[];
    get id(): string;
    get name(): string;
    get tags(): string[];
}
export declare class DataGoogleAgentRegistryAgentSkillsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAgentRegistryAgentSkillsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_agent_registry_agent google_agent_registry_agent}
*/
export declare class DataGoogleAgentRegistryAgent extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_agent_registry_agent";
    /**
    * Generates CDKTN code for importing a DataGoogleAgentRegistryAgent resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleAgentRegistryAgent to import
    * @param importFromId The id of the existing DataGoogleAgentRegistryAgent that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_agent_registry_agent#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleAgentRegistryAgent to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_agent_registry_agent google_agent_registry_agent} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleAgentRegistryAgentConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleAgentRegistryAgentConfig);
    private _agentId?;
    get agentId(): string;
    set agentId(value: string);
    resetAgentId(): void;
    get agentIdInput(): string | undefined;
    private _attributes;
    get attributes(): cdktn.StringMap;
    get createTime(): string;
    get description(): string;
    get displayName(): string;
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    get framework(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _protocols;
    get protocols(): DataGoogleAgentRegistryAgentProtocolsList;
    private _skills;
    get skills(): DataGoogleAgentRegistryAgentSkillsList;
    get updateTime(): string;
    get urn(): string;
    get version(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
