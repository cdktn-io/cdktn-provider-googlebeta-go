/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleCloudRunV2WorkerPoolConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_run_v2_worker_pool#id DataGoogleCloudRunV2WorkerPool#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the cloud run worker pool
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_run_v2_worker_pool#location DataGoogleCloudRunV2WorkerPool#location}
    */
    readonly location?: string;
    /**
    * Name of the WorkerPool.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_run_v2_worker_pool#name DataGoogleCloudRunV2WorkerPool#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_run_v2_worker_pool#project DataGoogleCloudRunV2WorkerPool#project}
    */
    readonly project?: string;
}
export interface DataGoogleCloudRunV2WorkerPoolBinaryAuthorization {
}
export declare function dataGoogleCloudRunV2WorkerPoolBinaryAuthorizationToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolBinaryAuthorization): any;
export declare function dataGoogleCloudRunV2WorkerPoolBinaryAuthorizationToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolBinaryAuthorization): any;
export declare class DataGoogleCloudRunV2WorkerPoolBinaryAuthorizationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolBinaryAuthorization | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolBinaryAuthorization | undefined);
    get breakglassJustification(): string;
    get policy(): string;
    get useDefault(): cdktn.IResolvable;
}
export declare class DataGoogleCloudRunV2WorkerPoolBinaryAuthorizationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolBinaryAuthorizationOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolConditions {
}
export declare function dataGoogleCloudRunV2WorkerPoolConditionsToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolConditions): any;
export declare function dataGoogleCloudRunV2WorkerPoolConditionsToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolConditions): any;
export declare class DataGoogleCloudRunV2WorkerPoolConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolConditions | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolConditions | undefined);
    get executionReason(): string;
    get lastTransitionTime(): string;
    get message(): string;
    get reason(): string;
    get revisionReason(): string;
    get severity(): string;
    get state(): string;
    get type(): string;
}
export declare class DataGoogleCloudRunV2WorkerPoolConditionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolConditionsOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolInstanceSplitStatuses {
}
export declare function dataGoogleCloudRunV2WorkerPoolInstanceSplitStatusesToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolInstanceSplitStatuses): any;
export declare function dataGoogleCloudRunV2WorkerPoolInstanceSplitStatusesToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolInstanceSplitStatuses): any;
export declare class DataGoogleCloudRunV2WorkerPoolInstanceSplitStatusesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolInstanceSplitStatuses | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolInstanceSplitStatuses | undefined);
    get percent(): number;
    get revision(): string;
    get type(): string;
}
export declare class DataGoogleCloudRunV2WorkerPoolInstanceSplitStatusesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolInstanceSplitStatusesOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolInstanceSplits {
}
export declare function dataGoogleCloudRunV2WorkerPoolInstanceSplitsToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolInstanceSplits): any;
export declare function dataGoogleCloudRunV2WorkerPoolInstanceSplitsToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolInstanceSplits): any;
export declare class DataGoogleCloudRunV2WorkerPoolInstanceSplitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolInstanceSplits | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolInstanceSplits | undefined);
    get percent(): number;
    get revision(): string;
    get type(): string;
}
export declare class DataGoogleCloudRunV2WorkerPoolInstanceSplitsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolInstanceSplitsOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolScaling {
}
export declare function dataGoogleCloudRunV2WorkerPoolScalingToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolScaling): any;
export declare function dataGoogleCloudRunV2WorkerPoolScalingToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolScaling): any;
export declare class DataGoogleCloudRunV2WorkerPoolScalingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolScaling | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolScaling | undefined);
    get manualInstanceCount(): number;
    get maxInstanceCount(): number;
    get minInstanceCount(): number;
    get scalingMode(): string;
}
export declare class DataGoogleCloudRunV2WorkerPoolScalingList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolScalingOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTemplateContainersEnvValueSourceSecretKeyRef {
}
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersEnvValueSourceSecretKeyRefToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersEnvValueSourceSecretKeyRef): any;
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersEnvValueSourceSecretKeyRefToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersEnvValueSourceSecretKeyRef): any;
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersEnvValueSourceSecretKeyRefOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTemplateContainersEnvValueSourceSecretKeyRef | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTemplateContainersEnvValueSourceSecretKeyRef | undefined);
    get secret(): string;
    get version(): string;
}
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersEnvValueSourceSecretKeyRefList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTemplateContainersEnvValueSourceSecretKeyRefOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTemplateContainersEnvValueSource {
}
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersEnvValueSourceToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersEnvValueSource): any;
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersEnvValueSourceToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersEnvValueSource): any;
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersEnvValueSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTemplateContainersEnvValueSource | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTemplateContainersEnvValueSource | undefined);
    private _secretKeyRef;
    get secretKeyRef(): DataGoogleCloudRunV2WorkerPoolTemplateContainersEnvValueSourceSecretKeyRefList;
}
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersEnvValueSourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTemplateContainersEnvValueSourceOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTemplateContainersEnv {
}
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersEnvToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersEnv): any;
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersEnvToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersEnv): any;
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersEnvOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTemplateContainersEnv | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTemplateContainersEnv | undefined);
    get name(): string;
    get value(): string;
    private _valueSource;
    get valueSource(): DataGoogleCloudRunV2WorkerPoolTemplateContainersEnvValueSourceList;
}
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersEnvList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTemplateContainersEnvOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeGrpc {
}
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeGrpcToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeGrpc): any;
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeGrpcToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeGrpc): any;
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeGrpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeGrpc | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeGrpc | undefined);
    get port(): number;
    get service(): string;
}
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeGrpcList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeGrpcOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetHttpHeaders {
}
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetHttpHeadersToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetHttpHeaders): any;
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetHttpHeadersToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetHttpHeaders): any;
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetHttpHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetHttpHeaders | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetHttpHeaders | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetHttpHeadersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetHttpHeadersOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGet {
}
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGet): any;
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGet): any;
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGet | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGet | undefined);
    private _httpHeaders;
    get httpHeaders(): DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetHttpHeadersList;
    get path(): string;
    get port(): number;
}
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeTcpSocket {
}
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeTcpSocketToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeTcpSocket): any;
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeTcpSocketToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeTcpSocket): any;
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeTcpSocket | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeTcpSocket | undefined);
    get port(): number;
}
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeTcpSocketList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeTcpSocketOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbe {
}
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbe): any;
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbe): any;
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbe | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbe | undefined);
    get failureThreshold(): number;
    private _grpc;
    get grpc(): DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeGrpcList;
    private _httpGet;
    get httpGet(): DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeHttpGetList;
    get initialDelaySeconds(): number;
    get periodSeconds(): number;
    private _tcpSocket;
    get tcpSocket(): DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeTcpSocketList;
    get timeoutSeconds(): number;
}
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTemplateContainersResources {
}
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersResourcesToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersResources): any;
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersResourcesToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersResources): any;
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTemplateContainersResources | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTemplateContainersResources | undefined);
    private _limits;
    get limits(): cdktn.StringMap;
}
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersResourcesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTemplateContainersResourcesOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeGrpc {
}
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeGrpcToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeGrpc): any;
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeGrpcToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeGrpc): any;
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeGrpcOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeGrpc | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeGrpc | undefined);
    get port(): number;
    get service(): string;
}
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeGrpcList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeGrpcOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetHttpHeaders {
}
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetHttpHeadersToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetHttpHeaders): any;
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetHttpHeadersToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetHttpHeaders): any;
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetHttpHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetHttpHeaders | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetHttpHeaders | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetHttpHeadersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetHttpHeadersOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGet {
}
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGet): any;
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGet): any;
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGet | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGet | undefined);
    private _httpHeaders;
    get httpHeaders(): DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetHttpHeadersList;
    get path(): string;
    get port(): number;
}
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeTcpSocket {
}
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeTcpSocketToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeTcpSocket): any;
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeTcpSocketToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeTcpSocket): any;
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeTcpSocketOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeTcpSocket | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeTcpSocket | undefined);
    get port(): number;
}
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeTcpSocketList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeTcpSocketOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbe {
}
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbe): any;
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbe): any;
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbe | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbe | undefined);
    get failureThreshold(): number;
    private _grpc;
    get grpc(): DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeGrpcList;
    private _httpGet;
    get httpGet(): DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeHttpGetList;
    get initialDelaySeconds(): number;
    get periodSeconds(): number;
    private _tcpSocket;
    get tcpSocket(): DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeTcpSocketList;
    get timeoutSeconds(): number;
}
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTemplateContainersVolumeMounts {
}
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersVolumeMountsToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersVolumeMounts): any;
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersVolumeMountsToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainersVolumeMounts): any;
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersVolumeMountsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTemplateContainersVolumeMounts | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTemplateContainersVolumeMounts | undefined);
    get mountPath(): string;
    get name(): string;
    get subPath(): string;
}
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersVolumeMountsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTemplateContainersVolumeMountsOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTemplateContainers {
}
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainers): any;
export declare function dataGoogleCloudRunV2WorkerPoolTemplateContainersToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateContainers): any;
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTemplateContainers | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTemplateContainers | undefined);
    get args(): string[];
    get command(): string[];
    get dependsOn(): string[];
    private _env;
    get env(): DataGoogleCloudRunV2WorkerPoolTemplateContainersEnvList;
    get image(): string;
    private _livenessProbe;
    get livenessProbe(): DataGoogleCloudRunV2WorkerPoolTemplateContainersLivenessProbeList;
    get name(): string;
    private _resources;
    get resources(): DataGoogleCloudRunV2WorkerPoolTemplateContainersResourcesList;
    get sandboxLauncher(): cdktn.IResolvable;
    private _startupProbe;
    get startupProbe(): DataGoogleCloudRunV2WorkerPoolTemplateContainersStartupProbeList;
    private _volumeMounts;
    get volumeMounts(): DataGoogleCloudRunV2WorkerPoolTemplateContainersVolumeMountsList;
    get workingDir(): string;
}
export declare class DataGoogleCloudRunV2WorkerPoolTemplateContainersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTemplateContainersOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTemplateNodeSelector {
}
export declare function dataGoogleCloudRunV2WorkerPoolTemplateNodeSelectorToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateNodeSelector): any;
export declare function dataGoogleCloudRunV2WorkerPoolTemplateNodeSelectorToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateNodeSelector): any;
export declare class DataGoogleCloudRunV2WorkerPoolTemplateNodeSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTemplateNodeSelector | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTemplateNodeSelector | undefined);
    get accelerator(): string;
}
export declare class DataGoogleCloudRunV2WorkerPoolTemplateNodeSelectorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTemplateNodeSelectorOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTemplateVolumesCloudSqlInstance {
}
export declare function dataGoogleCloudRunV2WorkerPoolTemplateVolumesCloudSqlInstanceToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateVolumesCloudSqlInstance): any;
export declare function dataGoogleCloudRunV2WorkerPoolTemplateVolumesCloudSqlInstanceToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateVolumesCloudSqlInstance): any;
export declare class DataGoogleCloudRunV2WorkerPoolTemplateVolumesCloudSqlInstanceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTemplateVolumesCloudSqlInstance | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTemplateVolumesCloudSqlInstance | undefined);
    get instances(): string[];
}
export declare class DataGoogleCloudRunV2WorkerPoolTemplateVolumesCloudSqlInstanceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTemplateVolumesCloudSqlInstanceOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTemplateVolumesEmptyDir {
}
export declare function dataGoogleCloudRunV2WorkerPoolTemplateVolumesEmptyDirToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateVolumesEmptyDir): any;
export declare function dataGoogleCloudRunV2WorkerPoolTemplateVolumesEmptyDirToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateVolumesEmptyDir): any;
export declare class DataGoogleCloudRunV2WorkerPoolTemplateVolumesEmptyDirOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTemplateVolumesEmptyDir | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTemplateVolumesEmptyDir | undefined);
    get medium(): string;
    get sizeLimit(): string;
}
export declare class DataGoogleCloudRunV2WorkerPoolTemplateVolumesEmptyDirList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTemplateVolumesEmptyDirOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTemplateVolumesGcs {
}
export declare function dataGoogleCloudRunV2WorkerPoolTemplateVolumesGcsToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateVolumesGcs): any;
export declare function dataGoogleCloudRunV2WorkerPoolTemplateVolumesGcsToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateVolumesGcs): any;
export declare class DataGoogleCloudRunV2WorkerPoolTemplateVolumesGcsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTemplateVolumesGcs | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTemplateVolumesGcs | undefined);
    get bucket(): string;
    get mountOptions(): string[];
    get readOnly(): cdktn.IResolvable;
}
export declare class DataGoogleCloudRunV2WorkerPoolTemplateVolumesGcsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTemplateVolumesGcsOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTemplateVolumesNfs {
}
export declare function dataGoogleCloudRunV2WorkerPoolTemplateVolumesNfsToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateVolumesNfs): any;
export declare function dataGoogleCloudRunV2WorkerPoolTemplateVolumesNfsToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateVolumesNfs): any;
export declare class DataGoogleCloudRunV2WorkerPoolTemplateVolumesNfsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTemplateVolumesNfs | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTemplateVolumesNfs | undefined);
    get path(): string;
    get readOnly(): cdktn.IResolvable;
    get server(): string;
}
export declare class DataGoogleCloudRunV2WorkerPoolTemplateVolumesNfsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTemplateVolumesNfsOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTemplateVolumesSecretItems {
}
export declare function dataGoogleCloudRunV2WorkerPoolTemplateVolumesSecretItemsToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateVolumesSecretItems): any;
export declare function dataGoogleCloudRunV2WorkerPoolTemplateVolumesSecretItemsToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateVolumesSecretItems): any;
export declare class DataGoogleCloudRunV2WorkerPoolTemplateVolumesSecretItemsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTemplateVolumesSecretItems | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTemplateVolumesSecretItems | undefined);
    get mode(): number;
    get path(): string;
    get version(): string;
}
export declare class DataGoogleCloudRunV2WorkerPoolTemplateVolumesSecretItemsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTemplateVolumesSecretItemsOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTemplateVolumesSecret {
}
export declare function dataGoogleCloudRunV2WorkerPoolTemplateVolumesSecretToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateVolumesSecret): any;
export declare function dataGoogleCloudRunV2WorkerPoolTemplateVolumesSecretToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateVolumesSecret): any;
export declare class DataGoogleCloudRunV2WorkerPoolTemplateVolumesSecretOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTemplateVolumesSecret | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTemplateVolumesSecret | undefined);
    get defaultMode(): number;
    private _items;
    get items(): DataGoogleCloudRunV2WorkerPoolTemplateVolumesSecretItemsList;
    get secret(): string;
}
export declare class DataGoogleCloudRunV2WorkerPoolTemplateVolumesSecretList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTemplateVolumesSecretOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTemplateVolumes {
}
export declare function dataGoogleCloudRunV2WorkerPoolTemplateVolumesToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateVolumes): any;
export declare function dataGoogleCloudRunV2WorkerPoolTemplateVolumesToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateVolumes): any;
export declare class DataGoogleCloudRunV2WorkerPoolTemplateVolumesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTemplateVolumes | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTemplateVolumes | undefined);
    private _cloudSqlInstance;
    get cloudSqlInstance(): DataGoogleCloudRunV2WorkerPoolTemplateVolumesCloudSqlInstanceList;
    private _emptyDir;
    get emptyDir(): DataGoogleCloudRunV2WorkerPoolTemplateVolumesEmptyDirList;
    private _gcs;
    get gcs(): DataGoogleCloudRunV2WorkerPoolTemplateVolumesGcsList;
    get name(): string;
    private _nfs;
    get nfs(): DataGoogleCloudRunV2WorkerPoolTemplateVolumesNfsList;
    private _secret;
    get secret(): DataGoogleCloudRunV2WorkerPoolTemplateVolumesSecretList;
}
export declare class DataGoogleCloudRunV2WorkerPoolTemplateVolumesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTemplateVolumesOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTemplateVpcAccessNetworkInterfaces {
}
export declare function dataGoogleCloudRunV2WorkerPoolTemplateVpcAccessNetworkInterfacesToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateVpcAccessNetworkInterfaces): any;
export declare function dataGoogleCloudRunV2WorkerPoolTemplateVpcAccessNetworkInterfacesToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateVpcAccessNetworkInterfaces): any;
export declare class DataGoogleCloudRunV2WorkerPoolTemplateVpcAccessNetworkInterfacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTemplateVpcAccessNetworkInterfaces | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTemplateVpcAccessNetworkInterfaces | undefined);
    get network(): string;
    get subnetwork(): string;
    get tags(): string[];
}
export declare class DataGoogleCloudRunV2WorkerPoolTemplateVpcAccessNetworkInterfacesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTemplateVpcAccessNetworkInterfacesOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTemplateVpcAccess {
}
export declare function dataGoogleCloudRunV2WorkerPoolTemplateVpcAccessToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateVpcAccess): any;
export declare function dataGoogleCloudRunV2WorkerPoolTemplateVpcAccessToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplateVpcAccess): any;
export declare class DataGoogleCloudRunV2WorkerPoolTemplateVpcAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTemplateVpcAccess | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTemplateVpcAccess | undefined);
    get connector(): string;
    get egress(): string;
    private _networkInterfaces;
    get networkInterfaces(): DataGoogleCloudRunV2WorkerPoolTemplateVpcAccessNetworkInterfacesList;
}
export declare class DataGoogleCloudRunV2WorkerPoolTemplateVpcAccessList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTemplateVpcAccessOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTemplate {
}
export declare function dataGoogleCloudRunV2WorkerPoolTemplateToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplate): any;
export declare function dataGoogleCloudRunV2WorkerPoolTemplateToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTemplate): any;
export declare class DataGoogleCloudRunV2WorkerPoolTemplateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTemplate | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTemplate | undefined);
    private _annotations;
    get annotations(): cdktn.StringMap;
    get client(): string;
    get clientVersion(): string;
    private _containers;
    get containers(): DataGoogleCloudRunV2WorkerPoolTemplateContainersList;
    get encryptionKey(): string;
    get encryptionKeyRevocationAction(): string;
    get encryptionKeyShutdownDuration(): string;
    get gpuZonalRedundancyDisabled(): cdktn.IResolvable;
    private _labels;
    get labels(): cdktn.StringMap;
    private _nodeSelector;
    get nodeSelector(): DataGoogleCloudRunV2WorkerPoolTemplateNodeSelectorList;
    get revision(): string;
    get serviceAccount(): string;
    private _volumes;
    get volumes(): DataGoogleCloudRunV2WorkerPoolTemplateVolumesList;
    private _vpcAccess;
    get vpcAccess(): DataGoogleCloudRunV2WorkerPoolTemplateVpcAccessList;
}
export declare class DataGoogleCloudRunV2WorkerPoolTemplateList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTemplateOutputReference;
}
export interface DataGoogleCloudRunV2WorkerPoolTerminalCondition {
}
export declare function dataGoogleCloudRunV2WorkerPoolTerminalConditionToTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTerminalCondition): any;
export declare function dataGoogleCloudRunV2WorkerPoolTerminalConditionToHclTerraform(struct?: DataGoogleCloudRunV2WorkerPoolTerminalCondition): any;
export declare class DataGoogleCloudRunV2WorkerPoolTerminalConditionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudRunV2WorkerPoolTerminalCondition | undefined;
    set internalValue(value: DataGoogleCloudRunV2WorkerPoolTerminalCondition | undefined);
    get executionReason(): string;
    get lastTransitionTime(): string;
    get message(): string;
    get reason(): string;
    get revisionReason(): string;
    get severity(): string;
    get state(): string;
    get type(): string;
}
export declare class DataGoogleCloudRunV2WorkerPoolTerminalConditionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudRunV2WorkerPoolTerminalConditionOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_run_v2_worker_pool google_cloud_run_v2_worker_pool}
*/
export declare class DataGoogleCloudRunV2WorkerPool extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_cloud_run_v2_worker_pool";
    /**
    * Generates CDKTN code for importing a DataGoogleCloudRunV2WorkerPool resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleCloudRunV2WorkerPool to import
    * @param importFromId The id of the existing DataGoogleCloudRunV2WorkerPool that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_run_v2_worker_pool#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleCloudRunV2WorkerPool to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_run_v2_worker_pool google_cloud_run_v2_worker_pool} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleCloudRunV2WorkerPoolConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleCloudRunV2WorkerPoolConfig);
    private _annotations;
    get annotations(): cdktn.StringMap;
    private _binaryAuthorization;
    get binaryAuthorization(): DataGoogleCloudRunV2WorkerPoolBinaryAuthorizationList;
    get client(): string;
    get clientVersion(): string;
    private _conditions;
    get conditions(): DataGoogleCloudRunV2WorkerPoolConditionsList;
    get createTime(): string;
    get creator(): string;
    get deleteTime(): string;
    get deletionPolicy(): string;
    get deletionProtection(): cdktn.IResolvable;
    get description(): string;
    private _effectiveAnnotations;
    get effectiveAnnotations(): cdktn.StringMap;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get etag(): string;
    get expireTime(): string;
    get generation(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceSplitStatuses;
    get instanceSplitStatuses(): DataGoogleCloudRunV2WorkerPoolInstanceSplitStatusesList;
    private _instanceSplits;
    get instanceSplits(): DataGoogleCloudRunV2WorkerPoolInstanceSplitsList;
    private _labels;
    get labels(): cdktn.StringMap;
    get lastModifier(): string;
    get latestCreatedRevision(): string;
    get latestReadyRevision(): string;
    get launchStage(): string;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get observedGeneration(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get reconciling(): cdktn.IResolvable;
    private _scaling;
    get scaling(): DataGoogleCloudRunV2WorkerPoolScalingList;
    private _template;
    get template(): DataGoogleCloudRunV2WorkerPoolTemplateList;
    private _terminalCondition;
    get terminalCondition(): DataGoogleCloudRunV2WorkerPoolTerminalConditionList;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get uid(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
