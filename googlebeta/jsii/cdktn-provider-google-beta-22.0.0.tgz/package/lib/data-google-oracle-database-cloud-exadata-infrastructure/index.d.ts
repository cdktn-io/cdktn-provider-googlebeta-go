/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleOracleDatabaseCloudExadataInfrastructureConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the Exadata Infrastructure to create. This value is restricted
    * to (^[a-z]([a-z0-9-]{0,61}[a-z0-9])?$) and must be a maximum of 63
    * characters in length. The value must start with a letter and end with
    * a letter or a number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_cloud_exadata_infrastructure#cloud_exadata_infrastructure_id DataGoogleOracleDatabaseCloudExadataInfrastructure#cloud_exadata_infrastructure_id}
    */
    readonly cloudExadataInfrastructureId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_cloud_exadata_infrastructure#id DataGoogleOracleDatabaseCloudExadataInfrastructure#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. See documentation for resource type 'oracledatabase.googleapis.com/DbServer'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_cloud_exadata_infrastructure#location DataGoogleOracleDatabaseCloudExadataInfrastructure#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_cloud_exadata_infrastructure#project DataGoogleOracleDatabaseCloudExadataInfrastructure#project}
    */
    readonly project?: string;
}
export interface DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesCustomerContacts {
}
export declare function dataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesCustomerContactsToTerraform(struct?: DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesCustomerContacts): any;
export declare function dataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesCustomerContactsToHclTerraform(struct?: DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesCustomerContacts): any;
export declare class DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesCustomerContactsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesCustomerContacts | undefined;
    set internalValue(value: DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesCustomerContacts | undefined);
    get email(): string;
}
export declare class DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesCustomerContactsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesCustomerContactsOutputReference;
}
export interface DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesExascaleConfig {
}
export declare function dataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesExascaleConfigToTerraform(struct?: DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesExascaleConfig): any;
export declare function dataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesExascaleConfigToHclTerraform(struct?: DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesExascaleConfig): any;
export declare class DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesExascaleConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesExascaleConfig | undefined;
    set internalValue(value: DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesExascaleConfig | undefined);
    get availableStorageSizeGb(): number;
    get availableVmStorageSizeGb(): number;
    get totalStorageSizeGb(): number;
    get totalVmStorageSizeGb(): number;
}
export declare class DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesExascaleConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesExascaleConfigOutputReference;
}
export interface DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesMaintenanceWindow {
}
export declare function dataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesMaintenanceWindowToTerraform(struct?: DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesMaintenanceWindow): any;
export declare function dataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesMaintenanceWindowToHclTerraform(struct?: DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesMaintenanceWindow): any;
export declare class DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesMaintenanceWindow | undefined;
    set internalValue(value: DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesMaintenanceWindow | undefined);
    get customActionTimeoutMins(): number;
    get daysOfWeek(): string[];
    get hoursOfDay(): number[];
    get isCustomActionTimeoutEnabled(): cdktn.IResolvable;
    get leadTimeWeek(): number;
    get months(): string[];
    get patchingMode(): string;
    get preference(): string;
    get weeksOfMonth(): number[];
}
export declare class DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesMaintenanceWindowList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesMaintenanceWindowOutputReference;
}
export interface DataGoogleOracleDatabaseCloudExadataInfrastructureProperties {
}
export declare function dataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesToTerraform(struct?: DataGoogleOracleDatabaseCloudExadataInfrastructureProperties): any;
export declare function dataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesToHclTerraform(struct?: DataGoogleOracleDatabaseCloudExadataInfrastructureProperties): any;
export declare class DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseCloudExadataInfrastructureProperties | undefined;
    set internalValue(value: DataGoogleOracleDatabaseCloudExadataInfrastructureProperties | undefined);
    get activatedStorageCount(): number;
    get additionalStorageCount(): number;
    get availableStorageSizeGb(): number;
    get computeCount(): number;
    get cpuCount(): number;
    private _customerContacts;
    get customerContacts(): DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesCustomerContactsList;
    get dataStorageSizeTb(): number;
    get dbNodeStorageSizeGb(): number;
    get dbServerVersion(): string;
    private _exascaleConfig;
    get exascaleConfig(): DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesExascaleConfigList;
    private _maintenanceWindow;
    get maintenanceWindow(): DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesMaintenanceWindowList;
    get maxCpuCount(): number;
    get maxDataStorageTb(): number;
    get maxDbNodeStorageSizeGb(): number;
    get maxMemoryGb(): number;
    get memorySizeGb(): number;
    get monthlyDbServerVersion(): string;
    get monthlyStorageServerVersion(): string;
    get nextMaintenanceRunId(): string;
    get nextMaintenanceRunTime(): string;
    get nextSecurityMaintenanceRunTime(): string;
    get ociUrl(): string;
    get ocid(): string;
    get shape(): string;
    get state(): string;
    get storageCount(): number;
    get storageServerVersion(): string;
    get totalStorageSizeGb(): number;
}
export declare class DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_cloud_exadata_infrastructure google_oracle_database_cloud_exadata_infrastructure}
*/
export declare class DataGoogleOracleDatabaseCloudExadataInfrastructure extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_oracle_database_cloud_exadata_infrastructure";
    /**
    * Generates CDKTN code for importing a DataGoogleOracleDatabaseCloudExadataInfrastructure resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleOracleDatabaseCloudExadataInfrastructure to import
    * @param importFromId The id of the existing DataGoogleOracleDatabaseCloudExadataInfrastructure that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_cloud_exadata_infrastructure#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleOracleDatabaseCloudExadataInfrastructure to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_cloud_exadata_infrastructure google_oracle_database_cloud_exadata_infrastructure} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleOracleDatabaseCloudExadataInfrastructureConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleOracleDatabaseCloudExadataInfrastructureConfig);
    private _cloudExadataInfrastructureId?;
    get cloudExadataInfrastructureId(): string;
    set cloudExadataInfrastructureId(value: string);
    get cloudExadataInfrastructureIdInput(): string | undefined;
    get createTime(): string;
    get deletionPolicy(): string;
    get deletionProtection(): cdktn.IResolvable;
    get displayName(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get entitlementId(): string;
    get gcpOracleZone(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels;
    get labels(): cdktn.StringMap;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _properties;
    get properties(): DataGoogleOracleDatabaseCloudExadataInfrastructurePropertiesList;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
