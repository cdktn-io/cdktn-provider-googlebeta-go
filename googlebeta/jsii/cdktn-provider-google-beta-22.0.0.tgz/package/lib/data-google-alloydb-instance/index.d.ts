/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleAlloydbInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the alloydb cluster that the instance belongs to.'alloydb_cluster_id'
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_alloydb_instance#cluster_id DataGoogleAlloydbInstance#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_alloydb_instance#id DataGoogleAlloydbInstance#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the alloydb instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_alloydb_instance#instance_id DataGoogleAlloydbInstance#instance_id}
    */
    readonly instanceId: string;
    /**
    * The canonical ID for the location. For example: "us-east1".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_alloydb_instance#location DataGoogleAlloydbInstance#location}
    */
    readonly location?: string;
    /**
    * Project ID of the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_alloydb_instance#project DataGoogleAlloydbInstance#project}
    */
    readonly project?: string;
}
export interface DataGoogleAlloydbInstanceClientConnectionConfigSslConfig {
}
export declare function dataGoogleAlloydbInstanceClientConnectionConfigSslConfigToTerraform(struct?: DataGoogleAlloydbInstanceClientConnectionConfigSslConfig): any;
export declare function dataGoogleAlloydbInstanceClientConnectionConfigSslConfigToHclTerraform(struct?: DataGoogleAlloydbInstanceClientConnectionConfigSslConfig): any;
export declare class DataGoogleAlloydbInstanceClientConnectionConfigSslConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbInstanceClientConnectionConfigSslConfig | undefined;
    set internalValue(value: DataGoogleAlloydbInstanceClientConnectionConfigSslConfig | undefined);
    get sslMode(): string;
}
export declare class DataGoogleAlloydbInstanceClientConnectionConfigSslConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbInstanceClientConnectionConfigSslConfigOutputReference;
}
export interface DataGoogleAlloydbInstanceClientConnectionConfig {
}
export declare function dataGoogleAlloydbInstanceClientConnectionConfigToTerraform(struct?: DataGoogleAlloydbInstanceClientConnectionConfig): any;
export declare function dataGoogleAlloydbInstanceClientConnectionConfigToHclTerraform(struct?: DataGoogleAlloydbInstanceClientConnectionConfig): any;
export declare class DataGoogleAlloydbInstanceClientConnectionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbInstanceClientConnectionConfig | undefined;
    set internalValue(value: DataGoogleAlloydbInstanceClientConnectionConfig | undefined);
    get requireConnectors(): cdktn.IResolvable;
    private _sslConfig;
    get sslConfig(): DataGoogleAlloydbInstanceClientConnectionConfigSslConfigList;
}
export declare class DataGoogleAlloydbInstanceClientConnectionConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbInstanceClientConnectionConfigOutputReference;
}
export interface DataGoogleAlloydbInstanceConnectionPoolConfig {
}
export declare function dataGoogleAlloydbInstanceConnectionPoolConfigToTerraform(struct?: DataGoogleAlloydbInstanceConnectionPoolConfig): any;
export declare function dataGoogleAlloydbInstanceConnectionPoolConfigToHclTerraform(struct?: DataGoogleAlloydbInstanceConnectionPoolConfig): any;
export declare class DataGoogleAlloydbInstanceConnectionPoolConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbInstanceConnectionPoolConfig | undefined;
    set internalValue(value: DataGoogleAlloydbInstanceConnectionPoolConfig | undefined);
    get enabled(): cdktn.IResolvable;
    private _flags;
    get flags(): cdktn.StringMap;
    get poolerCount(): number;
}
export declare class DataGoogleAlloydbInstanceConnectionPoolConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbInstanceConnectionPoolConfigOutputReference;
}
export interface DataGoogleAlloydbInstanceMachineConfig {
}
export declare function dataGoogleAlloydbInstanceMachineConfigToTerraform(struct?: DataGoogleAlloydbInstanceMachineConfig): any;
export declare function dataGoogleAlloydbInstanceMachineConfigToHclTerraform(struct?: DataGoogleAlloydbInstanceMachineConfig): any;
export declare class DataGoogleAlloydbInstanceMachineConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbInstanceMachineConfig | undefined;
    set internalValue(value: DataGoogleAlloydbInstanceMachineConfig | undefined);
    get cpuCount(): number;
    get machineType(): string;
}
export declare class DataGoogleAlloydbInstanceMachineConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbInstanceMachineConfigOutputReference;
}
export interface DataGoogleAlloydbInstanceNetworkConfigAuthorizedExternalNetworks {
}
export declare function dataGoogleAlloydbInstanceNetworkConfigAuthorizedExternalNetworksToTerraform(struct?: DataGoogleAlloydbInstanceNetworkConfigAuthorizedExternalNetworks): any;
export declare function dataGoogleAlloydbInstanceNetworkConfigAuthorizedExternalNetworksToHclTerraform(struct?: DataGoogleAlloydbInstanceNetworkConfigAuthorizedExternalNetworks): any;
export declare class DataGoogleAlloydbInstanceNetworkConfigAuthorizedExternalNetworksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbInstanceNetworkConfigAuthorizedExternalNetworks | undefined;
    set internalValue(value: DataGoogleAlloydbInstanceNetworkConfigAuthorizedExternalNetworks | undefined);
    get cidrRange(): string;
}
export declare class DataGoogleAlloydbInstanceNetworkConfigAuthorizedExternalNetworksList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbInstanceNetworkConfigAuthorizedExternalNetworksOutputReference;
}
export interface DataGoogleAlloydbInstanceNetworkConfig {
}
export declare function dataGoogleAlloydbInstanceNetworkConfigToTerraform(struct?: DataGoogleAlloydbInstanceNetworkConfig): any;
export declare function dataGoogleAlloydbInstanceNetworkConfigToHclTerraform(struct?: DataGoogleAlloydbInstanceNetworkConfig): any;
export declare class DataGoogleAlloydbInstanceNetworkConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbInstanceNetworkConfig | undefined;
    set internalValue(value: DataGoogleAlloydbInstanceNetworkConfig | undefined);
    get allocatedIpRangeOverride(): string;
    private _authorizedExternalNetworks;
    get authorizedExternalNetworks(): DataGoogleAlloydbInstanceNetworkConfigAuthorizedExternalNetworksList;
    get enableOutboundPublicIp(): cdktn.IResolvable;
    get enablePublicIp(): cdktn.IResolvable;
}
export declare class DataGoogleAlloydbInstanceNetworkConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbInstanceNetworkConfigOutputReference;
}
export interface DataGoogleAlloydbInstanceObservabilityConfig {
}
export declare function dataGoogleAlloydbInstanceObservabilityConfigToTerraform(struct?: DataGoogleAlloydbInstanceObservabilityConfig): any;
export declare function dataGoogleAlloydbInstanceObservabilityConfigToHclTerraform(struct?: DataGoogleAlloydbInstanceObservabilityConfig): any;
export declare class DataGoogleAlloydbInstanceObservabilityConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbInstanceObservabilityConfig | undefined;
    set internalValue(value: DataGoogleAlloydbInstanceObservabilityConfig | undefined);
    get assistiveExperiencesEnabled(): cdktn.IResolvable;
    get enabled(): cdktn.IResolvable;
    get maxQueryStringLength(): number;
    get preserveComments(): cdktn.IResolvable;
    get queryPlansPerMinute(): number;
    get recordApplicationTags(): cdktn.IResolvable;
    get trackActiveQueries(): cdktn.IResolvable;
    get trackClientAddress(): cdktn.IResolvable;
    get trackWaitEventTypes(): cdktn.IResolvable;
    get trackWaitEvents(): cdktn.IResolvable;
}
export declare class DataGoogleAlloydbInstanceObservabilityConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbInstanceObservabilityConfigOutputReference;
}
export interface DataGoogleAlloydbInstancePscInstanceConfigPscAutoConnections {
}
export declare function dataGoogleAlloydbInstancePscInstanceConfigPscAutoConnectionsToTerraform(struct?: DataGoogleAlloydbInstancePscInstanceConfigPscAutoConnections): any;
export declare function dataGoogleAlloydbInstancePscInstanceConfigPscAutoConnectionsToHclTerraform(struct?: DataGoogleAlloydbInstancePscInstanceConfigPscAutoConnections): any;
export declare class DataGoogleAlloydbInstancePscInstanceConfigPscAutoConnectionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbInstancePscInstanceConfigPscAutoConnections | undefined;
    set internalValue(value: DataGoogleAlloydbInstancePscInstanceConfigPscAutoConnections | undefined);
    get consumerNetwork(): string;
    get consumerNetworkStatus(): string;
    get consumerProject(): string;
    get ipAddress(): string;
    get status(): string;
}
export declare class DataGoogleAlloydbInstancePscInstanceConfigPscAutoConnectionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbInstancePscInstanceConfigPscAutoConnectionsOutputReference;
}
export interface DataGoogleAlloydbInstancePscInstanceConfigPscInterfaceConfigs {
}
export declare function dataGoogleAlloydbInstancePscInstanceConfigPscInterfaceConfigsToTerraform(struct?: DataGoogleAlloydbInstancePscInstanceConfigPscInterfaceConfigs): any;
export declare function dataGoogleAlloydbInstancePscInstanceConfigPscInterfaceConfigsToHclTerraform(struct?: DataGoogleAlloydbInstancePscInstanceConfigPscInterfaceConfigs): any;
export declare class DataGoogleAlloydbInstancePscInstanceConfigPscInterfaceConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbInstancePscInstanceConfigPscInterfaceConfigs | undefined;
    set internalValue(value: DataGoogleAlloydbInstancePscInstanceConfigPscInterfaceConfigs | undefined);
    get networkAttachmentResource(): string;
}
export declare class DataGoogleAlloydbInstancePscInstanceConfigPscInterfaceConfigsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbInstancePscInstanceConfigPscInterfaceConfigsOutputReference;
}
export interface DataGoogleAlloydbInstancePscInstanceConfig {
}
export declare function dataGoogleAlloydbInstancePscInstanceConfigToTerraform(struct?: DataGoogleAlloydbInstancePscInstanceConfig): any;
export declare function dataGoogleAlloydbInstancePscInstanceConfigToHclTerraform(struct?: DataGoogleAlloydbInstancePscInstanceConfig): any;
export declare class DataGoogleAlloydbInstancePscInstanceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbInstancePscInstanceConfig | undefined;
    set internalValue(value: DataGoogleAlloydbInstancePscInstanceConfig | undefined);
    get allowedConsumerProjects(): string[];
    private _pscAutoConnections;
    get pscAutoConnections(): DataGoogleAlloydbInstancePscInstanceConfigPscAutoConnectionsList;
    get pscDnsName(): string;
    private _pscInterfaceConfigs;
    get pscInterfaceConfigs(): DataGoogleAlloydbInstancePscInstanceConfigPscInterfaceConfigsList;
    get serviceAttachmentLink(): string;
}
export declare class DataGoogleAlloydbInstancePscInstanceConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbInstancePscInstanceConfigOutputReference;
}
export interface DataGoogleAlloydbInstanceQueryInsightsConfig {
}
export declare function dataGoogleAlloydbInstanceQueryInsightsConfigToTerraform(struct?: DataGoogleAlloydbInstanceQueryInsightsConfig): any;
export declare function dataGoogleAlloydbInstanceQueryInsightsConfigToHclTerraform(struct?: DataGoogleAlloydbInstanceQueryInsightsConfig): any;
export declare class DataGoogleAlloydbInstanceQueryInsightsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbInstanceQueryInsightsConfig | undefined;
    set internalValue(value: DataGoogleAlloydbInstanceQueryInsightsConfig | undefined);
    get queryPlansPerMinute(): number;
    get queryStringLength(): number;
    get recordApplicationTags(): cdktn.IResolvable;
    get recordClientAddress(): cdktn.IResolvable;
}
export declare class DataGoogleAlloydbInstanceQueryInsightsConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbInstanceQueryInsightsConfigOutputReference;
}
export interface DataGoogleAlloydbInstanceReadPoolConfig {
}
export declare function dataGoogleAlloydbInstanceReadPoolConfigToTerraform(struct?: DataGoogleAlloydbInstanceReadPoolConfig): any;
export declare function dataGoogleAlloydbInstanceReadPoolConfigToHclTerraform(struct?: DataGoogleAlloydbInstanceReadPoolConfig): any;
export declare class DataGoogleAlloydbInstanceReadPoolConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbInstanceReadPoolConfig | undefined;
    set internalValue(value: DataGoogleAlloydbInstanceReadPoolConfig | undefined);
    get nodeCount(): number;
}
export declare class DataGoogleAlloydbInstanceReadPoolConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbInstanceReadPoolConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_alloydb_instance google_alloydb_instance}
*/
export declare class DataGoogleAlloydbInstance extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_alloydb_instance";
    /**
    * Generates CDKTN code for importing a DataGoogleAlloydbInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleAlloydbInstance to import
    * @param importFromId The id of the existing DataGoogleAlloydbInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_alloydb_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleAlloydbInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_alloydb_instance google_alloydb_instance} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleAlloydbInstanceConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleAlloydbInstanceConfig);
    get activationPolicy(): string;
    private _annotations;
    get annotations(): cdktn.StringMap;
    get availabilityType(): string;
    private _clientConnectionConfig;
    get clientConnectionConfig(): DataGoogleAlloydbInstanceClientConnectionConfigList;
    get cluster(): string;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    private _connectionPoolConfig;
    get connectionPoolConfig(): DataGoogleAlloydbInstanceConnectionPoolConfigList;
    get createTime(): string;
    private _databaseFlags;
    get databaseFlags(): cdktn.StringMap;
    get deletionPolicy(): string;
    get displayName(): string;
    private _effectiveAnnotations;
    get effectiveAnnotations(): cdktn.StringMap;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get gceZone(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get instanceType(): string;
    get ipAddress(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _machineConfig;
    get machineConfig(): DataGoogleAlloydbInstanceMachineConfigList;
    get name(): string;
    private _networkConfig;
    get networkConfig(): DataGoogleAlloydbInstanceNetworkConfigList;
    private _observabilityConfig;
    get observabilityConfig(): DataGoogleAlloydbInstanceObservabilityConfigList;
    get outboundPublicIpAddresses(): string[];
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _pscInstanceConfig;
    get pscInstanceConfig(): DataGoogleAlloydbInstancePscInstanceConfigList;
    get publicIpAddress(): string;
    private _queryInsightsConfig;
    get queryInsightsConfig(): DataGoogleAlloydbInstanceQueryInsightsConfigList;
    private _readPoolConfig;
    get readPoolConfig(): DataGoogleAlloydbInstanceReadPoolConfigList;
    get reconciling(): cdktn.IResolvable;
    get state(): string;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get uid(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
