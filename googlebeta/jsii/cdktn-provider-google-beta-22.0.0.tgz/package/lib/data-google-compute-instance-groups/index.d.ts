/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleComputeInstanceGroupsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_instance_groups#filter DataGoogleComputeInstanceGroups#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_instance_groups#id DataGoogleComputeInstanceGroups#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_instance_groups#project DataGoogleComputeInstanceGroups#project}
    */
    readonly project?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_instance_groups#zone DataGoogleComputeInstanceGroups#zone}
    */
    readonly zone?: string;
}
export interface DataGoogleComputeInstanceGroupsInstanceGroupsNamedPort {
}
export declare function dataGoogleComputeInstanceGroupsInstanceGroupsNamedPortToTerraform(struct?: DataGoogleComputeInstanceGroupsInstanceGroupsNamedPort): any;
export declare function dataGoogleComputeInstanceGroupsInstanceGroupsNamedPortToHclTerraform(struct?: DataGoogleComputeInstanceGroupsInstanceGroupsNamedPort): any;
export declare class DataGoogleComputeInstanceGroupsInstanceGroupsNamedPortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceGroupsInstanceGroupsNamedPort | undefined;
    set internalValue(value: DataGoogleComputeInstanceGroupsInstanceGroupsNamedPort | undefined);
    get name(): string;
    get port(): number;
}
export declare class DataGoogleComputeInstanceGroupsInstanceGroupsNamedPortList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceGroupsInstanceGroupsNamedPortOutputReference;
}
export interface DataGoogleComputeInstanceGroupsInstanceGroups {
}
export declare function dataGoogleComputeInstanceGroupsInstanceGroupsToTerraform(struct?: DataGoogleComputeInstanceGroupsInstanceGroups): any;
export declare function dataGoogleComputeInstanceGroupsInstanceGroupsToHclTerraform(struct?: DataGoogleComputeInstanceGroupsInstanceGroups): any;
export declare class DataGoogleComputeInstanceGroupsInstanceGroupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeInstanceGroupsInstanceGroups | undefined;
    set internalValue(value: DataGoogleComputeInstanceGroupsInstanceGroups | undefined);
    get deletionPolicy(): string;
    get description(): string;
    get name(): string;
    private _namedPort;
    get namedPort(): DataGoogleComputeInstanceGroupsInstanceGroupsNamedPortList;
    get network(): string;
    get project(): string;
    get selfLink(): string;
    get size(): number;
    get zone(): string;
}
export declare class DataGoogleComputeInstanceGroupsInstanceGroupsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeInstanceGroupsInstanceGroupsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_instance_groups google_compute_instance_groups}
*/
export declare class DataGoogleComputeInstanceGroups extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_compute_instance_groups";
    /**
    * Generates CDKTN code for importing a DataGoogleComputeInstanceGroups resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleComputeInstanceGroups to import
    * @param importFromId The id of the existing DataGoogleComputeInstanceGroups that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_instance_groups#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleComputeInstanceGroups to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_instance_groups google_compute_instance_groups} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleComputeInstanceGroupsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGoogleComputeInstanceGroupsConfig);
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceGroups;
    get instanceGroups(): DataGoogleComputeInstanceGroupsInstanceGroupsList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    resetZone(): void;
    get zoneInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
