/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleCloudIdentityPoliciesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Filter expression for listing policies, as documented in the Cloud Identity Policy API policies.list method
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_identity_policies#filter DataGoogleCloudIdentityPolicies#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_identity_policies#id DataGoogleCloudIdentityPolicies#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataGoogleCloudIdentityPoliciesPoliciesPolicyQuery {
}
export declare function dataGoogleCloudIdentityPoliciesPoliciesPolicyQueryToTerraform(struct?: DataGoogleCloudIdentityPoliciesPoliciesPolicyQuery): any;
export declare function dataGoogleCloudIdentityPoliciesPoliciesPolicyQueryToHclTerraform(struct?: DataGoogleCloudIdentityPoliciesPoliciesPolicyQuery): any;
export declare class DataGoogleCloudIdentityPoliciesPoliciesPolicyQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudIdentityPoliciesPoliciesPolicyQuery | undefined;
    set internalValue(value: DataGoogleCloudIdentityPoliciesPoliciesPolicyQuery | undefined);
    get group(): string;
    get orgUnit(): string;
    get query(): string;
    get sortOrder(): number;
}
export declare class DataGoogleCloudIdentityPoliciesPoliciesPolicyQueryList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudIdentityPoliciesPoliciesPolicyQueryOutputReference;
}
export interface DataGoogleCloudIdentityPoliciesPolicies {
}
export declare function dataGoogleCloudIdentityPoliciesPoliciesToTerraform(struct?: DataGoogleCloudIdentityPoliciesPolicies): any;
export declare function dataGoogleCloudIdentityPoliciesPoliciesToHclTerraform(struct?: DataGoogleCloudIdentityPoliciesPolicies): any;
export declare class DataGoogleCloudIdentityPoliciesPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudIdentityPoliciesPolicies | undefined;
    set internalValue(value: DataGoogleCloudIdentityPoliciesPolicies | undefined);
    get customer(): string;
    get name(): string;
    private _policyQuery;
    get policyQuery(): DataGoogleCloudIdentityPoliciesPoliciesPolicyQueryList;
    get setting(): string;
    get type(): string;
}
export declare class DataGoogleCloudIdentityPoliciesPoliciesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudIdentityPoliciesPoliciesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_identity_policies google_cloud_identity_policies}
*/
export declare class DataGoogleCloudIdentityPolicies extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_cloud_identity_policies";
    /**
    * Generates CDKTN code for importing a DataGoogleCloudIdentityPolicies resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleCloudIdentityPolicies to import
    * @param importFromId The id of the existing DataGoogleCloudIdentityPolicies that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_identity_policies#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleCloudIdentityPolicies to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_identity_policies google_cloud_identity_policies} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleCloudIdentityPoliciesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGoogleCloudIdentityPoliciesConfig);
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _policies;
    get policies(): DataGoogleCloudIdentityPoliciesPoliciesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
