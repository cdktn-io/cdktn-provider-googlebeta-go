/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleArtifactRegistryRepositoriesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_artifact_registry_repositories#id DataGoogleArtifactRegistryRepositories#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_artifact_registry_repositories#location DataGoogleArtifactRegistryRepositories#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_artifact_registry_repositories#name_filter DataGoogleArtifactRegistryRepositories#name_filter}
    */
    readonly nameFilter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_artifact_registry_repositories#project DataGoogleArtifactRegistryRepositories#project}
    */
    readonly project?: string;
}
export interface DataGoogleArtifactRegistryRepositoriesRepositories {
}
export declare function dataGoogleArtifactRegistryRepositoriesRepositoriesToTerraform(struct?: DataGoogleArtifactRegistryRepositoriesRepositories): any;
export declare function dataGoogleArtifactRegistryRepositoriesRepositoriesToHclTerraform(struct?: DataGoogleArtifactRegistryRepositoriesRepositories): any;
export declare class DataGoogleArtifactRegistryRepositoriesRepositoriesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleArtifactRegistryRepositoriesRepositories | undefined;
    set internalValue(value: DataGoogleArtifactRegistryRepositoriesRepositories | undefined);
    get createTime(): string;
    get description(): string;
    get format(): string;
    get id(): string;
    get repositoryId(): string;
    get updateTime(): string;
}
export declare class DataGoogleArtifactRegistryRepositoriesRepositoriesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleArtifactRegistryRepositoriesRepositoriesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_artifact_registry_repositories google_artifact_registry_repositories}
*/
export declare class DataGoogleArtifactRegistryRepositories extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_artifact_registry_repositories";
    /**
    * Generates CDKTN code for importing a DataGoogleArtifactRegistryRepositories resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleArtifactRegistryRepositories to import
    * @param importFromId The id of the existing DataGoogleArtifactRegistryRepositories that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_artifact_registry_repositories#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleArtifactRegistryRepositories to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_artifact_registry_repositories google_artifact_registry_repositories} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleArtifactRegistryRepositoriesConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleArtifactRegistryRepositoriesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _nameFilter?;
    get nameFilter(): string;
    set nameFilter(value: string);
    resetNameFilter(): void;
    get nameFilterInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _repositories;
    get repositories(): DataGoogleArtifactRegistryRepositoriesRepositoriesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
