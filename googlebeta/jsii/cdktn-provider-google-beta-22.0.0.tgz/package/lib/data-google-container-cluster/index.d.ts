/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { DataGoogleContainerClusterAddonsConfigList, DataGoogleContainerClusterAnonymousAuthenticationConfigList, DataGoogleContainerClusterAuthenticatorGroupsConfigList, DataGoogleContainerClusterAutopilotClusterPolicyConfigList, DataGoogleContainerClusterBinaryAuthorizationList, DataGoogleContainerClusterClusterAutoscalingList, DataGoogleContainerClusterClusterTelemetryList, DataGoogleContainerClusterConfidentialNodesList, DataGoogleContainerClusterControlPlaneEndpointsConfigList, DataGoogleContainerClusterCostManagementConfigList, DataGoogleContainerClusterDatabaseEncryptionList, DataGoogleContainerClusterDefaultSnatStatusList, DataGoogleContainerClusterDnsConfigList, DataGoogleContainerClusterEnableK8SBetaApisList, DataGoogleContainerClusterEnterpriseConfigList, DataGoogleContainerClusterFleetList, DataGoogleContainerClusterGatewayApiConfigList, DataGoogleContainerClusterGkeAutoUpgradeConfigList, DataGoogleContainerClusterIdentityServiceConfigList, DataGoogleContainerClusterIpAllocationPolicyList, DataGoogleContainerClusterLoggingConfigList, DataGoogleContainerClusterMaintenancePolicyList, DataGoogleContainerClusterManagedMachineLearningDiagnosticsConfigList, DataGoogleContainerClusterManagedOpentelemetryConfigList, DataGoogleContainerClusterMasterAuthList, DataGoogleContainerClusterMasterAuthorizedNetworksConfigList, DataGoogleContainerClusterMeshCertificatesList, DataGoogleContainerClusterMonitoringConfigList, DataGoogleContainerClusterNetworkPerformanceConfigList, DataGoogleContainerClusterNetworkPolicyList, DataGoogleContainerClusterNodeConfigList, DataGoogleContainerClusterNodeCreationConfigList, DataGoogleContainerClusterNodePoolList, DataGoogleContainerClusterNodePoolAutoConfigList, DataGoogleContainerClusterNodePoolDefaultsList, DataGoogleContainerClusterNotificationConfigList, DataGoogleContainerClusterPodAutoscalingList, DataGoogleContainerClusterPodSecurityPolicyConfigList, DataGoogleContainerClusterPrivateClusterConfigList, DataGoogleContainerClusterProtectConfigList, DataGoogleContainerClusterRbacBindingConfigList, DataGoogleContainerClusterReleaseChannelList, DataGoogleContainerClusterResourceUsageExportConfigList, DataGoogleContainerClusterRollbackSafeUpgradeList, DataGoogleContainerClusterScheduleUpgradeConfigList, DataGoogleContainerClusterSecretManagerConfigList, DataGoogleContainerClusterSecretSyncConfigList, DataGoogleContainerClusterSecurityPostureConfigList, DataGoogleContainerClusterServiceExternalIpsConfigList, DataGoogleContainerClusterTpuConfigList, DataGoogleContainerClusterUserManagedKeysConfigList, DataGoogleContainerClusterVerticalPodAutoscalingList, DataGoogleContainerClusterWorkloadAltsConfigList, DataGoogleContainerClusterWorkloadIdentityConfigList } from './index-structs/index';
export * from './index-structs/index';
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleContainerClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_container_cluster#id DataGoogleContainerCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location (region or zone) in which the cluster master will be created, as well as the default node location. If you specify a zone (such as us-central1-a), the cluster will be a zonal cluster with a single cluster master. If you specify a region (such as us-west1), the cluster will be a regional cluster with multiple masters spread across zones in the region, and with default node locations in those zones as well.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_container_cluster#location DataGoogleContainerCluster#location}
    */
    readonly location?: string;
    /**
    * The name of the cluster, unique within the project and location.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_container_cluster#name DataGoogleContainerCluster#name}
    */
    readonly name: string;
    /**
    * The ID of the project in which the resource belongs. If it is not provided, the provider project is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_container_cluster#project DataGoogleContainerCluster#project}
    */
    readonly project?: string;
    /**
    * If true, the provider will not refresh the inline node_pool state from the API during cluster reads. Set this to true only when all node pools are managed via separate google_container_node_pool resources; it substantially improves plan/apply performance on clusters with a high node pool count. Must not be set to true when inline node_pool blocks are defined on this resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_container_cluster#skip_node_pool_refresh DataGoogleContainerCluster#skip_node_pool_refresh}
    */
    readonly skipNodePoolRefresh?: boolean | cdktn.IResolvable;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_container_cluster google_container_cluster}
*/
export declare class DataGoogleContainerCluster extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_container_cluster";
    /**
    * Generates CDKTN code for importing a DataGoogleContainerCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleContainerCluster to import
    * @param importFromId The id of the existing DataGoogleContainerCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_container_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleContainerCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_container_cluster google_container_cluster} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleContainerClusterConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleContainerClusterConfig);
    private _addonsConfig;
    get addonsConfig(): DataGoogleContainerClusterAddonsConfigList;
    get allowNetAdmin(): cdktn.IResolvable;
    private _anonymousAuthenticationConfig;
    get anonymousAuthenticationConfig(): DataGoogleContainerClusterAnonymousAuthenticationConfigList;
    private _authenticatorGroupsConfig;
    get authenticatorGroupsConfig(): DataGoogleContainerClusterAuthenticatorGroupsConfigList;
    private _autopilotClusterPolicyConfig;
    get autopilotClusterPolicyConfig(): DataGoogleContainerClusterAutopilotClusterPolicyConfigList;
    get autopilotPrivilegedAdmission(): string[];
    private _binaryAuthorization;
    get binaryAuthorization(): DataGoogleContainerClusterBinaryAuthorizationList;
    private _clusterAutoscaling;
    get clusterAutoscaling(): DataGoogleContainerClusterClusterAutoscalingList;
    get clusterIpv4Cidr(): string;
    private _clusterTelemetry;
    get clusterTelemetry(): DataGoogleContainerClusterClusterTelemetryList;
    private _confidentialNodes;
    get confidentialNodes(): DataGoogleContainerClusterConfidentialNodesList;
    private _controlPlaneEndpointsConfig;
    get controlPlaneEndpointsConfig(): DataGoogleContainerClusterControlPlaneEndpointsConfigList;
    private _costManagementConfig;
    get costManagementConfig(): DataGoogleContainerClusterCostManagementConfigList;
    private _databaseEncryption;
    get databaseEncryption(): DataGoogleContainerClusterDatabaseEncryptionList;
    get datapathProvider(): string;
    get dataplaneOptimizationMode(): string;
    get defaultMaxPodsPerNode(): number;
    private _defaultSnatStatus;
    get defaultSnatStatus(): DataGoogleContainerClusterDefaultSnatStatusList;
    get deletionPolicy(): string;
    get deletionProtection(): cdktn.IResolvable;
    get description(): string;
    get desiredEmulatedVersion(): string;
    get disableL4LbFirewallReconciliation(): cdktn.IResolvable;
    private _dnsConfig;
    get dnsConfig(): DataGoogleContainerClusterDnsConfigList;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get emulatedVersion(): string;
    get enableAutopilot(): cdktn.IResolvable;
    get enableCiliumClusterwideNetworkPolicy(): cdktn.IResolvable;
    get enableFqdnNetworkPolicy(): cdktn.IResolvable;
    get enableIntranodeVisibility(): cdktn.IResolvable;
    private _enableK8SBetaApis;
    get enableK8SBetaApis(): DataGoogleContainerClusterEnableK8SBetaApisList;
    get enableKubernetesAlpha(): cdktn.IResolvable;
    get enableL4IlbSubsetting(): cdktn.IResolvable;
    get enableLegacyAbac(): cdktn.IResolvable;
    get enableMultiNetworking(): cdktn.IResolvable;
    get enableShieldedNodes(): cdktn.IResolvable;
    get enableTpu(): cdktn.IResolvable;
    get endpoint(): string;
    private _enterpriseConfig;
    get enterpriseConfig(): DataGoogleContainerClusterEnterpriseConfigList;
    private _fleet;
    get fleet(): DataGoogleContainerClusterFleetList;
    private _gatewayApiConfig;
    get gatewayApiConfig(): DataGoogleContainerClusterGatewayApiConfigList;
    private _gkeAutoUpgradeConfig;
    get gkeAutoUpgradeConfig(): DataGoogleContainerClusterGkeAutoUpgradeConfigList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identityServiceConfig;
    get identityServiceConfig(): DataGoogleContainerClusterIdentityServiceConfigList;
    get ignoreNodeCountChanges(): cdktn.IResolvable;
    get inTransitEncryptionConfig(): string;
    get initialNodeCount(): number;
    private _ipAllocationPolicy;
    get ipAllocationPolicy(): DataGoogleContainerClusterIpAllocationPolicyList;
    get labelFingerprint(): string;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _loggingConfig;
    get loggingConfig(): DataGoogleContainerClusterLoggingConfigList;
    get loggingService(): string;
    private _maintenancePolicy;
    get maintenancePolicy(): DataGoogleContainerClusterMaintenancePolicyList;
    private _managedMachineLearningDiagnosticsConfig;
    get managedMachineLearningDiagnosticsConfig(): DataGoogleContainerClusterManagedMachineLearningDiagnosticsConfigList;
    private _managedOpentelemetryConfig;
    get managedOpentelemetryConfig(): DataGoogleContainerClusterManagedOpentelemetryConfigList;
    private _masterAuth;
    get masterAuth(): DataGoogleContainerClusterMasterAuthList;
    private _masterAuthorizedNetworksConfig;
    get masterAuthorizedNetworksConfig(): DataGoogleContainerClusterMasterAuthorizedNetworksConfigList;
    get masterVersion(): string;
    private _meshCertificates;
    get meshCertificates(): DataGoogleContainerClusterMeshCertificatesList;
    get minMasterVersion(): string;
    private _monitoringConfig;
    get monitoringConfig(): DataGoogleContainerClusterMonitoringConfigList;
    get monitoringService(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get network(): string;
    private _networkPerformanceConfig;
    get networkPerformanceConfig(): DataGoogleContainerClusterNetworkPerformanceConfigList;
    private _networkPolicy;
    get networkPolicy(): DataGoogleContainerClusterNetworkPolicyList;
    get networkingMode(): string;
    private _nodeConfig;
    get nodeConfig(): DataGoogleContainerClusterNodeConfigList;
    private _nodeCreationConfig;
    get nodeCreationConfig(): DataGoogleContainerClusterNodeCreationConfigList;
    get nodeLocations(): string[];
    private _nodePool;
    get nodePool(): DataGoogleContainerClusterNodePoolList;
    private _nodePoolAutoConfig;
    get nodePoolAutoConfig(): DataGoogleContainerClusterNodePoolAutoConfigList;
    private _nodePoolDefaults;
    get nodePoolDefaults(): DataGoogleContainerClusterNodePoolDefaultsList;
    get nodeVersion(): string;
    private _notificationConfig;
    get notificationConfig(): DataGoogleContainerClusterNotificationConfigList;
    get operation(): string;
    private _podAutoscaling;
    get podAutoscaling(): DataGoogleContainerClusterPodAutoscalingList;
    private _podSecurityPolicyConfig;
    get podSecurityPolicyConfig(): DataGoogleContainerClusterPodSecurityPolicyConfigList;
    private _privateClusterConfig;
    get privateClusterConfig(): DataGoogleContainerClusterPrivateClusterConfigList;
    get privateIpv6GoogleAccess(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _protectConfig;
    get protectConfig(): DataGoogleContainerClusterProtectConfigList;
    private _rbacBindingConfig;
    get rbacBindingConfig(): DataGoogleContainerClusterRbacBindingConfigList;
    private _releaseChannel;
    get releaseChannel(): DataGoogleContainerClusterReleaseChannelList;
    get removeDefaultNodePool(): cdktn.IResolvable;
    private _resourceLabels;
    get resourceLabels(): cdktn.StringMap;
    private _resourceUsageExportConfig;
    get resourceUsageExportConfig(): DataGoogleContainerClusterResourceUsageExportConfigList;
    private _rollbackSafeUpgrade;
    get rollbackSafeUpgrade(): DataGoogleContainerClusterRollbackSafeUpgradeList;
    private _scheduleUpgradeConfig;
    get scheduleUpgradeConfig(): DataGoogleContainerClusterScheduleUpgradeConfigList;
    private _secretManagerConfig;
    get secretManagerConfig(): DataGoogleContainerClusterSecretManagerConfigList;
    private _secretSyncConfig;
    get secretSyncConfig(): DataGoogleContainerClusterSecretSyncConfigList;
    private _securityPostureConfig;
    get securityPostureConfig(): DataGoogleContainerClusterSecurityPostureConfigList;
    get selfLink(): string;
    private _serviceExternalIpsConfig;
    get serviceExternalIpsConfig(): DataGoogleContainerClusterServiceExternalIpsConfigList;
    get servicesIpv4Cidr(): string;
    private _skipNodePoolRefresh?;
    get skipNodePoolRefresh(): boolean | cdktn.IResolvable;
    set skipNodePoolRefresh(value: boolean | cdktn.IResolvable);
    resetSkipNodePoolRefresh(): void;
    get skipNodePoolRefreshInput(): boolean | cdktn.IResolvable | undefined;
    get subnetwork(): string;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _tpuConfig;
    get tpuConfig(): DataGoogleContainerClusterTpuConfigList;
    get tpuIpv4CidrBlock(): string;
    private _userManagedKeysConfig;
    get userManagedKeysConfig(): DataGoogleContainerClusterUserManagedKeysConfigList;
    private _verticalPodAutoscaling;
    get verticalPodAutoscaling(): DataGoogleContainerClusterVerticalPodAutoscalingList;
    private _workloadAltsConfig;
    get workloadAltsConfig(): DataGoogleContainerClusterWorkloadAltsConfigList;
    private _workloadIdentityConfig;
    get workloadIdentityConfig(): DataGoogleContainerClusterWorkloadIdentityConfigList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
