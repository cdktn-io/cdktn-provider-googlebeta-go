/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleOracleDatabaseAutonomousDatabaseConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the Autonomous Database to create. This value is restricted
    * to (^[a-z]([a-z0-9-]{0,61}[a-z0-9])?$) and must be a maximum of 63
    * characters in length. The value must start with a letter and end with
    * a letter or a number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_autonomous_database#autonomous_database_id DataGoogleOracleDatabaseAutonomousDatabase#autonomous_database_id}
    */
    readonly autonomousDatabaseId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_autonomous_database#id DataGoogleOracleDatabaseAutonomousDatabase#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. See documentation for resource type 'oracledatabase.googleapis.com/AutonomousDatabaseBackup'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_autonomous_database#location DataGoogleOracleDatabaseAutonomousDatabase#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_autonomous_database#project DataGoogleOracleDatabaseAutonomousDatabase#project}
    */
    readonly project?: string;
}
export interface DataGoogleOracleDatabaseAutonomousDatabasePropertiesApexDetails {
}
export declare function dataGoogleOracleDatabaseAutonomousDatabasePropertiesApexDetailsToTerraform(struct?: DataGoogleOracleDatabaseAutonomousDatabasePropertiesApexDetails): any;
export declare function dataGoogleOracleDatabaseAutonomousDatabasePropertiesApexDetailsToHclTerraform(struct?: DataGoogleOracleDatabaseAutonomousDatabasePropertiesApexDetails): any;
export declare class DataGoogleOracleDatabaseAutonomousDatabasePropertiesApexDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseAutonomousDatabasePropertiesApexDetails | undefined;
    set internalValue(value: DataGoogleOracleDatabaseAutonomousDatabasePropertiesApexDetails | undefined);
    get apexVersion(): string;
    get ordsVersion(): string;
}
export declare class DataGoogleOracleDatabaseAutonomousDatabasePropertiesApexDetailsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseAutonomousDatabasePropertiesApexDetailsOutputReference;
}
export interface DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsAllConnectionStrings {
}
export declare function dataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsAllConnectionStringsToTerraform(struct?: DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsAllConnectionStrings): any;
export declare function dataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsAllConnectionStringsToHclTerraform(struct?: DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsAllConnectionStrings): any;
export declare class DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsAllConnectionStringsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsAllConnectionStrings | undefined;
    set internalValue(value: DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsAllConnectionStrings | undefined);
    get high(): string;
    get low(): string;
    get medium(): string;
}
export declare class DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsAllConnectionStringsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsAllConnectionStringsOutputReference;
}
export interface DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsProfiles {
}
export declare function dataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsProfilesToTerraform(struct?: DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsProfiles): any;
export declare function dataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsProfilesToHclTerraform(struct?: DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsProfiles): any;
export declare class DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsProfilesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsProfiles | undefined;
    set internalValue(value: DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsProfiles | undefined);
    get consumerGroup(): string;
    get displayName(): string;
    get hostFormat(): string;
    get isRegional(): cdktn.IResolvable;
    get protocol(): string;
    get sessionMode(): string;
    get syntaxFormat(): string;
    get tlsAuthentication(): string;
    get value(): string;
}
export declare class DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsProfilesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsProfilesOutputReference;
}
export interface DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStrings {
}
export declare function dataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsToTerraform(struct?: DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStrings): any;
export declare function dataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsToHclTerraform(struct?: DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStrings): any;
export declare class DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStrings | undefined;
    set internalValue(value: DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStrings | undefined);
    private _allConnectionStrings;
    get allConnectionStrings(): DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsAllConnectionStringsList;
    get dedicated(): string;
    get high(): string;
    get low(): string;
    get medium(): string;
    private _profiles;
    get profiles(): DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsProfilesList;
}
export declare class DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsOutputReference;
}
export interface DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionUrls {
}
export declare function dataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionUrlsToTerraform(struct?: DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionUrls): any;
export declare function dataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionUrlsToHclTerraform(struct?: DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionUrls): any;
export declare class DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionUrlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionUrls | undefined;
    set internalValue(value: DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionUrls | undefined);
    get apexUri(): string;
    get databaseTransformsUri(): string;
    get graphStudioUri(): string;
    get machineLearningNotebookUri(): string;
    get machineLearningUserManagementUri(): string;
    get mongoDbUri(): string;
    get ordsUri(): string;
    get sqlDevWebUri(): string;
}
export declare class DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionUrlsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionUrlsOutputReference;
}
export interface DataGoogleOracleDatabaseAutonomousDatabasePropertiesCustomerContacts {
}
export declare function dataGoogleOracleDatabaseAutonomousDatabasePropertiesCustomerContactsToTerraform(struct?: DataGoogleOracleDatabaseAutonomousDatabasePropertiesCustomerContacts): any;
export declare function dataGoogleOracleDatabaseAutonomousDatabasePropertiesCustomerContactsToHclTerraform(struct?: DataGoogleOracleDatabaseAutonomousDatabasePropertiesCustomerContacts): any;
export declare class DataGoogleOracleDatabaseAutonomousDatabasePropertiesCustomerContactsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseAutonomousDatabasePropertiesCustomerContacts | undefined;
    set internalValue(value: DataGoogleOracleDatabaseAutonomousDatabasePropertiesCustomerContacts | undefined);
    get email(): string;
}
export declare class DataGoogleOracleDatabaseAutonomousDatabasePropertiesCustomerContactsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseAutonomousDatabasePropertiesCustomerContactsOutputReference;
}
export interface DataGoogleOracleDatabaseAutonomousDatabasePropertiesLocalStandbyDb {
}
export declare function dataGoogleOracleDatabaseAutonomousDatabasePropertiesLocalStandbyDbToTerraform(struct?: DataGoogleOracleDatabaseAutonomousDatabasePropertiesLocalStandbyDb): any;
export declare function dataGoogleOracleDatabaseAutonomousDatabasePropertiesLocalStandbyDbToHclTerraform(struct?: DataGoogleOracleDatabaseAutonomousDatabasePropertiesLocalStandbyDb): any;
export declare class DataGoogleOracleDatabaseAutonomousDatabasePropertiesLocalStandbyDbOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseAutonomousDatabasePropertiesLocalStandbyDb | undefined;
    set internalValue(value: DataGoogleOracleDatabaseAutonomousDatabasePropertiesLocalStandbyDb | undefined);
    get dataGuardRoleChangedTime(): string;
    get disasterRecoveryRoleChangedTime(): string;
    get lagTimeDuration(): string;
    get lifecycleDetails(): string;
    get state(): string;
}
export declare class DataGoogleOracleDatabaseAutonomousDatabasePropertiesLocalStandbyDbList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseAutonomousDatabasePropertiesLocalStandbyDbOutputReference;
}
export interface DataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsStartTime {
}
export declare function dataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsStartTimeToTerraform(struct?: DataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsStartTime): any;
export declare function dataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsStartTimeToHclTerraform(struct?: DataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsStartTime): any;
export declare class DataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsStartTime | undefined;
    set internalValue(value: DataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsStartTime | undefined);
    get hours(): number;
    get minutes(): number;
    get nanos(): number;
    get seconds(): number;
}
export declare class DataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsStartTimeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsStartTimeOutputReference;
}
export interface DataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsStopTime {
}
export declare function dataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsStopTimeToTerraform(struct?: DataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsStopTime): any;
export declare function dataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsStopTimeToHclTerraform(struct?: DataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsStopTime): any;
export declare class DataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsStopTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsStopTime | undefined;
    set internalValue(value: DataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsStopTime | undefined);
    get hours(): number;
    get minutes(): number;
    get nanos(): number;
    get seconds(): number;
}
export declare class DataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsStopTimeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsStopTimeOutputReference;
}
export interface DataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetails {
}
export declare function dataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsToTerraform(struct?: DataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetails): any;
export declare function dataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsToHclTerraform(struct?: DataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetails): any;
export declare class DataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetails | undefined;
    set internalValue(value: DataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetails | undefined);
    get dayOfWeek(): string;
    private _startTime;
    get startTime(): DataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsStartTimeList;
    private _stopTime;
    get stopTime(): DataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsStopTimeList;
}
export declare class DataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsOutputReference;
}
export interface DataGoogleOracleDatabaseAutonomousDatabaseProperties {
}
export declare function dataGoogleOracleDatabaseAutonomousDatabasePropertiesToTerraform(struct?: DataGoogleOracleDatabaseAutonomousDatabaseProperties): any;
export declare function dataGoogleOracleDatabaseAutonomousDatabasePropertiesToHclTerraform(struct?: DataGoogleOracleDatabaseAutonomousDatabaseProperties): any;
export declare class DataGoogleOracleDatabaseAutonomousDatabasePropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseAutonomousDatabaseProperties | undefined;
    set internalValue(value: DataGoogleOracleDatabaseAutonomousDatabaseProperties | undefined);
    get actualUsedDataStorageSizeTb(): number;
    get allocatedStorageSizeTb(): number;
    private _apexDetails;
    get apexDetails(): DataGoogleOracleDatabaseAutonomousDatabasePropertiesApexDetailsList;
    get arePrimaryAllowlistedIpsUsed(): cdktn.IResolvable;
    get autonomousContainerDatabaseId(): string;
    get availableUpgradeVersions(): string[];
    get backupRetentionPeriodDays(): number;
    get characterSet(): string;
    get computeCount(): number;
    private _connectionStrings;
    get connectionStrings(): DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionStringsList;
    private _connectionUrls;
    get connectionUrls(): DataGoogleOracleDatabaseAutonomousDatabasePropertiesConnectionUrlsList;
    get cpuCoreCount(): number;
    private _customerContacts;
    get customerContacts(): DataGoogleOracleDatabaseAutonomousDatabasePropertiesCustomerContactsList;
    get dataSafeState(): string;
    get dataStorageSizeGb(): number;
    get dataStorageSizeTb(): number;
    get databaseManagementState(): string;
    get dbEdition(): string;
    get dbVersion(): string;
    get dbWorkload(): string;
    get failedDataRecoveryDuration(): string;
    get isAutoScalingEnabled(): cdktn.IResolvable;
    get isLocalDataGuardEnabled(): cdktn.IResolvable;
    get isStorageAutoScalingEnabled(): cdktn.IResolvable;
    get licenseType(): string;
    get lifecycleDetails(): string;
    get localAdgAutoFailoverMaxDataLossLimit(): number;
    get localDisasterRecoveryType(): string;
    private _localStandbyDb;
    get localStandbyDb(): DataGoogleOracleDatabaseAutonomousDatabasePropertiesLocalStandbyDbList;
    get maintenanceBeginTime(): string;
    get maintenanceEndTime(): string;
    get maintenanceScheduleType(): string;
    get memoryPerOracleComputeUnitGbs(): number;
    get memoryTableGbs(): number;
    get mtlsConnectionRequired(): cdktn.IResolvable;
    get nCharacterSet(): string;
    get nextLongTermBackupTime(): string;
    get ociUrl(): string;
    get ocid(): string;
    get openMode(): string;
    get operationsInsightsState(): string;
    get peerDbIds(): string[];
    get permissionLevel(): string;
    get privateEndpoint(): string;
    get privateEndpointIp(): string;
    get privateEndpointLabel(): string;
    get refreshableMode(): string;
    get refreshableState(): string;
    get role(): string;
    private _scheduledOperationDetails;
    get scheduledOperationDetails(): DataGoogleOracleDatabaseAutonomousDatabasePropertiesScheduledOperationDetailsList;
    get secretId(): string;
    get sqlWebDeveloperUrl(): string;
    get state(): string;
    get supportedCloneRegions(): string[];
    get totalAutoBackupStorageSizeGbs(): number;
    get usedDataStorageSizeTbs(): number;
    get vaultId(): string;
}
export declare class DataGoogleOracleDatabaseAutonomousDatabasePropertiesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseAutonomousDatabasePropertiesOutputReference;
}
export interface DataGoogleOracleDatabaseAutonomousDatabaseSourceConfig {
}
export declare function dataGoogleOracleDatabaseAutonomousDatabaseSourceConfigToTerraform(struct?: DataGoogleOracleDatabaseAutonomousDatabaseSourceConfig): any;
export declare function dataGoogleOracleDatabaseAutonomousDatabaseSourceConfigToHclTerraform(struct?: DataGoogleOracleDatabaseAutonomousDatabaseSourceConfig): any;
export declare class DataGoogleOracleDatabaseAutonomousDatabaseSourceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseAutonomousDatabaseSourceConfig | undefined;
    set internalValue(value: DataGoogleOracleDatabaseAutonomousDatabaseSourceConfig | undefined);
    get automaticBackupsReplicationEnabled(): cdktn.IResolvable;
    get autonomousDatabase(): string;
}
export declare class DataGoogleOracleDatabaseAutonomousDatabaseSourceConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseAutonomousDatabaseSourceConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_autonomous_database google_oracle_database_autonomous_database}
*/
export declare class DataGoogleOracleDatabaseAutonomousDatabase extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_oracle_database_autonomous_database";
    /**
    * Generates CDKTN code for importing a DataGoogleOracleDatabaseAutonomousDatabase resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleOracleDatabaseAutonomousDatabase to import
    * @param importFromId The id of the existing DataGoogleOracleDatabaseAutonomousDatabase that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_autonomous_database#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleOracleDatabaseAutonomousDatabase to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_autonomous_database google_oracle_database_autonomous_database} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleOracleDatabaseAutonomousDatabaseConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleOracleDatabaseAutonomousDatabaseConfig);
    get adminPassword(): string;
    private _autonomousDatabaseId?;
    get autonomousDatabaseId(): string;
    set autonomousDatabaseId(value: string);
    get autonomousDatabaseIdInput(): string | undefined;
    get cidr(): string;
    get createTime(): string;
    get database(): string;
    get deletionPolicy(): string;
    get deletionProtection(): cdktn.IResolvable;
    get disasterRecoverySupportedLocations(): string[];
    get displayName(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get entitlementId(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels;
    get labels(): cdktn.StringMap;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    get network(): string;
    get odbNetwork(): string;
    get odbSubnet(): string;
    get peerAutonomousDatabases(): string[];
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _properties;
    get properties(): DataGoogleOracleDatabaseAutonomousDatabasePropertiesList;
    private _sourceConfig;
    get sourceConfig(): DataGoogleOracleDatabaseAutonomousDatabaseSourceConfigList;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
