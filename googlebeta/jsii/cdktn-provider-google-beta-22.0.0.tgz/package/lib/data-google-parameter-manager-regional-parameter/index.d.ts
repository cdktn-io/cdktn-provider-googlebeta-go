/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleParameterManagerRegionalParameterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_parameter_manager_regional_parameter#id DataGoogleParameterManagerRegionalParameter#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the regional parameter. eg us-central1
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_parameter_manager_regional_parameter#location DataGoogleParameterManagerRegionalParameter#location}
    */
    readonly location: string;
    /**
    * This must be unique within the project.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_parameter_manager_regional_parameter#parameter_id DataGoogleParameterManagerRegionalParameter#parameter_id}
    */
    readonly parameterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_parameter_manager_regional_parameter#project DataGoogleParameterManagerRegionalParameter#project}
    */
    readonly project?: string;
}
export interface DataGoogleParameterManagerRegionalParameterPolicyMember {
}
export declare function dataGoogleParameterManagerRegionalParameterPolicyMemberToTerraform(struct?: DataGoogleParameterManagerRegionalParameterPolicyMember): any;
export declare function dataGoogleParameterManagerRegionalParameterPolicyMemberToHclTerraform(struct?: DataGoogleParameterManagerRegionalParameterPolicyMember): any;
export declare class DataGoogleParameterManagerRegionalParameterPolicyMemberOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleParameterManagerRegionalParameterPolicyMember | undefined;
    set internalValue(value: DataGoogleParameterManagerRegionalParameterPolicyMember | undefined);
    get iamPolicyNamePrincipal(): string;
    get iamPolicyUidPrincipal(): string;
}
export declare class DataGoogleParameterManagerRegionalParameterPolicyMemberList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleParameterManagerRegionalParameterPolicyMemberOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_parameter_manager_regional_parameter google_parameter_manager_regional_parameter}
*/
export declare class DataGoogleParameterManagerRegionalParameter extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_parameter_manager_regional_parameter";
    /**
    * Generates CDKTN code for importing a DataGoogleParameterManagerRegionalParameter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleParameterManagerRegionalParameter to import
    * @param importFromId The id of the existing DataGoogleParameterManagerRegionalParameter that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_parameter_manager_regional_parameter#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleParameterManagerRegionalParameter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_parameter_manager_regional_parameter google_parameter_manager_regional_parameter} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleParameterManagerRegionalParameterConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleParameterManagerRegionalParameterConfig);
    get createTime(): string;
    get deletionPolicy(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get format(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get kmsKey(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _parameterId?;
    get parameterId(): string;
    set parameterId(value: string);
    get parameterIdInput(): string | undefined;
    private _policyMember;
    get policyMember(): DataGoogleParameterManagerRegionalParameterPolicyMemberList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _tags;
    get tags(): cdktn.StringMap;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
