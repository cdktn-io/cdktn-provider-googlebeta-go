/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleRedisClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_redis_cluster#id DataGoogleRedisCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Unique name of the resource in this scope including project and location using the form:
    * projects/{projectId}/locations/{locationId}/clusters/{clusterId}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_redis_cluster#name DataGoogleRedisCluster#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_redis_cluster#project DataGoogleRedisCluster#project}
    */
    readonly project?: string;
    /**
    * The name of the region of the Redis cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_redis_cluster#region DataGoogleRedisCluster#region}
    */
    readonly region?: string;
}
export interface DataGoogleRedisClusterAutomatedBackupConfigFixedFrequencyScheduleStartTime {
}
export declare function dataGoogleRedisClusterAutomatedBackupConfigFixedFrequencyScheduleStartTimeToTerraform(struct?: DataGoogleRedisClusterAutomatedBackupConfigFixedFrequencyScheduleStartTime): any;
export declare function dataGoogleRedisClusterAutomatedBackupConfigFixedFrequencyScheduleStartTimeToHclTerraform(struct?: DataGoogleRedisClusterAutomatedBackupConfigFixedFrequencyScheduleStartTime): any;
export declare class DataGoogleRedisClusterAutomatedBackupConfigFixedFrequencyScheduleStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterAutomatedBackupConfigFixedFrequencyScheduleStartTime | undefined;
    set internalValue(value: DataGoogleRedisClusterAutomatedBackupConfigFixedFrequencyScheduleStartTime | undefined);
    get hours(): number;
}
export declare class DataGoogleRedisClusterAutomatedBackupConfigFixedFrequencyScheduleStartTimeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterAutomatedBackupConfigFixedFrequencyScheduleStartTimeOutputReference;
}
export interface DataGoogleRedisClusterAutomatedBackupConfigFixedFrequencySchedule {
}
export declare function dataGoogleRedisClusterAutomatedBackupConfigFixedFrequencyScheduleToTerraform(struct?: DataGoogleRedisClusterAutomatedBackupConfigFixedFrequencySchedule): any;
export declare function dataGoogleRedisClusterAutomatedBackupConfigFixedFrequencyScheduleToHclTerraform(struct?: DataGoogleRedisClusterAutomatedBackupConfigFixedFrequencySchedule): any;
export declare class DataGoogleRedisClusterAutomatedBackupConfigFixedFrequencyScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterAutomatedBackupConfigFixedFrequencySchedule | undefined;
    set internalValue(value: DataGoogleRedisClusterAutomatedBackupConfigFixedFrequencySchedule | undefined);
    private _startTime;
    get startTime(): DataGoogleRedisClusterAutomatedBackupConfigFixedFrequencyScheduleStartTimeList;
}
export declare class DataGoogleRedisClusterAutomatedBackupConfigFixedFrequencyScheduleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterAutomatedBackupConfigFixedFrequencyScheduleOutputReference;
}
export interface DataGoogleRedisClusterAutomatedBackupConfig {
}
export declare function dataGoogleRedisClusterAutomatedBackupConfigToTerraform(struct?: DataGoogleRedisClusterAutomatedBackupConfig): any;
export declare function dataGoogleRedisClusterAutomatedBackupConfigToHclTerraform(struct?: DataGoogleRedisClusterAutomatedBackupConfig): any;
export declare class DataGoogleRedisClusterAutomatedBackupConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterAutomatedBackupConfig | undefined;
    set internalValue(value: DataGoogleRedisClusterAutomatedBackupConfig | undefined);
    private _fixedFrequencySchedule;
    get fixedFrequencySchedule(): DataGoogleRedisClusterAutomatedBackupConfigFixedFrequencyScheduleList;
    get retention(): string;
}
export declare class DataGoogleRedisClusterAutomatedBackupConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterAutomatedBackupConfigOutputReference;
}
export interface DataGoogleRedisClusterCrossClusterReplicationConfigMembershipPrimaryCluster {
}
export declare function dataGoogleRedisClusterCrossClusterReplicationConfigMembershipPrimaryClusterToTerraform(struct?: DataGoogleRedisClusterCrossClusterReplicationConfigMembershipPrimaryCluster): any;
export declare function dataGoogleRedisClusterCrossClusterReplicationConfigMembershipPrimaryClusterToHclTerraform(struct?: DataGoogleRedisClusterCrossClusterReplicationConfigMembershipPrimaryCluster): any;
export declare class DataGoogleRedisClusterCrossClusterReplicationConfigMembershipPrimaryClusterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterCrossClusterReplicationConfigMembershipPrimaryCluster | undefined;
    set internalValue(value: DataGoogleRedisClusterCrossClusterReplicationConfigMembershipPrimaryCluster | undefined);
    get cluster(): string;
    get uid(): string;
}
export declare class DataGoogleRedisClusterCrossClusterReplicationConfigMembershipPrimaryClusterList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterCrossClusterReplicationConfigMembershipPrimaryClusterOutputReference;
}
export interface DataGoogleRedisClusterCrossClusterReplicationConfigMembershipSecondaryClusters {
}
export declare function dataGoogleRedisClusterCrossClusterReplicationConfigMembershipSecondaryClustersToTerraform(struct?: DataGoogleRedisClusterCrossClusterReplicationConfigMembershipSecondaryClusters): any;
export declare function dataGoogleRedisClusterCrossClusterReplicationConfigMembershipSecondaryClustersToHclTerraform(struct?: DataGoogleRedisClusterCrossClusterReplicationConfigMembershipSecondaryClusters): any;
export declare class DataGoogleRedisClusterCrossClusterReplicationConfigMembershipSecondaryClustersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterCrossClusterReplicationConfigMembershipSecondaryClusters | undefined;
    set internalValue(value: DataGoogleRedisClusterCrossClusterReplicationConfigMembershipSecondaryClusters | undefined);
    get cluster(): string;
    get uid(): string;
}
export declare class DataGoogleRedisClusterCrossClusterReplicationConfigMembershipSecondaryClustersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterCrossClusterReplicationConfigMembershipSecondaryClustersOutputReference;
}
export interface DataGoogleRedisClusterCrossClusterReplicationConfigMembership {
}
export declare function dataGoogleRedisClusterCrossClusterReplicationConfigMembershipToTerraform(struct?: DataGoogleRedisClusterCrossClusterReplicationConfigMembership): any;
export declare function dataGoogleRedisClusterCrossClusterReplicationConfigMembershipToHclTerraform(struct?: DataGoogleRedisClusterCrossClusterReplicationConfigMembership): any;
export declare class DataGoogleRedisClusterCrossClusterReplicationConfigMembershipOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterCrossClusterReplicationConfigMembership | undefined;
    set internalValue(value: DataGoogleRedisClusterCrossClusterReplicationConfigMembership | undefined);
    private _primaryCluster;
    get primaryCluster(): DataGoogleRedisClusterCrossClusterReplicationConfigMembershipPrimaryClusterList;
    private _secondaryClusters;
    get secondaryClusters(): DataGoogleRedisClusterCrossClusterReplicationConfigMembershipSecondaryClustersList;
}
export declare class DataGoogleRedisClusterCrossClusterReplicationConfigMembershipList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterCrossClusterReplicationConfigMembershipOutputReference;
}
export interface DataGoogleRedisClusterCrossClusterReplicationConfigPrimaryCluster {
}
export declare function dataGoogleRedisClusterCrossClusterReplicationConfigPrimaryClusterToTerraform(struct?: DataGoogleRedisClusterCrossClusterReplicationConfigPrimaryCluster): any;
export declare function dataGoogleRedisClusterCrossClusterReplicationConfigPrimaryClusterToHclTerraform(struct?: DataGoogleRedisClusterCrossClusterReplicationConfigPrimaryCluster): any;
export declare class DataGoogleRedisClusterCrossClusterReplicationConfigPrimaryClusterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterCrossClusterReplicationConfigPrimaryCluster | undefined;
    set internalValue(value: DataGoogleRedisClusterCrossClusterReplicationConfigPrimaryCluster | undefined);
    get cluster(): string;
    get uid(): string;
}
export declare class DataGoogleRedisClusterCrossClusterReplicationConfigPrimaryClusterList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterCrossClusterReplicationConfigPrimaryClusterOutputReference;
}
export interface DataGoogleRedisClusterCrossClusterReplicationConfigSecondaryClusters {
}
export declare function dataGoogleRedisClusterCrossClusterReplicationConfigSecondaryClustersToTerraform(struct?: DataGoogleRedisClusterCrossClusterReplicationConfigSecondaryClusters): any;
export declare function dataGoogleRedisClusterCrossClusterReplicationConfigSecondaryClustersToHclTerraform(struct?: DataGoogleRedisClusterCrossClusterReplicationConfigSecondaryClusters): any;
export declare class DataGoogleRedisClusterCrossClusterReplicationConfigSecondaryClustersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterCrossClusterReplicationConfigSecondaryClusters | undefined;
    set internalValue(value: DataGoogleRedisClusterCrossClusterReplicationConfigSecondaryClusters | undefined);
    get cluster(): string;
    get uid(): string;
}
export declare class DataGoogleRedisClusterCrossClusterReplicationConfigSecondaryClustersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterCrossClusterReplicationConfigSecondaryClustersOutputReference;
}
export interface DataGoogleRedisClusterCrossClusterReplicationConfig {
}
export declare function dataGoogleRedisClusterCrossClusterReplicationConfigToTerraform(struct?: DataGoogleRedisClusterCrossClusterReplicationConfig): any;
export declare function dataGoogleRedisClusterCrossClusterReplicationConfigToHclTerraform(struct?: DataGoogleRedisClusterCrossClusterReplicationConfig): any;
export declare class DataGoogleRedisClusterCrossClusterReplicationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterCrossClusterReplicationConfig | undefined;
    set internalValue(value: DataGoogleRedisClusterCrossClusterReplicationConfig | undefined);
    get clusterRole(): string;
    private _membership;
    get membership(): DataGoogleRedisClusterCrossClusterReplicationConfigMembershipList;
    private _primaryCluster;
    get primaryCluster(): DataGoogleRedisClusterCrossClusterReplicationConfigPrimaryClusterList;
    private _secondaryClusters;
    get secondaryClusters(): DataGoogleRedisClusterCrossClusterReplicationConfigSecondaryClustersList;
    get updateTime(): string;
}
export declare class DataGoogleRedisClusterCrossClusterReplicationConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterCrossClusterReplicationConfigOutputReference;
}
export interface DataGoogleRedisClusterDiscoveryEndpointsPscConfig {
}
export declare function dataGoogleRedisClusterDiscoveryEndpointsPscConfigToTerraform(struct?: DataGoogleRedisClusterDiscoveryEndpointsPscConfig): any;
export declare function dataGoogleRedisClusterDiscoveryEndpointsPscConfigToHclTerraform(struct?: DataGoogleRedisClusterDiscoveryEndpointsPscConfig): any;
export declare class DataGoogleRedisClusterDiscoveryEndpointsPscConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterDiscoveryEndpointsPscConfig | undefined;
    set internalValue(value: DataGoogleRedisClusterDiscoveryEndpointsPscConfig | undefined);
    get network(): string;
}
export declare class DataGoogleRedisClusterDiscoveryEndpointsPscConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterDiscoveryEndpointsPscConfigOutputReference;
}
export interface DataGoogleRedisClusterDiscoveryEndpoints {
}
export declare function dataGoogleRedisClusterDiscoveryEndpointsToTerraform(struct?: DataGoogleRedisClusterDiscoveryEndpoints): any;
export declare function dataGoogleRedisClusterDiscoveryEndpointsToHclTerraform(struct?: DataGoogleRedisClusterDiscoveryEndpoints): any;
export declare class DataGoogleRedisClusterDiscoveryEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterDiscoveryEndpoints | undefined;
    set internalValue(value: DataGoogleRedisClusterDiscoveryEndpoints | undefined);
    get address(): string;
    get port(): number;
    private _pscConfig;
    get pscConfig(): DataGoogleRedisClusterDiscoveryEndpointsPscConfigList;
}
export declare class DataGoogleRedisClusterDiscoveryEndpointsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterDiscoveryEndpointsOutputReference;
}
export interface DataGoogleRedisClusterGcsSource {
}
export declare function dataGoogleRedisClusterGcsSourceToTerraform(struct?: DataGoogleRedisClusterGcsSource): any;
export declare function dataGoogleRedisClusterGcsSourceToHclTerraform(struct?: DataGoogleRedisClusterGcsSource): any;
export declare class DataGoogleRedisClusterGcsSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterGcsSource | undefined;
    set internalValue(value: DataGoogleRedisClusterGcsSource | undefined);
    get uris(): string[];
}
export declare class DataGoogleRedisClusterGcsSourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterGcsSourceOutputReference;
}
export interface DataGoogleRedisClusterMaintenancePolicyWeeklyMaintenanceWindowStartTime {
}
export declare function dataGoogleRedisClusterMaintenancePolicyWeeklyMaintenanceWindowStartTimeToTerraform(struct?: DataGoogleRedisClusterMaintenancePolicyWeeklyMaintenanceWindowStartTime): any;
export declare function dataGoogleRedisClusterMaintenancePolicyWeeklyMaintenanceWindowStartTimeToHclTerraform(struct?: DataGoogleRedisClusterMaintenancePolicyWeeklyMaintenanceWindowStartTime): any;
export declare class DataGoogleRedisClusterMaintenancePolicyWeeklyMaintenanceWindowStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterMaintenancePolicyWeeklyMaintenanceWindowStartTime | undefined;
    set internalValue(value: DataGoogleRedisClusterMaintenancePolicyWeeklyMaintenanceWindowStartTime | undefined);
    get hours(): number;
    get minutes(): number;
    get nanos(): number;
    get seconds(): number;
}
export declare class DataGoogleRedisClusterMaintenancePolicyWeeklyMaintenanceWindowStartTimeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterMaintenancePolicyWeeklyMaintenanceWindowStartTimeOutputReference;
}
export interface DataGoogleRedisClusterMaintenancePolicyWeeklyMaintenanceWindow {
}
export declare function dataGoogleRedisClusterMaintenancePolicyWeeklyMaintenanceWindowToTerraform(struct?: DataGoogleRedisClusterMaintenancePolicyWeeklyMaintenanceWindow): any;
export declare function dataGoogleRedisClusterMaintenancePolicyWeeklyMaintenanceWindowToHclTerraform(struct?: DataGoogleRedisClusterMaintenancePolicyWeeklyMaintenanceWindow): any;
export declare class DataGoogleRedisClusterMaintenancePolicyWeeklyMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterMaintenancePolicyWeeklyMaintenanceWindow | undefined;
    set internalValue(value: DataGoogleRedisClusterMaintenancePolicyWeeklyMaintenanceWindow | undefined);
    get day(): string;
    get duration(): string;
    private _startTime;
    get startTime(): DataGoogleRedisClusterMaintenancePolicyWeeklyMaintenanceWindowStartTimeList;
}
export declare class DataGoogleRedisClusterMaintenancePolicyWeeklyMaintenanceWindowList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterMaintenancePolicyWeeklyMaintenanceWindowOutputReference;
}
export interface DataGoogleRedisClusterMaintenancePolicy {
}
export declare function dataGoogleRedisClusterMaintenancePolicyToTerraform(struct?: DataGoogleRedisClusterMaintenancePolicy): any;
export declare function dataGoogleRedisClusterMaintenancePolicyToHclTerraform(struct?: DataGoogleRedisClusterMaintenancePolicy): any;
export declare class DataGoogleRedisClusterMaintenancePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterMaintenancePolicy | undefined;
    set internalValue(value: DataGoogleRedisClusterMaintenancePolicy | undefined);
    get createTime(): string;
    get updateTime(): string;
    private _weeklyMaintenanceWindow;
    get weeklyMaintenanceWindow(): DataGoogleRedisClusterMaintenancePolicyWeeklyMaintenanceWindowList;
}
export declare class DataGoogleRedisClusterMaintenancePolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterMaintenancePolicyOutputReference;
}
export interface DataGoogleRedisClusterMaintenanceSchedule {
}
export declare function dataGoogleRedisClusterMaintenanceScheduleToTerraform(struct?: DataGoogleRedisClusterMaintenanceSchedule): any;
export declare function dataGoogleRedisClusterMaintenanceScheduleToHclTerraform(struct?: DataGoogleRedisClusterMaintenanceSchedule): any;
export declare class DataGoogleRedisClusterMaintenanceScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterMaintenanceSchedule | undefined;
    set internalValue(value: DataGoogleRedisClusterMaintenanceSchedule | undefined);
    get endTime(): string;
    get scheduleDeadlineTime(): string;
    get startTime(): string;
}
export declare class DataGoogleRedisClusterMaintenanceScheduleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterMaintenanceScheduleOutputReference;
}
export interface DataGoogleRedisClusterManagedBackupSource {
}
export declare function dataGoogleRedisClusterManagedBackupSourceToTerraform(struct?: DataGoogleRedisClusterManagedBackupSource): any;
export declare function dataGoogleRedisClusterManagedBackupSourceToHclTerraform(struct?: DataGoogleRedisClusterManagedBackupSource): any;
export declare class DataGoogleRedisClusterManagedBackupSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterManagedBackupSource | undefined;
    set internalValue(value: DataGoogleRedisClusterManagedBackupSource | undefined);
    get backup(): string;
}
export declare class DataGoogleRedisClusterManagedBackupSourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterManagedBackupSourceOutputReference;
}
export interface DataGoogleRedisClusterManagedServerCaCaCerts {
}
export declare function dataGoogleRedisClusterManagedServerCaCaCertsToTerraform(struct?: DataGoogleRedisClusterManagedServerCaCaCerts): any;
export declare function dataGoogleRedisClusterManagedServerCaCaCertsToHclTerraform(struct?: DataGoogleRedisClusterManagedServerCaCaCerts): any;
export declare class DataGoogleRedisClusterManagedServerCaCaCertsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterManagedServerCaCaCerts | undefined;
    set internalValue(value: DataGoogleRedisClusterManagedServerCaCaCerts | undefined);
    get certificates(): string[];
}
export declare class DataGoogleRedisClusterManagedServerCaCaCertsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterManagedServerCaCaCertsOutputReference;
}
export interface DataGoogleRedisClusterManagedServerCa {
}
export declare function dataGoogleRedisClusterManagedServerCaToTerraform(struct?: DataGoogleRedisClusterManagedServerCa): any;
export declare function dataGoogleRedisClusterManagedServerCaToHclTerraform(struct?: DataGoogleRedisClusterManagedServerCa): any;
export declare class DataGoogleRedisClusterManagedServerCaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterManagedServerCa | undefined;
    set internalValue(value: DataGoogleRedisClusterManagedServerCa | undefined);
    private _caCerts;
    get caCerts(): DataGoogleRedisClusterManagedServerCaCaCertsList;
}
export declare class DataGoogleRedisClusterManagedServerCaList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterManagedServerCaOutputReference;
}
export interface DataGoogleRedisClusterPersistenceConfigAofConfig {
}
export declare function dataGoogleRedisClusterPersistenceConfigAofConfigToTerraform(struct?: DataGoogleRedisClusterPersistenceConfigAofConfig): any;
export declare function dataGoogleRedisClusterPersistenceConfigAofConfigToHclTerraform(struct?: DataGoogleRedisClusterPersistenceConfigAofConfig): any;
export declare class DataGoogleRedisClusterPersistenceConfigAofConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterPersistenceConfigAofConfig | undefined;
    set internalValue(value: DataGoogleRedisClusterPersistenceConfigAofConfig | undefined);
    get appendFsync(): string;
}
export declare class DataGoogleRedisClusterPersistenceConfigAofConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterPersistenceConfigAofConfigOutputReference;
}
export interface DataGoogleRedisClusterPersistenceConfigRdbConfig {
}
export declare function dataGoogleRedisClusterPersistenceConfigRdbConfigToTerraform(struct?: DataGoogleRedisClusterPersistenceConfigRdbConfig): any;
export declare function dataGoogleRedisClusterPersistenceConfigRdbConfigToHclTerraform(struct?: DataGoogleRedisClusterPersistenceConfigRdbConfig): any;
export declare class DataGoogleRedisClusterPersistenceConfigRdbConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterPersistenceConfigRdbConfig | undefined;
    set internalValue(value: DataGoogleRedisClusterPersistenceConfigRdbConfig | undefined);
    get rdbSnapshotPeriod(): string;
    get rdbSnapshotStartTime(): string;
}
export declare class DataGoogleRedisClusterPersistenceConfigRdbConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterPersistenceConfigRdbConfigOutputReference;
}
export interface DataGoogleRedisClusterPersistenceConfig {
}
export declare function dataGoogleRedisClusterPersistenceConfigToTerraform(struct?: DataGoogleRedisClusterPersistenceConfig): any;
export declare function dataGoogleRedisClusterPersistenceConfigToHclTerraform(struct?: DataGoogleRedisClusterPersistenceConfig): any;
export declare class DataGoogleRedisClusterPersistenceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterPersistenceConfig | undefined;
    set internalValue(value: DataGoogleRedisClusterPersistenceConfig | undefined);
    private _aofConfig;
    get aofConfig(): DataGoogleRedisClusterPersistenceConfigAofConfigList;
    get mode(): string;
    private _rdbConfig;
    get rdbConfig(): DataGoogleRedisClusterPersistenceConfigRdbConfigList;
}
export declare class DataGoogleRedisClusterPersistenceConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterPersistenceConfigOutputReference;
}
export interface DataGoogleRedisClusterPscConfigs {
}
export declare function dataGoogleRedisClusterPscConfigsToTerraform(struct?: DataGoogleRedisClusterPscConfigs): any;
export declare function dataGoogleRedisClusterPscConfigsToHclTerraform(struct?: DataGoogleRedisClusterPscConfigs): any;
export declare class DataGoogleRedisClusterPscConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterPscConfigs | undefined;
    set internalValue(value: DataGoogleRedisClusterPscConfigs | undefined);
    get network(): string;
}
export declare class DataGoogleRedisClusterPscConfigsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterPscConfigsOutputReference;
}
export interface DataGoogleRedisClusterPscConnections {
}
export declare function dataGoogleRedisClusterPscConnectionsToTerraform(struct?: DataGoogleRedisClusterPscConnections): any;
export declare function dataGoogleRedisClusterPscConnectionsToHclTerraform(struct?: DataGoogleRedisClusterPscConnections): any;
export declare class DataGoogleRedisClusterPscConnectionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterPscConnections | undefined;
    set internalValue(value: DataGoogleRedisClusterPscConnections | undefined);
    get address(): string;
    get forwardingRule(): string;
    get network(): string;
    get projectId(): string;
    get pscConnectionId(): string;
}
export declare class DataGoogleRedisClusterPscConnectionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterPscConnectionsOutputReference;
}
export interface DataGoogleRedisClusterPscServiceAttachments {
}
export declare function dataGoogleRedisClusterPscServiceAttachmentsToTerraform(struct?: DataGoogleRedisClusterPscServiceAttachments): any;
export declare function dataGoogleRedisClusterPscServiceAttachmentsToHclTerraform(struct?: DataGoogleRedisClusterPscServiceAttachments): any;
export declare class DataGoogleRedisClusterPscServiceAttachmentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterPscServiceAttachments | undefined;
    set internalValue(value: DataGoogleRedisClusterPscServiceAttachments | undefined);
    get connectionType(): string;
    get serviceAttachment(): string;
}
export declare class DataGoogleRedisClusterPscServiceAttachmentsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterPscServiceAttachmentsOutputReference;
}
export interface DataGoogleRedisClusterStateInfoUpdateInfo {
}
export declare function dataGoogleRedisClusterStateInfoUpdateInfoToTerraform(struct?: DataGoogleRedisClusterStateInfoUpdateInfo): any;
export declare function dataGoogleRedisClusterStateInfoUpdateInfoToHclTerraform(struct?: DataGoogleRedisClusterStateInfoUpdateInfo): any;
export declare class DataGoogleRedisClusterStateInfoUpdateInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterStateInfoUpdateInfo | undefined;
    set internalValue(value: DataGoogleRedisClusterStateInfoUpdateInfo | undefined);
    get targetReplicaCount(): number;
    get targetShardCount(): number;
}
export declare class DataGoogleRedisClusterStateInfoUpdateInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterStateInfoUpdateInfoOutputReference;
}
export interface DataGoogleRedisClusterStateInfo {
}
export declare function dataGoogleRedisClusterStateInfoToTerraform(struct?: DataGoogleRedisClusterStateInfo): any;
export declare function dataGoogleRedisClusterStateInfoToHclTerraform(struct?: DataGoogleRedisClusterStateInfo): any;
export declare class DataGoogleRedisClusterStateInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterStateInfo | undefined;
    set internalValue(value: DataGoogleRedisClusterStateInfo | undefined);
    private _updateInfo;
    get updateInfo(): DataGoogleRedisClusterStateInfoUpdateInfoList;
}
export declare class DataGoogleRedisClusterStateInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterStateInfoOutputReference;
}
export interface DataGoogleRedisClusterZoneDistributionConfig {
}
export declare function dataGoogleRedisClusterZoneDistributionConfigToTerraform(struct?: DataGoogleRedisClusterZoneDistributionConfig): any;
export declare function dataGoogleRedisClusterZoneDistributionConfigToHclTerraform(struct?: DataGoogleRedisClusterZoneDistributionConfig): any;
export declare class DataGoogleRedisClusterZoneDistributionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisClusterZoneDistributionConfig | undefined;
    set internalValue(value: DataGoogleRedisClusterZoneDistributionConfig | undefined);
    get mode(): string;
    get zone(): string;
}
export declare class DataGoogleRedisClusterZoneDistributionConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisClusterZoneDistributionConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_redis_cluster google_redis_cluster}
*/
export declare class DataGoogleRedisCluster extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_redis_cluster";
    /**
    * Generates CDKTN code for importing a DataGoogleRedisCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleRedisCluster to import
    * @param importFromId The id of the existing DataGoogleRedisCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_redis_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleRedisCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_redis_cluster google_redis_cluster} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleRedisClusterConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleRedisClusterConfig);
    get aclPolicy(): string;
    get authorizationMode(): string;
    private _automatedBackupConfig;
    get automatedBackupConfig(): DataGoogleRedisClusterAutomatedBackupConfigList;
    get availableMaintenanceVersions(): string[];
    get backupCollection(): string;
    get createTime(): string;
    private _crossClusterReplicationConfig;
    get crossClusterReplicationConfig(): DataGoogleRedisClusterCrossClusterReplicationConfigList;
    get deletionPolicy(): string;
    get deletionProtectionEnabled(): cdktn.IResolvable;
    private _discoveryEndpoints;
    get discoveryEndpoints(): DataGoogleRedisClusterDiscoveryEndpointsList;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get effectiveMaintenanceVersion(): string;
    private _gcsSource;
    get gcsSource(): DataGoogleRedisClusterGcsSourceList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get isAclPolicyInSync(): cdktn.IResolvable;
    get kmsKey(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    private _maintenancePolicy;
    get maintenancePolicy(): DataGoogleRedisClusterMaintenancePolicyList;
    private _maintenanceSchedule;
    get maintenanceSchedule(): DataGoogleRedisClusterMaintenanceScheduleList;
    get maintenanceVersion(): string;
    private _managedBackupSource;
    get managedBackupSource(): DataGoogleRedisClusterManagedBackupSourceList;
    private _managedServerCa;
    get managedServerCa(): DataGoogleRedisClusterManagedServerCaList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get nodeType(): string;
    private _persistenceConfig;
    get persistenceConfig(): DataGoogleRedisClusterPersistenceConfigList;
    get preciseSizeGb(): number;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _pscConfigs;
    get pscConfigs(): DataGoogleRedisClusterPscConfigsList;
    private _pscConnections;
    get pscConnections(): DataGoogleRedisClusterPscConnectionsList;
    private _pscServiceAttachments;
    get pscServiceAttachments(): DataGoogleRedisClusterPscServiceAttachmentsList;
    private _redisConfigs;
    get redisConfigs(): cdktn.StringMap;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get replicaCount(): number;
    get serverCaMode(): string;
    get serverCaPool(): string;
    get shardCount(): number;
    get sizeGb(): number;
    get state(): string;
    private _stateInfo;
    get stateInfo(): DataGoogleRedisClusterStateInfoList;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get transitEncryptionMode(): string;
    get uid(): string;
    private _zoneDistributionConfig;
    get zoneDistributionConfig(): DataGoogleRedisClusterZoneDistributionConfigList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
