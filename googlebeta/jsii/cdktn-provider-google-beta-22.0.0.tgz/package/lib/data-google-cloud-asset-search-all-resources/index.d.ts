/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleCloudAssetSearchAllResourcesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_asset_search_all_resources#asset_types DataGoogleCloudAssetSearchAllResources#asset_types}
    */
    readonly assetTypes?: string[];
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_asset_search_all_resources#id DataGoogleCloudAssetSearchAllResources#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_asset_search_all_resources#query DataGoogleCloudAssetSearchAllResources#query}
    */
    readonly query?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_asset_search_all_resources#scope DataGoogleCloudAssetSearchAllResources#scope}
    */
    readonly scope: string;
}
export interface DataGoogleCloudAssetSearchAllResourcesResults {
}
export declare function dataGoogleCloudAssetSearchAllResourcesResultsToTerraform(struct?: DataGoogleCloudAssetSearchAllResourcesResults): any;
export declare function dataGoogleCloudAssetSearchAllResourcesResultsToHclTerraform(struct?: DataGoogleCloudAssetSearchAllResourcesResults): any;
export declare class DataGoogleCloudAssetSearchAllResourcesResultsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudAssetSearchAllResourcesResults | undefined;
    set internalValue(value: DataGoogleCloudAssetSearchAllResourcesResults | undefined);
    get assetType(): string;
    get createTime(): string;
    get description(): string;
    get displayName(): string;
    get folders(): string[];
    get kmsKeys(): string[];
    private _labels;
    get labels(): cdktn.StringMap;
    get location(): string;
    get name(): string;
    get networkTags(): string[];
    get organization(): string;
    get parentAssetType(): string;
    get parentFullResourceName(): string;
    get project(): string;
    get state(): string;
    get updateTime(): string;
}
export declare class DataGoogleCloudAssetSearchAllResourcesResultsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudAssetSearchAllResourcesResultsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_asset_search_all_resources google_cloud_asset_search_all_resources}
*/
export declare class DataGoogleCloudAssetSearchAllResources extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_cloud_asset_search_all_resources";
    /**
    * Generates CDKTN code for importing a DataGoogleCloudAssetSearchAllResources resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleCloudAssetSearchAllResources to import
    * @param importFromId The id of the existing DataGoogleCloudAssetSearchAllResources that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_asset_search_all_resources#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleCloudAssetSearchAllResources to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_asset_search_all_resources google_cloud_asset_search_all_resources} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleCloudAssetSearchAllResourcesConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleCloudAssetSearchAllResourcesConfig);
    private _assetTypes?;
    get assetTypes(): string[];
    set assetTypes(value: string[]);
    resetAssetTypes(): void;
    get assetTypesInput(): string[] | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _query?;
    get query(): string;
    set query(value: string);
    resetQuery(): void;
    get queryInput(): string | undefined;
    private _results;
    get results(): DataGoogleCloudAssetSearchAllResourcesResultsList;
    private _scope?;
    get scope(): string;
    set scope(value: string);
    get scopeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
