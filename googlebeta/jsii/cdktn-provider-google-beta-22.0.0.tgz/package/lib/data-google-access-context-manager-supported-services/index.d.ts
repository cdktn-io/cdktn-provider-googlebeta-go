/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleAccessContextManagerSupportedServicesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_access_context_manager_supported_services#id DataGoogleAccessContextManagerSupportedServices#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataGoogleAccessContextManagerSupportedServicesSupportedServices {
}
export declare function dataGoogleAccessContextManagerSupportedServicesSupportedServicesToTerraform(struct?: DataGoogleAccessContextManagerSupportedServicesSupportedServices): any;
export declare function dataGoogleAccessContextManagerSupportedServicesSupportedServicesToHclTerraform(struct?: DataGoogleAccessContextManagerSupportedServicesSupportedServices): any;
export declare class DataGoogleAccessContextManagerSupportedServicesSupportedServicesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAccessContextManagerSupportedServicesSupportedServices | undefined;
    set internalValue(value: DataGoogleAccessContextManagerSupportedServicesSupportedServices | undefined);
    get availableOnRestrictedVip(): cdktn.IResolvable;
    get knownLimitations(): cdktn.IResolvable;
    get name(): string;
    get serviceSupportStage(): string;
    get supportStage(): string;
    get title(): string;
}
export declare class DataGoogleAccessContextManagerSupportedServicesSupportedServicesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAccessContextManagerSupportedServicesSupportedServicesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_access_context_manager_supported_services google_access_context_manager_supported_services}
*/
export declare class DataGoogleAccessContextManagerSupportedServices extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_access_context_manager_supported_services";
    /**
    * Generates CDKTN code for importing a DataGoogleAccessContextManagerSupportedServices resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleAccessContextManagerSupportedServices to import
    * @param importFromId The id of the existing DataGoogleAccessContextManagerSupportedServices that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_access_context_manager_supported_services#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleAccessContextManagerSupportedServices to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_access_context_manager_supported_services google_access_context_manager_supported_services} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleAccessContextManagerSupportedServicesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGoogleAccessContextManagerSupportedServicesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _supportedServices;
    get supportedServices(): DataGoogleAccessContextManagerSupportedServicesSupportedServicesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
