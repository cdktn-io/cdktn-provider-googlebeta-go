/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleSiteVerificationTokenConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_site_verification_token#id DataGoogleSiteVerificationToken#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The site identifier. If the type is set to SITE, the identifier is a URL. If the type is
    * set to INET_DOMAIN, the identifier is a domain name.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_site_verification_token#identifier DataGoogleSiteVerificationToken#identifier}
    */
    readonly identifier: string;
    /**
    * The type of resource to be verified, either a domain or a web site. Possible values: ["INET_DOMAIN", "SITE"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_site_verification_token#type DataGoogleSiteVerificationToken#type}
    */
    readonly type: string;
    /**
    * The verification method for the Site Verification system to use to verify
    * this site or domain. Possible values: ["ANALYTICS", "DNS_CNAME", "DNS_TXT", "FILE", "META", "TAG_MANAGER"]
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_site_verification_token#verification_method DataGoogleSiteVerificationToken#verification_method}
    */
    readonly verificationMethod: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_site_verification_token#timeouts DataGoogleSiteVerificationToken#timeouts}
    */
    readonly timeouts?: DataGoogleSiteVerificationTokenTimeouts;
}
export interface DataGoogleSiteVerificationTokenTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_site_verification_token#read DataGoogleSiteVerificationToken#read}
    */
    readonly read?: string;
}
export declare function dataGoogleSiteVerificationTokenTimeoutsToTerraform(struct?: DataGoogleSiteVerificationTokenTimeouts | cdktn.IResolvable): any;
export declare function dataGoogleSiteVerificationTokenTimeoutsToHclTerraform(struct?: DataGoogleSiteVerificationTokenTimeouts | cdktn.IResolvable): any;
export declare class DataGoogleSiteVerificationTokenTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataGoogleSiteVerificationTokenTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataGoogleSiteVerificationTokenTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_site_verification_token google_site_verification_token}
*/
export declare class DataGoogleSiteVerificationToken extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_site_verification_token";
    /**
    * Generates CDKTN code for importing a DataGoogleSiteVerificationToken resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleSiteVerificationToken to import
    * @param importFromId The id of the existing DataGoogleSiteVerificationToken that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_site_verification_token#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleSiteVerificationToken to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_site_verification_token google_site_verification_token} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleSiteVerificationTokenConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleSiteVerificationTokenConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identifier?;
    get identifier(): string;
    set identifier(value: string);
    get identifierInput(): string | undefined;
    get token(): string;
    private _type?;
    get type(): string;
    set type(value: string);
    get typeInput(): string | undefined;
    private _verificationMethod?;
    get verificationMethod(): string;
    set verificationMethod(value: string);
    get verificationMethodInput(): string | undefined;
    private _timeouts;
    get timeouts(): DataGoogleSiteVerificationTokenTimeoutsOutputReference;
    putTimeouts(value: DataGoogleSiteVerificationTokenTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataGoogleSiteVerificationTokenTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
