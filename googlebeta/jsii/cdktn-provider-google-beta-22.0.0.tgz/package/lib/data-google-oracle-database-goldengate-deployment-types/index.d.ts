/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleOracleDatabaseGoldengateDeploymentTypesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_goldengate_deployment_types#id DataGoogleOracleDatabaseGoldengateDeploymentTypes#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_goldengate_deployment_types#location DataGoogleOracleDatabaseGoldengateDeploymentTypes#location}
    */
    readonly location: string;
    /**
    * The ID of the project in which the resource is located. If it is not provided, the provider project is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_goldengate_deployment_types#project DataGoogleOracleDatabaseGoldengateDeploymentTypes#project}
    */
    readonly project?: string;
}
export interface DataGoogleOracleDatabaseGoldengateDeploymentTypesGoldengateDeploymentTypes {
}
export declare function dataGoogleOracleDatabaseGoldengateDeploymentTypesGoldengateDeploymentTypesToTerraform(struct?: DataGoogleOracleDatabaseGoldengateDeploymentTypesGoldengateDeploymentTypes): any;
export declare function dataGoogleOracleDatabaseGoldengateDeploymentTypesGoldengateDeploymentTypesToHclTerraform(struct?: DataGoogleOracleDatabaseGoldengateDeploymentTypesGoldengateDeploymentTypes): any;
export declare class DataGoogleOracleDatabaseGoldengateDeploymentTypesGoldengateDeploymentTypesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseGoldengateDeploymentTypesGoldengateDeploymentTypes | undefined;
    set internalValue(value: DataGoogleOracleDatabaseGoldengateDeploymentTypesGoldengateDeploymentTypes | undefined);
    get category(): string;
    get connectionTypes(): string[];
    get defaultUsername(): string;
    get deploymentType(): string;
    get displayName(): string;
    get name(): string;
    get oggVersion(): string;
    get sourceTechnologies(): string[];
    get supportedCapabilities(): string[];
    get supportedTechnologiesUrl(): string;
    get targetTechnologies(): string[];
}
export declare class DataGoogleOracleDatabaseGoldengateDeploymentTypesGoldengateDeploymentTypesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseGoldengateDeploymentTypesGoldengateDeploymentTypesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_goldengate_deployment_types google_oracle_database_goldengate_deployment_types}
*/
export declare class DataGoogleOracleDatabaseGoldengateDeploymentTypes extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_oracle_database_goldengate_deployment_types";
    /**
    * Generates CDKTN code for importing a DataGoogleOracleDatabaseGoldengateDeploymentTypes resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleOracleDatabaseGoldengateDeploymentTypes to import
    * @param importFromId The id of the existing DataGoogleOracleDatabaseGoldengateDeploymentTypes that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_goldengate_deployment_types#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleOracleDatabaseGoldengateDeploymentTypes to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_goldengate_deployment_types google_oracle_database_goldengate_deployment_types} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleOracleDatabaseGoldengateDeploymentTypesConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleOracleDatabaseGoldengateDeploymentTypesConfig);
    private _goldengateDeploymentTypes;
    get goldengateDeploymentTypes(): DataGoogleOracleDatabaseGoldengateDeploymentTypesGoldengateDeploymentTypesList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
