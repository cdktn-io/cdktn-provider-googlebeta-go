/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleCloudIdentityPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_identity_policy#id DataGoogleCloudIdentityPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The resource name of the policy to retrieve.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_identity_policy#name DataGoogleCloudIdentityPolicy#name}
    */
    readonly name: string;
}
export interface DataGoogleCloudIdentityPolicyPolicyQuery {
}
export declare function dataGoogleCloudIdentityPolicyPolicyQueryToTerraform(struct?: DataGoogleCloudIdentityPolicyPolicyQuery): any;
export declare function dataGoogleCloudIdentityPolicyPolicyQueryToHclTerraform(struct?: DataGoogleCloudIdentityPolicyPolicyQuery): any;
export declare class DataGoogleCloudIdentityPolicyPolicyQueryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudIdentityPolicyPolicyQuery | undefined;
    set internalValue(value: DataGoogleCloudIdentityPolicyPolicyQuery | undefined);
    get group(): string;
    get orgUnit(): string;
    get query(): string;
    get sortOrder(): number;
}
export declare class DataGoogleCloudIdentityPolicyPolicyQueryList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudIdentityPolicyPolicyQueryOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_identity_policy google_cloud_identity_policy}
*/
export declare class DataGoogleCloudIdentityPolicy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_cloud_identity_policy";
    /**
    * Generates CDKTN code for importing a DataGoogleCloudIdentityPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleCloudIdentityPolicy to import
    * @param importFromId The id of the existing DataGoogleCloudIdentityPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_identity_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleCloudIdentityPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_identity_policy google_cloud_identity_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleCloudIdentityPolicyConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleCloudIdentityPolicyConfig);
    get customer(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _policyQuery;
    get policyQuery(): DataGoogleCloudIdentityPolicyPolicyQueryList;
    get setting(): string;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
