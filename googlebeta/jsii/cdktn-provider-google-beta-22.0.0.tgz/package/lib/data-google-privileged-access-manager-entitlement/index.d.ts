/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGooglePrivilegedAccessManagerEntitlementConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID to use for this Entitlement. This will become the last part of the resource name.
    * This value should be 4-63 characters, and valid characters are "[a-z]", "[0-9]", and "-". The first character should be from [a-z].
    * This value should be unique among all other Entitlements under the specified 'parent'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_privileged_access_manager_entitlement#entitlement_id DataGooglePrivilegedAccessManagerEntitlement#entitlement_id}
    */
    readonly entitlementId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_privileged_access_manager_entitlement#id DataGooglePrivilegedAccessManagerEntitlement#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The region of the Entitlement resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_privileged_access_manager_entitlement#location DataGooglePrivilegedAccessManagerEntitlement#location}
    */
    readonly location?: string;
    /**
    * Format: projects/{project-id|project-number} or organizations/{organization-number} or folders/{folder-number}
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_privileged_access_manager_entitlement#parent DataGooglePrivilegedAccessManagerEntitlement#parent}
    */
    readonly parent?: string;
}
export interface DataGooglePrivilegedAccessManagerEntitlementAdditionalNotificationTargets {
}
export declare function dataGooglePrivilegedAccessManagerEntitlementAdditionalNotificationTargetsToTerraform(struct?: DataGooglePrivilegedAccessManagerEntitlementAdditionalNotificationTargets): any;
export declare function dataGooglePrivilegedAccessManagerEntitlementAdditionalNotificationTargetsToHclTerraform(struct?: DataGooglePrivilegedAccessManagerEntitlementAdditionalNotificationTargets): any;
export declare class DataGooglePrivilegedAccessManagerEntitlementAdditionalNotificationTargetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivilegedAccessManagerEntitlementAdditionalNotificationTargets | undefined;
    set internalValue(value: DataGooglePrivilegedAccessManagerEntitlementAdditionalNotificationTargets | undefined);
    get adminEmailRecipients(): string[];
    get requesterEmailRecipients(): string[];
}
export declare class DataGooglePrivilegedAccessManagerEntitlementAdditionalNotificationTargetsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivilegedAccessManagerEntitlementAdditionalNotificationTargetsOutputReference;
}
export interface DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsStepsApprovers {
}
export declare function dataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsStepsApproversToTerraform(struct?: DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsStepsApprovers): any;
export declare function dataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsStepsApproversToHclTerraform(struct?: DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsStepsApprovers): any;
export declare class DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsStepsApproversOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsStepsApprovers | undefined;
    set internalValue(value: DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsStepsApprovers | undefined);
    get principals(): string[];
}
export declare class DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsStepsApproversList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsStepsApproversOutputReference;
}
export interface DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsSteps {
}
export declare function dataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsStepsToTerraform(struct?: DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsSteps): any;
export declare function dataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsStepsToHclTerraform(struct?: DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsSteps): any;
export declare class DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsStepsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsSteps | undefined;
    set internalValue(value: DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsSteps | undefined);
    get approvalsNeeded(): number;
    get approverEmailRecipients(): string[];
    private _approvers;
    get approvers(): DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsStepsApproversList;
    get id(): string;
}
export declare class DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsStepsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsStepsOutputReference;
}
export interface DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovals {
}
export declare function dataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsToTerraform(struct?: DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovals): any;
export declare function dataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsToHclTerraform(struct?: DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovals): any;
export declare class DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovals | undefined;
    set internalValue(value: DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovals | undefined);
    get requireApproverJustification(): cdktn.IResolvable;
    private _steps;
    get steps(): DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsStepsList;
}
export declare class DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsOutputReference;
}
export interface DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflow {
}
export declare function dataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowToTerraform(struct?: DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflow): any;
export declare function dataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowToHclTerraform(struct?: DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflow): any;
export declare class DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflow | undefined;
    set internalValue(value: DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflow | undefined);
    private _manualApprovals;
    get manualApprovals(): DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowManualApprovalsList;
}
export declare class DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowOutputReference;
}
export interface DataGooglePrivilegedAccessManagerEntitlementEligibleUsers {
}
export declare function dataGooglePrivilegedAccessManagerEntitlementEligibleUsersToTerraform(struct?: DataGooglePrivilegedAccessManagerEntitlementEligibleUsers): any;
export declare function dataGooglePrivilegedAccessManagerEntitlementEligibleUsersToHclTerraform(struct?: DataGooglePrivilegedAccessManagerEntitlementEligibleUsers): any;
export declare class DataGooglePrivilegedAccessManagerEntitlementEligibleUsersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivilegedAccessManagerEntitlementEligibleUsers | undefined;
    set internalValue(value: DataGooglePrivilegedAccessManagerEntitlementEligibleUsers | undefined);
    get principals(): string[];
}
export declare class DataGooglePrivilegedAccessManagerEntitlementEligibleUsersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivilegedAccessManagerEntitlementEligibleUsersOutputReference;
}
export interface DataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessGcpIamAccessRoleBindings {
}
export declare function dataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessGcpIamAccessRoleBindingsToTerraform(struct?: DataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessGcpIamAccessRoleBindings): any;
export declare function dataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessGcpIamAccessRoleBindingsToHclTerraform(struct?: DataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessGcpIamAccessRoleBindings): any;
export declare class DataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessGcpIamAccessRoleBindingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessGcpIamAccessRoleBindings | undefined;
    set internalValue(value: DataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessGcpIamAccessRoleBindings | undefined);
    get conditionExpression(): string;
    get id(): string;
    get role(): string;
}
export declare class DataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessGcpIamAccessRoleBindingsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessGcpIamAccessRoleBindingsOutputReference;
}
export interface DataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessGcpIamAccess {
}
export declare function dataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessGcpIamAccessToTerraform(struct?: DataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessGcpIamAccess): any;
export declare function dataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessGcpIamAccessToHclTerraform(struct?: DataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessGcpIamAccess): any;
export declare class DataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessGcpIamAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessGcpIamAccess | undefined;
    set internalValue(value: DataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessGcpIamAccess | undefined);
    get resource(): string;
    get resourceType(): string;
    private _roleBindings;
    get roleBindings(): DataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessGcpIamAccessRoleBindingsList;
}
export declare class DataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessGcpIamAccessList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessGcpIamAccessOutputReference;
}
export interface DataGooglePrivilegedAccessManagerEntitlementPrivilegedAccess {
}
export declare function dataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessToTerraform(struct?: DataGooglePrivilegedAccessManagerEntitlementPrivilegedAccess): any;
export declare function dataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessToHclTerraform(struct?: DataGooglePrivilegedAccessManagerEntitlementPrivilegedAccess): any;
export declare class DataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivilegedAccessManagerEntitlementPrivilegedAccess | undefined;
    set internalValue(value: DataGooglePrivilegedAccessManagerEntitlementPrivilegedAccess | undefined);
    private _gcpIamAccess;
    get gcpIamAccess(): DataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessGcpIamAccessList;
}
export declare class DataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessOutputReference;
}
export interface DataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigNotMandatory {
}
export declare function dataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigNotMandatoryToTerraform(struct?: DataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigNotMandatory): any;
export declare function dataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigNotMandatoryToHclTerraform(struct?: DataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigNotMandatory): any;
export declare class DataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigNotMandatoryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigNotMandatory | undefined;
    set internalValue(value: DataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigNotMandatory | undefined);
}
export declare class DataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigNotMandatoryList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigNotMandatoryOutputReference;
}
export interface DataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigUnstructured {
}
export declare function dataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigUnstructuredToTerraform(struct?: DataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigUnstructured): any;
export declare function dataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigUnstructuredToHclTerraform(struct?: DataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigUnstructured): any;
export declare class DataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigUnstructuredOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigUnstructured | undefined;
    set internalValue(value: DataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigUnstructured | undefined);
}
export declare class DataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigUnstructuredList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigUnstructuredOutputReference;
}
export interface DataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfig {
}
export declare function dataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigToTerraform(struct?: DataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfig): any;
export declare function dataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigToHclTerraform(struct?: DataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfig): any;
export declare class DataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfig | undefined;
    set internalValue(value: DataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfig | undefined);
    private _notMandatory;
    get notMandatory(): DataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigNotMandatoryList;
    private _unstructured;
    get unstructured(): DataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigUnstructuredList;
}
export declare class DataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_privileged_access_manager_entitlement google_privileged_access_manager_entitlement}
*/
export declare class DataGooglePrivilegedAccessManagerEntitlement extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_privileged_access_manager_entitlement";
    /**
    * Generates CDKTN code for importing a DataGooglePrivilegedAccessManagerEntitlement resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGooglePrivilegedAccessManagerEntitlement to import
    * @param importFromId The id of the existing DataGooglePrivilegedAccessManagerEntitlement that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_privileged_access_manager_entitlement#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGooglePrivilegedAccessManagerEntitlement to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_privileged_access_manager_entitlement google_privileged_access_manager_entitlement} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGooglePrivilegedAccessManagerEntitlementConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGooglePrivilegedAccessManagerEntitlementConfig);
    private _additionalNotificationTargets;
    get additionalNotificationTargets(): DataGooglePrivilegedAccessManagerEntitlementAdditionalNotificationTargetsList;
    private _approvalWorkflow;
    get approvalWorkflow(): DataGooglePrivilegedAccessManagerEntitlementApprovalWorkflowList;
    get createTime(): string;
    get deletionPolicy(): string;
    private _eligibleUsers;
    get eligibleUsers(): DataGooglePrivilegedAccessManagerEntitlementEligibleUsersList;
    private _entitlementId?;
    get entitlementId(): string;
    set entitlementId(value: string);
    resetEntitlementId(): void;
    get entitlementIdInput(): string | undefined;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    get maxRequestDuration(): string;
    get name(): string;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    resetParent(): void;
    get parentInput(): string | undefined;
    private _privilegedAccess;
    get privilegedAccess(): DataGooglePrivilegedAccessManagerEntitlementPrivilegedAccessList;
    private _requesterJustificationConfig;
    get requesterJustificationConfig(): DataGooglePrivilegedAccessManagerEntitlementRequesterJustificationConfigList;
    get state(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
