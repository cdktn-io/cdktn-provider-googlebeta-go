/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleAlloydbClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the alloydb cluster.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_alloydb_cluster#cluster_id DataGoogleAlloydbCluster#cluster_id}
    */
    readonly clusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_alloydb_cluster#id DataGoogleAlloydbCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location where the alloydb cluster should reside.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_alloydb_cluster#location DataGoogleAlloydbCluster#location}
    */
    readonly location?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_alloydb_cluster#project DataGoogleAlloydbCluster#project}
    */
    readonly project?: string;
}
export interface DataGoogleAlloydbClusterAutomatedBackupPolicyEncryptionConfig {
}
export declare function dataGoogleAlloydbClusterAutomatedBackupPolicyEncryptionConfigToTerraform(struct?: DataGoogleAlloydbClusterAutomatedBackupPolicyEncryptionConfig): any;
export declare function dataGoogleAlloydbClusterAutomatedBackupPolicyEncryptionConfigToHclTerraform(struct?: DataGoogleAlloydbClusterAutomatedBackupPolicyEncryptionConfig): any;
export declare class DataGoogleAlloydbClusterAutomatedBackupPolicyEncryptionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterAutomatedBackupPolicyEncryptionConfig | undefined;
    set internalValue(value: DataGoogleAlloydbClusterAutomatedBackupPolicyEncryptionConfig | undefined);
    get kmsKeyName(): string;
}
export declare class DataGoogleAlloydbClusterAutomatedBackupPolicyEncryptionConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterAutomatedBackupPolicyEncryptionConfigOutputReference;
}
export interface DataGoogleAlloydbClusterAutomatedBackupPolicyQuantityBasedRetention {
}
export declare function dataGoogleAlloydbClusterAutomatedBackupPolicyQuantityBasedRetentionToTerraform(struct?: DataGoogleAlloydbClusterAutomatedBackupPolicyQuantityBasedRetention): any;
export declare function dataGoogleAlloydbClusterAutomatedBackupPolicyQuantityBasedRetentionToHclTerraform(struct?: DataGoogleAlloydbClusterAutomatedBackupPolicyQuantityBasedRetention): any;
export declare class DataGoogleAlloydbClusterAutomatedBackupPolicyQuantityBasedRetentionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterAutomatedBackupPolicyQuantityBasedRetention | undefined;
    set internalValue(value: DataGoogleAlloydbClusterAutomatedBackupPolicyQuantityBasedRetention | undefined);
    get count(): number;
}
export declare class DataGoogleAlloydbClusterAutomatedBackupPolicyQuantityBasedRetentionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterAutomatedBackupPolicyQuantityBasedRetentionOutputReference;
}
export interface DataGoogleAlloydbClusterAutomatedBackupPolicyTimeBasedRetention {
}
export declare function dataGoogleAlloydbClusterAutomatedBackupPolicyTimeBasedRetentionToTerraform(struct?: DataGoogleAlloydbClusterAutomatedBackupPolicyTimeBasedRetention): any;
export declare function dataGoogleAlloydbClusterAutomatedBackupPolicyTimeBasedRetentionToHclTerraform(struct?: DataGoogleAlloydbClusterAutomatedBackupPolicyTimeBasedRetention): any;
export declare class DataGoogleAlloydbClusterAutomatedBackupPolicyTimeBasedRetentionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterAutomatedBackupPolicyTimeBasedRetention | undefined;
    set internalValue(value: DataGoogleAlloydbClusterAutomatedBackupPolicyTimeBasedRetention | undefined);
    get retentionPeriod(): string;
}
export declare class DataGoogleAlloydbClusterAutomatedBackupPolicyTimeBasedRetentionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterAutomatedBackupPolicyTimeBasedRetentionOutputReference;
}
export interface DataGoogleAlloydbClusterAutomatedBackupPolicyWeeklyScheduleStartTimes {
}
export declare function dataGoogleAlloydbClusterAutomatedBackupPolicyWeeklyScheduleStartTimesToTerraform(struct?: DataGoogleAlloydbClusterAutomatedBackupPolicyWeeklyScheduleStartTimes): any;
export declare function dataGoogleAlloydbClusterAutomatedBackupPolicyWeeklyScheduleStartTimesToHclTerraform(struct?: DataGoogleAlloydbClusterAutomatedBackupPolicyWeeklyScheduleStartTimes): any;
export declare class DataGoogleAlloydbClusterAutomatedBackupPolicyWeeklyScheduleStartTimesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterAutomatedBackupPolicyWeeklyScheduleStartTimes | undefined;
    set internalValue(value: DataGoogleAlloydbClusterAutomatedBackupPolicyWeeklyScheduleStartTimes | undefined);
    get hours(): number;
    get minutes(): number;
    get nanos(): number;
    get seconds(): number;
}
export declare class DataGoogleAlloydbClusterAutomatedBackupPolicyWeeklyScheduleStartTimesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterAutomatedBackupPolicyWeeklyScheduleStartTimesOutputReference;
}
export interface DataGoogleAlloydbClusterAutomatedBackupPolicyWeeklySchedule {
}
export declare function dataGoogleAlloydbClusterAutomatedBackupPolicyWeeklyScheduleToTerraform(struct?: DataGoogleAlloydbClusterAutomatedBackupPolicyWeeklySchedule): any;
export declare function dataGoogleAlloydbClusterAutomatedBackupPolicyWeeklyScheduleToHclTerraform(struct?: DataGoogleAlloydbClusterAutomatedBackupPolicyWeeklySchedule): any;
export declare class DataGoogleAlloydbClusterAutomatedBackupPolicyWeeklyScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterAutomatedBackupPolicyWeeklySchedule | undefined;
    set internalValue(value: DataGoogleAlloydbClusterAutomatedBackupPolicyWeeklySchedule | undefined);
    get daysOfWeek(): string[];
    private _startTimes;
    get startTimes(): DataGoogleAlloydbClusterAutomatedBackupPolicyWeeklyScheduleStartTimesList;
}
export declare class DataGoogleAlloydbClusterAutomatedBackupPolicyWeeklyScheduleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterAutomatedBackupPolicyWeeklyScheduleOutputReference;
}
export interface DataGoogleAlloydbClusterAutomatedBackupPolicy {
}
export declare function dataGoogleAlloydbClusterAutomatedBackupPolicyToTerraform(struct?: DataGoogleAlloydbClusterAutomatedBackupPolicy): any;
export declare function dataGoogleAlloydbClusterAutomatedBackupPolicyToHclTerraform(struct?: DataGoogleAlloydbClusterAutomatedBackupPolicy): any;
export declare class DataGoogleAlloydbClusterAutomatedBackupPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterAutomatedBackupPolicy | undefined;
    set internalValue(value: DataGoogleAlloydbClusterAutomatedBackupPolicy | undefined);
    get backupWindow(): string;
    get enabled(): cdktn.IResolvable;
    private _encryptionConfig;
    get encryptionConfig(): DataGoogleAlloydbClusterAutomatedBackupPolicyEncryptionConfigList;
    private _labels;
    get labels(): cdktn.StringMap;
    get location(): string;
    private _quantityBasedRetention;
    get quantityBasedRetention(): DataGoogleAlloydbClusterAutomatedBackupPolicyQuantityBasedRetentionList;
    private _timeBasedRetention;
    get timeBasedRetention(): DataGoogleAlloydbClusterAutomatedBackupPolicyTimeBasedRetentionList;
    private _weeklySchedule;
    get weeklySchedule(): DataGoogleAlloydbClusterAutomatedBackupPolicyWeeklyScheduleList;
}
export declare class DataGoogleAlloydbClusterAutomatedBackupPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterAutomatedBackupPolicyOutputReference;
}
export interface DataGoogleAlloydbClusterBackupSource {
}
export declare function dataGoogleAlloydbClusterBackupSourceToTerraform(struct?: DataGoogleAlloydbClusterBackupSource): any;
export declare function dataGoogleAlloydbClusterBackupSourceToHclTerraform(struct?: DataGoogleAlloydbClusterBackupSource): any;
export declare class DataGoogleAlloydbClusterBackupSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterBackupSource | undefined;
    set internalValue(value: DataGoogleAlloydbClusterBackupSource | undefined);
    get backupName(): string;
}
export declare class DataGoogleAlloydbClusterBackupSourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterBackupSourceOutputReference;
}
export interface DataGoogleAlloydbClusterBackupdrBackupSource {
}
export declare function dataGoogleAlloydbClusterBackupdrBackupSourceToTerraform(struct?: DataGoogleAlloydbClusterBackupdrBackupSource): any;
export declare function dataGoogleAlloydbClusterBackupdrBackupSourceToHclTerraform(struct?: DataGoogleAlloydbClusterBackupdrBackupSource): any;
export declare class DataGoogleAlloydbClusterBackupdrBackupSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterBackupdrBackupSource | undefined;
    set internalValue(value: DataGoogleAlloydbClusterBackupdrBackupSource | undefined);
    get backup(): string;
}
export declare class DataGoogleAlloydbClusterBackupdrBackupSourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterBackupdrBackupSourceOutputReference;
}
export interface DataGoogleAlloydbClusterContinuousBackupConfigEncryptionConfig {
}
export declare function dataGoogleAlloydbClusterContinuousBackupConfigEncryptionConfigToTerraform(struct?: DataGoogleAlloydbClusterContinuousBackupConfigEncryptionConfig): any;
export declare function dataGoogleAlloydbClusterContinuousBackupConfigEncryptionConfigToHclTerraform(struct?: DataGoogleAlloydbClusterContinuousBackupConfigEncryptionConfig): any;
export declare class DataGoogleAlloydbClusterContinuousBackupConfigEncryptionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterContinuousBackupConfigEncryptionConfig | undefined;
    set internalValue(value: DataGoogleAlloydbClusterContinuousBackupConfigEncryptionConfig | undefined);
    get kmsKeyName(): string;
}
export declare class DataGoogleAlloydbClusterContinuousBackupConfigEncryptionConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterContinuousBackupConfigEncryptionConfigOutputReference;
}
export interface DataGoogleAlloydbClusterContinuousBackupConfig {
}
export declare function dataGoogleAlloydbClusterContinuousBackupConfigToTerraform(struct?: DataGoogleAlloydbClusterContinuousBackupConfig): any;
export declare function dataGoogleAlloydbClusterContinuousBackupConfigToHclTerraform(struct?: DataGoogleAlloydbClusterContinuousBackupConfig): any;
export declare class DataGoogleAlloydbClusterContinuousBackupConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterContinuousBackupConfig | undefined;
    set internalValue(value: DataGoogleAlloydbClusterContinuousBackupConfig | undefined);
    get enabled(): cdktn.IResolvable;
    private _encryptionConfig;
    get encryptionConfig(): DataGoogleAlloydbClusterContinuousBackupConfigEncryptionConfigList;
    get recoveryWindowDays(): number;
}
export declare class DataGoogleAlloydbClusterContinuousBackupConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterContinuousBackupConfigOutputReference;
}
export interface DataGoogleAlloydbClusterContinuousBackupInfoEncryptionInfo {
}
export declare function dataGoogleAlloydbClusterContinuousBackupInfoEncryptionInfoToTerraform(struct?: DataGoogleAlloydbClusterContinuousBackupInfoEncryptionInfo): any;
export declare function dataGoogleAlloydbClusterContinuousBackupInfoEncryptionInfoToHclTerraform(struct?: DataGoogleAlloydbClusterContinuousBackupInfoEncryptionInfo): any;
export declare class DataGoogleAlloydbClusterContinuousBackupInfoEncryptionInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterContinuousBackupInfoEncryptionInfo | undefined;
    set internalValue(value: DataGoogleAlloydbClusterContinuousBackupInfoEncryptionInfo | undefined);
    get encryptionType(): string;
    get kmsKeyVersions(): string[];
}
export declare class DataGoogleAlloydbClusterContinuousBackupInfoEncryptionInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterContinuousBackupInfoEncryptionInfoOutputReference;
}
export interface DataGoogleAlloydbClusterContinuousBackupInfo {
}
export declare function dataGoogleAlloydbClusterContinuousBackupInfoToTerraform(struct?: DataGoogleAlloydbClusterContinuousBackupInfo): any;
export declare function dataGoogleAlloydbClusterContinuousBackupInfoToHclTerraform(struct?: DataGoogleAlloydbClusterContinuousBackupInfo): any;
export declare class DataGoogleAlloydbClusterContinuousBackupInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterContinuousBackupInfo | undefined;
    set internalValue(value: DataGoogleAlloydbClusterContinuousBackupInfo | undefined);
    get earliestRestorableTime(): string;
    get enabledTime(): string;
    private _encryptionInfo;
    get encryptionInfo(): DataGoogleAlloydbClusterContinuousBackupInfoEncryptionInfoList;
    get schedule(): string[];
}
export declare class DataGoogleAlloydbClusterContinuousBackupInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterContinuousBackupInfoOutputReference;
}
export interface DataGoogleAlloydbClusterDataplexConfig {
}
export declare function dataGoogleAlloydbClusterDataplexConfigToTerraform(struct?: DataGoogleAlloydbClusterDataplexConfig): any;
export declare function dataGoogleAlloydbClusterDataplexConfigToHclTerraform(struct?: DataGoogleAlloydbClusterDataplexConfig): any;
export declare class DataGoogleAlloydbClusterDataplexConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterDataplexConfig | undefined;
    set internalValue(value: DataGoogleAlloydbClusterDataplexConfig | undefined);
    get enabled(): cdktn.IResolvable;
}
export declare class DataGoogleAlloydbClusterDataplexConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterDataplexConfigOutputReference;
}
export interface DataGoogleAlloydbClusterEncryptionConfig {
}
export declare function dataGoogleAlloydbClusterEncryptionConfigToTerraform(struct?: DataGoogleAlloydbClusterEncryptionConfig): any;
export declare function dataGoogleAlloydbClusterEncryptionConfigToHclTerraform(struct?: DataGoogleAlloydbClusterEncryptionConfig): any;
export declare class DataGoogleAlloydbClusterEncryptionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterEncryptionConfig | undefined;
    set internalValue(value: DataGoogleAlloydbClusterEncryptionConfig | undefined);
    get kmsKeyName(): string;
}
export declare class DataGoogleAlloydbClusterEncryptionConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterEncryptionConfigOutputReference;
}
export interface DataGoogleAlloydbClusterEncryptionInfo {
}
export declare function dataGoogleAlloydbClusterEncryptionInfoToTerraform(struct?: DataGoogleAlloydbClusterEncryptionInfo): any;
export declare function dataGoogleAlloydbClusterEncryptionInfoToHclTerraform(struct?: DataGoogleAlloydbClusterEncryptionInfo): any;
export declare class DataGoogleAlloydbClusterEncryptionInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterEncryptionInfo | undefined;
    set internalValue(value: DataGoogleAlloydbClusterEncryptionInfo | undefined);
    get encryptionType(): string;
    get kmsKeyVersions(): string[];
}
export declare class DataGoogleAlloydbClusterEncryptionInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterEncryptionInfoOutputReference;
}
export interface DataGoogleAlloydbClusterInitialUser {
}
export declare function dataGoogleAlloydbClusterInitialUserToTerraform(struct?: DataGoogleAlloydbClusterInitialUser): any;
export declare function dataGoogleAlloydbClusterInitialUserToHclTerraform(struct?: DataGoogleAlloydbClusterInitialUser): any;
export declare class DataGoogleAlloydbClusterInitialUserOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterInitialUser | undefined;
    set internalValue(value: DataGoogleAlloydbClusterInitialUser | undefined);
    get password(): string;
    get passwordWo(): string;
    get passwordWoVersion(): string;
    get user(): string;
}
export declare class DataGoogleAlloydbClusterInitialUserList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterInitialUserOutputReference;
}
export interface DataGoogleAlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsStartTime {
}
export declare function dataGoogleAlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsStartTimeToTerraform(struct?: DataGoogleAlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsStartTime): any;
export declare function dataGoogleAlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsStartTimeToHclTerraform(struct?: DataGoogleAlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsStartTime): any;
export declare class DataGoogleAlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsStartTime | undefined;
    set internalValue(value: DataGoogleAlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsStartTime | undefined);
    get hours(): number;
    get minutes(): number;
    get nanos(): number;
    get seconds(): number;
}
export declare class DataGoogleAlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsStartTimeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsStartTimeOutputReference;
}
export interface DataGoogleAlloydbClusterMaintenanceUpdatePolicyMaintenanceWindows {
}
export declare function dataGoogleAlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsToTerraform(struct?: DataGoogleAlloydbClusterMaintenanceUpdatePolicyMaintenanceWindows): any;
export declare function dataGoogleAlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsToHclTerraform(struct?: DataGoogleAlloydbClusterMaintenanceUpdatePolicyMaintenanceWindows): any;
export declare class DataGoogleAlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterMaintenanceUpdatePolicyMaintenanceWindows | undefined;
    set internalValue(value: DataGoogleAlloydbClusterMaintenanceUpdatePolicyMaintenanceWindows | undefined);
    get day(): string;
    private _startTime;
    get startTime(): DataGoogleAlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsStartTimeList;
}
export declare class DataGoogleAlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsOutputReference;
}
export interface DataGoogleAlloydbClusterMaintenanceUpdatePolicy {
}
export declare function dataGoogleAlloydbClusterMaintenanceUpdatePolicyToTerraform(struct?: DataGoogleAlloydbClusterMaintenanceUpdatePolicy): any;
export declare function dataGoogleAlloydbClusterMaintenanceUpdatePolicyToHclTerraform(struct?: DataGoogleAlloydbClusterMaintenanceUpdatePolicy): any;
export declare class DataGoogleAlloydbClusterMaintenanceUpdatePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterMaintenanceUpdatePolicy | undefined;
    set internalValue(value: DataGoogleAlloydbClusterMaintenanceUpdatePolicy | undefined);
    private _maintenanceWindows;
    get maintenanceWindows(): DataGoogleAlloydbClusterMaintenanceUpdatePolicyMaintenanceWindowsList;
}
export declare class DataGoogleAlloydbClusterMaintenanceUpdatePolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterMaintenanceUpdatePolicyOutputReference;
}
export interface DataGoogleAlloydbClusterMigrationSource {
}
export declare function dataGoogleAlloydbClusterMigrationSourceToTerraform(struct?: DataGoogleAlloydbClusterMigrationSource): any;
export declare function dataGoogleAlloydbClusterMigrationSourceToHclTerraform(struct?: DataGoogleAlloydbClusterMigrationSource): any;
export declare class DataGoogleAlloydbClusterMigrationSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterMigrationSource | undefined;
    set internalValue(value: DataGoogleAlloydbClusterMigrationSource | undefined);
    get hostPort(): string;
    get referenceId(): string;
    get sourceType(): string;
}
export declare class DataGoogleAlloydbClusterMigrationSourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterMigrationSourceOutputReference;
}
export interface DataGoogleAlloydbClusterNetworkConfig {
}
export declare function dataGoogleAlloydbClusterNetworkConfigToTerraform(struct?: DataGoogleAlloydbClusterNetworkConfig): any;
export declare function dataGoogleAlloydbClusterNetworkConfigToHclTerraform(struct?: DataGoogleAlloydbClusterNetworkConfig): any;
export declare class DataGoogleAlloydbClusterNetworkConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterNetworkConfig | undefined;
    set internalValue(value: DataGoogleAlloydbClusterNetworkConfig | undefined);
    get allocatedIpRange(): string;
    get network(): string;
}
export declare class DataGoogleAlloydbClusterNetworkConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterNetworkConfigOutputReference;
}
export interface DataGoogleAlloydbClusterPscConfig {
}
export declare function dataGoogleAlloydbClusterPscConfigToTerraform(struct?: DataGoogleAlloydbClusterPscConfig): any;
export declare function dataGoogleAlloydbClusterPscConfigToHclTerraform(struct?: DataGoogleAlloydbClusterPscConfig): any;
export declare class DataGoogleAlloydbClusterPscConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterPscConfig | undefined;
    set internalValue(value: DataGoogleAlloydbClusterPscConfig | undefined);
    get pscEnabled(): cdktn.IResolvable;
    get serviceOwnedProjectNumber(): number;
}
export declare class DataGoogleAlloydbClusterPscConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterPscConfigOutputReference;
}
export interface DataGoogleAlloydbClusterRestoreBackupSource {
}
export declare function dataGoogleAlloydbClusterRestoreBackupSourceToTerraform(struct?: DataGoogleAlloydbClusterRestoreBackupSource): any;
export declare function dataGoogleAlloydbClusterRestoreBackupSourceToHclTerraform(struct?: DataGoogleAlloydbClusterRestoreBackupSource): any;
export declare class DataGoogleAlloydbClusterRestoreBackupSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterRestoreBackupSource | undefined;
    set internalValue(value: DataGoogleAlloydbClusterRestoreBackupSource | undefined);
    get backupName(): string;
}
export declare class DataGoogleAlloydbClusterRestoreBackupSourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterRestoreBackupSourceOutputReference;
}
export interface DataGoogleAlloydbClusterRestoreBackupdrBackupSource {
}
export declare function dataGoogleAlloydbClusterRestoreBackupdrBackupSourceToTerraform(struct?: DataGoogleAlloydbClusterRestoreBackupdrBackupSource): any;
export declare function dataGoogleAlloydbClusterRestoreBackupdrBackupSourceToHclTerraform(struct?: DataGoogleAlloydbClusterRestoreBackupdrBackupSource): any;
export declare class DataGoogleAlloydbClusterRestoreBackupdrBackupSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterRestoreBackupdrBackupSource | undefined;
    set internalValue(value: DataGoogleAlloydbClusterRestoreBackupdrBackupSource | undefined);
    get backup(): string;
}
export declare class DataGoogleAlloydbClusterRestoreBackupdrBackupSourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterRestoreBackupdrBackupSourceOutputReference;
}
export interface DataGoogleAlloydbClusterRestoreBackupdrPitrSource {
}
export declare function dataGoogleAlloydbClusterRestoreBackupdrPitrSourceToTerraform(struct?: DataGoogleAlloydbClusterRestoreBackupdrPitrSource): any;
export declare function dataGoogleAlloydbClusterRestoreBackupdrPitrSourceToHclTerraform(struct?: DataGoogleAlloydbClusterRestoreBackupdrPitrSource): any;
export declare class DataGoogleAlloydbClusterRestoreBackupdrPitrSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterRestoreBackupdrPitrSource | undefined;
    set internalValue(value: DataGoogleAlloydbClusterRestoreBackupdrPitrSource | undefined);
    get dataSource(): string;
    get pointInTime(): string;
}
export declare class DataGoogleAlloydbClusterRestoreBackupdrPitrSourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterRestoreBackupdrPitrSourceOutputReference;
}
export interface DataGoogleAlloydbClusterRestoreContinuousBackupSource {
}
export declare function dataGoogleAlloydbClusterRestoreContinuousBackupSourceToTerraform(struct?: DataGoogleAlloydbClusterRestoreContinuousBackupSource): any;
export declare function dataGoogleAlloydbClusterRestoreContinuousBackupSourceToHclTerraform(struct?: DataGoogleAlloydbClusterRestoreContinuousBackupSource): any;
export declare class DataGoogleAlloydbClusterRestoreContinuousBackupSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterRestoreContinuousBackupSource | undefined;
    set internalValue(value: DataGoogleAlloydbClusterRestoreContinuousBackupSource | undefined);
    get cluster(): string;
    get pointInTime(): string;
}
export declare class DataGoogleAlloydbClusterRestoreContinuousBackupSourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterRestoreContinuousBackupSourceOutputReference;
}
export interface DataGoogleAlloydbClusterSecondaryConfig {
}
export declare function dataGoogleAlloydbClusterSecondaryConfigToTerraform(struct?: DataGoogleAlloydbClusterSecondaryConfig): any;
export declare function dataGoogleAlloydbClusterSecondaryConfigToHclTerraform(struct?: DataGoogleAlloydbClusterSecondaryConfig): any;
export declare class DataGoogleAlloydbClusterSecondaryConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterSecondaryConfig | undefined;
    set internalValue(value: DataGoogleAlloydbClusterSecondaryConfig | undefined);
    get primaryClusterName(): string;
}
export declare class DataGoogleAlloydbClusterSecondaryConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterSecondaryConfigOutputReference;
}
export interface DataGoogleAlloydbClusterTrialMetadata {
}
export declare function dataGoogleAlloydbClusterTrialMetadataToTerraform(struct?: DataGoogleAlloydbClusterTrialMetadata): any;
export declare function dataGoogleAlloydbClusterTrialMetadataToHclTerraform(struct?: DataGoogleAlloydbClusterTrialMetadata): any;
export declare class DataGoogleAlloydbClusterTrialMetadataOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAlloydbClusterTrialMetadata | undefined;
    set internalValue(value: DataGoogleAlloydbClusterTrialMetadata | undefined);
    get endTime(): string;
    get graceEndTime(): string;
    get startTime(): string;
    get upgradeTime(): string;
}
export declare class DataGoogleAlloydbClusterTrialMetadataList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAlloydbClusterTrialMetadataOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_alloydb_cluster google_alloydb_cluster}
*/
export declare class DataGoogleAlloydbCluster extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_alloydb_cluster";
    /**
    * Generates CDKTN code for importing a DataGoogleAlloydbCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleAlloydbCluster to import
    * @param importFromId The id of the existing DataGoogleAlloydbCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_alloydb_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleAlloydbCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_alloydb_cluster google_alloydb_cluster} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleAlloydbClusterConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleAlloydbClusterConfig);
    private _annotations;
    get annotations(): cdktn.StringMap;
    private _automatedBackupPolicy;
    get automatedBackupPolicy(): DataGoogleAlloydbClusterAutomatedBackupPolicyList;
    private _backupSource;
    get backupSource(): DataGoogleAlloydbClusterBackupSourceList;
    private _backupdrBackupSource;
    get backupdrBackupSource(): DataGoogleAlloydbClusterBackupdrBackupSourceList;
    private _clusterId?;
    get clusterId(): string;
    set clusterId(value: string);
    get clusterIdInput(): string | undefined;
    get clusterType(): string;
    private _continuousBackupConfig;
    get continuousBackupConfig(): DataGoogleAlloydbClusterContinuousBackupConfigList;
    private _continuousBackupInfo;
    get continuousBackupInfo(): DataGoogleAlloydbClusterContinuousBackupInfoList;
    get databaseVersion(): string;
    private _dataplexConfig;
    get dataplexConfig(): DataGoogleAlloydbClusterDataplexConfigList;
    get deletionPolicy(): string;
    get deletionProtection(): cdktn.IResolvable;
    get displayName(): string;
    private _effectiveAnnotations;
    get effectiveAnnotations(): cdktn.StringMap;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _encryptionConfig;
    get encryptionConfig(): DataGoogleAlloydbClusterEncryptionConfigList;
    private _encryptionInfo;
    get encryptionInfo(): DataGoogleAlloydbClusterEncryptionInfoList;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _initialUser;
    get initialUser(): DataGoogleAlloydbClusterInitialUserList;
    private _labels;
    get labels(): cdktn.StringMap;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _maintenanceUpdatePolicy;
    get maintenanceUpdatePolicy(): DataGoogleAlloydbClusterMaintenanceUpdatePolicyList;
    private _migrationSource;
    get migrationSource(): DataGoogleAlloydbClusterMigrationSourceList;
    get name(): string;
    private _networkConfig;
    get networkConfig(): DataGoogleAlloydbClusterNetworkConfigList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _pscConfig;
    get pscConfig(): DataGoogleAlloydbClusterPscConfigList;
    get reconciling(): cdktn.IResolvable;
    private _restoreBackupSource;
    get restoreBackupSource(): DataGoogleAlloydbClusterRestoreBackupSourceList;
    private _restoreBackupdrBackupSource;
    get restoreBackupdrBackupSource(): DataGoogleAlloydbClusterRestoreBackupdrBackupSourceList;
    private _restoreBackupdrPitrSource;
    get restoreBackupdrPitrSource(): DataGoogleAlloydbClusterRestoreBackupdrPitrSourceList;
    private _restoreContinuousBackupSource;
    get restoreContinuousBackupSource(): DataGoogleAlloydbClusterRestoreContinuousBackupSourceList;
    private _secondaryConfig;
    get secondaryConfig(): DataGoogleAlloydbClusterSecondaryConfigList;
    get skipAwaitMajorVersionUpgrade(): cdktn.IResolvable;
    get state(): string;
    get subscriptionType(): string;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    private _trialMetadata;
    get trialMetadata(): DataGoogleAlloydbClusterTrialMetadataList;
    get uid(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
