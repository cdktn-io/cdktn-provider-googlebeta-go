/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleArtifactRegistryVersionsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_artifact_registry_versions#filter DataGoogleArtifactRegistryVersions#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_artifact_registry_versions#id DataGoogleArtifactRegistryVersions#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_artifact_registry_versions#location DataGoogleArtifactRegistryVersions#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_artifact_registry_versions#package_name DataGoogleArtifactRegistryVersions#package_name}
    */
    readonly packageName: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_artifact_registry_versions#project DataGoogleArtifactRegistryVersions#project}
    */
    readonly project?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_artifact_registry_versions#repository_id DataGoogleArtifactRegistryVersions#repository_id}
    */
    readonly repositoryId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_artifact_registry_versions#view DataGoogleArtifactRegistryVersions#view}
    */
    readonly view?: string;
}
export interface DataGoogleArtifactRegistryVersionsVersionsRelatedTags {
}
export declare function dataGoogleArtifactRegistryVersionsVersionsRelatedTagsToTerraform(struct?: DataGoogleArtifactRegistryVersionsVersionsRelatedTags): any;
export declare function dataGoogleArtifactRegistryVersionsVersionsRelatedTagsToHclTerraform(struct?: DataGoogleArtifactRegistryVersionsVersionsRelatedTags): any;
export declare class DataGoogleArtifactRegistryVersionsVersionsRelatedTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleArtifactRegistryVersionsVersionsRelatedTags | undefined;
    set internalValue(value: DataGoogleArtifactRegistryVersionsVersionsRelatedTags | undefined);
    get name(): string;
    get version(): string;
}
export declare class DataGoogleArtifactRegistryVersionsVersionsRelatedTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleArtifactRegistryVersionsVersionsRelatedTagsOutputReference;
}
export interface DataGoogleArtifactRegistryVersionsVersions {
}
export declare function dataGoogleArtifactRegistryVersionsVersionsToTerraform(struct?: DataGoogleArtifactRegistryVersionsVersions): any;
export declare function dataGoogleArtifactRegistryVersionsVersionsToHclTerraform(struct?: DataGoogleArtifactRegistryVersionsVersions): any;
export declare class DataGoogleArtifactRegistryVersionsVersionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleArtifactRegistryVersionsVersions | undefined;
    set internalValue(value: DataGoogleArtifactRegistryVersionsVersions | undefined);
    private _annotations;
    get annotations(): cdktn.StringMap;
    get createTime(): string;
    get description(): string;
    get name(): string;
    private _relatedTags;
    get relatedTags(): DataGoogleArtifactRegistryVersionsVersionsRelatedTagsList;
    get updateTime(): string;
}
export declare class DataGoogleArtifactRegistryVersionsVersionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleArtifactRegistryVersionsVersionsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_artifact_registry_versions google_artifact_registry_versions}
*/
export declare class DataGoogleArtifactRegistryVersions extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_artifact_registry_versions";
    /**
    * Generates CDKTN code for importing a DataGoogleArtifactRegistryVersions resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleArtifactRegistryVersions to import
    * @param importFromId The id of the existing DataGoogleArtifactRegistryVersions that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_artifact_registry_versions#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleArtifactRegistryVersions to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_artifact_registry_versions google_artifact_registry_versions} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleArtifactRegistryVersionsConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleArtifactRegistryVersionsConfig);
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _packageName?;
    get packageName(): string;
    set packageName(value: string);
    get packageNameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _repositoryId?;
    get repositoryId(): string;
    set repositoryId(value: string);
    get repositoryIdInput(): string | undefined;
    private _versions;
    get versions(): DataGoogleArtifactRegistryVersionsVersionsList;
    private _view?;
    get view(): string;
    set view(value: string);
    resetView(): void;
    get viewInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
