/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleLustreInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_lustre_instance#id DataGoogleLustreInstance#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the Managed Lustre instance.
    *
    * * Must contain only lowercase letters, numbers, and hyphens.
    * * Must start with a letter.
    * * Must be between 1-63 characters.
    * * Must end with a number or a letter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_lustre_instance#instance_id DataGoogleLustreInstance#instance_id}
    */
    readonly instanceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_lustre_instance#project DataGoogleLustreInstance#project}
    */
    readonly project?: string;
    /**
    * Zone of Lustre instance
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_lustre_instance#zone DataGoogleLustreInstance#zone}
    */
    readonly zone?: string;
}
export interface DataGoogleLustreInstanceAccessRulesOptionsAccessRules {
}
export declare function dataGoogleLustreInstanceAccessRulesOptionsAccessRulesToTerraform(struct?: DataGoogleLustreInstanceAccessRulesOptionsAccessRules): any;
export declare function dataGoogleLustreInstanceAccessRulesOptionsAccessRulesToHclTerraform(struct?: DataGoogleLustreInstanceAccessRulesOptionsAccessRules): any;
export declare class DataGoogleLustreInstanceAccessRulesOptionsAccessRulesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleLustreInstanceAccessRulesOptionsAccessRules | undefined;
    set internalValue(value: DataGoogleLustreInstanceAccessRulesOptionsAccessRules | undefined);
    get ipAddressRanges(): string[];
    get name(): string;
    get squashMode(): string;
}
export declare class DataGoogleLustreInstanceAccessRulesOptionsAccessRulesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleLustreInstanceAccessRulesOptionsAccessRulesOutputReference;
}
export interface DataGoogleLustreInstanceAccessRulesOptions {
}
export declare function dataGoogleLustreInstanceAccessRulesOptionsToTerraform(struct?: DataGoogleLustreInstanceAccessRulesOptions): any;
export declare function dataGoogleLustreInstanceAccessRulesOptionsToHclTerraform(struct?: DataGoogleLustreInstanceAccessRulesOptions): any;
export declare class DataGoogleLustreInstanceAccessRulesOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleLustreInstanceAccessRulesOptions | undefined;
    set internalValue(value: DataGoogleLustreInstanceAccessRulesOptions | undefined);
    private _accessRules;
    get accessRules(): DataGoogleLustreInstanceAccessRulesOptionsAccessRulesList;
    get defaultSquashGid(): number;
    get defaultSquashMode(): string;
    get defaultSquashUid(): number;
}
export declare class DataGoogleLustreInstanceAccessRulesOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleLustreInstanceAccessRulesOptionsOutputReference;
}
export interface DataGoogleLustreInstanceDynamicTierOptions {
}
export declare function dataGoogleLustreInstanceDynamicTierOptionsToTerraform(struct?: DataGoogleLustreInstanceDynamicTierOptions): any;
export declare function dataGoogleLustreInstanceDynamicTierOptionsToHclTerraform(struct?: DataGoogleLustreInstanceDynamicTierOptions): any;
export declare class DataGoogleLustreInstanceDynamicTierOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleLustreInstanceDynamicTierOptions | undefined;
    set internalValue(value: DataGoogleLustreInstanceDynamicTierOptions | undefined);
    get mode(): string;
}
export declare class DataGoogleLustreInstanceDynamicTierOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleLustreInstanceDynamicTierOptionsOutputReference;
}
export interface DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowEndDate {
}
export declare function dataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowEndDateToTerraform(struct?: DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowEndDate): any;
export declare function dataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowEndDateToHclTerraform(struct?: DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowEndDate): any;
export declare class DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowEndDateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowEndDate | undefined;
    set internalValue(value: DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowEndDate | undefined);
    get day(): number;
    get month(): number;
    get year(): number;
}
export declare class DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowEndDateList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowEndDateOutputReference;
}
export interface DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowStartDate {
}
export declare function dataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowStartDateToTerraform(struct?: DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowStartDate): any;
export declare function dataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowStartDateToHclTerraform(struct?: DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowStartDate): any;
export declare class DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowStartDateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowStartDate | undefined;
    set internalValue(value: DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowStartDate | undefined);
    get day(): number;
    get month(): number;
    get year(): number;
}
export declare class DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowStartDateList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowStartDateOutputReference;
}
export interface DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowTime {
}
export declare function dataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowTimeToTerraform(struct?: DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowTime): any;
export declare function dataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowTimeToHclTerraform(struct?: DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowTime): any;
export declare class DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowTime | undefined;
    set internalValue(value: DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowTime | undefined);
    get hours(): number;
    get minutes(): number;
    get nanos(): number;
    get seconds(): number;
}
export declare class DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowTimeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowTimeOutputReference;
}
export interface DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindow {
}
export declare function dataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowToTerraform(struct?: DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindow): any;
export declare function dataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowToHclTerraform(struct?: DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindow): any;
export declare class DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindow | undefined;
    set internalValue(value: DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindow | undefined);
    private _endDate;
    get endDate(): DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowEndDateList;
    private _startDate;
    get startDate(): DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowStartDateList;
    private _time;
    get time(): DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowTimeList;
}
export declare class DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowOutputReference;
}
export interface DataGoogleLustreInstanceMaintenancePolicyWeeklyMaintenanceWindowsStartTime {
}
export declare function dataGoogleLustreInstanceMaintenancePolicyWeeklyMaintenanceWindowsStartTimeToTerraform(struct?: DataGoogleLustreInstanceMaintenancePolicyWeeklyMaintenanceWindowsStartTime): any;
export declare function dataGoogleLustreInstanceMaintenancePolicyWeeklyMaintenanceWindowsStartTimeToHclTerraform(struct?: DataGoogleLustreInstanceMaintenancePolicyWeeklyMaintenanceWindowsStartTime): any;
export declare class DataGoogleLustreInstanceMaintenancePolicyWeeklyMaintenanceWindowsStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleLustreInstanceMaintenancePolicyWeeklyMaintenanceWindowsStartTime | undefined;
    set internalValue(value: DataGoogleLustreInstanceMaintenancePolicyWeeklyMaintenanceWindowsStartTime | undefined);
    get hours(): number;
    get minutes(): number;
    get nanos(): number;
    get seconds(): number;
}
export declare class DataGoogleLustreInstanceMaintenancePolicyWeeklyMaintenanceWindowsStartTimeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleLustreInstanceMaintenancePolicyWeeklyMaintenanceWindowsStartTimeOutputReference;
}
export interface DataGoogleLustreInstanceMaintenancePolicyWeeklyMaintenanceWindows {
}
export declare function dataGoogleLustreInstanceMaintenancePolicyWeeklyMaintenanceWindowsToTerraform(struct?: DataGoogleLustreInstanceMaintenancePolicyWeeklyMaintenanceWindows): any;
export declare function dataGoogleLustreInstanceMaintenancePolicyWeeklyMaintenanceWindowsToHclTerraform(struct?: DataGoogleLustreInstanceMaintenancePolicyWeeklyMaintenanceWindows): any;
export declare class DataGoogleLustreInstanceMaintenancePolicyWeeklyMaintenanceWindowsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleLustreInstanceMaintenancePolicyWeeklyMaintenanceWindows | undefined;
    set internalValue(value: DataGoogleLustreInstanceMaintenancePolicyWeeklyMaintenanceWindows | undefined);
    get dayOfWeek(): string;
    private _startTime;
    get startTime(): DataGoogleLustreInstanceMaintenancePolicyWeeklyMaintenanceWindowsStartTimeList;
}
export declare class DataGoogleLustreInstanceMaintenancePolicyWeeklyMaintenanceWindowsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleLustreInstanceMaintenancePolicyWeeklyMaintenanceWindowsOutputReference;
}
export interface DataGoogleLustreInstanceMaintenancePolicy {
}
export declare function dataGoogleLustreInstanceMaintenancePolicyToTerraform(struct?: DataGoogleLustreInstanceMaintenancePolicy): any;
export declare function dataGoogleLustreInstanceMaintenancePolicyToHclTerraform(struct?: DataGoogleLustreInstanceMaintenancePolicy): any;
export declare class DataGoogleLustreInstanceMaintenancePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleLustreInstanceMaintenancePolicy | undefined;
    set internalValue(value: DataGoogleLustreInstanceMaintenancePolicy | undefined);
    private _maintenanceExclusionWindow;
    get maintenanceExclusionWindow(): DataGoogleLustreInstanceMaintenancePolicyMaintenanceExclusionWindowList;
    private _weeklyMaintenanceWindows;
    get weeklyMaintenanceWindows(): DataGoogleLustreInstanceMaintenancePolicyWeeklyMaintenanceWindowsList;
}
export declare class DataGoogleLustreInstanceMaintenancePolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleLustreInstanceMaintenancePolicyOutputReference;
}
export interface DataGoogleLustreInstanceUpcomingMaintenanceSchedule {
}
export declare function dataGoogleLustreInstanceUpcomingMaintenanceScheduleToTerraform(struct?: DataGoogleLustreInstanceUpcomingMaintenanceSchedule): any;
export declare function dataGoogleLustreInstanceUpcomingMaintenanceScheduleToHclTerraform(struct?: DataGoogleLustreInstanceUpcomingMaintenanceSchedule): any;
export declare class DataGoogleLustreInstanceUpcomingMaintenanceScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleLustreInstanceUpcomingMaintenanceSchedule | undefined;
    set internalValue(value: DataGoogleLustreInstanceUpcomingMaintenanceSchedule | undefined);
    get endTime(): string;
    get startTime(): string;
}
export declare class DataGoogleLustreInstanceUpcomingMaintenanceScheduleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleLustreInstanceUpcomingMaintenanceScheduleOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_lustre_instance google_lustre_instance}
*/
export declare class DataGoogleLustreInstance extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_lustre_instance";
    /**
    * Generates CDKTN code for importing a DataGoogleLustreInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleLustreInstance to import
    * @param importFromId The id of the existing DataGoogleLustreInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_lustre_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleLustreInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_lustre_instance google_lustre_instance} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleLustreInstanceConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleLustreInstanceConfig);
    private _accessRulesOptions;
    get accessRulesOptions(): DataGoogleLustreInstanceAccessRulesOptionsList;
    get availableVersion(): string;
    get capacityGib(): string;
    get createTime(): string;
    get deletionPolicy(): string;
    get description(): string;
    private _dynamicTierOptions;
    get dynamicTierOptions(): DataGoogleLustreInstanceDynamicTierOptionsList;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get effectiveVersion(): string;
    get filesystem(): string;
    get gkeSupportEnabled(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get kmsKey(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    get location(): string;
    private _maintenancePolicy;
    get maintenancePolicy(): DataGoogleLustreInstanceMaintenancePolicyList;
    get mountPoint(): string;
    get name(): string;
    get network(): string;
    get perUnitStorageThroughput(): string;
    get placementPolicy(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get state(): string;
    get stateReason(): string;
    get targetVersion(): string;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get uid(): string;
    private _upcomingMaintenanceSchedule;
    get upcomingMaintenanceSchedule(): DataGoogleLustreInstanceUpcomingMaintenanceScheduleList;
    get updateTime(): string;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    resetZone(): void;
    get zoneInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
