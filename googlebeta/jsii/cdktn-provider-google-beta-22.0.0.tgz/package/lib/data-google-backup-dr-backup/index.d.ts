/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleBackupDrBackupConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_backup#backup_vault_id DataGoogleBackupDrBackup#backup_vault_id}
    */
    readonly backupVaultId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_backup#data_source_id DataGoogleBackupDrBackup#data_source_id}
    */
    readonly dataSourceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_backup#id DataGoogleBackupDrBackup#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_backup#location DataGoogleBackupDrBackup#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_backup#project DataGoogleBackupDrBackup#project}
    */
    readonly project: string;
}
export interface DataGoogleBackupDrBackupBackupsComputeInstanceBackupProperties {
}
export declare function dataGoogleBackupDrBackupBackupsComputeInstanceBackupPropertiesToTerraform(struct?: DataGoogleBackupDrBackupBackupsComputeInstanceBackupProperties): any;
export declare function dataGoogleBackupDrBackupBackupsComputeInstanceBackupPropertiesToHclTerraform(struct?: DataGoogleBackupDrBackupBackupsComputeInstanceBackupProperties): any;
export declare class DataGoogleBackupDrBackupBackupsComputeInstanceBackupPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrBackupBackupsComputeInstanceBackupProperties | undefined;
    set internalValue(value: DataGoogleBackupDrBackupBackupsComputeInstanceBackupProperties | undefined);
    get guestFlush(): cdktn.IResolvable;
}
export declare class DataGoogleBackupDrBackupBackupsComputeInstanceBackupPropertiesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrBackupBackupsComputeInstanceBackupPropertiesOutputReference;
}
export interface DataGoogleBackupDrBackupBackupsDiskBackupProperties {
}
export declare function dataGoogleBackupDrBackupBackupsDiskBackupPropertiesToTerraform(struct?: DataGoogleBackupDrBackupBackupsDiskBackupProperties): any;
export declare function dataGoogleBackupDrBackupBackupsDiskBackupPropertiesToHclTerraform(struct?: DataGoogleBackupDrBackupBackupsDiskBackupProperties): any;
export declare class DataGoogleBackupDrBackupBackupsDiskBackupPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrBackupBackupsDiskBackupProperties | undefined;
    set internalValue(value: DataGoogleBackupDrBackupBackupsDiskBackupProperties | undefined);
    get guestFlush(): cdktn.IResolvable;
}
export declare class DataGoogleBackupDrBackupBackupsDiskBackupPropertiesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrBackupBackupsDiskBackupPropertiesOutputReference;
}
export interface DataGoogleBackupDrBackupBackups {
}
export declare function dataGoogleBackupDrBackupBackupsToTerraform(struct?: DataGoogleBackupDrBackupBackups): any;
export declare function dataGoogleBackupDrBackupBackupsToHclTerraform(struct?: DataGoogleBackupDrBackupBackups): any;
export declare class DataGoogleBackupDrBackupBackupsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrBackupBackups | undefined;
    set internalValue(value: DataGoogleBackupDrBackupBackups | undefined);
    get backupId(): string;
    get backupVaultId(): string;
    private _computeInstanceBackupProperties;
    get computeInstanceBackupProperties(): DataGoogleBackupDrBackupBackupsComputeInstanceBackupPropertiesList;
    get createTime(): string;
    get dataSourceId(): string;
    private _diskBackupProperties;
    get diskBackupProperties(): DataGoogleBackupDrBackupBackupsDiskBackupPropertiesList;
    get location(): string;
    get name(): string;
}
export declare class DataGoogleBackupDrBackupBackupsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrBackupBackupsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_backup google_backup_dr_backup}
*/
export declare class DataGoogleBackupDrBackup extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_backup_dr_backup";
    /**
    * Generates CDKTN code for importing a DataGoogleBackupDrBackup resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleBackupDrBackup to import
    * @param importFromId The id of the existing DataGoogleBackupDrBackup that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_backup#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleBackupDrBackup to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_backup google_backup_dr_backup} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleBackupDrBackupConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleBackupDrBackupConfig);
    private _backupVaultId?;
    get backupVaultId(): string;
    set backupVaultId(value: string);
    get backupVaultIdInput(): string | undefined;
    private _backups;
    get backups(): DataGoogleBackupDrBackupBackupsList;
    get createTime(): string;
    private _dataSourceId?;
    get dataSourceId(): string;
    set dataSourceId(value: string);
    get dataSourceIdInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
