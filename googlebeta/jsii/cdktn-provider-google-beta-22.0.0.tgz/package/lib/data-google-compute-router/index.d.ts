/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleComputeRouterConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_router#id DataGoogleComputeRouter#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the resource. The name must be 1-63 characters long, and
    * comply with RFC1035. Specifically, the name must be 1-63 characters
    * long and match the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?'
    * which means the first character must be a lowercase letter, and all
    * following characters must be a dash, lowercase letter, or digit,
    * except the last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_router#name DataGoogleComputeRouter#name}
    */
    readonly name: string;
    /**
    * A reference to the network to which this router belongs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_router#network DataGoogleComputeRouter#network}
    */
    readonly network: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_router#project DataGoogleComputeRouter#project}
    */
    readonly project?: string;
    /**
    * Region where the router resides.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_router#region DataGoogleComputeRouter#region}
    */
    readonly region?: string;
}
export interface DataGoogleComputeRouterBgpAdvertisedIpRanges {
}
export declare function dataGoogleComputeRouterBgpAdvertisedIpRangesToTerraform(struct?: DataGoogleComputeRouterBgpAdvertisedIpRanges): any;
export declare function dataGoogleComputeRouterBgpAdvertisedIpRangesToHclTerraform(struct?: DataGoogleComputeRouterBgpAdvertisedIpRanges): any;
export declare class DataGoogleComputeRouterBgpAdvertisedIpRangesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRouterBgpAdvertisedIpRanges | undefined;
    set internalValue(value: DataGoogleComputeRouterBgpAdvertisedIpRanges | undefined);
    get description(): string;
    get range(): string;
}
export declare class DataGoogleComputeRouterBgpAdvertisedIpRangesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRouterBgpAdvertisedIpRangesOutputReference;
}
export interface DataGoogleComputeRouterBgp {
}
export declare function dataGoogleComputeRouterBgpToTerraform(struct?: DataGoogleComputeRouterBgp): any;
export declare function dataGoogleComputeRouterBgpToHclTerraform(struct?: DataGoogleComputeRouterBgp): any;
export declare class DataGoogleComputeRouterBgpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRouterBgp | undefined;
    set internalValue(value: DataGoogleComputeRouterBgp | undefined);
    get advertiseMode(): string;
    get advertisedGroups(): string[];
    private _advertisedIpRanges;
    get advertisedIpRanges(): DataGoogleComputeRouterBgpAdvertisedIpRangesList;
    get asn(): number;
    get identifierRange(): string;
    get keepaliveInterval(): number;
}
export declare class DataGoogleComputeRouterBgpList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRouterBgpOutputReference;
}
export interface DataGoogleComputeRouterMd5AuthenticationKeys {
}
export declare function dataGoogleComputeRouterMd5AuthenticationKeysToTerraform(struct?: DataGoogleComputeRouterMd5AuthenticationKeys): any;
export declare function dataGoogleComputeRouterMd5AuthenticationKeysToHclTerraform(struct?: DataGoogleComputeRouterMd5AuthenticationKeys): any;
export declare class DataGoogleComputeRouterMd5AuthenticationKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRouterMd5AuthenticationKeys | undefined;
    set internalValue(value: DataGoogleComputeRouterMd5AuthenticationKeys | undefined);
    get key(): string;
    get name(): string;
}
export declare class DataGoogleComputeRouterMd5AuthenticationKeysList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRouterMd5AuthenticationKeysOutputReference;
}
export interface DataGoogleComputeRouterParams {
}
export declare function dataGoogleComputeRouterParamsToTerraform(struct?: DataGoogleComputeRouterParams): any;
export declare function dataGoogleComputeRouterParamsToHclTerraform(struct?: DataGoogleComputeRouterParams): any;
export declare class DataGoogleComputeRouterParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRouterParams | undefined;
    set internalValue(value: DataGoogleComputeRouterParams | undefined);
    private _resourceManagerTags;
    get resourceManagerTags(): cdktn.StringMap;
}
export declare class DataGoogleComputeRouterParamsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRouterParamsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_router google_compute_router}
*/
export declare class DataGoogleComputeRouter extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_compute_router";
    /**
    * Generates CDKTN code for importing a DataGoogleComputeRouter resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleComputeRouter to import
    * @param importFromId The id of the existing DataGoogleComputeRouter that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_router#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleComputeRouter to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_router google_compute_router} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleComputeRouterConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleComputeRouterConfig);
    private _bgp;
    get bgp(): DataGoogleComputeRouterBgpList;
    get creationTimestamp(): string;
    get deletionPolicy(): string;
    get description(): string;
    get encryptedInterconnectRouter(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _md5AuthenticationKeys;
    get md5AuthenticationKeys(): DataGoogleComputeRouterMd5AuthenticationKeysList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get nccGateway(): string;
    private _network?;
    get network(): string;
    set network(value: string);
    get networkInput(): string | undefined;
    private _params;
    get params(): DataGoogleComputeRouterParamsList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get routerId(): number;
    get selfLink(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
