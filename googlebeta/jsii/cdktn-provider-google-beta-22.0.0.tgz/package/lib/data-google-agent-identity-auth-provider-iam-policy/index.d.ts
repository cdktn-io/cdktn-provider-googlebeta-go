/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleAgentIdentityAuthProviderIamPolicyConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_agent_identity_auth_provider_iam_policy#auth_provider_id DataGoogleAgentIdentityAuthProviderIamPolicy#auth_provider_id}
    */
    readonly authProviderId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_agent_identity_auth_provider_iam_policy#id DataGoogleAgentIdentityAuthProviderIamPolicy#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_agent_identity_auth_provider_iam_policy#location DataGoogleAgentIdentityAuthProviderIamPolicy#location}
    */
    readonly location?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_agent_identity_auth_provider_iam_policy#project DataGoogleAgentIdentityAuthProviderIamPolicy#project}
    */
    readonly project?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_agent_identity_auth_provider_iam_policy google_agent_identity_auth_provider_iam_policy}
*/
export declare class DataGoogleAgentIdentityAuthProviderIamPolicy extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_agent_identity_auth_provider_iam_policy";
    /**
    * Generates CDKTN code for importing a DataGoogleAgentIdentityAuthProviderIamPolicy resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleAgentIdentityAuthProviderIamPolicy to import
    * @param importFromId The id of the existing DataGoogleAgentIdentityAuthProviderIamPolicy that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_agent_identity_auth_provider_iam_policy#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleAgentIdentityAuthProviderIamPolicy to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_agent_identity_auth_provider_iam_policy google_agent_identity_auth_provider_iam_policy} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleAgentIdentityAuthProviderIamPolicyConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleAgentIdentityAuthProviderIamPolicyConfig);
    private _authProviderId?;
    get authProviderId(): string;
    set authProviderId(value: string);
    get authProviderIdInput(): string | undefined;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    get policyData(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
