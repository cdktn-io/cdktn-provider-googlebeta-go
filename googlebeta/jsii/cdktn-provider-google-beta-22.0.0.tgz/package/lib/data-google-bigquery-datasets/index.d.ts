/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleBigqueryDatasetsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_bigquery_datasets#id DataGoogleBigqueryDatasets#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the project in which the datasets are located. If it is not provided, the provider project is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_bigquery_datasets#project DataGoogleBigqueryDatasets#project}
    */
    readonly project?: string;
}
export interface DataGoogleBigqueryDatasetsDatasets {
}
export declare function dataGoogleBigqueryDatasetsDatasetsToTerraform(struct?: DataGoogleBigqueryDatasetsDatasets): any;
export declare function dataGoogleBigqueryDatasetsDatasetsToHclTerraform(struct?: DataGoogleBigqueryDatasetsDatasets): any;
export declare class DataGoogleBigqueryDatasetsDatasetsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBigqueryDatasetsDatasets | undefined;
    set internalValue(value: DataGoogleBigqueryDatasetsDatasets | undefined);
    get datasetId(): string;
    get friendlyName(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    get location(): string;
}
export declare class DataGoogleBigqueryDatasetsDatasetsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBigqueryDatasetsDatasetsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_bigquery_datasets google_bigquery_datasets}
*/
export declare class DataGoogleBigqueryDatasets extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_bigquery_datasets";
    /**
    * Generates CDKTN code for importing a DataGoogleBigqueryDatasets resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleBigqueryDatasets to import
    * @param importFromId The id of the existing DataGoogleBigqueryDatasets that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_bigquery_datasets#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleBigqueryDatasets to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_bigquery_datasets google_bigquery_datasets} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleBigqueryDatasetsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGoogleBigqueryDatasetsConfig);
    private _datasets;
    get datasets(): DataGoogleBigqueryDatasetsDatasetsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
