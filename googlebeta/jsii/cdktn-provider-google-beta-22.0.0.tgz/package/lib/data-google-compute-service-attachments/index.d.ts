/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleComputeServiceAttachmentsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_service_attachments#filter DataGoogleComputeServiceAttachments#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_service_attachments#id DataGoogleComputeServiceAttachments#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_service_attachments#project DataGoogleComputeServiceAttachments#project}
    */
    readonly project?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_service_attachments#region DataGoogleComputeServiceAttachments#region}
    */
    readonly region?: string;
}
export interface DataGoogleComputeServiceAttachmentsServiceAttachmentsConnectedEndpoints {
}
export declare function dataGoogleComputeServiceAttachmentsServiceAttachmentsConnectedEndpointsToTerraform(struct?: DataGoogleComputeServiceAttachmentsServiceAttachmentsConnectedEndpoints): any;
export declare function dataGoogleComputeServiceAttachmentsServiceAttachmentsConnectedEndpointsToHclTerraform(struct?: DataGoogleComputeServiceAttachmentsServiceAttachmentsConnectedEndpoints): any;
export declare class DataGoogleComputeServiceAttachmentsServiceAttachmentsConnectedEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeServiceAttachmentsServiceAttachmentsConnectedEndpoints | undefined;
    set internalValue(value: DataGoogleComputeServiceAttachmentsServiceAttachmentsConnectedEndpoints | undefined);
    get consumerNetwork(): string;
    get endpoint(): string;
    get natIps(): string[];
    get propagatedConnectionCount(): number;
    get pscConnectionId(): string;
    get status(): string;
}
export declare class DataGoogleComputeServiceAttachmentsServiceAttachmentsConnectedEndpointsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeServiceAttachmentsServiceAttachmentsConnectedEndpointsOutputReference;
}
export interface DataGoogleComputeServiceAttachmentsServiceAttachmentsConsumerAcceptLists {
}
export declare function dataGoogleComputeServiceAttachmentsServiceAttachmentsConsumerAcceptListsToTerraform(struct?: DataGoogleComputeServiceAttachmentsServiceAttachmentsConsumerAcceptLists): any;
export declare function dataGoogleComputeServiceAttachmentsServiceAttachmentsConsumerAcceptListsToHclTerraform(struct?: DataGoogleComputeServiceAttachmentsServiceAttachmentsConsumerAcceptLists): any;
export declare class DataGoogleComputeServiceAttachmentsServiceAttachmentsConsumerAcceptListsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeServiceAttachmentsServiceAttachmentsConsumerAcceptLists | undefined;
    set internalValue(value: DataGoogleComputeServiceAttachmentsServiceAttachmentsConsumerAcceptLists | undefined);
    get connectionLimit(): number;
    get endpointUrl(): string;
    get networkUrl(): string;
    get projectIdOrNum(): string;
}
export declare class DataGoogleComputeServiceAttachmentsServiceAttachmentsConsumerAcceptListsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeServiceAttachmentsServiceAttachmentsConsumerAcceptListsOutputReference;
}
export interface DataGoogleComputeServiceAttachmentsServiceAttachmentsPscServiceAttachmentId {
}
export declare function dataGoogleComputeServiceAttachmentsServiceAttachmentsPscServiceAttachmentIdToTerraform(struct?: DataGoogleComputeServiceAttachmentsServiceAttachmentsPscServiceAttachmentId): any;
export declare function dataGoogleComputeServiceAttachmentsServiceAttachmentsPscServiceAttachmentIdToHclTerraform(struct?: DataGoogleComputeServiceAttachmentsServiceAttachmentsPscServiceAttachmentId): any;
export declare class DataGoogleComputeServiceAttachmentsServiceAttachmentsPscServiceAttachmentIdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeServiceAttachmentsServiceAttachmentsPscServiceAttachmentId | undefined;
    set internalValue(value: DataGoogleComputeServiceAttachmentsServiceAttachmentsPscServiceAttachmentId | undefined);
    get high(): string;
    get low(): string;
}
export declare class DataGoogleComputeServiceAttachmentsServiceAttachmentsPscServiceAttachmentIdList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeServiceAttachmentsServiceAttachmentsPscServiceAttachmentIdOutputReference;
}
export interface DataGoogleComputeServiceAttachmentsServiceAttachmentsTunnelingConfig {
}
export declare function dataGoogleComputeServiceAttachmentsServiceAttachmentsTunnelingConfigToTerraform(struct?: DataGoogleComputeServiceAttachmentsServiceAttachmentsTunnelingConfig): any;
export declare function dataGoogleComputeServiceAttachmentsServiceAttachmentsTunnelingConfigToHclTerraform(struct?: DataGoogleComputeServiceAttachmentsServiceAttachmentsTunnelingConfig): any;
export declare class DataGoogleComputeServiceAttachmentsServiceAttachmentsTunnelingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeServiceAttachmentsServiceAttachmentsTunnelingConfig | undefined;
    set internalValue(value: DataGoogleComputeServiceAttachmentsServiceAttachmentsTunnelingConfig | undefined);
    get encapsulationProfile(): string;
    get routingMode(): string;
}
export declare class DataGoogleComputeServiceAttachmentsServiceAttachmentsTunnelingConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeServiceAttachmentsServiceAttachmentsTunnelingConfigOutputReference;
}
export interface DataGoogleComputeServiceAttachmentsServiceAttachments {
}
export declare function dataGoogleComputeServiceAttachmentsServiceAttachmentsToTerraform(struct?: DataGoogleComputeServiceAttachmentsServiceAttachments): any;
export declare function dataGoogleComputeServiceAttachmentsServiceAttachmentsToHclTerraform(struct?: DataGoogleComputeServiceAttachmentsServiceAttachments): any;
export declare class DataGoogleComputeServiceAttachmentsServiceAttachmentsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeServiceAttachmentsServiceAttachments | undefined;
    set internalValue(value: DataGoogleComputeServiceAttachmentsServiceAttachments | undefined);
    private _connectedEndpoints;
    get connectedEndpoints(): DataGoogleComputeServiceAttachmentsServiceAttachmentsConnectedEndpointsList;
    get connectionPreference(): string;
    private _consumerAcceptLists;
    get consumerAcceptLists(): DataGoogleComputeServiceAttachmentsServiceAttachmentsConsumerAcceptListsList;
    get consumerRejectLists(): string[];
    get deletionPolicy(): string;
    get description(): string;
    get domainNames(): string[];
    get enableProxyProtocol(): cdktn.IResolvable;
    get fingerprint(): string;
    get name(): string;
    get natIpsPerEndpoint(): number;
    get natSubnets(): string[];
    get project(): string;
    get propagatedConnectionLimit(): number;
    private _pscServiceAttachmentId;
    get pscServiceAttachmentId(): DataGoogleComputeServiceAttachmentsServiceAttachmentsPscServiceAttachmentIdList;
    get reconcileConnections(): cdktn.IResolvable;
    get region(): string;
    get selfLink(): string;
    get sendPropagatedConnectionLimitIfZero(): cdktn.IResolvable;
    get serviceAttachmentId(): number;
    get showNatIps(): cdktn.IResolvable;
    get targetService(): string;
    private _tunnelingConfig;
    get tunnelingConfig(): DataGoogleComputeServiceAttachmentsServiceAttachmentsTunnelingConfigList;
}
export declare class DataGoogleComputeServiceAttachmentsServiceAttachmentsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeServiceAttachmentsServiceAttachmentsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_service_attachments google_compute_service_attachments}
*/
export declare class DataGoogleComputeServiceAttachments extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_compute_service_attachments";
    /**
    * Generates CDKTN code for importing a DataGoogleComputeServiceAttachments resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleComputeServiceAttachments to import
    * @param importFromId The id of the existing DataGoogleComputeServiceAttachments that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_service_attachments#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleComputeServiceAttachments to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_service_attachments google_compute_service_attachments} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleComputeServiceAttachmentsConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGoogleComputeServiceAttachmentsConfig);
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _serviceAttachments;
    get serviceAttachments(): DataGoogleComputeServiceAttachmentsServiceAttachmentsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
