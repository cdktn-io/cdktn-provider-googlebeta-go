/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleApphubApplicationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Required. The Application identifier.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_apphub_application#application_id DataGoogleApphubApplication#application_id}
    */
    readonly applicationId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_apphub_application#id DataGoogleApphubApplication#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Part of 'parent'. See documentation of 'projectsId'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_apphub_application#location DataGoogleApphubApplication#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_apphub_application#project DataGoogleApphubApplication#project}
    */
    readonly project: string;
}
export interface DataGoogleApphubApplicationAttributesBusinessOwners {
}
export declare function dataGoogleApphubApplicationAttributesBusinessOwnersToTerraform(struct?: DataGoogleApphubApplicationAttributesBusinessOwners): any;
export declare function dataGoogleApphubApplicationAttributesBusinessOwnersToHclTerraform(struct?: DataGoogleApphubApplicationAttributesBusinessOwners): any;
export declare class DataGoogleApphubApplicationAttributesBusinessOwnersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleApphubApplicationAttributesBusinessOwners | undefined;
    set internalValue(value: DataGoogleApphubApplicationAttributesBusinessOwners | undefined);
    get displayName(): string;
    get email(): string;
}
export declare class DataGoogleApphubApplicationAttributesBusinessOwnersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleApphubApplicationAttributesBusinessOwnersOutputReference;
}
export interface DataGoogleApphubApplicationAttributesCriticality {
}
export declare function dataGoogleApphubApplicationAttributesCriticalityToTerraform(struct?: DataGoogleApphubApplicationAttributesCriticality): any;
export declare function dataGoogleApphubApplicationAttributesCriticalityToHclTerraform(struct?: DataGoogleApphubApplicationAttributesCriticality): any;
export declare class DataGoogleApphubApplicationAttributesCriticalityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleApphubApplicationAttributesCriticality | undefined;
    set internalValue(value: DataGoogleApphubApplicationAttributesCriticality | undefined);
    get type(): string;
}
export declare class DataGoogleApphubApplicationAttributesCriticalityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleApphubApplicationAttributesCriticalityOutputReference;
}
export interface DataGoogleApphubApplicationAttributesDeveloperOwners {
}
export declare function dataGoogleApphubApplicationAttributesDeveloperOwnersToTerraform(struct?: DataGoogleApphubApplicationAttributesDeveloperOwners): any;
export declare function dataGoogleApphubApplicationAttributesDeveloperOwnersToHclTerraform(struct?: DataGoogleApphubApplicationAttributesDeveloperOwners): any;
export declare class DataGoogleApphubApplicationAttributesDeveloperOwnersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleApphubApplicationAttributesDeveloperOwners | undefined;
    set internalValue(value: DataGoogleApphubApplicationAttributesDeveloperOwners | undefined);
    get displayName(): string;
    get email(): string;
}
export declare class DataGoogleApphubApplicationAttributesDeveloperOwnersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleApphubApplicationAttributesDeveloperOwnersOutputReference;
}
export interface DataGoogleApphubApplicationAttributesEnvironment {
}
export declare function dataGoogleApphubApplicationAttributesEnvironmentToTerraform(struct?: DataGoogleApphubApplicationAttributesEnvironment): any;
export declare function dataGoogleApphubApplicationAttributesEnvironmentToHclTerraform(struct?: DataGoogleApphubApplicationAttributesEnvironment): any;
export declare class DataGoogleApphubApplicationAttributesEnvironmentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleApphubApplicationAttributesEnvironment | undefined;
    set internalValue(value: DataGoogleApphubApplicationAttributesEnvironment | undefined);
    get type(): string;
}
export declare class DataGoogleApphubApplicationAttributesEnvironmentList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleApphubApplicationAttributesEnvironmentOutputReference;
}
export interface DataGoogleApphubApplicationAttributesOperatorOwners {
}
export declare function dataGoogleApphubApplicationAttributesOperatorOwnersToTerraform(struct?: DataGoogleApphubApplicationAttributesOperatorOwners): any;
export declare function dataGoogleApphubApplicationAttributesOperatorOwnersToHclTerraform(struct?: DataGoogleApphubApplicationAttributesOperatorOwners): any;
export declare class DataGoogleApphubApplicationAttributesOperatorOwnersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleApphubApplicationAttributesOperatorOwners | undefined;
    set internalValue(value: DataGoogleApphubApplicationAttributesOperatorOwners | undefined);
    get displayName(): string;
    get email(): string;
}
export declare class DataGoogleApphubApplicationAttributesOperatorOwnersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleApphubApplicationAttributesOperatorOwnersOutputReference;
}
export interface DataGoogleApphubApplicationAttributes {
}
export declare function dataGoogleApphubApplicationAttributesToTerraform(struct?: DataGoogleApphubApplicationAttributes): any;
export declare function dataGoogleApphubApplicationAttributesToHclTerraform(struct?: DataGoogleApphubApplicationAttributes): any;
export declare class DataGoogleApphubApplicationAttributesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleApphubApplicationAttributes | undefined;
    set internalValue(value: DataGoogleApphubApplicationAttributes | undefined);
    private _businessOwners;
    get businessOwners(): DataGoogleApphubApplicationAttributesBusinessOwnersList;
    private _criticality;
    get criticality(): DataGoogleApphubApplicationAttributesCriticalityList;
    private _developerOwners;
    get developerOwners(): DataGoogleApphubApplicationAttributesDeveloperOwnersList;
    private _environment;
    get environment(): DataGoogleApphubApplicationAttributesEnvironmentList;
    private _operatorOwners;
    get operatorOwners(): DataGoogleApphubApplicationAttributesOperatorOwnersList;
}
export declare class DataGoogleApphubApplicationAttributesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleApphubApplicationAttributesOutputReference;
}
export interface DataGoogleApphubApplicationScope {
}
export declare function dataGoogleApphubApplicationScopeToTerraform(struct?: DataGoogleApphubApplicationScope): any;
export declare function dataGoogleApphubApplicationScopeToHclTerraform(struct?: DataGoogleApphubApplicationScope): any;
export declare class DataGoogleApphubApplicationScopeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleApphubApplicationScope | undefined;
    set internalValue(value: DataGoogleApphubApplicationScope | undefined);
    get type(): string;
}
export declare class DataGoogleApphubApplicationScopeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleApphubApplicationScopeOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_apphub_application google_apphub_application}
*/
export declare class DataGoogleApphubApplication extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_apphub_application";
    /**
    * Generates CDKTN code for importing a DataGoogleApphubApplication resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleApphubApplication to import
    * @param importFromId The id of the existing DataGoogleApphubApplication that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_apphub_application#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleApphubApplication to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_apphub_application google_apphub_application} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleApphubApplicationConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleApphubApplicationConfig);
    private _applicationId?;
    get applicationId(): string;
    set applicationId(value: string);
    get applicationIdInput(): string | undefined;
    private _attributes;
    get attributes(): DataGoogleApphubApplicationAttributesList;
    get createTime(): string;
    get deletionPolicy(): string;
    get description(): string;
    get displayName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    get projectInput(): string | undefined;
    private _scope;
    get scope(): DataGoogleApphubApplicationScopeList;
    get state(): string;
    get uid(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
