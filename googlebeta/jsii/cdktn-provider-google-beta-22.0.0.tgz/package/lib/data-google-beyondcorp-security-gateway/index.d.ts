/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleBeyondcorpSecurityGatewayConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_beyondcorp_security_gateway#id DataGoogleBeyondcorpSecurityGateway#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_beyondcorp_security_gateway#project DataGoogleBeyondcorpSecurityGateway#project}
    */
    readonly project?: string;
    /**
    * Optional. User-settable SecurityGateway resource ID.
    * * Must start with a letter.
    * * Must contain between 4-63 characters from '/a-z-/'.
    * * Must end with a number or letter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_beyondcorp_security_gateway#security_gateway_id DataGoogleBeyondcorpSecurityGateway#security_gateway_id}
    */
    readonly securityGatewayId: string;
}
export interface DataGoogleBeyondcorpSecurityGatewayHubsInternetGateway {
}
export declare function dataGoogleBeyondcorpSecurityGatewayHubsInternetGatewayToTerraform(struct?: DataGoogleBeyondcorpSecurityGatewayHubsInternetGateway): any;
export declare function dataGoogleBeyondcorpSecurityGatewayHubsInternetGatewayToHclTerraform(struct?: DataGoogleBeyondcorpSecurityGatewayHubsInternetGateway): any;
export declare class DataGoogleBeyondcorpSecurityGatewayHubsInternetGatewayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBeyondcorpSecurityGatewayHubsInternetGateway | undefined;
    set internalValue(value: DataGoogleBeyondcorpSecurityGatewayHubsInternetGateway | undefined);
    get assignedIps(): string[];
}
export declare class DataGoogleBeyondcorpSecurityGatewayHubsInternetGatewayList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBeyondcorpSecurityGatewayHubsInternetGatewayOutputReference;
}
export interface DataGoogleBeyondcorpSecurityGatewayHubs {
}
export declare function dataGoogleBeyondcorpSecurityGatewayHubsToTerraform(struct?: DataGoogleBeyondcorpSecurityGatewayHubs): any;
export declare function dataGoogleBeyondcorpSecurityGatewayHubsToHclTerraform(struct?: DataGoogleBeyondcorpSecurityGatewayHubs): any;
export declare class DataGoogleBeyondcorpSecurityGatewayHubsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBeyondcorpSecurityGatewayHubs | undefined;
    set internalValue(value: DataGoogleBeyondcorpSecurityGatewayHubs | undefined);
    private _internetGateway;
    get internetGateway(): DataGoogleBeyondcorpSecurityGatewayHubsInternetGatewayList;
    get region(): string;
}
export declare class DataGoogleBeyondcorpSecurityGatewayHubsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBeyondcorpSecurityGatewayHubsOutputReference;
}
export interface DataGoogleBeyondcorpSecurityGatewayLogging {
}
export declare function dataGoogleBeyondcorpSecurityGatewayLoggingToTerraform(struct?: DataGoogleBeyondcorpSecurityGatewayLogging): any;
export declare function dataGoogleBeyondcorpSecurityGatewayLoggingToHclTerraform(struct?: DataGoogleBeyondcorpSecurityGatewayLogging): any;
export declare class DataGoogleBeyondcorpSecurityGatewayLoggingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBeyondcorpSecurityGatewayLogging | undefined;
    set internalValue(value: DataGoogleBeyondcorpSecurityGatewayLogging | undefined);
}
export declare class DataGoogleBeyondcorpSecurityGatewayLoggingList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBeyondcorpSecurityGatewayLoggingOutputReference;
}
export interface DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersDeviceInfo {
}
export declare function dataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersDeviceInfoToTerraform(struct?: DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersDeviceInfo): any;
export declare function dataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersDeviceInfoToHclTerraform(struct?: DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersDeviceInfo): any;
export declare class DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersDeviceInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersDeviceInfo | undefined;
    set internalValue(value: DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersDeviceInfo | undefined);
    get outputType(): string;
}
export declare class DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersDeviceInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersDeviceInfoOutputReference;
}
export interface DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersGroupInfo {
}
export declare function dataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersGroupInfoToTerraform(struct?: DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersGroupInfo): any;
export declare function dataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersGroupInfoToHclTerraform(struct?: DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersGroupInfo): any;
export declare class DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersGroupInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersGroupInfo | undefined;
    set internalValue(value: DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersGroupInfo | undefined);
    get outputType(): string;
}
export declare class DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersGroupInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersGroupInfoOutputReference;
}
export interface DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersUserInfo {
}
export declare function dataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersUserInfoToTerraform(struct?: DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersUserInfo): any;
export declare function dataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersUserInfoToHclTerraform(struct?: DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersUserInfo): any;
export declare class DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersUserInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersUserInfo | undefined;
    set internalValue(value: DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersUserInfo | undefined);
    get outputType(): string;
}
export declare class DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersUserInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersUserInfoOutputReference;
}
export interface DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeaders {
}
export declare function dataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersToTerraform(struct?: DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeaders): any;
export declare function dataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersToHclTerraform(struct?: DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeaders): any;
export declare class DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeaders | undefined;
    set internalValue(value: DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeaders | undefined);
    private _deviceInfo;
    get deviceInfo(): DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersDeviceInfoList;
    private _groupInfo;
    get groupInfo(): DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersGroupInfoList;
    get outputType(): string;
    private _userInfo;
    get userInfo(): DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersUserInfoList;
}
export declare class DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersOutputReference;
}
export interface DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfig {
}
export declare function dataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigToTerraform(struct?: DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfig): any;
export declare function dataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigToHclTerraform(struct?: DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfig): any;
export declare class DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfig | undefined;
    set internalValue(value: DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfig | undefined);
    get allowedClientHeaders(): string[];
    get clientIp(): cdktn.IResolvable;
    private _contextualHeaders;
    get contextualHeaders(): DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigContextualHeadersList;
    get gatewayIdentity(): string;
    private _metadataHeaders;
    get metadataHeaders(): cdktn.StringMap;
}
export declare class DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigOutputReference;
}
export interface DataGoogleBeyondcorpSecurityGatewayServiceDiscoveryApiGatewayResourceOverride {
}
export declare function dataGoogleBeyondcorpSecurityGatewayServiceDiscoveryApiGatewayResourceOverrideToTerraform(struct?: DataGoogleBeyondcorpSecurityGatewayServiceDiscoveryApiGatewayResourceOverride): any;
export declare function dataGoogleBeyondcorpSecurityGatewayServiceDiscoveryApiGatewayResourceOverrideToHclTerraform(struct?: DataGoogleBeyondcorpSecurityGatewayServiceDiscoveryApiGatewayResourceOverride): any;
export declare class DataGoogleBeyondcorpSecurityGatewayServiceDiscoveryApiGatewayResourceOverrideOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBeyondcorpSecurityGatewayServiceDiscoveryApiGatewayResourceOverride | undefined;
    set internalValue(value: DataGoogleBeyondcorpSecurityGatewayServiceDiscoveryApiGatewayResourceOverride | undefined);
    get path(): string;
}
export declare class DataGoogleBeyondcorpSecurityGatewayServiceDiscoveryApiGatewayResourceOverrideList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBeyondcorpSecurityGatewayServiceDiscoveryApiGatewayResourceOverrideOutputReference;
}
export interface DataGoogleBeyondcorpSecurityGatewayServiceDiscoveryApiGateway {
}
export declare function dataGoogleBeyondcorpSecurityGatewayServiceDiscoveryApiGatewayToTerraform(struct?: DataGoogleBeyondcorpSecurityGatewayServiceDiscoveryApiGateway): any;
export declare function dataGoogleBeyondcorpSecurityGatewayServiceDiscoveryApiGatewayToHclTerraform(struct?: DataGoogleBeyondcorpSecurityGatewayServiceDiscoveryApiGateway): any;
export declare class DataGoogleBeyondcorpSecurityGatewayServiceDiscoveryApiGatewayOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBeyondcorpSecurityGatewayServiceDiscoveryApiGateway | undefined;
    set internalValue(value: DataGoogleBeyondcorpSecurityGatewayServiceDiscoveryApiGateway | undefined);
    private _resourceOverride;
    get resourceOverride(): DataGoogleBeyondcorpSecurityGatewayServiceDiscoveryApiGatewayResourceOverrideList;
}
export declare class DataGoogleBeyondcorpSecurityGatewayServiceDiscoveryApiGatewayList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBeyondcorpSecurityGatewayServiceDiscoveryApiGatewayOutputReference;
}
export interface DataGoogleBeyondcorpSecurityGatewayServiceDiscovery {
}
export declare function dataGoogleBeyondcorpSecurityGatewayServiceDiscoveryToTerraform(struct?: DataGoogleBeyondcorpSecurityGatewayServiceDiscovery): any;
export declare function dataGoogleBeyondcorpSecurityGatewayServiceDiscoveryToHclTerraform(struct?: DataGoogleBeyondcorpSecurityGatewayServiceDiscovery): any;
export declare class DataGoogleBeyondcorpSecurityGatewayServiceDiscoveryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBeyondcorpSecurityGatewayServiceDiscovery | undefined;
    set internalValue(value: DataGoogleBeyondcorpSecurityGatewayServiceDiscovery | undefined);
    private _apiGateway;
    get apiGateway(): DataGoogleBeyondcorpSecurityGatewayServiceDiscoveryApiGatewayList;
}
export declare class DataGoogleBeyondcorpSecurityGatewayServiceDiscoveryList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBeyondcorpSecurityGatewayServiceDiscoveryOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_beyondcorp_security_gateway google_beyondcorp_security_gateway}
*/
export declare class DataGoogleBeyondcorpSecurityGateway extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_beyondcorp_security_gateway";
    /**
    * Generates CDKTN code for importing a DataGoogleBeyondcorpSecurityGateway resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleBeyondcorpSecurityGateway to import
    * @param importFromId The id of the existing DataGoogleBeyondcorpSecurityGateway that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_beyondcorp_security_gateway#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleBeyondcorpSecurityGateway to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_beyondcorp_security_gateway google_beyondcorp_security_gateway} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleBeyondcorpSecurityGatewayConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleBeyondcorpSecurityGatewayConfig);
    get createTime(): string;
    get delegatingServiceAccount(): string;
    get deletionPolicy(): string;
    get displayName(): string;
    get externalIps(): string[];
    private _hubs;
    get hubs(): DataGoogleBeyondcorpSecurityGatewayHubsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get location(): string;
    private _logging;
    get logging(): DataGoogleBeyondcorpSecurityGatewayLoggingList;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _proxyProtocolConfig;
    get proxyProtocolConfig(): DataGoogleBeyondcorpSecurityGatewayProxyProtocolConfigList;
    private _securityGatewayId?;
    get securityGatewayId(): string;
    set securityGatewayId(value: string);
    get securityGatewayIdInput(): string | undefined;
    private _serviceDiscovery;
    get serviceDiscovery(): DataGoogleBeyondcorpSecurityGatewayServiceDiscoveryList;
    get state(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
