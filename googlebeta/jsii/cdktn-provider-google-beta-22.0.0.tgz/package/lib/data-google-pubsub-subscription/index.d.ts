/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGooglePubsubSubscriptionConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_pubsub_subscription#id DataGooglePubsubSubscription#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the subscription.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_pubsub_subscription#name DataGooglePubsubSubscription#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_pubsub_subscription#project DataGooglePubsubSubscription#project}
    */
    readonly project?: string;
}
export interface DataGooglePubsubSubscriptionBigqueryConfig {
}
export declare function dataGooglePubsubSubscriptionBigqueryConfigToTerraform(struct?: DataGooglePubsubSubscriptionBigqueryConfig): any;
export declare function dataGooglePubsubSubscriptionBigqueryConfigToHclTerraform(struct?: DataGooglePubsubSubscriptionBigqueryConfig): any;
export declare class DataGooglePubsubSubscriptionBigqueryConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubSubscriptionBigqueryConfig | undefined;
    set internalValue(value: DataGooglePubsubSubscriptionBigqueryConfig | undefined);
    get dropUnknownFields(): cdktn.IResolvable;
    get serviceAccountEmail(): string;
    get table(): string;
    get useTableSchema(): cdktn.IResolvable;
    get useTopicSchema(): cdktn.IResolvable;
    get writeMetadata(): cdktn.IResolvable;
}
export declare class DataGooglePubsubSubscriptionBigqueryConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubSubscriptionBigqueryConfigOutputReference;
}
export interface DataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingDelimitedKey {
}
export declare function dataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingDelimitedKeyToTerraform(struct?: DataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingDelimitedKey): any;
export declare function dataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingDelimitedKeyToHclTerraform(struct?: DataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingDelimitedKey): any;
export declare class DataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingDelimitedKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingDelimitedKey | undefined;
    set internalValue(value: DataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingDelimitedKey | undefined);
    get delimiter(): string;
    get keyFields(): string[];
}
export declare class DataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingDelimitedKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingDelimitedKeyOutputReference;
}
export interface DataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingRowKeySchema {
}
export declare function dataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingRowKeySchemaToTerraform(struct?: DataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingRowKeySchema): any;
export declare function dataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingRowKeySchemaToHclTerraform(struct?: DataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingRowKeySchema): any;
export declare class DataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingRowKeySchemaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingRowKeySchema | undefined;
    set internalValue(value: DataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingRowKeySchema | undefined);
}
export declare class DataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingRowKeySchemaList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingRowKeySchemaOutputReference;
}
export interface DataGooglePubsubSubscriptionBigtableConfigColumnFamilyMapping {
}
export declare function dataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingToTerraform(struct?: DataGooglePubsubSubscriptionBigtableConfigColumnFamilyMapping): any;
export declare function dataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingToHclTerraform(struct?: DataGooglePubsubSubscriptionBigtableConfigColumnFamilyMapping): any;
export declare class DataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubSubscriptionBigtableConfigColumnFamilyMapping | undefined;
    set internalValue(value: DataGooglePubsubSubscriptionBigtableConfigColumnFamilyMapping | undefined);
    private _delimitedKey;
    get delimitedKey(): DataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingDelimitedKeyList;
    private _rowKeySchema;
    get rowKeySchema(): DataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingRowKeySchemaList;
}
export declare class DataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingOutputReference;
}
export interface DataGooglePubsubSubscriptionBigtableConfig {
}
export declare function dataGooglePubsubSubscriptionBigtableConfigToTerraform(struct?: DataGooglePubsubSubscriptionBigtableConfig): any;
export declare function dataGooglePubsubSubscriptionBigtableConfigToHclTerraform(struct?: DataGooglePubsubSubscriptionBigtableConfig): any;
export declare class DataGooglePubsubSubscriptionBigtableConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubSubscriptionBigtableConfig | undefined;
    set internalValue(value: DataGooglePubsubSubscriptionBigtableConfig | undefined);
    get appProfileId(): string;
    private _columnFamilyMapping;
    get columnFamilyMapping(): DataGooglePubsubSubscriptionBigtableConfigColumnFamilyMappingList;
    get serviceAccountEmail(): string;
    get state(): string;
    get table(): string;
    get writeMetadata(): cdktn.IResolvable;
}
export declare class DataGooglePubsubSubscriptionBigtableConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubSubscriptionBigtableConfigOutputReference;
}
export interface DataGooglePubsubSubscriptionCloudStorageConfigAvroConfig {
}
export declare function dataGooglePubsubSubscriptionCloudStorageConfigAvroConfigToTerraform(struct?: DataGooglePubsubSubscriptionCloudStorageConfigAvroConfig): any;
export declare function dataGooglePubsubSubscriptionCloudStorageConfigAvroConfigToHclTerraform(struct?: DataGooglePubsubSubscriptionCloudStorageConfigAvroConfig): any;
export declare class DataGooglePubsubSubscriptionCloudStorageConfigAvroConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubSubscriptionCloudStorageConfigAvroConfig | undefined;
    set internalValue(value: DataGooglePubsubSubscriptionCloudStorageConfigAvroConfig | undefined);
    get useTopicSchema(): cdktn.IResolvable;
    get writeMetadata(): cdktn.IResolvable;
}
export declare class DataGooglePubsubSubscriptionCloudStorageConfigAvroConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubSubscriptionCloudStorageConfigAvroConfigOutputReference;
}
export interface DataGooglePubsubSubscriptionCloudStorageConfigTextConfig {
}
export declare function dataGooglePubsubSubscriptionCloudStorageConfigTextConfigToTerraform(struct?: DataGooglePubsubSubscriptionCloudStorageConfigTextConfig): any;
export declare function dataGooglePubsubSubscriptionCloudStorageConfigTextConfigToHclTerraform(struct?: DataGooglePubsubSubscriptionCloudStorageConfigTextConfig): any;
export declare class DataGooglePubsubSubscriptionCloudStorageConfigTextConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubSubscriptionCloudStorageConfigTextConfig | undefined;
    set internalValue(value: DataGooglePubsubSubscriptionCloudStorageConfigTextConfig | undefined);
    get state(): string;
}
export declare class DataGooglePubsubSubscriptionCloudStorageConfigTextConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubSubscriptionCloudStorageConfigTextConfigOutputReference;
}
export interface DataGooglePubsubSubscriptionCloudStorageConfig {
}
export declare function dataGooglePubsubSubscriptionCloudStorageConfigToTerraform(struct?: DataGooglePubsubSubscriptionCloudStorageConfig): any;
export declare function dataGooglePubsubSubscriptionCloudStorageConfigToHclTerraform(struct?: DataGooglePubsubSubscriptionCloudStorageConfig): any;
export declare class DataGooglePubsubSubscriptionCloudStorageConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubSubscriptionCloudStorageConfig | undefined;
    set internalValue(value: DataGooglePubsubSubscriptionCloudStorageConfig | undefined);
    private _avroConfig;
    get avroConfig(): DataGooglePubsubSubscriptionCloudStorageConfigAvroConfigList;
    get bucket(): string;
    get filenameDatetimeFormat(): string;
    get filenamePrefix(): string;
    get filenameSuffix(): string;
    get maxBytes(): number;
    get maxDuration(): string;
    get maxMessages(): number;
    get serviceAccountEmail(): string;
    get state(): string;
    private _textConfig;
    get textConfig(): DataGooglePubsubSubscriptionCloudStorageConfigTextConfigList;
}
export declare class DataGooglePubsubSubscriptionCloudStorageConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubSubscriptionCloudStorageConfigOutputReference;
}
export interface DataGooglePubsubSubscriptionDeadLetterPolicy {
}
export declare function dataGooglePubsubSubscriptionDeadLetterPolicyToTerraform(struct?: DataGooglePubsubSubscriptionDeadLetterPolicy): any;
export declare function dataGooglePubsubSubscriptionDeadLetterPolicyToHclTerraform(struct?: DataGooglePubsubSubscriptionDeadLetterPolicy): any;
export declare class DataGooglePubsubSubscriptionDeadLetterPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubSubscriptionDeadLetterPolicy | undefined;
    set internalValue(value: DataGooglePubsubSubscriptionDeadLetterPolicy | undefined);
    get deadLetterTopic(): string;
    get maxDeliveryAttempts(): number;
}
export declare class DataGooglePubsubSubscriptionDeadLetterPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubSubscriptionDeadLetterPolicyOutputReference;
}
export interface DataGooglePubsubSubscriptionExpirationPolicy {
}
export declare function dataGooglePubsubSubscriptionExpirationPolicyToTerraform(struct?: DataGooglePubsubSubscriptionExpirationPolicy): any;
export declare function dataGooglePubsubSubscriptionExpirationPolicyToHclTerraform(struct?: DataGooglePubsubSubscriptionExpirationPolicy): any;
export declare class DataGooglePubsubSubscriptionExpirationPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubSubscriptionExpirationPolicy | undefined;
    set internalValue(value: DataGooglePubsubSubscriptionExpirationPolicy | undefined);
    get ttl(): string;
}
export declare class DataGooglePubsubSubscriptionExpirationPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubSubscriptionExpirationPolicyOutputReference;
}
export interface DataGooglePubsubSubscriptionMessageTransformsAiInferenceUnstructuredInference {
}
export declare function dataGooglePubsubSubscriptionMessageTransformsAiInferenceUnstructuredInferenceToTerraform(struct?: DataGooglePubsubSubscriptionMessageTransformsAiInferenceUnstructuredInference): any;
export declare function dataGooglePubsubSubscriptionMessageTransformsAiInferenceUnstructuredInferenceToHclTerraform(struct?: DataGooglePubsubSubscriptionMessageTransformsAiInferenceUnstructuredInference): any;
export declare class DataGooglePubsubSubscriptionMessageTransformsAiInferenceUnstructuredInferenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubSubscriptionMessageTransformsAiInferenceUnstructuredInference | undefined;
    set internalValue(value: DataGooglePubsubSubscriptionMessageTransformsAiInferenceUnstructuredInference | undefined);
    private _parameters;
    get parameters(): cdktn.StringMap;
}
export declare class DataGooglePubsubSubscriptionMessageTransformsAiInferenceUnstructuredInferenceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubSubscriptionMessageTransformsAiInferenceUnstructuredInferenceOutputReference;
}
export interface DataGooglePubsubSubscriptionMessageTransformsAiInference {
}
export declare function dataGooglePubsubSubscriptionMessageTransformsAiInferenceToTerraform(struct?: DataGooglePubsubSubscriptionMessageTransformsAiInference): any;
export declare function dataGooglePubsubSubscriptionMessageTransformsAiInferenceToHclTerraform(struct?: DataGooglePubsubSubscriptionMessageTransformsAiInference): any;
export declare class DataGooglePubsubSubscriptionMessageTransformsAiInferenceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubSubscriptionMessageTransformsAiInference | undefined;
    set internalValue(value: DataGooglePubsubSubscriptionMessageTransformsAiInference | undefined);
    get endpoint(): string;
    get serviceAccountEmail(): string;
    private _unstructuredInference;
    get unstructuredInference(): DataGooglePubsubSubscriptionMessageTransformsAiInferenceUnstructuredInferenceList;
}
export declare class DataGooglePubsubSubscriptionMessageTransformsAiInferenceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubSubscriptionMessageTransformsAiInferenceOutputReference;
}
export interface DataGooglePubsubSubscriptionMessageTransformsJavascriptUdf {
}
export declare function dataGooglePubsubSubscriptionMessageTransformsJavascriptUdfToTerraform(struct?: DataGooglePubsubSubscriptionMessageTransformsJavascriptUdf): any;
export declare function dataGooglePubsubSubscriptionMessageTransformsJavascriptUdfToHclTerraform(struct?: DataGooglePubsubSubscriptionMessageTransformsJavascriptUdf): any;
export declare class DataGooglePubsubSubscriptionMessageTransformsJavascriptUdfOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubSubscriptionMessageTransformsJavascriptUdf | undefined;
    set internalValue(value: DataGooglePubsubSubscriptionMessageTransformsJavascriptUdf | undefined);
    get code(): string;
    get functionName(): string;
}
export declare class DataGooglePubsubSubscriptionMessageTransformsJavascriptUdfList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubSubscriptionMessageTransformsJavascriptUdfOutputReference;
}
export interface DataGooglePubsubSubscriptionMessageTransforms {
}
export declare function dataGooglePubsubSubscriptionMessageTransformsToTerraform(struct?: DataGooglePubsubSubscriptionMessageTransforms): any;
export declare function dataGooglePubsubSubscriptionMessageTransformsToHclTerraform(struct?: DataGooglePubsubSubscriptionMessageTransforms): any;
export declare class DataGooglePubsubSubscriptionMessageTransformsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubSubscriptionMessageTransforms | undefined;
    set internalValue(value: DataGooglePubsubSubscriptionMessageTransforms | undefined);
    private _aiInference;
    get aiInference(): DataGooglePubsubSubscriptionMessageTransformsAiInferenceList;
    get disabled(): cdktn.IResolvable;
    private _javascriptUdf;
    get javascriptUdf(): DataGooglePubsubSubscriptionMessageTransformsJavascriptUdfList;
}
export declare class DataGooglePubsubSubscriptionMessageTransformsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubSubscriptionMessageTransformsOutputReference;
}
export interface DataGooglePubsubSubscriptionPushConfigNoWrapper {
}
export declare function dataGooglePubsubSubscriptionPushConfigNoWrapperToTerraform(struct?: DataGooglePubsubSubscriptionPushConfigNoWrapper): any;
export declare function dataGooglePubsubSubscriptionPushConfigNoWrapperToHclTerraform(struct?: DataGooglePubsubSubscriptionPushConfigNoWrapper): any;
export declare class DataGooglePubsubSubscriptionPushConfigNoWrapperOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubSubscriptionPushConfigNoWrapper | undefined;
    set internalValue(value: DataGooglePubsubSubscriptionPushConfigNoWrapper | undefined);
    get writeMetadata(): cdktn.IResolvable;
}
export declare class DataGooglePubsubSubscriptionPushConfigNoWrapperList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubSubscriptionPushConfigNoWrapperOutputReference;
}
export interface DataGooglePubsubSubscriptionPushConfigOidcToken {
}
export declare function dataGooglePubsubSubscriptionPushConfigOidcTokenToTerraform(struct?: DataGooglePubsubSubscriptionPushConfigOidcToken): any;
export declare function dataGooglePubsubSubscriptionPushConfigOidcTokenToHclTerraform(struct?: DataGooglePubsubSubscriptionPushConfigOidcToken): any;
export declare class DataGooglePubsubSubscriptionPushConfigOidcTokenOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubSubscriptionPushConfigOidcToken | undefined;
    set internalValue(value: DataGooglePubsubSubscriptionPushConfigOidcToken | undefined);
    get audience(): string;
    get serviceAccountEmail(): string;
}
export declare class DataGooglePubsubSubscriptionPushConfigOidcTokenList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubSubscriptionPushConfigOidcTokenOutputReference;
}
export interface DataGooglePubsubSubscriptionPushConfig {
}
export declare function dataGooglePubsubSubscriptionPushConfigToTerraform(struct?: DataGooglePubsubSubscriptionPushConfig): any;
export declare function dataGooglePubsubSubscriptionPushConfigToHclTerraform(struct?: DataGooglePubsubSubscriptionPushConfig): any;
export declare class DataGooglePubsubSubscriptionPushConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubSubscriptionPushConfig | undefined;
    set internalValue(value: DataGooglePubsubSubscriptionPushConfig | undefined);
    private _attributes;
    get attributes(): cdktn.StringMap;
    private _noWrapper;
    get noWrapper(): DataGooglePubsubSubscriptionPushConfigNoWrapperList;
    private _oidcToken;
    get oidcToken(): DataGooglePubsubSubscriptionPushConfigOidcTokenList;
    get pushEndpoint(): string;
}
export declare class DataGooglePubsubSubscriptionPushConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubSubscriptionPushConfigOutputReference;
}
export interface DataGooglePubsubSubscriptionRetryPolicy {
}
export declare function dataGooglePubsubSubscriptionRetryPolicyToTerraform(struct?: DataGooglePubsubSubscriptionRetryPolicy): any;
export declare function dataGooglePubsubSubscriptionRetryPolicyToHclTerraform(struct?: DataGooglePubsubSubscriptionRetryPolicy): any;
export declare class DataGooglePubsubSubscriptionRetryPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePubsubSubscriptionRetryPolicy | undefined;
    set internalValue(value: DataGooglePubsubSubscriptionRetryPolicy | undefined);
    get maximumBackoff(): string;
    get minimumBackoff(): string;
}
export declare class DataGooglePubsubSubscriptionRetryPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePubsubSubscriptionRetryPolicyOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_pubsub_subscription google_pubsub_subscription}
*/
export declare class DataGooglePubsubSubscription extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_pubsub_subscription";
    /**
    * Generates CDKTN code for importing a DataGooglePubsubSubscription resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGooglePubsubSubscription to import
    * @param importFromId The id of the existing DataGooglePubsubSubscription that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_pubsub_subscription#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGooglePubsubSubscription to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_pubsub_subscription google_pubsub_subscription} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGooglePubsubSubscriptionConfig
    */
    constructor(scope: Construct, id: string, config: DataGooglePubsubSubscriptionConfig);
    get ackDeadlineSeconds(): number;
    private _bigqueryConfig;
    get bigqueryConfig(): DataGooglePubsubSubscriptionBigqueryConfigList;
    private _bigtableConfig;
    get bigtableConfig(): DataGooglePubsubSubscriptionBigtableConfigList;
    private _cloudStorageConfig;
    get cloudStorageConfig(): DataGooglePubsubSubscriptionCloudStorageConfigList;
    private _deadLetterPolicy;
    get deadLetterPolicy(): DataGooglePubsubSubscriptionDeadLetterPolicyList;
    get deletionPolicy(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get enableExactlyOnceDelivery(): cdktn.IResolvable;
    get enableMessageOrdering(): cdktn.IResolvable;
    private _expirationPolicy;
    get expirationPolicy(): DataGooglePubsubSubscriptionExpirationPolicyList;
    get filter(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels;
    get labels(): cdktn.StringMap;
    get messageRetentionDuration(): string;
    private _messageTransforms;
    get messageTransforms(): DataGooglePubsubSubscriptionMessageTransformsList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _pushConfig;
    get pushConfig(): DataGooglePubsubSubscriptionPushConfigList;
    get retainAckedMessages(): cdktn.IResolvable;
    private _retryPolicy;
    get retryPolicy(): DataGooglePubsubSubscriptionRetryPolicyList;
    private _tags;
    get tags(): cdktn.StringMap;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get topic(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
