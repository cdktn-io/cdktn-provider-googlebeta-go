/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleDataLineageConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_data_lineage_config#id DataGoogleDataLineageConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The region of the data lineage configuration for integration.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_data_lineage_config#location DataGoogleDataLineageConfig#location}
    */
    readonly location: string;
    /**
    * Parent scope for the config.
    * Format: projects/{project-id|project-number} or folders/{folder-number} or organizations/{organization-number}.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_data_lineage_config#parent DataGoogleDataLineageConfig#parent}
    */
    readonly parent: string;
}
export interface DataGoogleDataLineageConfigIngestionRuleIntegrationSelector {
}
export declare function dataGoogleDataLineageConfigIngestionRuleIntegrationSelectorToTerraform(struct?: DataGoogleDataLineageConfigIngestionRuleIntegrationSelector): any;
export declare function dataGoogleDataLineageConfigIngestionRuleIntegrationSelectorToHclTerraform(struct?: DataGoogleDataLineageConfigIngestionRuleIntegrationSelector): any;
export declare class DataGoogleDataLineageConfigIngestionRuleIntegrationSelectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleDataLineageConfigIngestionRuleIntegrationSelector | undefined;
    set internalValue(value: DataGoogleDataLineageConfigIngestionRuleIntegrationSelector | undefined);
    get integration(): string;
}
export declare class DataGoogleDataLineageConfigIngestionRuleIntegrationSelectorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleDataLineageConfigIngestionRuleIntegrationSelectorOutputReference;
}
export interface DataGoogleDataLineageConfigIngestionRuleLineageEnablement {
}
export declare function dataGoogleDataLineageConfigIngestionRuleLineageEnablementToTerraform(struct?: DataGoogleDataLineageConfigIngestionRuleLineageEnablement): any;
export declare function dataGoogleDataLineageConfigIngestionRuleLineageEnablementToHclTerraform(struct?: DataGoogleDataLineageConfigIngestionRuleLineageEnablement): any;
export declare class DataGoogleDataLineageConfigIngestionRuleLineageEnablementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleDataLineageConfigIngestionRuleLineageEnablement | undefined;
    set internalValue(value: DataGoogleDataLineageConfigIngestionRuleLineageEnablement | undefined);
    get enabled(): cdktn.IResolvable;
}
export declare class DataGoogleDataLineageConfigIngestionRuleLineageEnablementList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleDataLineageConfigIngestionRuleLineageEnablementOutputReference;
}
export interface DataGoogleDataLineageConfigIngestionRule {
}
export declare function dataGoogleDataLineageConfigIngestionRuleToTerraform(struct?: DataGoogleDataLineageConfigIngestionRule): any;
export declare function dataGoogleDataLineageConfigIngestionRuleToHclTerraform(struct?: DataGoogleDataLineageConfigIngestionRule): any;
export declare class DataGoogleDataLineageConfigIngestionRuleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleDataLineageConfigIngestionRule | undefined;
    set internalValue(value: DataGoogleDataLineageConfigIngestionRule | undefined);
    private _integrationSelector;
    get integrationSelector(): DataGoogleDataLineageConfigIngestionRuleIntegrationSelectorList;
    private _lineageEnablement;
    get lineageEnablement(): DataGoogleDataLineageConfigIngestionRuleLineageEnablementList;
}
export declare class DataGoogleDataLineageConfigIngestionRuleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleDataLineageConfigIngestionRuleOutputReference;
}
export interface DataGoogleDataLineageConfigIngestion {
}
export declare function dataGoogleDataLineageConfigIngestionToTerraform(struct?: DataGoogleDataLineageConfigIngestion): any;
export declare function dataGoogleDataLineageConfigIngestionToHclTerraform(struct?: DataGoogleDataLineageConfigIngestion): any;
export declare class DataGoogleDataLineageConfigIngestionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleDataLineageConfigIngestion | undefined;
    set internalValue(value: DataGoogleDataLineageConfigIngestion | undefined);
    private _rule;
    get rule(): DataGoogleDataLineageConfigIngestionRuleList;
}
export declare class DataGoogleDataLineageConfigIngestionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleDataLineageConfigIngestionOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_data_lineage_config google_data_lineage_config}
*/
export declare class DataGoogleDataLineageConfig extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_data_lineage_config";
    /**
    * Generates CDKTN code for importing a DataGoogleDataLineageConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleDataLineageConfig to import
    * @param importFromId The id of the existing DataGoogleDataLineageConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_data_lineage_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleDataLineageConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_data_lineage_config google_data_lineage_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleDataLineageConfigConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleDataLineageConfigConfig);
    get deletionPolicy(): string;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _ingestion;
    get ingestion(): DataGoogleDataLineageConfigIngestionList;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
