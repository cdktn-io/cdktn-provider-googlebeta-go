/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleBackupDrDataSourceReferenceConfig extends cdktn.TerraformMetaArguments {
    /**
    * The `id` of the data source reference.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_source_reference#data_source_reference_id DataGoogleBackupDrDataSourceReference#data_source_reference_id}
    */
    readonly dataSourceReferenceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_source_reference#id DataGoogleBackupDrDataSourceReference#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the data source reference.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_source_reference#location DataGoogleBackupDrDataSourceReference#location}
    */
    readonly location: string;
    /**
    * The ID of the project in which the resource belongs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_source_reference#project DataGoogleBackupDrDataSourceReference#project}
    */
    readonly project?: string;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_source_reference google_backup_dr_data_source_reference}
*/
export declare class DataGoogleBackupDrDataSourceReference extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_backup_dr_data_source_reference";
    /**
    * Generates CDKTN code for importing a DataGoogleBackupDrDataSourceReference resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleBackupDrDataSourceReference to import
    * @param importFromId The id of the existing DataGoogleBackupDrDataSourceReference that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_source_reference#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleBackupDrDataSourceReference to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_source_reference google_backup_dr_data_source_reference} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleBackupDrDataSourceReferenceConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleBackupDrDataSourceReferenceConfig);
    get backupConfigState(): string;
    get backupCount(): number;
    get dataSource(): string;
    private _dataSourceReferenceId?;
    get dataSourceReferenceId(): string;
    set dataSourceReferenceId(value: string);
    get dataSourceReferenceIdInput(): string | undefined;
    get gcpResourceName(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get lastBackupState(): string;
    get lastSuccessfulBackupTime(): string;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get resourceType(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
