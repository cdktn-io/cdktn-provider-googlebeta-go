/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleComputeReservationConfig extends cdktn.TerraformMetaArguments {
    /**
    * Name of the resource. Provided by the client when the resource is
    * created. The name must be 1-63 characters long, and comply with
    * RFC1035. Specifically, the name must be 1-63 characters long and match
    * the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the
    * first character must be a lowercase letter, and all following
    * characters must be a dash, lowercase letter, or digit, except the last
    * character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_reservation#name DataGoogleComputeReservation#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_reservation#project DataGoogleComputeReservation#project}
    */
    readonly project?: string;
    /**
    * The zone where the reservation is made.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_reservation#zone DataGoogleComputeReservation#zone}
    */
    readonly zone: string;
}
export interface DataGoogleComputeReservationDeleteAfterDuration {
}
export declare function dataGoogleComputeReservationDeleteAfterDurationToTerraform(struct?: DataGoogleComputeReservationDeleteAfterDuration): any;
export declare function dataGoogleComputeReservationDeleteAfterDurationToHclTerraform(struct?: DataGoogleComputeReservationDeleteAfterDuration): any;
export declare class DataGoogleComputeReservationDeleteAfterDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeReservationDeleteAfterDuration | undefined;
    set internalValue(value: DataGoogleComputeReservationDeleteAfterDuration | undefined);
    get nanos(): number;
    get seconds(): string;
}
export declare class DataGoogleComputeReservationDeleteAfterDurationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeReservationDeleteAfterDurationOutputReference;
}
export interface DataGoogleComputeReservationParams {
}
export declare function dataGoogleComputeReservationParamsToTerraform(struct?: DataGoogleComputeReservationParams): any;
export declare function dataGoogleComputeReservationParamsToHclTerraform(struct?: DataGoogleComputeReservationParams): any;
export declare class DataGoogleComputeReservationParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeReservationParams | undefined;
    set internalValue(value: DataGoogleComputeReservationParams | undefined);
    private _resourceManagerTags;
    get resourceManagerTags(): cdktn.StringMap;
}
export declare class DataGoogleComputeReservationParamsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeReservationParamsOutputReference;
}
export interface DataGoogleComputeReservationReservationSharingPolicy {
}
export declare function dataGoogleComputeReservationReservationSharingPolicyToTerraform(struct?: DataGoogleComputeReservationReservationSharingPolicy): any;
export declare function dataGoogleComputeReservationReservationSharingPolicyToHclTerraform(struct?: DataGoogleComputeReservationReservationSharingPolicy): any;
export declare class DataGoogleComputeReservationReservationSharingPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeReservationReservationSharingPolicy | undefined;
    set internalValue(value: DataGoogleComputeReservationReservationSharingPolicy | undefined);
    get serviceShareType(): string;
}
export declare class DataGoogleComputeReservationReservationSharingPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeReservationReservationSharingPolicyOutputReference;
}
export interface DataGoogleComputeReservationResourceStatusHealthInfo {
}
export declare function dataGoogleComputeReservationResourceStatusHealthInfoToTerraform(struct?: DataGoogleComputeReservationResourceStatusHealthInfo): any;
export declare function dataGoogleComputeReservationResourceStatusHealthInfoToHclTerraform(struct?: DataGoogleComputeReservationResourceStatusHealthInfo): any;
export declare class DataGoogleComputeReservationResourceStatusHealthInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeReservationResourceStatusHealthInfo | undefined;
    set internalValue(value: DataGoogleComputeReservationResourceStatusHealthInfo | undefined);
    get degradedBlockCount(): number;
    get healthStatus(): string;
    get healthyBlockCount(): number;
}
export declare class DataGoogleComputeReservationResourceStatusHealthInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeReservationResourceStatusHealthInfoOutputReference;
}
export interface DataGoogleComputeReservationResourceStatusReservationMaintenanceUpcomingGroupMaintenance {
}
export declare function dataGoogleComputeReservationResourceStatusReservationMaintenanceUpcomingGroupMaintenanceToTerraform(struct?: DataGoogleComputeReservationResourceStatusReservationMaintenanceUpcomingGroupMaintenance): any;
export declare function dataGoogleComputeReservationResourceStatusReservationMaintenanceUpcomingGroupMaintenanceToHclTerraform(struct?: DataGoogleComputeReservationResourceStatusReservationMaintenanceUpcomingGroupMaintenance): any;
export declare class DataGoogleComputeReservationResourceStatusReservationMaintenanceUpcomingGroupMaintenanceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeReservationResourceStatusReservationMaintenanceUpcomingGroupMaintenance | undefined;
    set internalValue(value: DataGoogleComputeReservationResourceStatusReservationMaintenanceUpcomingGroupMaintenance | undefined);
    get canReschedule(): cdktn.IResolvable;
    get latestWindowStartTime(): string;
    get maintenanceOnShutdown(): cdktn.IResolvable;
    get maintenanceReasons(): string[];
    get maintenanceStatus(): string;
    get type(): string;
    get windowEndTime(): string;
    get windowStartTime(): string;
}
export declare class DataGoogleComputeReservationResourceStatusReservationMaintenanceUpcomingGroupMaintenanceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeReservationResourceStatusReservationMaintenanceUpcomingGroupMaintenanceOutputReference;
}
export interface DataGoogleComputeReservationResourceStatusReservationMaintenance {
}
export declare function dataGoogleComputeReservationResourceStatusReservationMaintenanceToTerraform(struct?: DataGoogleComputeReservationResourceStatusReservationMaintenance): any;
export declare function dataGoogleComputeReservationResourceStatusReservationMaintenanceToHclTerraform(struct?: DataGoogleComputeReservationResourceStatusReservationMaintenance): any;
export declare class DataGoogleComputeReservationResourceStatusReservationMaintenanceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeReservationResourceStatusReservationMaintenance | undefined;
    set internalValue(value: DataGoogleComputeReservationResourceStatusReservationMaintenance | undefined);
    get instanceMaintenanceOngoingCount(): number;
    get instanceMaintenancePendingCount(): number;
    get maintenanceOngoingCount(): number;
    get maintenancePendingCount(): number;
    get schedulingType(): string;
    get subblockInfraMaintenanceOngoingCount(): number;
    get subblockInfraMaintenancePendingCount(): number;
    private _upcomingGroupMaintenance;
    get upcomingGroupMaintenance(): DataGoogleComputeReservationResourceStatusReservationMaintenanceUpcomingGroupMaintenanceList;
}
export declare class DataGoogleComputeReservationResourceStatusReservationMaintenanceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeReservationResourceStatusReservationMaintenanceOutputReference;
}
export interface DataGoogleComputeReservationResourceStatusSpecificSkuAllocation {
}
export declare function dataGoogleComputeReservationResourceStatusSpecificSkuAllocationToTerraform(struct?: DataGoogleComputeReservationResourceStatusSpecificSkuAllocation): any;
export declare function dataGoogleComputeReservationResourceStatusSpecificSkuAllocationToHclTerraform(struct?: DataGoogleComputeReservationResourceStatusSpecificSkuAllocation): any;
export declare class DataGoogleComputeReservationResourceStatusSpecificSkuAllocationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeReservationResourceStatusSpecificSkuAllocation | undefined;
    set internalValue(value: DataGoogleComputeReservationResourceStatusSpecificSkuAllocation | undefined);
    get sourceInstanceTemplateId(): string;
    private _utilizations;
    get utilizations(): cdktn.StringMap;
}
export declare class DataGoogleComputeReservationResourceStatusSpecificSkuAllocationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeReservationResourceStatusSpecificSkuAllocationOutputReference;
}
export interface DataGoogleComputeReservationResourceStatus {
}
export declare function dataGoogleComputeReservationResourceStatusToTerraform(struct?: DataGoogleComputeReservationResourceStatus): any;
export declare function dataGoogleComputeReservationResourceStatusToHclTerraform(struct?: DataGoogleComputeReservationResourceStatus): any;
export declare class DataGoogleComputeReservationResourceStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeReservationResourceStatus | undefined;
    set internalValue(value: DataGoogleComputeReservationResourceStatus | undefined);
    private _healthInfo;
    get healthInfo(): DataGoogleComputeReservationResourceStatusHealthInfoList;
    get reservationBlockCount(): number;
    private _reservationMaintenance;
    get reservationMaintenance(): DataGoogleComputeReservationResourceStatusReservationMaintenanceList;
    private _specificSkuAllocation;
    get specificSkuAllocation(): DataGoogleComputeReservationResourceStatusSpecificSkuAllocationList;
}
export declare class DataGoogleComputeReservationResourceStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeReservationResourceStatusOutputReference;
}
export interface DataGoogleComputeReservationShareSettingsProjectMap {
}
export declare function dataGoogleComputeReservationShareSettingsProjectMapToTerraform(struct?: DataGoogleComputeReservationShareSettingsProjectMap): any;
export declare function dataGoogleComputeReservationShareSettingsProjectMapToHclTerraform(struct?: DataGoogleComputeReservationShareSettingsProjectMap): any;
export declare class DataGoogleComputeReservationShareSettingsProjectMapOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeReservationShareSettingsProjectMap | undefined;
    set internalValue(value: DataGoogleComputeReservationShareSettingsProjectMap | undefined);
    get id(): string;
    get projectId(): string;
}
export declare class DataGoogleComputeReservationShareSettingsProjectMapList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeReservationShareSettingsProjectMapOutputReference;
}
export interface DataGoogleComputeReservationShareSettings {
}
export declare function dataGoogleComputeReservationShareSettingsToTerraform(struct?: DataGoogleComputeReservationShareSettings): any;
export declare function dataGoogleComputeReservationShareSettingsToHclTerraform(struct?: DataGoogleComputeReservationShareSettings): any;
export declare class DataGoogleComputeReservationShareSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeReservationShareSettings | undefined;
    set internalValue(value: DataGoogleComputeReservationShareSettings | undefined);
    private _projectMap;
    get projectMap(): DataGoogleComputeReservationShareSettingsProjectMapList;
    get projects(): string[];
    get shareType(): string;
}
export declare class DataGoogleComputeReservationShareSettingsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeReservationShareSettingsOutputReference;
}
export interface DataGoogleComputeReservationSpecificReservationInstancePropertiesGuestAccelerators {
}
export declare function dataGoogleComputeReservationSpecificReservationInstancePropertiesGuestAcceleratorsToTerraform(struct?: DataGoogleComputeReservationSpecificReservationInstancePropertiesGuestAccelerators): any;
export declare function dataGoogleComputeReservationSpecificReservationInstancePropertiesGuestAcceleratorsToHclTerraform(struct?: DataGoogleComputeReservationSpecificReservationInstancePropertiesGuestAccelerators): any;
export declare class DataGoogleComputeReservationSpecificReservationInstancePropertiesGuestAcceleratorsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeReservationSpecificReservationInstancePropertiesGuestAccelerators | undefined;
    set internalValue(value: DataGoogleComputeReservationSpecificReservationInstancePropertiesGuestAccelerators | undefined);
    get acceleratorCount(): number;
    get acceleratorType(): string;
}
export declare class DataGoogleComputeReservationSpecificReservationInstancePropertiesGuestAcceleratorsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeReservationSpecificReservationInstancePropertiesGuestAcceleratorsOutputReference;
}
export interface DataGoogleComputeReservationSpecificReservationInstancePropertiesLocalSsds {
}
export declare function dataGoogleComputeReservationSpecificReservationInstancePropertiesLocalSsdsToTerraform(struct?: DataGoogleComputeReservationSpecificReservationInstancePropertiesLocalSsds): any;
export declare function dataGoogleComputeReservationSpecificReservationInstancePropertiesLocalSsdsToHclTerraform(struct?: DataGoogleComputeReservationSpecificReservationInstancePropertiesLocalSsds): any;
export declare class DataGoogleComputeReservationSpecificReservationInstancePropertiesLocalSsdsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeReservationSpecificReservationInstancePropertiesLocalSsds | undefined;
    set internalValue(value: DataGoogleComputeReservationSpecificReservationInstancePropertiesLocalSsds | undefined);
    get diskSizeGb(): number;
    get interface(): string;
}
export declare class DataGoogleComputeReservationSpecificReservationInstancePropertiesLocalSsdsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeReservationSpecificReservationInstancePropertiesLocalSsdsOutputReference;
}
export interface DataGoogleComputeReservationSpecificReservationInstanceProperties {
}
export declare function dataGoogleComputeReservationSpecificReservationInstancePropertiesToTerraform(struct?: DataGoogleComputeReservationSpecificReservationInstanceProperties): any;
export declare function dataGoogleComputeReservationSpecificReservationInstancePropertiesToHclTerraform(struct?: DataGoogleComputeReservationSpecificReservationInstanceProperties): any;
export declare class DataGoogleComputeReservationSpecificReservationInstancePropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeReservationSpecificReservationInstanceProperties | undefined;
    set internalValue(value: DataGoogleComputeReservationSpecificReservationInstanceProperties | undefined);
    private _guestAccelerators;
    get guestAccelerators(): DataGoogleComputeReservationSpecificReservationInstancePropertiesGuestAcceleratorsList;
    private _localSsds;
    get localSsds(): DataGoogleComputeReservationSpecificReservationInstancePropertiesLocalSsdsList;
    get locationHint(): string;
    get machineType(): string;
    get maintenanceInterval(): string;
    get minCpuPlatform(): string;
}
export declare class DataGoogleComputeReservationSpecificReservationInstancePropertiesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeReservationSpecificReservationInstancePropertiesOutputReference;
}
export interface DataGoogleComputeReservationSpecificReservation {
}
export declare function dataGoogleComputeReservationSpecificReservationToTerraform(struct?: DataGoogleComputeReservationSpecificReservation): any;
export declare function dataGoogleComputeReservationSpecificReservationToHclTerraform(struct?: DataGoogleComputeReservationSpecificReservation): any;
export declare class DataGoogleComputeReservationSpecificReservationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeReservationSpecificReservation | undefined;
    set internalValue(value: DataGoogleComputeReservationSpecificReservation | undefined);
    get assuredCount(): number;
    get count(): number;
    get inUseCount(): number;
    private _instanceProperties;
    get instanceProperties(): DataGoogleComputeReservationSpecificReservationInstancePropertiesList;
    get sourceInstanceTemplate(): string;
}
export declare class DataGoogleComputeReservationSpecificReservationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeReservationSpecificReservationOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_reservation google_compute_reservation}
*/
export declare class DataGoogleComputeReservation extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_compute_reservation";
    /**
    * Generates CDKTN code for importing a DataGoogleComputeReservation resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleComputeReservation to import
    * @param importFromId The id of the existing DataGoogleComputeReservation that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_reservation#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleComputeReservation to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_reservation google_compute_reservation} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleComputeReservationConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleComputeReservationConfig);
    get blockNames(): string[];
    get commitment(): string;
    get creationTimestamp(): string;
    private _deleteAfterDuration;
    get deleteAfterDuration(): DataGoogleComputeReservationDeleteAfterDurationList;
    get deleteAtTime(): string;
    get deletionPolicy(): string;
    get description(): string;
    get enableEmergentMaintenance(): cdktn.IResolvable;
    get id(): string;
    get kind(): string;
    get linkedCommitments(): string[];
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _params;
    get params(): DataGoogleComputeReservationParamsList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _reservationSharingPolicy;
    get reservationSharingPolicy(): DataGoogleComputeReservationReservationSharingPolicyList;
    private _resourceStatus;
    get resourceStatus(): DataGoogleComputeReservationResourceStatusList;
    get satisfiesPzs(): cdktn.IResolvable;
    get selfLink(): string;
    private _shareSettings;
    get shareSettings(): DataGoogleComputeReservationShareSettingsList;
    private _specificReservation;
    get specificReservation(): DataGoogleComputeReservationSpecificReservationList;
    get specificReservationRequired(): cdktn.IResolvable;
    get status(): string;
    private _zone?;
    get zone(): string;
    set zone(value: string);
    get zoneInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
