/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleOracleDatabaseCloudVmClustersConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_cloud_vm_clusters#id DataGoogleOracleDatabaseCloudVmClusters#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * location
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_cloud_vm_clusters#location DataGoogleOracleDatabaseCloudVmClusters#location}
    */
    readonly location: string;
    /**
    * The ID of the project in which the dataset is located. If it is not provided, the provider project is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_cloud_vm_clusters#project DataGoogleOracleDatabaseCloudVmClusters#project}
    */
    readonly project?: string;
}
export interface DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersIdentityConnector {
}
export declare function dataGoogleOracleDatabaseCloudVmClustersCloudVmClustersIdentityConnectorToTerraform(struct?: DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersIdentityConnector): any;
export declare function dataGoogleOracleDatabaseCloudVmClustersCloudVmClustersIdentityConnectorToHclTerraform(struct?: DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersIdentityConnector): any;
export declare class DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersIdentityConnectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersIdentityConnector | undefined;
    set internalValue(value: DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersIdentityConnector | undefined);
    get connectionState(): string;
    get serviceAgentEmail(): string;
}
export declare class DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersIdentityConnectorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersIdentityConnectorOutputReference;
}
export interface DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesDiagnosticsDataCollectionOptions {
}
export declare function dataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesDiagnosticsDataCollectionOptionsToTerraform(struct?: DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesDiagnosticsDataCollectionOptions): any;
export declare function dataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesDiagnosticsDataCollectionOptionsToHclTerraform(struct?: DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesDiagnosticsDataCollectionOptions): any;
export declare class DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesDiagnosticsDataCollectionOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesDiagnosticsDataCollectionOptions | undefined;
    set internalValue(value: DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesDiagnosticsDataCollectionOptions | undefined);
    get diagnosticsEventsEnabled(): cdktn.IResolvable;
    get healthMonitoringEnabled(): cdktn.IResolvable;
    get incidentLogsEnabled(): cdktn.IResolvable;
}
export declare class DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesDiagnosticsDataCollectionOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesDiagnosticsDataCollectionOptionsOutputReference;
}
export interface DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesTimeZone {
}
export declare function dataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesTimeZoneToTerraform(struct?: DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesTimeZone): any;
export declare function dataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesTimeZoneToHclTerraform(struct?: DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesTimeZone): any;
export declare class DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesTimeZoneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesTimeZone | undefined;
    set internalValue(value: DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesTimeZone | undefined);
    get id(): string;
    get version(): string;
}
export declare class DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesTimeZoneList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesTimeZoneOutputReference;
}
export interface DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersProperties {
}
export declare function dataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesToTerraform(struct?: DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersProperties): any;
export declare function dataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesToHclTerraform(struct?: DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersProperties): any;
export declare class DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersProperties | undefined;
    set internalValue(value: DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersProperties | undefined);
    get clusterName(): string;
    get compartmentId(): string;
    get cpuCoreCount(): number;
    get dataStorageSizeTb(): number;
    get dbNodeStorageSizeGb(): number;
    get dbServerOcids(): string[];
    private _diagnosticsDataCollectionOptions;
    get diagnosticsDataCollectionOptions(): DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesDiagnosticsDataCollectionOptionsList;
    get diskRedundancy(): string;
    get dnsListenerIp(): string;
    get domain(): string;
    get giVersion(): string;
    get hostname(): string;
    get hostnamePrefix(): string;
    get licenseType(): string;
    get localBackupEnabled(): cdktn.IResolvable;
    get memorySizeGb(): number;
    get nodeCount(): number;
    get ociUrl(): string;
    get ocid(): string;
    get ocpuCount(): number;
    get scanDns(): string;
    get scanDnsRecordId(): string;
    get scanIpIds(): string[];
    get scanListenerPortTcp(): number;
    get scanListenerPortTcpSsl(): number;
    get shape(): string;
    get sparseDiskgroupEnabled(): cdktn.IResolvable;
    get sshPublicKeys(): string[];
    get state(): string;
    get storageManagementType(): string;
    get storageSizeGb(): number;
    get systemVersion(): string;
    private _timeZone;
    get timeZone(): DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesTimeZoneList;
    get vmBackupStorageType(): string;
    get vmFileSystemStorageType(): string;
}
export declare class DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesOutputReference;
}
export interface DataGoogleOracleDatabaseCloudVmClustersCloudVmClusters {
}
export declare function dataGoogleOracleDatabaseCloudVmClustersCloudVmClustersToTerraform(struct?: DataGoogleOracleDatabaseCloudVmClustersCloudVmClusters): any;
export declare function dataGoogleOracleDatabaseCloudVmClustersCloudVmClustersToHclTerraform(struct?: DataGoogleOracleDatabaseCloudVmClustersCloudVmClusters): any;
export declare class DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseCloudVmClustersCloudVmClusters | undefined;
    set internalValue(value: DataGoogleOracleDatabaseCloudVmClustersCloudVmClusters | undefined);
    get backupOdbSubnet(): string;
    get backupSubnetCidr(): string;
    get cidr(): string;
    get cloudVmClusterId(): string;
    get createTime(): string;
    get deletionPolicy(): string;
    get deletionProtection(): cdktn.IResolvable;
    get displayName(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get exadataInfrastructure(): string;
    get exascaleDbStorageVault(): string;
    get gcpOracleZone(): string;
    private _identityConnector;
    get identityConnector(): DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersIdentityConnectorList;
    private _labels;
    get labels(): cdktn.StringMap;
    get location(): string;
    get name(): string;
    get network(): string;
    get odbNetwork(): string;
    get odbSubnet(): string;
    get project(): string;
    private _properties;
    get properties(): DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersPropertiesList;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
}
export declare class DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_cloud_vm_clusters google_oracle_database_cloud_vm_clusters}
*/
export declare class DataGoogleOracleDatabaseCloudVmClusters extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_oracle_database_cloud_vm_clusters";
    /**
    * Generates CDKTN code for importing a DataGoogleOracleDatabaseCloudVmClusters resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleOracleDatabaseCloudVmClusters to import
    * @param importFromId The id of the existing DataGoogleOracleDatabaseCloudVmClusters that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_cloud_vm_clusters#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleOracleDatabaseCloudVmClusters to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_cloud_vm_clusters google_oracle_database_cloud_vm_clusters} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleOracleDatabaseCloudVmClustersConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleOracleDatabaseCloudVmClustersConfig);
    private _cloudVmClusters;
    get cloudVmClusters(): DataGoogleOracleDatabaseCloudVmClustersCloudVmClustersList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
