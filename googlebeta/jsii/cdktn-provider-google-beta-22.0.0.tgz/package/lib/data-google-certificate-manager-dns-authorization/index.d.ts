/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleCertificateManagerDnsAuthorizationConfig extends cdktn.TerraformMetaArguments {
    /**
    * A domain which is being authorized. A DnsAuthorization resource covers a
    * single domain and its wildcard, e.g. authorization for "example.com" can
    * be used to issue certificates for "example.com" and "*.example.com".
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_certificate_manager_dns_authorization#domain DataGoogleCertificateManagerDnsAuthorization#domain}
    */
    readonly domain: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_certificate_manager_dns_authorization#id DataGoogleCertificateManagerDnsAuthorization#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The Certificate Manager location. If not specified, "global" is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_certificate_manager_dns_authorization#location DataGoogleCertificateManagerDnsAuthorization#location}
    */
    readonly location?: string;
    /**
    * Name of the resource; provided by the client when the resource is created.
    * The name must be 1-64 characters long, and match the regular expression [a-zA-Z][a-zA-Z0-9_-]* which means the first character must be a letter,
    * and all following characters must be a dash, underscore, letter or digit.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_certificate_manager_dns_authorization#name DataGoogleCertificateManagerDnsAuthorization#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_certificate_manager_dns_authorization#project DataGoogleCertificateManagerDnsAuthorization#project}
    */
    readonly project?: string;
}
export interface DataGoogleCertificateManagerDnsAuthorizationDnsResourceRecord {
}
export declare function dataGoogleCertificateManagerDnsAuthorizationDnsResourceRecordToTerraform(struct?: DataGoogleCertificateManagerDnsAuthorizationDnsResourceRecord): any;
export declare function dataGoogleCertificateManagerDnsAuthorizationDnsResourceRecordToHclTerraform(struct?: DataGoogleCertificateManagerDnsAuthorizationDnsResourceRecord): any;
export declare class DataGoogleCertificateManagerDnsAuthorizationDnsResourceRecordOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCertificateManagerDnsAuthorizationDnsResourceRecord | undefined;
    set internalValue(value: DataGoogleCertificateManagerDnsAuthorizationDnsResourceRecord | undefined);
    get data(): string;
    get name(): string;
    get type(): string;
}
export declare class DataGoogleCertificateManagerDnsAuthorizationDnsResourceRecordList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCertificateManagerDnsAuthorizationDnsResourceRecordOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_certificate_manager_dns_authorization google_certificate_manager_dns_authorization}
*/
export declare class DataGoogleCertificateManagerDnsAuthorization extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_certificate_manager_dns_authorization";
    /**
    * Generates CDKTN code for importing a DataGoogleCertificateManagerDnsAuthorization resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleCertificateManagerDnsAuthorization to import
    * @param importFromId The id of the existing DataGoogleCertificateManagerDnsAuthorization that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_certificate_manager_dns_authorization#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleCertificateManagerDnsAuthorization to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_certificate_manager_dns_authorization google_certificate_manager_dns_authorization} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleCertificateManagerDnsAuthorizationConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleCertificateManagerDnsAuthorizationConfig);
    get deletionPolicy(): string;
    get description(): string;
    private _dnsResourceRecord;
    get dnsResourceRecord(): DataGoogleCertificateManagerDnsAuthorizationDnsResourceRecordList;
    private _domain?;
    get domain(): string;
    set domain(value: string);
    get domainInput(): string | undefined;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels;
    get labels(): cdktn.StringMap;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get type(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
