/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleAgentRegistryMcpServerConfig extends cdktn.TerraformMetaArguments {
    /**
    * A filter string that identifies a unique MCP server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_agent_registry_mcp_server#filter DataGoogleAgentRegistryMcpServer#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_agent_registry_mcp_server#id DataGoogleAgentRegistryMcpServer#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_agent_registry_mcp_server#location DataGoogleAgentRegistryMcpServer#location}
    */
    readonly location: string;
    /**
    * The unique identifier for the MCP server.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_agent_registry_mcp_server#mcp_server_id DataGoogleAgentRegistryMcpServer#mcp_server_id}
    */
    readonly mcpServerId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_agent_registry_mcp_server#project DataGoogleAgentRegistryMcpServer#project}
    */
    readonly project?: string;
}
export interface DataGoogleAgentRegistryMcpServerInterfaces {
}
export declare function dataGoogleAgentRegistryMcpServerInterfacesToTerraform(struct?: DataGoogleAgentRegistryMcpServerInterfaces): any;
export declare function dataGoogleAgentRegistryMcpServerInterfacesToHclTerraform(struct?: DataGoogleAgentRegistryMcpServerInterfaces): any;
export declare class DataGoogleAgentRegistryMcpServerInterfacesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAgentRegistryMcpServerInterfaces | undefined;
    set internalValue(value: DataGoogleAgentRegistryMcpServerInterfaces | undefined);
    get protocolBinding(): string;
    get url(): string;
}
export declare class DataGoogleAgentRegistryMcpServerInterfacesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAgentRegistryMcpServerInterfacesOutputReference;
}
export interface DataGoogleAgentRegistryMcpServerToolsAnnotations {
}
export declare function dataGoogleAgentRegistryMcpServerToolsAnnotationsToTerraform(struct?: DataGoogleAgentRegistryMcpServerToolsAnnotations): any;
export declare function dataGoogleAgentRegistryMcpServerToolsAnnotationsToHclTerraform(struct?: DataGoogleAgentRegistryMcpServerToolsAnnotations): any;
export declare class DataGoogleAgentRegistryMcpServerToolsAnnotationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAgentRegistryMcpServerToolsAnnotations | undefined;
    set internalValue(value: DataGoogleAgentRegistryMcpServerToolsAnnotations | undefined);
    get destructiveHint(): cdktn.IResolvable;
    get idempotentHint(): cdktn.IResolvable;
    get openWorldHint(): cdktn.IResolvable;
    get readOnlyHint(): cdktn.IResolvable;
    get title(): string;
}
export declare class DataGoogleAgentRegistryMcpServerToolsAnnotationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAgentRegistryMcpServerToolsAnnotationsOutputReference;
}
export interface DataGoogleAgentRegistryMcpServerTools {
}
export declare function dataGoogleAgentRegistryMcpServerToolsToTerraform(struct?: DataGoogleAgentRegistryMcpServerTools): any;
export declare function dataGoogleAgentRegistryMcpServerToolsToHclTerraform(struct?: DataGoogleAgentRegistryMcpServerTools): any;
export declare class DataGoogleAgentRegistryMcpServerToolsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleAgentRegistryMcpServerTools | undefined;
    set internalValue(value: DataGoogleAgentRegistryMcpServerTools | undefined);
    private _annotations;
    get annotations(): DataGoogleAgentRegistryMcpServerToolsAnnotationsList;
    get description(): string;
    get name(): string;
}
export declare class DataGoogleAgentRegistryMcpServerToolsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleAgentRegistryMcpServerToolsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_agent_registry_mcp_server google_agent_registry_mcp_server}
*/
export declare class DataGoogleAgentRegistryMcpServer extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_agent_registry_mcp_server";
    /**
    * Generates CDKTN code for importing a DataGoogleAgentRegistryMcpServer resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleAgentRegistryMcpServer to import
    * @param importFromId The id of the existing DataGoogleAgentRegistryMcpServer that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_agent_registry_mcp_server#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleAgentRegistryMcpServer to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_agent_registry_mcp_server google_agent_registry_mcp_server} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleAgentRegistryMcpServerConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleAgentRegistryMcpServerConfig);
    private _attributes;
    get attributes(): cdktn.StringMap;
    get createTime(): string;
    get description(): string;
    get displayName(): string;
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _interfaces;
    get interfaces(): DataGoogleAgentRegistryMcpServerInterfacesList;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _mcpServerId?;
    get mcpServerId(): string;
    set mcpServerId(value: string);
    resetMcpServerId(): void;
    get mcpServerIdInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _tools;
    get tools(): DataGoogleAgentRegistryMcpServerToolsList;
    get updateTime(): string;
    get urn(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
