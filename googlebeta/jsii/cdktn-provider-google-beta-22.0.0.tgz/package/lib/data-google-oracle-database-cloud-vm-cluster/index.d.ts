/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleOracleDatabaseCloudVmClusterConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the VM Cluster to create. This value is restricted
    * to (^[a-z]([a-z0-9-]{0,61}[a-z0-9])?$) and must be a maximum of 63
    * characters in length. The value must start with a letter and end with
    * a letter or a number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_cloud_vm_cluster#cloud_vm_cluster_id DataGoogleOracleDatabaseCloudVmCluster#cloud_vm_cluster_id}
    */
    readonly cloudVmClusterId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_cloud_vm_cluster#id DataGoogleOracleDatabaseCloudVmCluster#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Resource ID segment making up resource 'name'. See documentation for resource type 'oracledatabase.googleapis.com/DbNode'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_cloud_vm_cluster#location DataGoogleOracleDatabaseCloudVmCluster#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_cloud_vm_cluster#project DataGoogleOracleDatabaseCloudVmCluster#project}
    */
    readonly project?: string;
}
export interface DataGoogleOracleDatabaseCloudVmClusterIdentityConnector {
}
export declare function dataGoogleOracleDatabaseCloudVmClusterIdentityConnectorToTerraform(struct?: DataGoogleOracleDatabaseCloudVmClusterIdentityConnector): any;
export declare function dataGoogleOracleDatabaseCloudVmClusterIdentityConnectorToHclTerraform(struct?: DataGoogleOracleDatabaseCloudVmClusterIdentityConnector): any;
export declare class DataGoogleOracleDatabaseCloudVmClusterIdentityConnectorOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseCloudVmClusterIdentityConnector | undefined;
    set internalValue(value: DataGoogleOracleDatabaseCloudVmClusterIdentityConnector | undefined);
    get connectionState(): string;
    get serviceAgentEmail(): string;
}
export declare class DataGoogleOracleDatabaseCloudVmClusterIdentityConnectorList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseCloudVmClusterIdentityConnectorOutputReference;
}
export interface DataGoogleOracleDatabaseCloudVmClusterPropertiesDiagnosticsDataCollectionOptions {
}
export declare function dataGoogleOracleDatabaseCloudVmClusterPropertiesDiagnosticsDataCollectionOptionsToTerraform(struct?: DataGoogleOracleDatabaseCloudVmClusterPropertiesDiagnosticsDataCollectionOptions): any;
export declare function dataGoogleOracleDatabaseCloudVmClusterPropertiesDiagnosticsDataCollectionOptionsToHclTerraform(struct?: DataGoogleOracleDatabaseCloudVmClusterPropertiesDiagnosticsDataCollectionOptions): any;
export declare class DataGoogleOracleDatabaseCloudVmClusterPropertiesDiagnosticsDataCollectionOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseCloudVmClusterPropertiesDiagnosticsDataCollectionOptions | undefined;
    set internalValue(value: DataGoogleOracleDatabaseCloudVmClusterPropertiesDiagnosticsDataCollectionOptions | undefined);
    get diagnosticsEventsEnabled(): cdktn.IResolvable;
    get healthMonitoringEnabled(): cdktn.IResolvable;
    get incidentLogsEnabled(): cdktn.IResolvable;
}
export declare class DataGoogleOracleDatabaseCloudVmClusterPropertiesDiagnosticsDataCollectionOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseCloudVmClusterPropertiesDiagnosticsDataCollectionOptionsOutputReference;
}
export interface DataGoogleOracleDatabaseCloudVmClusterPropertiesTimeZone {
}
export declare function dataGoogleOracleDatabaseCloudVmClusterPropertiesTimeZoneToTerraform(struct?: DataGoogleOracleDatabaseCloudVmClusterPropertiesTimeZone): any;
export declare function dataGoogleOracleDatabaseCloudVmClusterPropertiesTimeZoneToHclTerraform(struct?: DataGoogleOracleDatabaseCloudVmClusterPropertiesTimeZone): any;
export declare class DataGoogleOracleDatabaseCloudVmClusterPropertiesTimeZoneOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseCloudVmClusterPropertiesTimeZone | undefined;
    set internalValue(value: DataGoogleOracleDatabaseCloudVmClusterPropertiesTimeZone | undefined);
    get id(): string;
    get version(): string;
}
export declare class DataGoogleOracleDatabaseCloudVmClusterPropertiesTimeZoneList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseCloudVmClusterPropertiesTimeZoneOutputReference;
}
export interface DataGoogleOracleDatabaseCloudVmClusterProperties {
}
export declare function dataGoogleOracleDatabaseCloudVmClusterPropertiesToTerraform(struct?: DataGoogleOracleDatabaseCloudVmClusterProperties): any;
export declare function dataGoogleOracleDatabaseCloudVmClusterPropertiesToHclTerraform(struct?: DataGoogleOracleDatabaseCloudVmClusterProperties): any;
export declare class DataGoogleOracleDatabaseCloudVmClusterPropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleOracleDatabaseCloudVmClusterProperties | undefined;
    set internalValue(value: DataGoogleOracleDatabaseCloudVmClusterProperties | undefined);
    get clusterName(): string;
    get compartmentId(): string;
    get cpuCoreCount(): number;
    get dataStorageSizeTb(): number;
    get dbNodeStorageSizeGb(): number;
    get dbServerOcids(): string[];
    private _diagnosticsDataCollectionOptions;
    get diagnosticsDataCollectionOptions(): DataGoogleOracleDatabaseCloudVmClusterPropertiesDiagnosticsDataCollectionOptionsList;
    get diskRedundancy(): string;
    get dnsListenerIp(): string;
    get domain(): string;
    get giVersion(): string;
    get hostname(): string;
    get hostnamePrefix(): string;
    get licenseType(): string;
    get localBackupEnabled(): cdktn.IResolvable;
    get memorySizeGb(): number;
    get nodeCount(): number;
    get ociUrl(): string;
    get ocid(): string;
    get ocpuCount(): number;
    get scanDns(): string;
    get scanDnsRecordId(): string;
    get scanIpIds(): string[];
    get scanListenerPortTcp(): number;
    get scanListenerPortTcpSsl(): number;
    get shape(): string;
    get sparseDiskgroupEnabled(): cdktn.IResolvable;
    get sshPublicKeys(): string[];
    get state(): string;
    get storageManagementType(): string;
    get storageSizeGb(): number;
    get systemVersion(): string;
    private _timeZone;
    get timeZone(): DataGoogleOracleDatabaseCloudVmClusterPropertiesTimeZoneList;
    get vmBackupStorageType(): string;
    get vmFileSystemStorageType(): string;
}
export declare class DataGoogleOracleDatabaseCloudVmClusterPropertiesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleOracleDatabaseCloudVmClusterPropertiesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_cloud_vm_cluster google_oracle_database_cloud_vm_cluster}
*/
export declare class DataGoogleOracleDatabaseCloudVmCluster extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_oracle_database_cloud_vm_cluster";
    /**
    * Generates CDKTN code for importing a DataGoogleOracleDatabaseCloudVmCluster resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleOracleDatabaseCloudVmCluster to import
    * @param importFromId The id of the existing DataGoogleOracleDatabaseCloudVmCluster that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_cloud_vm_cluster#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleOracleDatabaseCloudVmCluster to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_oracle_database_cloud_vm_cluster google_oracle_database_cloud_vm_cluster} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleOracleDatabaseCloudVmClusterConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleOracleDatabaseCloudVmClusterConfig);
    get backupOdbSubnet(): string;
    get backupSubnetCidr(): string;
    get cidr(): string;
    private _cloudVmClusterId?;
    get cloudVmClusterId(): string;
    set cloudVmClusterId(value: string);
    get cloudVmClusterIdInput(): string | undefined;
    get createTime(): string;
    get deletionPolicy(): string;
    get deletionProtection(): cdktn.IResolvable;
    get displayName(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get exadataInfrastructure(): string;
    get exascaleDbStorageVault(): string;
    get gcpOracleZone(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _identityConnector;
    get identityConnector(): DataGoogleOracleDatabaseCloudVmClusterIdentityConnectorList;
    private _labels;
    get labels(): cdktn.StringMap;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    get network(): string;
    get odbNetwork(): string;
    get odbSubnet(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _properties;
    get properties(): DataGoogleOracleDatabaseCloudVmClusterPropertiesList;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
