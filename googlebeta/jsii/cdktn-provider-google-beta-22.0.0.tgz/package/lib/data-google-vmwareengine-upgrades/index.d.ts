/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleVmwareengineUpgradesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_vmwareengine_upgrades#id DataGoogleVmwareengineUpgrades#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The resource name of the specific Upgrade to retrieve. If provided, the 'upgrades' list will contain only this upgrade.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_vmwareengine_upgrades#name DataGoogleVmwareengineUpgrades#name}
    */
    readonly name?: string;
    /**
    * The resource name of the private cloud for which upgrades will be listed.
    * Resource names are schemeless URIs that follow the conventions in https://cloud.google.com/apis/design/resource_names.
    * For example: projects/my-project/locations/us-west1-a/privateClouds/my-cloud
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_vmwareengine_upgrades#parent DataGoogleVmwareengineUpgrades#parent}
    */
    readonly parent: string;
}
export interface DataGoogleVmwareengineUpgradesUpgradesComponentUpgrades {
}
export declare function dataGoogleVmwareengineUpgradesUpgradesComponentUpgradesToTerraform(struct?: DataGoogleVmwareengineUpgradesUpgradesComponentUpgrades): any;
export declare function dataGoogleVmwareengineUpgradesUpgradesComponentUpgradesToHclTerraform(struct?: DataGoogleVmwareengineUpgradesUpgradesComponentUpgrades): any;
export declare class DataGoogleVmwareengineUpgradesUpgradesComponentUpgradesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleVmwareengineUpgradesUpgradesComponentUpgrades | undefined;
    set internalValue(value: DataGoogleVmwareengineUpgradesUpgradesComponentUpgrades | undefined);
    get componentType(): string;
    get state(): string;
}
export declare class DataGoogleVmwareengineUpgradesUpgradesComponentUpgradesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleVmwareengineUpgradesUpgradesComponentUpgradesOutputReference;
}
export interface DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsEndTime {
}
export declare function dataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsEndTimeToTerraform(struct?: DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsEndTime): any;
export declare function dataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsEndTimeToHclTerraform(struct?: DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsEndTime): any;
export declare class DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsEndTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsEndTime | undefined;
    set internalValue(value: DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsEndTime | undefined);
    get hours(): number;
    get minutes(): number;
}
export declare class DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsEndTimeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsEndTimeOutputReference;
}
export interface DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsStartTime {
}
export declare function dataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsStartTimeToTerraform(struct?: DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsStartTime): any;
export declare function dataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsStartTimeToHclTerraform(struct?: DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsStartTime): any;
export declare class DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsStartTime | undefined;
    set internalValue(value: DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsStartTime | undefined);
    get hours(): number;
    get minutes(): number;
}
export declare class DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsStartTimeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsStartTimeOutputReference;
}
export interface DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervals {
}
export declare function dataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsToTerraform(struct?: DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervals): any;
export declare function dataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsToHclTerraform(struct?: DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervals): any;
export declare class DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervals | undefined;
    set internalValue(value: DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervals | undefined);
    get endDay(): string;
    private _endTime;
    get endTime(): DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsEndTimeList;
    get startDay(): string;
    private _startTime;
    get startTime(): DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsStartTimeList;
}
export declare class DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsOutputReference;
}
export interface DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsRescheduleDateRange {
}
export declare function dataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsRescheduleDateRangeToTerraform(struct?: DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsRescheduleDateRange): any;
export declare function dataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsRescheduleDateRangeToHclTerraform(struct?: DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsRescheduleDateRange): any;
export declare class DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsRescheduleDateRangeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsRescheduleDateRange | undefined;
    set internalValue(value: DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsRescheduleDateRange | undefined);
    get endTime(): string;
    get startTime(): string;
}
export declare class DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsRescheduleDateRangeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsRescheduleDateRangeOutputReference;
}
export interface DataGoogleVmwareengineUpgradesUpgradesScheduleConstraints {
}
export declare function dataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsToTerraform(struct?: DataGoogleVmwareengineUpgradesUpgradesScheduleConstraints): any;
export declare function dataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsToHclTerraform(struct?: DataGoogleVmwareengineUpgradesUpgradesScheduleConstraints): any;
export declare class DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleVmwareengineUpgradesUpgradesScheduleConstraints | undefined;
    set internalValue(value: DataGoogleVmwareengineUpgradesUpgradesScheduleConstraints | undefined);
    private _disallowedIntervals;
    get disallowedIntervals(): DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsDisallowedIntervalsList;
    get minHoursDay(): number;
    get minHoursWeek(): number;
    private _rescheduleDateRange;
    get rescheduleDateRange(): DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsRescheduleDateRangeList;
}
export declare class DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsOutputReference;
}
export interface DataGoogleVmwareengineUpgradesUpgradesScheduleEditWindow {
}
export declare function dataGoogleVmwareengineUpgradesUpgradesScheduleEditWindowToTerraform(struct?: DataGoogleVmwareengineUpgradesUpgradesScheduleEditWindow): any;
export declare function dataGoogleVmwareengineUpgradesUpgradesScheduleEditWindowToHclTerraform(struct?: DataGoogleVmwareengineUpgradesUpgradesScheduleEditWindow): any;
export declare class DataGoogleVmwareengineUpgradesUpgradesScheduleEditWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleVmwareengineUpgradesUpgradesScheduleEditWindow | undefined;
    set internalValue(value: DataGoogleVmwareengineUpgradesUpgradesScheduleEditWindow | undefined);
    get endTime(): string;
    get startTime(): string;
}
export declare class DataGoogleVmwareengineUpgradesUpgradesScheduleEditWindowList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleVmwareengineUpgradesUpgradesScheduleEditWindowOutputReference;
}
export interface DataGoogleVmwareengineUpgradesUpgradesScheduleWeeklyWindowsStartTime {
}
export declare function dataGoogleVmwareengineUpgradesUpgradesScheduleWeeklyWindowsStartTimeToTerraform(struct?: DataGoogleVmwareengineUpgradesUpgradesScheduleWeeklyWindowsStartTime): any;
export declare function dataGoogleVmwareengineUpgradesUpgradesScheduleWeeklyWindowsStartTimeToHclTerraform(struct?: DataGoogleVmwareengineUpgradesUpgradesScheduleWeeklyWindowsStartTime): any;
export declare class DataGoogleVmwareengineUpgradesUpgradesScheduleWeeklyWindowsStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleVmwareengineUpgradesUpgradesScheduleWeeklyWindowsStartTime | undefined;
    set internalValue(value: DataGoogleVmwareengineUpgradesUpgradesScheduleWeeklyWindowsStartTime | undefined);
    get hours(): number;
    get minutes(): number;
}
export declare class DataGoogleVmwareengineUpgradesUpgradesScheduleWeeklyWindowsStartTimeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleVmwareengineUpgradesUpgradesScheduleWeeklyWindowsStartTimeOutputReference;
}
export interface DataGoogleVmwareengineUpgradesUpgradesScheduleWeeklyWindows {
}
export declare function dataGoogleVmwareengineUpgradesUpgradesScheduleWeeklyWindowsToTerraform(struct?: DataGoogleVmwareengineUpgradesUpgradesScheduleWeeklyWindows): any;
export declare function dataGoogleVmwareengineUpgradesUpgradesScheduleWeeklyWindowsToHclTerraform(struct?: DataGoogleVmwareengineUpgradesUpgradesScheduleWeeklyWindows): any;
export declare class DataGoogleVmwareengineUpgradesUpgradesScheduleWeeklyWindowsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleVmwareengineUpgradesUpgradesScheduleWeeklyWindows | undefined;
    set internalValue(value: DataGoogleVmwareengineUpgradesUpgradesScheduleWeeklyWindows | undefined);
    get dayOfWeek(): string;
    get duration(): string;
    private _startTime;
    get startTime(): DataGoogleVmwareengineUpgradesUpgradesScheduleWeeklyWindowsStartTimeList;
}
export declare class DataGoogleVmwareengineUpgradesUpgradesScheduleWeeklyWindowsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleVmwareengineUpgradesUpgradesScheduleWeeklyWindowsOutputReference;
}
export interface DataGoogleVmwareengineUpgradesUpgradesSchedule {
}
export declare function dataGoogleVmwareengineUpgradesUpgradesScheduleToTerraform(struct?: DataGoogleVmwareengineUpgradesUpgradesSchedule): any;
export declare function dataGoogleVmwareengineUpgradesUpgradesScheduleToHclTerraform(struct?: DataGoogleVmwareengineUpgradesUpgradesSchedule): any;
export declare class DataGoogleVmwareengineUpgradesUpgradesScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleVmwareengineUpgradesUpgradesSchedule | undefined;
    set internalValue(value: DataGoogleVmwareengineUpgradesUpgradesSchedule | undefined);
    private _constraints;
    get constraints(): DataGoogleVmwareengineUpgradesUpgradesScheduleConstraintsList;
    private _editWindow;
    get editWindow(): DataGoogleVmwareengineUpgradesUpgradesScheduleEditWindowList;
    get lastEditor(): string;
    get startTime(): string;
    private _weeklyWindows;
    get weeklyWindows(): DataGoogleVmwareengineUpgradesUpgradesScheduleWeeklyWindowsList;
}
export declare class DataGoogleVmwareengineUpgradesUpgradesScheduleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleVmwareengineUpgradesUpgradesScheduleOutputReference;
}
export interface DataGoogleVmwareengineUpgradesUpgrades {
}
export declare function dataGoogleVmwareengineUpgradesUpgradesToTerraform(struct?: DataGoogleVmwareengineUpgradesUpgrades): any;
export declare function dataGoogleVmwareengineUpgradesUpgradesToHclTerraform(struct?: DataGoogleVmwareengineUpgradesUpgrades): any;
export declare class DataGoogleVmwareengineUpgradesUpgradesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleVmwareengineUpgradesUpgrades | undefined;
    set internalValue(value: DataGoogleVmwareengineUpgradesUpgrades | undefined);
    private _componentUpgrades;
    get componentUpgrades(): DataGoogleVmwareengineUpgradesUpgradesComponentUpgradesList;
    get description(): string;
    get endTime(): string;
    get estimatedDuration(): string;
    get name(): string;
    private _schedule;
    get schedule(): DataGoogleVmwareengineUpgradesUpgradesScheduleList;
    get startVersion(): string;
    get state(): string;
    get targetVersion(): string;
    get type(): string;
}
export declare class DataGoogleVmwareengineUpgradesUpgradesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleVmwareengineUpgradesUpgradesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_vmwareengine_upgrades google_vmwareengine_upgrades}
*/
export declare class DataGoogleVmwareengineUpgrades extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_vmwareengine_upgrades";
    /**
    * Generates CDKTN code for importing a DataGoogleVmwareengineUpgrades resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleVmwareengineUpgrades to import
    * @param importFromId The id of the existing DataGoogleVmwareengineUpgrades that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_vmwareengine_upgrades#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleVmwareengineUpgrades to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_vmwareengine_upgrades google_vmwareengine_upgrades} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleVmwareengineUpgradesConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleVmwareengineUpgradesConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _parent?;
    get parent(): string;
    set parent(value: string);
    get parentInput(): string | undefined;
    private _upgrades;
    get upgrades(): DataGoogleVmwareengineUpgradesUpgradesList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
