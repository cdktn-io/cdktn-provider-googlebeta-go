/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleNetworkManagementConnectivityTestRunConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_network_management_connectivity_test_run#id DataGoogleNetworkManagementConnectivityTestRun#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Unique name for the connectivity test.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_network_management_connectivity_test_run#name DataGoogleNetworkManagementConnectivityTestRun#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_network_management_connectivity_test_run#project DataGoogleNetworkManagementConnectivityTestRun#project}
    */
    readonly project?: string;
}
export interface DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesEndpointInfo {
}
export declare function dataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesEndpointInfoToTerraform(struct?: DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesEndpointInfo): any;
export declare function dataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesEndpointInfoToHclTerraform(struct?: DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesEndpointInfo): any;
export declare class DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesEndpointInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesEndpointInfo | undefined;
    set internalValue(value: DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesEndpointInfo | undefined);
    get destinationIp(): string;
    get destinationNetworkUri(): string;
    get destinationPort(): number;
    get protocol(): string;
    get sourceAgentUri(): string;
    get sourceIp(): string;
    get sourceNetworkUri(): string;
    get sourcePort(): number;
}
export declare class DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesEndpointInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesEndpointInfoOutputReference;
}
export interface DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesSteps {
}
export declare function dataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesStepsToTerraform(struct?: DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesSteps): any;
export declare function dataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesStepsToHclTerraform(struct?: DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesSteps): any;
export declare class DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesStepsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesSteps | undefined;
    set internalValue(value: DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesSteps | undefined);
    get causesDrop(): cdktn.IResolvable;
    get description(): string;
    get projectId(): string;
    get state(): string;
}
export declare class DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesStepsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesStepsOutputReference;
}
export interface DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTraces {
}
export declare function dataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesToTerraform(struct?: DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTraces): any;
export declare function dataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesToHclTerraform(struct?: DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTraces): any;
export declare class DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTraces | undefined;
    set internalValue(value: DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTraces | undefined);
    private _endpointInfo;
    get endpointInfo(): DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesEndpointInfoList;
    get forwardTraceId(): number;
    private _steps;
    get steps(): DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesStepsList;
}
export declare class DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesOutputReference;
}
export interface DataGoogleNetworkManagementConnectivityTestRunReachabilityDetails {
}
export declare function dataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsToTerraform(struct?: DataGoogleNetworkManagementConnectivityTestRunReachabilityDetails): any;
export declare function dataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsToHclTerraform(struct?: DataGoogleNetworkManagementConnectivityTestRunReachabilityDetails): any;
export declare class DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleNetworkManagementConnectivityTestRunReachabilityDetails | undefined;
    set internalValue(value: DataGoogleNetworkManagementConnectivityTestRunReachabilityDetails | undefined);
    get result(): string;
    private _traces;
    get traces(): DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsTracesList;
    get verifyTime(): string;
}
export declare class DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_network_management_connectivity_test_run google_network_management_connectivity_test_run}
*/
export declare class DataGoogleNetworkManagementConnectivityTestRun extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_network_management_connectivity_test_run";
    /**
    * Generates CDKTN code for importing a DataGoogleNetworkManagementConnectivityTestRun resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleNetworkManagementConnectivityTestRun to import
    * @param importFromId The id of the existing DataGoogleNetworkManagementConnectivityTestRun that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_network_management_connectivity_test_run#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleNetworkManagementConnectivityTestRun to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_network_management_connectivity_test_run google_network_management_connectivity_test_run} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleNetworkManagementConnectivityTestRunConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleNetworkManagementConnectivityTestRunConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _reachabilityDetails;
    get reachabilityDetails(): DataGoogleNetworkManagementConnectivityTestRunReachabilityDetailsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
