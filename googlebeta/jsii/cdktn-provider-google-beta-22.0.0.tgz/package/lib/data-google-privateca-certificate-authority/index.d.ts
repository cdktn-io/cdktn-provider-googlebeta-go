/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGooglePrivatecaCertificateAuthorityConfig extends cdktn.TerraformMetaArguments {
    /**
    * The user provided Resource ID for this Certificate Authority.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_privateca_certificate_authority#certificate_authority_id DataGooglePrivatecaCertificateAuthority#certificate_authority_id}
    */
    readonly certificateAuthorityId?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_privateca_certificate_authority#id DataGooglePrivatecaCertificateAuthority#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Location of the CertificateAuthority. A full list of valid locations can be found by
    * running 'gcloud privateca locations list'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_privateca_certificate_authority#location DataGooglePrivatecaCertificateAuthority#location}
    */
    readonly location?: string;
    /**
    * The name of the CaPool this Certificate Authority belongs to.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_privateca_certificate_authority#pool DataGooglePrivatecaCertificateAuthority#pool}
    */
    readonly pool?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_privateca_certificate_authority#project DataGooglePrivatecaCertificateAuthority#project}
    */
    readonly project?: string;
}
export interface DataGooglePrivatecaCertificateAuthorityAccessUrls {
}
export declare function dataGooglePrivatecaCertificateAuthorityAccessUrlsToTerraform(struct?: DataGooglePrivatecaCertificateAuthorityAccessUrls): any;
export declare function dataGooglePrivatecaCertificateAuthorityAccessUrlsToHclTerraform(struct?: DataGooglePrivatecaCertificateAuthorityAccessUrls): any;
export declare class DataGooglePrivatecaCertificateAuthorityAccessUrlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivatecaCertificateAuthorityAccessUrls | undefined;
    set internalValue(value: DataGooglePrivatecaCertificateAuthorityAccessUrls | undefined);
    get caCertificateAccessUrl(): string;
    get crlAccessUrls(): string[];
}
export declare class DataGooglePrivatecaCertificateAuthorityAccessUrlsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivatecaCertificateAuthorityAccessUrlsOutputReference;
}
export interface DataGooglePrivatecaCertificateAuthorityConfigSubjectConfigSubject {
}
export declare function dataGooglePrivatecaCertificateAuthorityConfigSubjectConfigSubjectToTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigSubjectConfigSubject): any;
export declare function dataGooglePrivatecaCertificateAuthorityConfigSubjectConfigSubjectToHclTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigSubjectConfigSubject): any;
export declare class DataGooglePrivatecaCertificateAuthorityConfigSubjectConfigSubjectOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivatecaCertificateAuthorityConfigSubjectConfigSubject | undefined;
    set internalValue(value: DataGooglePrivatecaCertificateAuthorityConfigSubjectConfigSubject | undefined);
    get commonName(): string;
    get countryCode(): string;
    get locality(): string;
    get organization(): string;
    get organizationalUnit(): string;
    get postalCode(): string;
    get province(): string;
    get streetAddress(): string;
}
export declare class DataGooglePrivatecaCertificateAuthorityConfigSubjectConfigSubjectList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivatecaCertificateAuthorityConfigSubjectConfigSubjectOutputReference;
}
export interface DataGooglePrivatecaCertificateAuthorityConfigSubjectConfigSubjectAltName {
}
export declare function dataGooglePrivatecaCertificateAuthorityConfigSubjectConfigSubjectAltNameToTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigSubjectConfigSubjectAltName): any;
export declare function dataGooglePrivatecaCertificateAuthorityConfigSubjectConfigSubjectAltNameToHclTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigSubjectConfigSubjectAltName): any;
export declare class DataGooglePrivatecaCertificateAuthorityConfigSubjectConfigSubjectAltNameOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivatecaCertificateAuthorityConfigSubjectConfigSubjectAltName | undefined;
    set internalValue(value: DataGooglePrivatecaCertificateAuthorityConfigSubjectConfigSubjectAltName | undefined);
    get dnsNames(): string[];
    get emailAddresses(): string[];
    get ipAddresses(): string[];
    get uris(): string[];
}
export declare class DataGooglePrivatecaCertificateAuthorityConfigSubjectConfigSubjectAltNameList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivatecaCertificateAuthorityConfigSubjectConfigSubjectAltNameOutputReference;
}
export interface DataGooglePrivatecaCertificateAuthorityConfigSubjectConfig {
}
export declare function dataGooglePrivatecaCertificateAuthorityConfigSubjectConfigToTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigSubjectConfig): any;
export declare function dataGooglePrivatecaCertificateAuthorityConfigSubjectConfigToHclTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigSubjectConfig): any;
export declare class DataGooglePrivatecaCertificateAuthorityConfigSubjectConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivatecaCertificateAuthorityConfigSubjectConfig | undefined;
    set internalValue(value: DataGooglePrivatecaCertificateAuthorityConfigSubjectConfig | undefined);
    private _subject;
    get subject(): DataGooglePrivatecaCertificateAuthorityConfigSubjectConfigSubjectList;
    private _subjectAltName;
    get subjectAltName(): DataGooglePrivatecaCertificateAuthorityConfigSubjectConfigSubjectAltNameList;
}
export declare class DataGooglePrivatecaCertificateAuthorityConfigSubjectConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivatecaCertificateAuthorityConfigSubjectConfigOutputReference;
}
export interface DataGooglePrivatecaCertificateAuthorityConfigSubjectKeyId {
}
export declare function dataGooglePrivatecaCertificateAuthorityConfigSubjectKeyIdToTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigSubjectKeyId): any;
export declare function dataGooglePrivatecaCertificateAuthorityConfigSubjectKeyIdToHclTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigSubjectKeyId): any;
export declare class DataGooglePrivatecaCertificateAuthorityConfigSubjectKeyIdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivatecaCertificateAuthorityConfigSubjectKeyId | undefined;
    set internalValue(value: DataGooglePrivatecaCertificateAuthorityConfigSubjectKeyId | undefined);
    get keyId(): string;
}
export declare class DataGooglePrivatecaCertificateAuthorityConfigSubjectKeyIdList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivatecaCertificateAuthorityConfigSubjectKeyIdOutputReference;
}
export interface DataGooglePrivatecaCertificateAuthorityConfigX509ConfigAdditionalExtensionsObjectId {
}
export declare function dataGooglePrivatecaCertificateAuthorityConfigX509ConfigAdditionalExtensionsObjectIdToTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigX509ConfigAdditionalExtensionsObjectId): any;
export declare function dataGooglePrivatecaCertificateAuthorityConfigX509ConfigAdditionalExtensionsObjectIdToHclTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigX509ConfigAdditionalExtensionsObjectId): any;
export declare class DataGooglePrivatecaCertificateAuthorityConfigX509ConfigAdditionalExtensionsObjectIdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigAdditionalExtensionsObjectId | undefined;
    set internalValue(value: DataGooglePrivatecaCertificateAuthorityConfigX509ConfigAdditionalExtensionsObjectId | undefined);
    get objectIdPath(): number[];
}
export declare class DataGooglePrivatecaCertificateAuthorityConfigX509ConfigAdditionalExtensionsObjectIdList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigAdditionalExtensionsObjectIdOutputReference;
}
export interface DataGooglePrivatecaCertificateAuthorityConfigX509ConfigAdditionalExtensions {
}
export declare function dataGooglePrivatecaCertificateAuthorityConfigX509ConfigAdditionalExtensionsToTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigX509ConfigAdditionalExtensions): any;
export declare function dataGooglePrivatecaCertificateAuthorityConfigX509ConfigAdditionalExtensionsToHclTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigX509ConfigAdditionalExtensions): any;
export declare class DataGooglePrivatecaCertificateAuthorityConfigX509ConfigAdditionalExtensionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigAdditionalExtensions | undefined;
    set internalValue(value: DataGooglePrivatecaCertificateAuthorityConfigX509ConfigAdditionalExtensions | undefined);
    get critical(): cdktn.IResolvable;
    private _objectId;
    get objectId(): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigAdditionalExtensionsObjectIdList;
    get value(): string;
}
export declare class DataGooglePrivatecaCertificateAuthorityConfigX509ConfigAdditionalExtensionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigAdditionalExtensionsOutputReference;
}
export interface DataGooglePrivatecaCertificateAuthorityConfigX509ConfigCaOptions {
}
export declare function dataGooglePrivatecaCertificateAuthorityConfigX509ConfigCaOptionsToTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigX509ConfigCaOptions): any;
export declare function dataGooglePrivatecaCertificateAuthorityConfigX509ConfigCaOptionsToHclTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigX509ConfigCaOptions): any;
export declare class DataGooglePrivatecaCertificateAuthorityConfigX509ConfigCaOptionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigCaOptions | undefined;
    set internalValue(value: DataGooglePrivatecaCertificateAuthorityConfigX509ConfigCaOptions | undefined);
    get isCa(): cdktn.IResolvable;
    get maxIssuerPathLength(): number;
    get nonCa(): cdktn.IResolvable;
    get zeroMaxIssuerPathLength(): cdktn.IResolvable;
}
export declare class DataGooglePrivatecaCertificateAuthorityConfigX509ConfigCaOptionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigCaOptionsOutputReference;
}
export interface DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageBaseKeyUsage {
}
export declare function dataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageBaseKeyUsageToTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageBaseKeyUsage): any;
export declare function dataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageBaseKeyUsageToHclTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageBaseKeyUsage): any;
export declare class DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageBaseKeyUsageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageBaseKeyUsage | undefined;
    set internalValue(value: DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageBaseKeyUsage | undefined);
    get certSign(): cdktn.IResolvable;
    get contentCommitment(): cdktn.IResolvable;
    get crlSign(): cdktn.IResolvable;
    get dataEncipherment(): cdktn.IResolvable;
    get decipherOnly(): cdktn.IResolvable;
    get digitalSignature(): cdktn.IResolvable;
    get encipherOnly(): cdktn.IResolvable;
    get keyAgreement(): cdktn.IResolvable;
    get keyEncipherment(): cdktn.IResolvable;
}
export declare class DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageBaseKeyUsageList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageBaseKeyUsageOutputReference;
}
export interface DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageExtendedKeyUsage {
}
export declare function dataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageExtendedKeyUsageToTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageExtendedKeyUsage): any;
export declare function dataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageExtendedKeyUsageToHclTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageExtendedKeyUsage): any;
export declare class DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageExtendedKeyUsageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageExtendedKeyUsage | undefined;
    set internalValue(value: DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageExtendedKeyUsage | undefined);
    get clientAuth(): cdktn.IResolvable;
    get codeSigning(): cdktn.IResolvable;
    get emailProtection(): cdktn.IResolvable;
    get ocspSigning(): cdktn.IResolvable;
    get serverAuth(): cdktn.IResolvable;
    get timeStamping(): cdktn.IResolvable;
}
export declare class DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageExtendedKeyUsageList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageExtendedKeyUsageOutputReference;
}
export interface DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageUnknownExtendedKeyUsages {
}
export declare function dataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageUnknownExtendedKeyUsagesToTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageUnknownExtendedKeyUsages): any;
export declare function dataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageUnknownExtendedKeyUsagesToHclTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageUnknownExtendedKeyUsages): any;
export declare class DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageUnknownExtendedKeyUsagesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageUnknownExtendedKeyUsages | undefined;
    set internalValue(value: DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageUnknownExtendedKeyUsages | undefined);
    get objectIdPath(): number[];
}
export declare class DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageUnknownExtendedKeyUsagesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageUnknownExtendedKeyUsagesOutputReference;
}
export interface DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsage {
}
export declare function dataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageToTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsage): any;
export declare function dataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageToHclTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsage): any;
export declare class DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsage | undefined;
    set internalValue(value: DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsage | undefined);
    private _baseKeyUsage;
    get baseKeyUsage(): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageBaseKeyUsageList;
    private _extendedKeyUsage;
    get extendedKeyUsage(): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageExtendedKeyUsageList;
    private _unknownExtendedKeyUsages;
    get unknownExtendedKeyUsages(): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageUnknownExtendedKeyUsagesList;
}
export declare class DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageOutputReference;
}
export interface DataGooglePrivatecaCertificateAuthorityConfigX509ConfigNameConstraints {
}
export declare function dataGooglePrivatecaCertificateAuthorityConfigX509ConfigNameConstraintsToTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigX509ConfigNameConstraints): any;
export declare function dataGooglePrivatecaCertificateAuthorityConfigX509ConfigNameConstraintsToHclTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigX509ConfigNameConstraints): any;
export declare class DataGooglePrivatecaCertificateAuthorityConfigX509ConfigNameConstraintsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigNameConstraints | undefined;
    set internalValue(value: DataGooglePrivatecaCertificateAuthorityConfigX509ConfigNameConstraints | undefined);
    get critical(): cdktn.IResolvable;
    get excludedDnsNames(): string[];
    get excludedEmailAddresses(): string[];
    get excludedIpRanges(): string[];
    get excludedUris(): string[];
    get permittedDnsNames(): string[];
    get permittedEmailAddresses(): string[];
    get permittedIpRanges(): string[];
    get permittedUris(): string[];
}
export declare class DataGooglePrivatecaCertificateAuthorityConfigX509ConfigNameConstraintsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigNameConstraintsOutputReference;
}
export interface DataGooglePrivatecaCertificateAuthorityConfigX509ConfigPolicyIds {
}
export declare function dataGooglePrivatecaCertificateAuthorityConfigX509ConfigPolicyIdsToTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigX509ConfigPolicyIds): any;
export declare function dataGooglePrivatecaCertificateAuthorityConfigX509ConfigPolicyIdsToHclTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigX509ConfigPolicyIds): any;
export declare class DataGooglePrivatecaCertificateAuthorityConfigX509ConfigPolicyIdsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigPolicyIds | undefined;
    set internalValue(value: DataGooglePrivatecaCertificateAuthorityConfigX509ConfigPolicyIds | undefined);
    get objectIdPath(): number[];
}
export declare class DataGooglePrivatecaCertificateAuthorityConfigX509ConfigPolicyIdsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigPolicyIdsOutputReference;
}
export interface DataGooglePrivatecaCertificateAuthorityConfigX509Config {
}
export declare function dataGooglePrivatecaCertificateAuthorityConfigX509ConfigToTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigX509Config): any;
export declare function dataGooglePrivatecaCertificateAuthorityConfigX509ConfigToHclTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigX509Config): any;
export declare class DataGooglePrivatecaCertificateAuthorityConfigX509ConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivatecaCertificateAuthorityConfigX509Config | undefined;
    set internalValue(value: DataGooglePrivatecaCertificateAuthorityConfigX509Config | undefined);
    private _additionalExtensions;
    get additionalExtensions(): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigAdditionalExtensionsList;
    get aiaOcspServers(): string[];
    private _caOptions;
    get caOptions(): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigCaOptionsList;
    private _keyUsage;
    get keyUsage(): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigKeyUsageList;
    private _nameConstraints;
    get nameConstraints(): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigNameConstraintsList;
    private _policyIds;
    get policyIds(): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigPolicyIdsList;
}
export declare class DataGooglePrivatecaCertificateAuthorityConfigX509ConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigOutputReference;
}
export interface DataGooglePrivatecaCertificateAuthorityConfigA {
}
export declare function dataGooglePrivatecaCertificateAuthorityConfigAToTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigA): any;
export declare function dataGooglePrivatecaCertificateAuthorityConfigAToHclTerraform(struct?: DataGooglePrivatecaCertificateAuthorityConfigA): any;
export declare class DataGooglePrivatecaCertificateAuthorityConfigAOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivatecaCertificateAuthorityConfigA | undefined;
    set internalValue(value: DataGooglePrivatecaCertificateAuthorityConfigA | undefined);
    private _subjectConfig;
    get subjectConfig(): DataGooglePrivatecaCertificateAuthorityConfigSubjectConfigList;
    private _subjectKeyId;
    get subjectKeyId(): DataGooglePrivatecaCertificateAuthorityConfigSubjectKeyIdList;
    private _x509Config;
    get x509Config(): DataGooglePrivatecaCertificateAuthorityConfigX509ConfigList;
}
export declare class DataGooglePrivatecaCertificateAuthorityConfigAList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivatecaCertificateAuthorityConfigAOutputReference;
}
export interface DataGooglePrivatecaCertificateAuthorityKeySpec {
}
export declare function dataGooglePrivatecaCertificateAuthorityKeySpecToTerraform(struct?: DataGooglePrivatecaCertificateAuthorityKeySpec): any;
export declare function dataGooglePrivatecaCertificateAuthorityKeySpecToHclTerraform(struct?: DataGooglePrivatecaCertificateAuthorityKeySpec): any;
export declare class DataGooglePrivatecaCertificateAuthorityKeySpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivatecaCertificateAuthorityKeySpec | undefined;
    set internalValue(value: DataGooglePrivatecaCertificateAuthorityKeySpec | undefined);
    get algorithm(): string;
    get cloudKmsKeyVersion(): string;
}
export declare class DataGooglePrivatecaCertificateAuthorityKeySpecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivatecaCertificateAuthorityKeySpecOutputReference;
}
export interface DataGooglePrivatecaCertificateAuthoritySubordinateConfigPemIssuerChain {
}
export declare function dataGooglePrivatecaCertificateAuthoritySubordinateConfigPemIssuerChainToTerraform(struct?: DataGooglePrivatecaCertificateAuthoritySubordinateConfigPemIssuerChain): any;
export declare function dataGooglePrivatecaCertificateAuthoritySubordinateConfigPemIssuerChainToHclTerraform(struct?: DataGooglePrivatecaCertificateAuthoritySubordinateConfigPemIssuerChain): any;
export declare class DataGooglePrivatecaCertificateAuthoritySubordinateConfigPemIssuerChainOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivatecaCertificateAuthoritySubordinateConfigPemIssuerChain | undefined;
    set internalValue(value: DataGooglePrivatecaCertificateAuthoritySubordinateConfigPemIssuerChain | undefined);
    get pemCertificates(): string[];
}
export declare class DataGooglePrivatecaCertificateAuthoritySubordinateConfigPemIssuerChainList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivatecaCertificateAuthoritySubordinateConfigPemIssuerChainOutputReference;
}
export interface DataGooglePrivatecaCertificateAuthoritySubordinateConfig {
}
export declare function dataGooglePrivatecaCertificateAuthoritySubordinateConfigToTerraform(struct?: DataGooglePrivatecaCertificateAuthoritySubordinateConfig): any;
export declare function dataGooglePrivatecaCertificateAuthoritySubordinateConfigToHclTerraform(struct?: DataGooglePrivatecaCertificateAuthoritySubordinateConfig): any;
export declare class DataGooglePrivatecaCertificateAuthoritySubordinateConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivatecaCertificateAuthoritySubordinateConfig | undefined;
    set internalValue(value: DataGooglePrivatecaCertificateAuthoritySubordinateConfig | undefined);
    get certificateAuthority(): string;
    private _pemIssuerChain;
    get pemIssuerChain(): DataGooglePrivatecaCertificateAuthoritySubordinateConfigPemIssuerChainList;
}
export declare class DataGooglePrivatecaCertificateAuthoritySubordinateConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivatecaCertificateAuthoritySubordinateConfigOutputReference;
}
export interface DataGooglePrivatecaCertificateAuthorityUserDefinedAccessUrls {
}
export declare function dataGooglePrivatecaCertificateAuthorityUserDefinedAccessUrlsToTerraform(struct?: DataGooglePrivatecaCertificateAuthorityUserDefinedAccessUrls): any;
export declare function dataGooglePrivatecaCertificateAuthorityUserDefinedAccessUrlsToHclTerraform(struct?: DataGooglePrivatecaCertificateAuthorityUserDefinedAccessUrls): any;
export declare class DataGooglePrivatecaCertificateAuthorityUserDefinedAccessUrlsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGooglePrivatecaCertificateAuthorityUserDefinedAccessUrls | undefined;
    set internalValue(value: DataGooglePrivatecaCertificateAuthorityUserDefinedAccessUrls | undefined);
    get aiaIssuingCertificateUrls(): string[];
    get crlAccessUrls(): string[];
}
export declare class DataGooglePrivatecaCertificateAuthorityUserDefinedAccessUrlsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGooglePrivatecaCertificateAuthorityUserDefinedAccessUrlsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_privateca_certificate_authority google_privateca_certificate_authority}
*/
export declare class DataGooglePrivatecaCertificateAuthority extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_privateca_certificate_authority";
    /**
    * Generates CDKTN code for importing a DataGooglePrivatecaCertificateAuthority resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGooglePrivatecaCertificateAuthority to import
    * @param importFromId The id of the existing DataGooglePrivatecaCertificateAuthority that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_privateca_certificate_authority#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGooglePrivatecaCertificateAuthority to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_privateca_certificate_authority google_privateca_certificate_authority} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGooglePrivatecaCertificateAuthorityConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGooglePrivatecaCertificateAuthorityConfig);
    private _accessUrls;
    get accessUrls(): DataGooglePrivatecaCertificateAuthorityAccessUrlsList;
    private _certificateAuthorityId?;
    get certificateAuthorityId(): string;
    set certificateAuthorityId(value: string);
    resetCertificateAuthorityId(): void;
    get certificateAuthorityIdInput(): string | undefined;
    private _config;
    get config(): DataGooglePrivatecaCertificateAuthorityConfigAList;
    get createTime(): string;
    get deletionPolicy(): string;
    get deletionProtection(): cdktn.IResolvable;
    get desiredState(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get gcsBucket(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ignoreActiveCertificatesOnDeletion(): cdktn.IResolvable;
    private _keySpec;
    get keySpec(): DataGooglePrivatecaCertificateAuthorityKeySpecList;
    private _labels;
    get labels(): cdktn.StringMap;
    get lifetime(): string;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    get name(): string;
    get pemCaCertificate(): string;
    get pemCaCertificates(): string[];
    get pemCsr(): string;
    private _pool?;
    get pool(): string;
    set pool(value: string);
    resetPool(): void;
    get poolInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get skipGracePeriod(): cdktn.IResolvable;
    get state(): string;
    private _subordinateConfig;
    get subordinateConfig(): DataGooglePrivatecaCertificateAuthoritySubordinateConfigList;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get type(): string;
    get updateTime(): string;
    private _userDefinedAccessUrls;
    get userDefinedAccessUrls(): DataGooglePrivatecaCertificateAuthorityUserDefinedAccessUrlsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
