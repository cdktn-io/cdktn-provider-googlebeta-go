/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleRedisInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_redis_instance#id DataGoogleRedisInstance#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The ID of the instance or a fully qualified identifier for the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_redis_instance#name DataGoogleRedisInstance#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_redis_instance#project DataGoogleRedisInstance#project}
    */
    readonly project?: string;
    /**
    * The name of the Redis region of the instance.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_redis_instance#region DataGoogleRedisInstance#region}
    */
    readonly region?: string;
}
export interface DataGoogleRedisInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTime {
}
export declare function dataGoogleRedisInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTimeToTerraform(struct?: DataGoogleRedisInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTime): any;
export declare function dataGoogleRedisInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTimeToHclTerraform(struct?: DataGoogleRedisInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTime): any;
export declare class DataGoogleRedisInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTime | undefined;
    set internalValue(value: DataGoogleRedisInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTime | undefined);
    get hours(): number;
    get minutes(): number;
    get nanos(): number;
    get seconds(): number;
}
export declare class DataGoogleRedisInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTimeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTimeOutputReference;
}
export interface DataGoogleRedisInstanceMaintenancePolicyWeeklyMaintenanceWindow {
}
export declare function dataGoogleRedisInstanceMaintenancePolicyWeeklyMaintenanceWindowToTerraform(struct?: DataGoogleRedisInstanceMaintenancePolicyWeeklyMaintenanceWindow): any;
export declare function dataGoogleRedisInstanceMaintenancePolicyWeeklyMaintenanceWindowToHclTerraform(struct?: DataGoogleRedisInstanceMaintenancePolicyWeeklyMaintenanceWindow): any;
export declare class DataGoogleRedisInstanceMaintenancePolicyWeeklyMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisInstanceMaintenancePolicyWeeklyMaintenanceWindow | undefined;
    set internalValue(value: DataGoogleRedisInstanceMaintenancePolicyWeeklyMaintenanceWindow | undefined);
    get day(): string;
    get duration(): string;
    private _startTime;
    get startTime(): DataGoogleRedisInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTimeList;
}
export declare class DataGoogleRedisInstanceMaintenancePolicyWeeklyMaintenanceWindowList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisInstanceMaintenancePolicyWeeklyMaintenanceWindowOutputReference;
}
export interface DataGoogleRedisInstanceMaintenancePolicy {
}
export declare function dataGoogleRedisInstanceMaintenancePolicyToTerraform(struct?: DataGoogleRedisInstanceMaintenancePolicy): any;
export declare function dataGoogleRedisInstanceMaintenancePolicyToHclTerraform(struct?: DataGoogleRedisInstanceMaintenancePolicy): any;
export declare class DataGoogleRedisInstanceMaintenancePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisInstanceMaintenancePolicy | undefined;
    set internalValue(value: DataGoogleRedisInstanceMaintenancePolicy | undefined);
    get createTime(): string;
    get description(): string;
    get updateTime(): string;
    private _weeklyMaintenanceWindow;
    get weeklyMaintenanceWindow(): DataGoogleRedisInstanceMaintenancePolicyWeeklyMaintenanceWindowList;
}
export declare class DataGoogleRedisInstanceMaintenancePolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisInstanceMaintenancePolicyOutputReference;
}
export interface DataGoogleRedisInstanceMaintenanceSchedule {
}
export declare function dataGoogleRedisInstanceMaintenanceScheduleToTerraform(struct?: DataGoogleRedisInstanceMaintenanceSchedule): any;
export declare function dataGoogleRedisInstanceMaintenanceScheduleToHclTerraform(struct?: DataGoogleRedisInstanceMaintenanceSchedule): any;
export declare class DataGoogleRedisInstanceMaintenanceScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisInstanceMaintenanceSchedule | undefined;
    set internalValue(value: DataGoogleRedisInstanceMaintenanceSchedule | undefined);
    get endTime(): string;
    get scheduleDeadlineTime(): string;
    get startTime(): string;
}
export declare class DataGoogleRedisInstanceMaintenanceScheduleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisInstanceMaintenanceScheduleOutputReference;
}
export interface DataGoogleRedisInstanceNodes {
}
export declare function dataGoogleRedisInstanceNodesToTerraform(struct?: DataGoogleRedisInstanceNodes): any;
export declare function dataGoogleRedisInstanceNodesToHclTerraform(struct?: DataGoogleRedisInstanceNodes): any;
export declare class DataGoogleRedisInstanceNodesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisInstanceNodes | undefined;
    set internalValue(value: DataGoogleRedisInstanceNodes | undefined);
    get id(): string;
    get zone(): string;
}
export declare class DataGoogleRedisInstanceNodesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisInstanceNodesOutputReference;
}
export interface DataGoogleRedisInstancePersistenceConfig {
}
export declare function dataGoogleRedisInstancePersistenceConfigToTerraform(struct?: DataGoogleRedisInstancePersistenceConfig): any;
export declare function dataGoogleRedisInstancePersistenceConfigToHclTerraform(struct?: DataGoogleRedisInstancePersistenceConfig): any;
export declare class DataGoogleRedisInstancePersistenceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisInstancePersistenceConfig | undefined;
    set internalValue(value: DataGoogleRedisInstancePersistenceConfig | undefined);
    get persistenceMode(): string;
    get rdbNextSnapshotTime(): string;
    get rdbSnapshotPeriod(): string;
    get rdbSnapshotStartTime(): string;
}
export declare class DataGoogleRedisInstancePersistenceConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisInstancePersistenceConfigOutputReference;
}
export interface DataGoogleRedisInstanceServerCaCerts {
}
export declare function dataGoogleRedisInstanceServerCaCertsToTerraform(struct?: DataGoogleRedisInstanceServerCaCerts): any;
export declare function dataGoogleRedisInstanceServerCaCertsToHclTerraform(struct?: DataGoogleRedisInstanceServerCaCerts): any;
export declare class DataGoogleRedisInstanceServerCaCertsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleRedisInstanceServerCaCerts | undefined;
    set internalValue(value: DataGoogleRedisInstanceServerCaCerts | undefined);
    get cert(): string;
    get createTime(): string;
    get expireTime(): string;
    get serialNumber(): string;
    get sha1Fingerprint(): string;
}
export declare class DataGoogleRedisInstanceServerCaCertsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleRedisInstanceServerCaCertsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_redis_instance google_redis_instance}
*/
export declare class DataGoogleRedisInstance extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_redis_instance";
    /**
    * Generates CDKTN code for importing a DataGoogleRedisInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleRedisInstance to import
    * @param importFromId The id of the existing DataGoogleRedisInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_redis_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleRedisInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_redis_instance google_redis_instance} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleRedisInstanceConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleRedisInstanceConfig);
    get alternativeLocationId(): string;
    get authEnabled(): cdktn.IResolvable;
    get authString(): string;
    get authorizedNetwork(): string;
    get connectMode(): string;
    get createTime(): string;
    get currentLocationId(): string;
    get customerManagedKey(): string;
    get deletionPolicy(): string;
    get deletionProtection(): cdktn.IResolvable;
    get displayName(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get effectiveReservedIpRange(): string;
    get host(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels;
    get labels(): cdktn.StringMap;
    get locationId(): string;
    private _maintenancePolicy;
    get maintenancePolicy(): DataGoogleRedisInstanceMaintenancePolicyList;
    private _maintenanceSchedule;
    get maintenanceSchedule(): DataGoogleRedisInstanceMaintenanceScheduleList;
    get maintenanceVersion(): string;
    get memorySizeGb(): number;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _nodes;
    get nodes(): DataGoogleRedisInstanceNodesList;
    private _persistenceConfig;
    get persistenceConfig(): DataGoogleRedisInstancePersistenceConfigList;
    get persistenceIamIdentity(): string;
    get port(): number;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get readEndpoint(): string;
    get readEndpointPort(): number;
    get readReplicasMode(): string;
    private _redisConfigs;
    get redisConfigs(): cdktn.StringMap;
    get redisVersion(): string;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get replicaCount(): number;
    get reservedIpRange(): string;
    get secondaryIpRange(): string;
    private _serverCaCerts;
    get serverCaCerts(): DataGoogleRedisInstanceServerCaCertsList;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get tier(): string;
    get transitEncryptionMode(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
