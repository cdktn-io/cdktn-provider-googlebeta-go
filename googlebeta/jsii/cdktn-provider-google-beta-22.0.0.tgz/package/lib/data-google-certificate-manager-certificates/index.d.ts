/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleCertificateManagerCertificatesConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_certificate_manager_certificates#filter DataGoogleCertificateManagerCertificates#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_certificate_manager_certificates#id DataGoogleCertificateManagerCertificates#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_certificate_manager_certificates#region DataGoogleCertificateManagerCertificates#region}
    */
    readonly region?: string;
}
export interface DataGoogleCertificateManagerCertificatesCertificatesManagedAuthorizationAttemptInfo {
}
export declare function dataGoogleCertificateManagerCertificatesCertificatesManagedAuthorizationAttemptInfoToTerraform(struct?: DataGoogleCertificateManagerCertificatesCertificatesManagedAuthorizationAttemptInfo): any;
export declare function dataGoogleCertificateManagerCertificatesCertificatesManagedAuthorizationAttemptInfoToHclTerraform(struct?: DataGoogleCertificateManagerCertificatesCertificatesManagedAuthorizationAttemptInfo): any;
export declare class DataGoogleCertificateManagerCertificatesCertificatesManagedAuthorizationAttemptInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCertificateManagerCertificatesCertificatesManagedAuthorizationAttemptInfo | undefined;
    set internalValue(value: DataGoogleCertificateManagerCertificatesCertificatesManagedAuthorizationAttemptInfo | undefined);
    get details(): string;
    get domain(): string;
    get failureReason(): string;
    get state(): string;
}
export declare class DataGoogleCertificateManagerCertificatesCertificatesManagedAuthorizationAttemptInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCertificateManagerCertificatesCertificatesManagedAuthorizationAttemptInfoOutputReference;
}
export interface DataGoogleCertificateManagerCertificatesCertificatesManagedProvisioningIssue {
}
export declare function dataGoogleCertificateManagerCertificatesCertificatesManagedProvisioningIssueToTerraform(struct?: DataGoogleCertificateManagerCertificatesCertificatesManagedProvisioningIssue): any;
export declare function dataGoogleCertificateManagerCertificatesCertificatesManagedProvisioningIssueToHclTerraform(struct?: DataGoogleCertificateManagerCertificatesCertificatesManagedProvisioningIssue): any;
export declare class DataGoogleCertificateManagerCertificatesCertificatesManagedProvisioningIssueOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCertificateManagerCertificatesCertificatesManagedProvisioningIssue | undefined;
    set internalValue(value: DataGoogleCertificateManagerCertificatesCertificatesManagedProvisioningIssue | undefined);
    get details(): string;
    get reason(): string;
}
export declare class DataGoogleCertificateManagerCertificatesCertificatesManagedProvisioningIssueList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCertificateManagerCertificatesCertificatesManagedProvisioningIssueOutputReference;
}
export interface DataGoogleCertificateManagerCertificatesCertificatesManaged {
}
export declare function dataGoogleCertificateManagerCertificatesCertificatesManagedToTerraform(struct?: DataGoogleCertificateManagerCertificatesCertificatesManaged): any;
export declare function dataGoogleCertificateManagerCertificatesCertificatesManagedToHclTerraform(struct?: DataGoogleCertificateManagerCertificatesCertificatesManaged): any;
export declare class DataGoogleCertificateManagerCertificatesCertificatesManagedOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCertificateManagerCertificatesCertificatesManaged | undefined;
    set internalValue(value: DataGoogleCertificateManagerCertificatesCertificatesManaged | undefined);
    private _authorizationAttemptInfo;
    get authorizationAttemptInfo(): DataGoogleCertificateManagerCertificatesCertificatesManagedAuthorizationAttemptInfoList;
    get dnsAuthorizations(): string[];
    get domains(): string[];
    get issuanceConfig(): string;
    private _provisioningIssue;
    get provisioningIssue(): DataGoogleCertificateManagerCertificatesCertificatesManagedProvisioningIssueList;
    get state(): string;
}
export declare class DataGoogleCertificateManagerCertificatesCertificatesManagedList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCertificateManagerCertificatesCertificatesManagedOutputReference;
}
export interface DataGoogleCertificateManagerCertificatesCertificates {
}
export declare function dataGoogleCertificateManagerCertificatesCertificatesToTerraform(struct?: DataGoogleCertificateManagerCertificatesCertificates): any;
export declare function dataGoogleCertificateManagerCertificatesCertificatesToHclTerraform(struct?: DataGoogleCertificateManagerCertificatesCertificates): any;
export declare class DataGoogleCertificateManagerCertificatesCertificatesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCertificateManagerCertificatesCertificates | undefined;
    set internalValue(value: DataGoogleCertificateManagerCertificatesCertificates | undefined);
    get deletionPolicy(): string;
    get description(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _labels;
    get labels(): cdktn.StringMap;
    get location(): string;
    private _managed;
    get managed(): DataGoogleCertificateManagerCertificatesCertificatesManagedList;
    get name(): string;
    get project(): string;
    get sanDnsnames(): string[];
    get scope(): string;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
}
export declare class DataGoogleCertificateManagerCertificatesCertificatesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCertificateManagerCertificatesCertificatesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_certificate_manager_certificates google_certificate_manager_certificates}
*/
export declare class DataGoogleCertificateManagerCertificates extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_certificate_manager_certificates";
    /**
    * Generates CDKTN code for importing a DataGoogleCertificateManagerCertificates resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleCertificateManagerCertificates to import
    * @param importFromId The id of the existing DataGoogleCertificateManagerCertificates that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_certificate_manager_certificates#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleCertificateManagerCertificates to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_certificate_manager_certificates google_certificate_manager_certificates} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleCertificateManagerCertificatesConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGoogleCertificateManagerCertificatesConfig);
    private _certificates;
    get certificates(): DataGoogleCertificateManagerCertificatesCertificatesList;
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
