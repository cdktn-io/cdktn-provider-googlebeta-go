/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleBackupDrDataSourceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_source#backup_vault_id DataGoogleBackupDrDataSource#backup_vault_id}
    */
    readonly backupVaultId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_source#data_source_id DataGoogleBackupDrDataSource#data_source_id}
    */
    readonly dataSourceId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_source#id DataGoogleBackupDrDataSource#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_source#location DataGoogleBackupDrDataSource#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_source#project DataGoogleBackupDrDataSource#project}
    */
    readonly project?: string;
}
export interface DataGoogleBackupDrDataSourceBackupConfigInfoBackupApplianceBackupConfig {
}
export declare function dataGoogleBackupDrDataSourceBackupConfigInfoBackupApplianceBackupConfigToTerraform(struct?: DataGoogleBackupDrDataSourceBackupConfigInfoBackupApplianceBackupConfig): any;
export declare function dataGoogleBackupDrDataSourceBackupConfigInfoBackupApplianceBackupConfigToHclTerraform(struct?: DataGoogleBackupDrDataSourceBackupConfigInfoBackupApplianceBackupConfig): any;
export declare class DataGoogleBackupDrDataSourceBackupConfigInfoBackupApplianceBackupConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrDataSourceBackupConfigInfoBackupApplianceBackupConfig | undefined;
    set internalValue(value: DataGoogleBackupDrDataSourceBackupConfigInfoBackupApplianceBackupConfig | undefined);
    get applicationName(): string;
    get backupApplianceId(): string;
    get backupApplianceName(): string;
    get hostName(): string;
    get slaId(): string;
    get slpName(): string;
    get sltName(): string;
}
export declare class DataGoogleBackupDrDataSourceBackupConfigInfoBackupApplianceBackupConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrDataSourceBackupConfigInfoBackupApplianceBackupConfigOutputReference;
}
export interface DataGoogleBackupDrDataSourceBackupConfigInfoGcpBackupConfig {
}
export declare function dataGoogleBackupDrDataSourceBackupConfigInfoGcpBackupConfigToTerraform(struct?: DataGoogleBackupDrDataSourceBackupConfigInfoGcpBackupConfig): any;
export declare function dataGoogleBackupDrDataSourceBackupConfigInfoGcpBackupConfigToHclTerraform(struct?: DataGoogleBackupDrDataSourceBackupConfigInfoGcpBackupConfig): any;
export declare class DataGoogleBackupDrDataSourceBackupConfigInfoGcpBackupConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrDataSourceBackupConfigInfoGcpBackupConfig | undefined;
    set internalValue(value: DataGoogleBackupDrDataSourceBackupConfigInfoGcpBackupConfig | undefined);
    get backupPlan(): string;
    get backupPlanAssociation(): string;
    get backupPlanDescription(): string;
    get backupPlanRules(): string[];
}
export declare class DataGoogleBackupDrDataSourceBackupConfigInfoGcpBackupConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrDataSourceBackupConfigInfoGcpBackupConfigOutputReference;
}
export interface DataGoogleBackupDrDataSourceBackupConfigInfo {
}
export declare function dataGoogleBackupDrDataSourceBackupConfigInfoToTerraform(struct?: DataGoogleBackupDrDataSourceBackupConfigInfo): any;
export declare function dataGoogleBackupDrDataSourceBackupConfigInfoToHclTerraform(struct?: DataGoogleBackupDrDataSourceBackupConfigInfo): any;
export declare class DataGoogleBackupDrDataSourceBackupConfigInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrDataSourceBackupConfigInfo | undefined;
    set internalValue(value: DataGoogleBackupDrDataSourceBackupConfigInfo | undefined);
    private _backupApplianceBackupConfig;
    get backupApplianceBackupConfig(): DataGoogleBackupDrDataSourceBackupConfigInfoBackupApplianceBackupConfigList;
    private _gcpBackupConfig;
    get gcpBackupConfig(): DataGoogleBackupDrDataSourceBackupConfigInfoGcpBackupConfigList;
    private _lastBackupError;
    get lastBackupError(): cdktn.StringMap;
    get lastBackupState(): string;
    get lastSuccessfulBackupConsistencyTime(): string;
}
export declare class DataGoogleBackupDrDataSourceBackupConfigInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrDataSourceBackupConfigInfoOutputReference;
}
export interface DataGoogleBackupDrDataSourceDataSourceBackupApplianceApplication {
}
export declare function dataGoogleBackupDrDataSourceDataSourceBackupApplianceApplicationToTerraform(struct?: DataGoogleBackupDrDataSourceDataSourceBackupApplianceApplication): any;
export declare function dataGoogleBackupDrDataSourceDataSourceBackupApplianceApplicationToHclTerraform(struct?: DataGoogleBackupDrDataSourceDataSourceBackupApplianceApplication): any;
export declare class DataGoogleBackupDrDataSourceDataSourceBackupApplianceApplicationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrDataSourceDataSourceBackupApplianceApplication | undefined;
    set internalValue(value: DataGoogleBackupDrDataSourceDataSourceBackupApplianceApplication | undefined);
    get applianceId(): string;
    get applicationId(): string;
    get applicationName(): string;
    get backupAppliance(): string;
    get hostId(): string;
    get hostname(): string;
    get type(): string;
}
export declare class DataGoogleBackupDrDataSourceDataSourceBackupApplianceApplicationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrDataSourceDataSourceBackupApplianceApplicationOutputReference;
}
export interface DataGoogleBackupDrDataSourceDataSourceGcpResourceComputeInstanceDataSourceProperties {
}
export declare function dataGoogleBackupDrDataSourceDataSourceGcpResourceComputeInstanceDataSourcePropertiesToTerraform(struct?: DataGoogleBackupDrDataSourceDataSourceGcpResourceComputeInstanceDataSourceProperties): any;
export declare function dataGoogleBackupDrDataSourceDataSourceGcpResourceComputeInstanceDataSourcePropertiesToHclTerraform(struct?: DataGoogleBackupDrDataSourceDataSourceGcpResourceComputeInstanceDataSourceProperties): any;
export declare class DataGoogleBackupDrDataSourceDataSourceGcpResourceComputeInstanceDataSourcePropertiesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrDataSourceDataSourceGcpResourceComputeInstanceDataSourceProperties | undefined;
    set internalValue(value: DataGoogleBackupDrDataSourceDataSourceGcpResourceComputeInstanceDataSourceProperties | undefined);
    get description(): string;
    get machineType(): string;
    get name(): string;
    get totalDiskCount(): string;
    get totalDiskSizeGb(): string;
}
export declare class DataGoogleBackupDrDataSourceDataSourceGcpResourceComputeInstanceDataSourcePropertiesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrDataSourceDataSourceGcpResourceComputeInstanceDataSourcePropertiesOutputReference;
}
export interface DataGoogleBackupDrDataSourceDataSourceGcpResource {
}
export declare function dataGoogleBackupDrDataSourceDataSourceGcpResourceToTerraform(struct?: DataGoogleBackupDrDataSourceDataSourceGcpResource): any;
export declare function dataGoogleBackupDrDataSourceDataSourceGcpResourceToHclTerraform(struct?: DataGoogleBackupDrDataSourceDataSourceGcpResource): any;
export declare class DataGoogleBackupDrDataSourceDataSourceGcpResourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrDataSourceDataSourceGcpResource | undefined;
    set internalValue(value: DataGoogleBackupDrDataSourceDataSourceGcpResource | undefined);
    private _computeInstanceDataSourceProperties;
    get computeInstanceDataSourceProperties(): DataGoogleBackupDrDataSourceDataSourceGcpResourceComputeInstanceDataSourcePropertiesList;
    get gcpResourcename(): string;
    get location(): string;
    get type(): string;
}
export declare class DataGoogleBackupDrDataSourceDataSourceGcpResourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrDataSourceDataSourceGcpResourceOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_source google_backup_dr_data_source}
*/
export declare class DataGoogleBackupDrDataSource extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_backup_dr_data_source";
    /**
    * Generates CDKTN code for importing a DataGoogleBackupDrDataSource resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleBackupDrDataSource to import
    * @param importFromId The id of the existing DataGoogleBackupDrDataSource that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_source#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleBackupDrDataSource to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_data_source google_backup_dr_data_source} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleBackupDrDataSourceConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleBackupDrDataSourceConfig);
    get backupBlockedByVaultAccessRestriction(): cdktn.IResolvable;
    private _backupConfigInfo;
    get backupConfigInfo(): DataGoogleBackupDrDataSourceBackupConfigInfoList;
    get backupCount(): string;
    private _backupVaultId?;
    get backupVaultId(): string;
    set backupVaultId(value: string);
    get backupVaultIdInput(): string | undefined;
    get configState(): string;
    get createTime(): string;
    private _dataSourceBackupApplianceApplication;
    get dataSourceBackupApplianceApplication(): DataGoogleBackupDrDataSourceDataSourceBackupApplianceApplicationList;
    private _dataSourceGcpResource;
    get dataSourceGcpResource(): DataGoogleBackupDrDataSourceDataSourceGcpResourceList;
    private _dataSourceId?;
    get dataSourceId(): string;
    set dataSourceId(value: string);
    get dataSourceIdInput(): string | undefined;
    get etag(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels;
    get labels(): cdktn.StringMap;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get state(): string;
    get totalStoredBytes(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
