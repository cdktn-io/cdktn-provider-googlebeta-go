/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleBackupDrBackupVaultConfig extends cdktn.TerraformMetaArguments {
    /**
    * Required. ID of the requesting object.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_backup_vault#backup_vault_id DataGoogleBackupDrBackupVault#backup_vault_id}
    */
    readonly backupVaultId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_backup_vault#id DataGoogleBackupDrBackupVault#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The GCP location for the backup vault.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_backup_vault#location DataGoogleBackupDrBackupVault#location}
    */
    readonly location: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_backup_vault#project DataGoogleBackupDrBackupVault#project}
    */
    readonly project?: string;
}
export interface DataGoogleBackupDrBackupVaultEncryptionConfig {
}
export declare function dataGoogleBackupDrBackupVaultEncryptionConfigToTerraform(struct?: DataGoogleBackupDrBackupVaultEncryptionConfig): any;
export declare function dataGoogleBackupDrBackupVaultEncryptionConfigToHclTerraform(struct?: DataGoogleBackupDrBackupVaultEncryptionConfig): any;
export declare class DataGoogleBackupDrBackupVaultEncryptionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleBackupDrBackupVaultEncryptionConfig | undefined;
    set internalValue(value: DataGoogleBackupDrBackupVaultEncryptionConfig | undefined);
    get kmsKeyName(): string;
}
export declare class DataGoogleBackupDrBackupVaultEncryptionConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleBackupDrBackupVaultEncryptionConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_backup_vault google_backup_dr_backup_vault}
*/
export declare class DataGoogleBackupDrBackupVault extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_backup_dr_backup_vault";
    /**
    * Generates CDKTN code for importing a DataGoogleBackupDrBackupVault resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleBackupDrBackupVault to import
    * @param importFromId The id of the existing DataGoogleBackupDrBackupVault that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_backup_vault#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleBackupDrBackupVault to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_backup_dr_backup_vault google_backup_dr_backup_vault} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleBackupDrBackupVaultConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleBackupDrBackupVaultConfig);
    get accessRestriction(): string;
    get allowMissing(): cdktn.IResolvable;
    private _annotations;
    get annotations(): cdktn.StringMap;
    get backupCount(): string;
    get backupMinimumEnforcedRetentionDuration(): string;
    get backupRetentionInheritance(): string;
    private _backupVaultId?;
    get backupVaultId(): string;
    set backupVaultId(value: string);
    get backupVaultIdInput(): string | undefined;
    get createTime(): string;
    get deletable(): cdktn.IResolvable;
    get deletionPolicy(): string;
    get description(): string;
    private _effectiveAnnotations;
    get effectiveAnnotations(): cdktn.StringMap;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get effectiveTime(): string;
    private _encryptionConfig;
    get encryptionConfig(): DataGoogleBackupDrBackupVaultEncryptionConfigList;
    get etag(): string;
    get forceDelete(): cdktn.IResolvable;
    get forceUpdate(): cdktn.IResolvable;
    get forceUpdateAccessRestriction(): cdktn.IResolvable;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ignoreBackupPlanReferences(): cdktn.IResolvable;
    get ignoreInactiveDatasources(): cdktn.IResolvable;
    private _labels;
    get labels(): cdktn.StringMap;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get serviceAccount(): string;
    get state(): string;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get totalStoredBytes(): string;
    get uid(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
