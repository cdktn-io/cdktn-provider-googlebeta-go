/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleComputeRegionInstanceGroupManagerConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_region_instance_group_manager#id DataGoogleComputeRegionInstanceGroupManager#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the instance group manager. Must be 1-63 characters long and comply with RFC1035. Supported characters include lowercase letters, numbers, and hyphens.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_region_instance_group_manager#name DataGoogleComputeRegionInstanceGroupManager#name}
    */
    readonly name?: string;
    /**
    * The ID of the project in which the resource belongs. If it is not provided, the provider project is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_region_instance_group_manager#project DataGoogleComputeRegionInstanceGroupManager#project}
    */
    readonly project?: string;
    /**
    * The region where the managed instance group resides.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_region_instance_group_manager#region DataGoogleComputeRegionInstanceGroupManager#region}
    */
    readonly region?: string;
    /**
    * The URL of the created resource.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_region_instance_group_manager#self_link DataGoogleComputeRegionInstanceGroupManager#self_link}
    */
    readonly selfLink?: string;
}
export interface DataGoogleComputeRegionInstanceGroupManagerAllInstancesConfig {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerAllInstancesConfigToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerAllInstancesConfig): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerAllInstancesConfigToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerAllInstancesConfig): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerAllInstancesConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerAllInstancesConfig | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerAllInstancesConfig | undefined);
    private _labels;
    get labels(): cdktn.StringMap;
    private _metadata;
    get metadata(): cdktn.StringMap;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerAllInstancesConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerAllInstancesConfigOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupManagerAutoHealingPolicies {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerAutoHealingPoliciesToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerAutoHealingPolicies): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerAutoHealingPoliciesToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerAutoHealingPolicies): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerAutoHealingPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerAutoHealingPolicies | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerAutoHealingPolicies | undefined);
    get healthCheck(): string;
    get initialDelaySec(): number;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerAutoHealingPoliciesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerAutoHealingPoliciesOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksDiskEncryptionKey {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksDiskEncryptionKeyToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksDiskEncryptionKey): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksDiskEncryptionKeyToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksDiskEncryptionKey): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksDiskEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksDiskEncryptionKey | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksDiskEncryptionKey | undefined);
    get kmsKeySelfLink(): string;
    get kmsKeyServiceAccount(): string;
    get rawKey(): string;
    get rsaEncryptedKey(): string;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksDiskEncryptionKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksDiskEncryptionKeyOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksLabels {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksLabelsToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksLabels): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksLabelsToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksLabels): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksLabelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksLabels | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksLabels | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksLabelsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksLabelsOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksResourceManagerTags {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksResourceManagerTagsToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksResourceManagerTags): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksResourceManagerTagsToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksResourceManagerTags): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksResourceManagerTagsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksResourceManagerTags | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksResourceManagerTags | undefined);
    get key(): string;
    get value(): string;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksResourceManagerTagsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksResourceManagerTagsOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceImageEncryptionKey {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceImageEncryptionKeyToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceImageEncryptionKey): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceImageEncryptionKeyToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceImageEncryptionKey): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceImageEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceImageEncryptionKey | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceImageEncryptionKey | undefined);
    get kmsKeySelfLink(): string;
    get kmsKeyServiceAccount(): string;
    get rawKey(): string;
    get rsaEncryptedKey(): string;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceImageEncryptionKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceImageEncryptionKeyOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceSnapshotEncryptionKey {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceSnapshotEncryptionKeyToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceSnapshotEncryptionKey): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceSnapshotEncryptionKeyToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceSnapshotEncryptionKey): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceSnapshotEncryptionKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceSnapshotEncryptionKey | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceSnapshotEncryptionKey | undefined);
    get kmsKeySelfLink(): string;
    get kmsKeyServiceAccount(): string;
    get rawKey(): string;
    get rsaEncryptedKey(): string;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceSnapshotEncryptionKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceSnapshotEncryptionKeyOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisks {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisks): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisks): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisks | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisks | undefined);
    get architecture(): string;
    get autoDelete(): cdktn.IResolvable;
    get boot(): cdktn.IResolvable;
    get deviceName(): string;
    private _diskEncryptionKey;
    get diskEncryptionKey(): DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksDiskEncryptionKeyList;
    get diskName(): string;
    get diskSizeGb(): number;
    get diskType(): string;
    get guestOsFeatures(): string[];
    get interface(): string;
    private _labels;
    get labels(): DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksLabelsList;
    get mode(): string;
    get provisionedIops(): number;
    get provisionedThroughput(): number;
    private _resourceManagerTags;
    get resourceManagerTags(): DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksResourceManagerTagsList;
    get resourcePolicies(): string[];
    get source(): string;
    get sourceImage(): string;
    private _sourceImageEncryptionKey;
    get sourceImageEncryptionKey(): DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceImageEncryptionKeyList;
    get sourceSnapshot(): string;
    private _sourceSnapshotEncryptionKey;
    get sourceSnapshotEncryptionKey(): DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksSourceSnapshotEncryptionKeyList;
    get type(): string;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelections {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelections): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelections): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelections | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelections | undefined);
    private _disks;
    get disks(): DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsDisksList;
    get machineTypes(): string[];
    get minCpuPlatform(): string;
    get name(): string;
    get rank(): number;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicy {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicy): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicy): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicy | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicy | undefined);
    private _instanceSelections;
    get instanceSelections(): DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyInstanceSelectionsList;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOnRepair {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOnRepairToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOnRepair): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOnRepairToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOnRepair): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOnRepairOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOnRepair | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOnRepair | undefined);
    get allowChangingZone(): string;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOnRepairList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOnRepairOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupManagerInstanceLifecyclePolicy {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerInstanceLifecyclePolicyToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerInstanceLifecyclePolicy): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerInstanceLifecyclePolicyToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerInstanceLifecyclePolicy): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerInstanceLifecyclePolicy | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerInstanceLifecyclePolicy | undefined);
    get defaultActionOnFailure(): string;
    get forceUpdateOnRepair(): string;
    get onFailedHealthCheck(): string;
    private _onRepair;
    get onRepair(): DataGoogleComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOnRepairList;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerInstanceLifecyclePolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerInstanceLifecyclePolicyOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupManagerNamedPort {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerNamedPortToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerNamedPort): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerNamedPortToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerNamedPort): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerNamedPortOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerNamedPort | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerNamedPort | undefined);
    get name(): string;
    get port(): number;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerNamedPortList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerNamedPortOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupManagerParams {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerParamsToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerParams): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerParamsToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerParams): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerParams | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerParams | undefined);
    private _resourceManagerTags;
    get resourceManagerTags(): cdktn.StringMap;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerParamsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerParamsOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupManagerResourcePolicies {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerResourcePoliciesToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerResourcePolicies): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerResourcePoliciesToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerResourcePolicies): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerResourcePoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerResourcePolicies | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerResourcePolicies | undefined);
    get workloadPolicy(): string;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerResourcePoliciesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerResourcePoliciesOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupManagerStandbyPolicy {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerStandbyPolicyToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerStandbyPolicy): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerStandbyPolicyToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerStandbyPolicy): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerStandbyPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerStandbyPolicy | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerStandbyPolicy | undefined);
    get initialDelaySec(): number;
    get mode(): string;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerStandbyPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerStandbyPolicyOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupManagerStatefulDisk {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerStatefulDiskToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerStatefulDisk): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerStatefulDiskToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerStatefulDisk): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerStatefulDiskOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerStatefulDisk | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerStatefulDisk | undefined);
    get deleteRule(): string;
    get deviceName(): string;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerStatefulDiskList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerStatefulDiskOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupManagerStatefulExternalIp {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerStatefulExternalIpToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerStatefulExternalIp): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerStatefulExternalIpToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerStatefulExternalIp): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerStatefulExternalIpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerStatefulExternalIp | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerStatefulExternalIp | undefined);
    get deleteRule(): string;
    get interfaceName(): string;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerStatefulExternalIpList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerStatefulExternalIpOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupManagerStatefulInternalIp {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerStatefulInternalIpToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerStatefulInternalIp): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerStatefulInternalIpToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerStatefulInternalIp): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerStatefulInternalIpOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerStatefulInternalIp | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerStatefulInternalIp | undefined);
    get deleteRule(): string;
    get interfaceName(): string;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerStatefulInternalIpList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerStatefulInternalIpOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupManagerStatusAllInstancesConfig {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerStatusAllInstancesConfigToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerStatusAllInstancesConfig): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerStatusAllInstancesConfigToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerStatusAllInstancesConfig): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerStatusAllInstancesConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerStatusAllInstancesConfig | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerStatusAllInstancesConfig | undefined);
    get currentRevision(): string;
    get effective(): cdktn.IResolvable;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerStatusAllInstancesConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerStatusAllInstancesConfigOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupManagerStatusStatefulPerInstanceConfigs {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerStatusStatefulPerInstanceConfigsToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerStatusStatefulPerInstanceConfigs): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerStatusStatefulPerInstanceConfigsToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerStatusStatefulPerInstanceConfigs): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerStatusStatefulPerInstanceConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerStatusStatefulPerInstanceConfigs | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerStatusStatefulPerInstanceConfigs | undefined);
    get allEffective(): cdktn.IResolvable;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerStatusStatefulPerInstanceConfigsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerStatusStatefulPerInstanceConfigsOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupManagerStatusStateful {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerStatusStatefulToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerStatusStateful): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerStatusStatefulToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerStatusStateful): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerStatusStatefulOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerStatusStateful | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerStatusStateful | undefined);
    get hasStatefulConfig(): cdktn.IResolvable;
    private _perInstanceConfigs;
    get perInstanceConfigs(): DataGoogleComputeRegionInstanceGroupManagerStatusStatefulPerInstanceConfigsList;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerStatusStatefulList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerStatusStatefulOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupManagerStatusVersionTarget {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerStatusVersionTargetToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerStatusVersionTarget): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerStatusVersionTargetToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerStatusVersionTarget): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerStatusVersionTargetOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerStatusVersionTarget | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerStatusVersionTarget | undefined);
    get isReached(): cdktn.IResolvable;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerStatusVersionTargetList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerStatusVersionTargetOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupManagerStatus {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerStatusToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerStatus): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerStatusToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerStatus): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerStatusOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerStatus | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerStatus | undefined);
    private _allInstancesConfig;
    get allInstancesConfig(): DataGoogleComputeRegionInstanceGroupManagerStatusAllInstancesConfigList;
    get isStable(): cdktn.IResolvable;
    private _stateful;
    get stateful(): DataGoogleComputeRegionInstanceGroupManagerStatusStatefulList;
    private _versionTarget;
    get versionTarget(): DataGoogleComputeRegionInstanceGroupManagerStatusVersionTargetList;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerStatusList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerStatusOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupManagerTargetSizePolicy {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerTargetSizePolicyToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerTargetSizePolicy): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerTargetSizePolicyToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerTargetSizePolicy): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerTargetSizePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerTargetSizePolicy | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerTargetSizePolicy | undefined);
    get mode(): string;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerTargetSizePolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerTargetSizePolicyOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupManagerUpdatePolicy {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerUpdatePolicyToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerUpdatePolicy): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerUpdatePolicyToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerUpdatePolicy): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerUpdatePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerUpdatePolicy | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerUpdatePolicy | undefined);
    get instanceRedistributionType(): string;
    get maxSurgeFixed(): number;
    get maxSurgePercent(): number;
    get maxUnavailableFixed(): number;
    get maxUnavailablePercent(): number;
    get minReadySec(): number;
    get minimalAction(): string;
    get mostDisruptiveAllowedAction(): string;
    get replacementMethod(): string;
    get type(): string;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerUpdatePolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerUpdatePolicyOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupManagerVersionTargetSize {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerVersionTargetSizeToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerVersionTargetSize): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerVersionTargetSizeToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerVersionTargetSize): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerVersionTargetSizeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerVersionTargetSize | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerVersionTargetSize | undefined);
    get fixed(): number;
    get percent(): number;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerVersionTargetSizeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerVersionTargetSizeOutputReference;
}
export interface DataGoogleComputeRegionInstanceGroupManagerVersion {
}
export declare function dataGoogleComputeRegionInstanceGroupManagerVersionToTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerVersion): any;
export declare function dataGoogleComputeRegionInstanceGroupManagerVersionToHclTerraform(struct?: DataGoogleComputeRegionInstanceGroupManagerVersion): any;
export declare class DataGoogleComputeRegionInstanceGroupManagerVersionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeRegionInstanceGroupManagerVersion | undefined;
    set internalValue(value: DataGoogleComputeRegionInstanceGroupManagerVersion | undefined);
    get instanceTemplate(): string;
    get name(): string;
    private _targetSize;
    get targetSize(): DataGoogleComputeRegionInstanceGroupManagerVersionTargetSizeList;
}
export declare class DataGoogleComputeRegionInstanceGroupManagerVersionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeRegionInstanceGroupManagerVersionOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_region_instance_group_manager google_compute_region_instance_group_manager}
*/
export declare class DataGoogleComputeRegionInstanceGroupManager extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_compute_region_instance_group_manager";
    /**
    * Generates CDKTN code for importing a DataGoogleComputeRegionInstanceGroupManager resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleComputeRegionInstanceGroupManager to import
    * @param importFromId The id of the existing DataGoogleComputeRegionInstanceGroupManager that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_region_instance_group_manager#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleComputeRegionInstanceGroupManager to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_region_instance_group_manager google_compute_region_instance_group_manager} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleComputeRegionInstanceGroupManagerConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGoogleComputeRegionInstanceGroupManagerConfig);
    private _allInstancesConfig;
    get allInstancesConfig(): DataGoogleComputeRegionInstanceGroupManagerAllInstancesConfigList;
    private _autoHealingPolicies;
    get autoHealingPolicies(): DataGoogleComputeRegionInstanceGroupManagerAutoHealingPoliciesList;
    get baseInstanceName(): string;
    get creationTimestamp(): string;
    get deletionPolicy(): string;
    get description(): string;
    get distributionPolicyTargetShape(): string;
    get distributionPolicyZones(): string[];
    get fingerprint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceFlexibilityPolicy;
    get instanceFlexibilityPolicy(): DataGoogleComputeRegionInstanceGroupManagerInstanceFlexibilityPolicyList;
    get instanceGroup(): string;
    get instanceGroupManagerId(): number;
    private _instanceLifecyclePolicy;
    get instanceLifecyclePolicy(): DataGoogleComputeRegionInstanceGroupManagerInstanceLifecyclePolicyList;
    get listManagedInstancesResults(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    private _namedPort;
    get namedPort(): DataGoogleComputeRegionInstanceGroupManagerNamedPortList;
    private _params;
    get params(): DataGoogleComputeRegionInstanceGroupManagerParamsList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    private _resourcePolicies;
    get resourcePolicies(): DataGoogleComputeRegionInstanceGroupManagerResourcePoliciesList;
    private _selfLink?;
    get selfLink(): string;
    set selfLink(value: string);
    resetSelfLink(): void;
    get selfLinkInput(): string | undefined;
    private _standbyPolicy;
    get standbyPolicy(): DataGoogleComputeRegionInstanceGroupManagerStandbyPolicyList;
    private _statefulDisk;
    get statefulDisk(): DataGoogleComputeRegionInstanceGroupManagerStatefulDiskList;
    private _statefulExternalIp;
    get statefulExternalIp(): DataGoogleComputeRegionInstanceGroupManagerStatefulExternalIpList;
    private _statefulInternalIp;
    get statefulInternalIp(): DataGoogleComputeRegionInstanceGroupManagerStatefulInternalIpList;
    private _status;
    get status(): DataGoogleComputeRegionInstanceGroupManagerStatusList;
    get targetPools(): string[];
    get targetSize(): number;
    private _targetSizePolicy;
    get targetSizePolicy(): DataGoogleComputeRegionInstanceGroupManagerTargetSizePolicyList;
    get targetStoppedSize(): number;
    get targetSuspendedSize(): number;
    private _updatePolicy;
    get updatePolicy(): DataGoogleComputeRegionInstanceGroupManagerUpdatePolicyList;
    private _version;
    get version(): DataGoogleComputeRegionInstanceGroupManagerVersionList;
    get waitForInstances(): cdktn.IResolvable;
    get waitForInstancesStatus(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
