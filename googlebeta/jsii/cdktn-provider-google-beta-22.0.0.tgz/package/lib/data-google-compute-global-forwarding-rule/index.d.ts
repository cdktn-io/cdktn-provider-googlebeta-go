/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleComputeGlobalForwardingRuleConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_global_forwarding_rule#id DataGoogleComputeGlobalForwardingRule#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the resource; provided by the client when the resource is created.
    * The name must be 1-63 characters long, and comply with
    * [RFC1035](https://www.ietf.org/rfc/rfc1035.txt).
    *
    * Specifically, the name must be 1-63 characters long and match the regular
    * expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the first
    * character must be a lowercase letter, and all following characters must
    * be a dash, lowercase letter, or digit, except the last character, which
    * cannot be a dash.
    *
    * For Private Service Connect forwarding rules that forward traffic to Google
    * APIs, the forwarding rule name must be a 1-20 characters string with
    * lowercase letters and numbers and must start with a letter.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_global_forwarding_rule#name DataGoogleComputeGlobalForwardingRule#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_global_forwarding_rule#project DataGoogleComputeGlobalForwardingRule#project}
    */
    readonly project?: string;
}
export interface DataGoogleComputeGlobalForwardingRuleMetadataFiltersFilterLabels {
}
export declare function dataGoogleComputeGlobalForwardingRuleMetadataFiltersFilterLabelsToTerraform(struct?: DataGoogleComputeGlobalForwardingRuleMetadataFiltersFilterLabels): any;
export declare function dataGoogleComputeGlobalForwardingRuleMetadataFiltersFilterLabelsToHclTerraform(struct?: DataGoogleComputeGlobalForwardingRuleMetadataFiltersFilterLabels): any;
export declare class DataGoogleComputeGlobalForwardingRuleMetadataFiltersFilterLabelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeGlobalForwardingRuleMetadataFiltersFilterLabels | undefined;
    set internalValue(value: DataGoogleComputeGlobalForwardingRuleMetadataFiltersFilterLabels | undefined);
    get name(): string;
    get value(): string;
}
export declare class DataGoogleComputeGlobalForwardingRuleMetadataFiltersFilterLabelsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeGlobalForwardingRuleMetadataFiltersFilterLabelsOutputReference;
}
export interface DataGoogleComputeGlobalForwardingRuleMetadataFilters {
}
export declare function dataGoogleComputeGlobalForwardingRuleMetadataFiltersToTerraform(struct?: DataGoogleComputeGlobalForwardingRuleMetadataFilters): any;
export declare function dataGoogleComputeGlobalForwardingRuleMetadataFiltersToHclTerraform(struct?: DataGoogleComputeGlobalForwardingRuleMetadataFilters): any;
export declare class DataGoogleComputeGlobalForwardingRuleMetadataFiltersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeGlobalForwardingRuleMetadataFilters | undefined;
    set internalValue(value: DataGoogleComputeGlobalForwardingRuleMetadataFilters | undefined);
    private _filterLabels;
    get filterLabels(): DataGoogleComputeGlobalForwardingRuleMetadataFiltersFilterLabelsList;
    get filterMatchCriteria(): string;
}
export declare class DataGoogleComputeGlobalForwardingRuleMetadataFiltersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeGlobalForwardingRuleMetadataFiltersOutputReference;
}
export interface DataGoogleComputeGlobalForwardingRuleServiceDirectoryRegistrations {
}
export declare function dataGoogleComputeGlobalForwardingRuleServiceDirectoryRegistrationsToTerraform(struct?: DataGoogleComputeGlobalForwardingRuleServiceDirectoryRegistrations): any;
export declare function dataGoogleComputeGlobalForwardingRuleServiceDirectoryRegistrationsToHclTerraform(struct?: DataGoogleComputeGlobalForwardingRuleServiceDirectoryRegistrations): any;
export declare class DataGoogleComputeGlobalForwardingRuleServiceDirectoryRegistrationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeGlobalForwardingRuleServiceDirectoryRegistrations | undefined;
    set internalValue(value: DataGoogleComputeGlobalForwardingRuleServiceDirectoryRegistrations | undefined);
    get namespace(): string;
    get serviceDirectoryRegion(): string;
}
export declare class DataGoogleComputeGlobalForwardingRuleServiceDirectoryRegistrationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeGlobalForwardingRuleServiceDirectoryRegistrationsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_global_forwarding_rule google_compute_global_forwarding_rule}
*/
export declare class DataGoogleComputeGlobalForwardingRule extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_compute_global_forwarding_rule";
    /**
    * Generates CDKTN code for importing a DataGoogleComputeGlobalForwardingRule resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleComputeGlobalForwardingRule to import
    * @param importFromId The id of the existing DataGoogleComputeGlobalForwardingRule that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_global_forwarding_rule#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleComputeGlobalForwardingRule to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_global_forwarding_rule google_compute_global_forwarding_rule} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleComputeGlobalForwardingRuleConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleComputeGlobalForwardingRuleConfig);
    get allowPscGlobalAccess(): cdktn.IResolvable;
    get baseForwardingRule(): string;
    get deletionPolicy(): string;
    get description(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get externalManagedBackendBucketMigrationState(): string;
    get externalManagedBackendBucketMigrationTestingPercentage(): number;
    get forwardingRuleId(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ipAddress(): string;
    get ipProtocol(): string;
    get ipVersion(): string;
    get labelFingerprint(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    get loadBalancingScheme(): string;
    private _metadataFilters;
    get metadataFilters(): DataGoogleComputeGlobalForwardingRuleMetadataFiltersList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get network(): string;
    get networkTier(): string;
    get noAutomateDnsZone(): cdktn.IResolvable;
    get portRange(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get pscConnectionId(): string;
    get pscConnectionStatus(): string;
    get selfLink(): string;
    private _serviceDirectoryRegistrations;
    get serviceDirectoryRegistrations(): DataGoogleComputeGlobalForwardingRuleServiceDirectoryRegistrationsList;
    get sourceIpRanges(): string[];
    get subnetwork(): string;
    get target(): string;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
