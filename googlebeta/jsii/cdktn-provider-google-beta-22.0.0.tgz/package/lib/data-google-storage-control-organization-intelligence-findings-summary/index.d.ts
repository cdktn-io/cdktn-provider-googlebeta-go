/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleStorageControlOrganizationIntelligenceFindingsSummaryConfig extends cdktn.TerraformMetaArguments {
    /**
    * The filter expression. Supports filtering by FindingType.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_control_organization_intelligence_findings_summary#filter DataGoogleStorageControlOrganizationIntelligenceFindingsSummary#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_control_organization_intelligence_findings_summary#id DataGoogleStorageControlOrganizationIntelligenceFindingsSummary#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the intelligence findings summary. Currently default value is global and users cannot use for input for now.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_control_organization_intelligence_findings_summary#location DataGoogleStorageControlOrganizationIntelligenceFindingsSummary#location}
    */
    readonly location?: string;
    /**
    * The ID of the Google Cloud Organization.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_control_organization_intelligence_findings_summary#organization DataGoogleStorageControlOrganizationIntelligenceFindingsSummary#organization}
    */
    readonly organization: string;
    /**
    * Determines the granularity of the findings when the parent is an organization or folder. Possible values are PARENT and PROJECT. Default value is PARENT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_control_organization_intelligence_findings_summary#resource_scope DataGoogleStorageControlOrganizationIntelligenceFindingsSummary#resource_scope}
    */
    readonly resourceScope?: string;
}
export interface DataGoogleStorageControlOrganizationIntelligenceFindingsSummaryFindingSummariesSummaryDetails {
}
export declare function dataGoogleStorageControlOrganizationIntelligenceFindingsSummaryFindingSummariesSummaryDetailsToTerraform(struct?: DataGoogleStorageControlOrganizationIntelligenceFindingsSummaryFindingSummariesSummaryDetails): any;
export declare function dataGoogleStorageControlOrganizationIntelligenceFindingsSummaryFindingSummariesSummaryDetailsToHclTerraform(struct?: DataGoogleStorageControlOrganizationIntelligenceFindingsSummaryFindingSummariesSummaryDetails): any;
export declare class DataGoogleStorageControlOrganizationIntelligenceFindingsSummaryFindingSummariesSummaryDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlOrganizationIntelligenceFindingsSummaryFindingSummariesSummaryDetails | undefined;
    set internalValue(value: DataGoogleStorageControlOrganizationIntelligenceFindingsSummaryFindingSummariesSummaryDetails | undefined);
    get count(): string;
    get description(): string;
    get percentage(): number;
    get resourceType(): string;
}
export declare class DataGoogleStorageControlOrganizationIntelligenceFindingsSummaryFindingSummariesSummaryDetailsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlOrganizationIntelligenceFindingsSummaryFindingSummariesSummaryDetailsOutputReference;
}
export interface DataGoogleStorageControlOrganizationIntelligenceFindingsSummaryFindingSummaries {
}
export declare function dataGoogleStorageControlOrganizationIntelligenceFindingsSummaryFindingSummariesToTerraform(struct?: DataGoogleStorageControlOrganizationIntelligenceFindingsSummaryFindingSummaries): any;
export declare function dataGoogleStorageControlOrganizationIntelligenceFindingsSummaryFindingSummariesToHclTerraform(struct?: DataGoogleStorageControlOrganizationIntelligenceFindingsSummaryFindingSummaries): any;
export declare class DataGoogleStorageControlOrganizationIntelligenceFindingsSummaryFindingSummariesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlOrganizationIntelligenceFindingsSummaryFindingSummaries | undefined;
    set internalValue(value: DataGoogleStorageControlOrganizationIntelligenceFindingsSummaryFindingSummaries | undefined);
    get category(): string;
    get createTime(): string;
    get severity(): string;
    private _summaryDetails;
    get summaryDetails(): DataGoogleStorageControlOrganizationIntelligenceFindingsSummaryFindingSummariesSummaryDetailsList;
    get targetResource(): string;
    get type(): string;
    get updateTime(): string;
}
export declare class DataGoogleStorageControlOrganizationIntelligenceFindingsSummaryFindingSummariesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlOrganizationIntelligenceFindingsSummaryFindingSummariesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_control_organization_intelligence_findings_summary google_storage_control_organization_intelligence_findings_summary}
*/
export declare class DataGoogleStorageControlOrganizationIntelligenceFindingsSummary extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_storage_control_organization_intelligence_findings_summary";
    /**
    * Generates CDKTN code for importing a DataGoogleStorageControlOrganizationIntelligenceFindingsSummary resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleStorageControlOrganizationIntelligenceFindingsSummary to import
    * @param importFromId The id of the existing DataGoogleStorageControlOrganizationIntelligenceFindingsSummary that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_control_organization_intelligence_findings_summary#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleStorageControlOrganizationIntelligenceFindingsSummary to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_control_organization_intelligence_findings_summary google_storage_control_organization_intelligence_findings_summary} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleStorageControlOrganizationIntelligenceFindingsSummaryConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleStorageControlOrganizationIntelligenceFindingsSummaryConfig);
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _findingSummaries;
    get findingSummaries(): DataGoogleStorageControlOrganizationIntelligenceFindingsSummaryFindingSummariesList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _organization?;
    get organization(): string;
    set organization(value: string);
    get organizationInput(): string | undefined;
    private _resourceScope?;
    get resourceScope(): string;
    set resourceScope(value: string);
    resetResourceScope(): void;
    get resourceScopeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
