/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleStorageBucketObjectConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the containing bucket.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_bucket_object#bucket DataGoogleStorageBucketObject#bucket}
    */
    readonly bucket?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_bucket_object#id DataGoogleStorageBucketObject#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the object. If you're interpolating the name of this object, see output_name instead.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_bucket_object#name DataGoogleStorageBucketObject#name}
    */
    readonly name?: string;
}
export interface DataGoogleStorageBucketObjectContextsCustom {
}
export declare function dataGoogleStorageBucketObjectContextsCustomToTerraform(struct?: DataGoogleStorageBucketObjectContextsCustom): any;
export declare function dataGoogleStorageBucketObjectContextsCustomToHclTerraform(struct?: DataGoogleStorageBucketObjectContextsCustom): any;
export declare class DataGoogleStorageBucketObjectContextsCustomOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageBucketObjectContextsCustom | undefined;
    set internalValue(value: DataGoogleStorageBucketObjectContextsCustom | undefined);
    get createTime(): string;
    get key(): string;
    get updateTime(): string;
    get value(): string;
}
export declare class DataGoogleStorageBucketObjectContextsCustomList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageBucketObjectContextsCustomOutputReference;
}
export interface DataGoogleStorageBucketObjectContexts {
}
export declare function dataGoogleStorageBucketObjectContextsToTerraform(struct?: DataGoogleStorageBucketObjectContexts): any;
export declare function dataGoogleStorageBucketObjectContextsToHclTerraform(struct?: DataGoogleStorageBucketObjectContexts): any;
export declare class DataGoogleStorageBucketObjectContextsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageBucketObjectContexts | undefined;
    set internalValue(value: DataGoogleStorageBucketObjectContexts | undefined);
    private _custom;
    get custom(): DataGoogleStorageBucketObjectContextsCustomList;
}
export declare class DataGoogleStorageBucketObjectContextsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageBucketObjectContextsOutputReference;
}
export interface DataGoogleStorageBucketObjectCustomerEncryption {
}
export declare function dataGoogleStorageBucketObjectCustomerEncryptionToTerraform(struct?: DataGoogleStorageBucketObjectCustomerEncryption): any;
export declare function dataGoogleStorageBucketObjectCustomerEncryptionToHclTerraform(struct?: DataGoogleStorageBucketObjectCustomerEncryption): any;
export declare class DataGoogleStorageBucketObjectCustomerEncryptionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageBucketObjectCustomerEncryption | undefined;
    set internalValue(value: DataGoogleStorageBucketObjectCustomerEncryption | undefined);
    get encryptionAlgorithm(): string;
    get encryptionKey(): string;
}
export declare class DataGoogleStorageBucketObjectCustomerEncryptionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageBucketObjectCustomerEncryptionOutputReference;
}
export interface DataGoogleStorageBucketObjectRetention {
}
export declare function dataGoogleStorageBucketObjectRetentionToTerraform(struct?: DataGoogleStorageBucketObjectRetention): any;
export declare function dataGoogleStorageBucketObjectRetentionToHclTerraform(struct?: DataGoogleStorageBucketObjectRetention): any;
export declare class DataGoogleStorageBucketObjectRetentionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageBucketObjectRetention | undefined;
    set internalValue(value: DataGoogleStorageBucketObjectRetention | undefined);
    get mode(): string;
    get retainUntilTime(): string;
}
export declare class DataGoogleStorageBucketObjectRetentionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageBucketObjectRetentionOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_bucket_object google_storage_bucket_object}
*/
export declare class DataGoogleStorageBucketObject extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_storage_bucket_object";
    /**
    * Generates CDKTN code for importing a DataGoogleStorageBucketObject resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleStorageBucketObject to import
    * @param importFromId The id of the existing DataGoogleStorageBucketObject that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_bucket_object#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleStorageBucketObject to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_bucket_object google_storage_bucket_object} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleStorageBucketObjectConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGoogleStorageBucketObjectConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    resetBucket(): void;
    get bucketInput(): string | undefined;
    get cacheControl(): string;
    get content(): string;
    get contentDisposition(): string;
    get contentEncoding(): string;
    get contentLanguage(): string;
    get contentType(): string;
    private _contexts;
    get contexts(): DataGoogleStorageBucketObjectContextsList;
    get crc32C(): string;
    private _customerEncryption;
    get customerEncryption(): DataGoogleStorageBucketObjectCustomerEncryptionList;
    get deletionPolicy(): string;
    get detectMd5Hash(): string;
    get eventBasedHold(): cdktn.IResolvable;
    get forceEmptyContentType(): cdktn.IResolvable;
    get generation(): number;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get kmsKeyName(): string;
    get md5Hash(): string;
    get md5Hexhash(): string;
    get mediaLink(): string;
    private _metadata;
    get metadata(): cdktn.StringMap;
    private _name?;
    get name(): string;
    set name(value: string);
    resetName(): void;
    get nameInput(): string | undefined;
    get outputName(): string;
    private _retention;
    get retention(): DataGoogleStorageBucketObjectRetentionList;
    get selfLink(): string;
    get source(): string;
    get sourceMd5Hash(): string;
    get storageClass(): string;
    get temporaryHold(): cdktn.IResolvable;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
