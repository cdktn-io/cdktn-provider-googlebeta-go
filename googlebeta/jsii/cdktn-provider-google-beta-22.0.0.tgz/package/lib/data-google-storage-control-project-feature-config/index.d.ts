/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleStorageControlProjectFeatureConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * The ID of the feature configuration, which becomes the final component of its resource name.
    * The ID must be 1 to 63 characters long, start with a lowercase letter, and contain only
    * lowercase letters, digits, and dashes. The last character can't be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_control_project_feature_config#feature_config_id DataGoogleStorageControlProjectFeatureConfig#feature_config_id}
    */
    readonly featureConfigId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_control_project_feature_config#id DataGoogleStorageControlProjectFeatureConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_control_project_feature_config#project DataGoogleStorageControlProjectFeatureConfig#project}
    */
    readonly project?: string;
}
export interface DataGoogleStorageControlProjectFeatureConfigAutoAnnotateConfigModels {
}
export declare function dataGoogleStorageControlProjectFeatureConfigAutoAnnotateConfigModelsToTerraform(struct?: DataGoogleStorageControlProjectFeatureConfigAutoAnnotateConfigModels): any;
export declare function dataGoogleStorageControlProjectFeatureConfigAutoAnnotateConfigModelsToHclTerraform(struct?: DataGoogleStorageControlProjectFeatureConfigAutoAnnotateConfigModels): any;
export declare class DataGoogleStorageControlProjectFeatureConfigAutoAnnotateConfigModelsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlProjectFeatureConfigAutoAnnotateConfigModels | undefined;
    set internalValue(value: DataGoogleStorageControlProjectFeatureConfigAutoAnnotateConfigModels | undefined);
    get name(): string;
}
export declare class DataGoogleStorageControlProjectFeatureConfigAutoAnnotateConfigModelsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlProjectFeatureConfigAutoAnnotateConfigModelsOutputReference;
}
export interface DataGoogleStorageControlProjectFeatureConfigAutoAnnotateConfig {
}
export declare function dataGoogleStorageControlProjectFeatureConfigAutoAnnotateConfigToTerraform(struct?: DataGoogleStorageControlProjectFeatureConfigAutoAnnotateConfig): any;
export declare function dataGoogleStorageControlProjectFeatureConfigAutoAnnotateConfigToHclTerraform(struct?: DataGoogleStorageControlProjectFeatureConfigAutoAnnotateConfig): any;
export declare class DataGoogleStorageControlProjectFeatureConfigAutoAnnotateConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlProjectFeatureConfigAutoAnnotateConfig | undefined;
    set internalValue(value: DataGoogleStorageControlProjectFeatureConfigAutoAnnotateConfig | undefined);
    private _models;
    get models(): DataGoogleStorageControlProjectFeatureConfigAutoAnnotateConfigModelsList;
    get processingLocation(): string;
}
export declare class DataGoogleStorageControlProjectFeatureConfigAutoAnnotateConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlProjectFeatureConfigAutoAnnotateConfigOutputReference;
}
export interface DataGoogleStorageControlProjectFeatureConfigFilterIncludedCloudStorageBuckets {
}
export declare function dataGoogleStorageControlProjectFeatureConfigFilterIncludedCloudStorageBucketsToTerraform(struct?: DataGoogleStorageControlProjectFeatureConfigFilterIncludedCloudStorageBuckets): any;
export declare function dataGoogleStorageControlProjectFeatureConfigFilterIncludedCloudStorageBucketsToHclTerraform(struct?: DataGoogleStorageControlProjectFeatureConfigFilterIncludedCloudStorageBuckets): any;
export declare class DataGoogleStorageControlProjectFeatureConfigFilterIncludedCloudStorageBucketsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlProjectFeatureConfigFilterIncludedCloudStorageBuckets | undefined;
    set internalValue(value: DataGoogleStorageControlProjectFeatureConfigFilterIncludedCloudStorageBuckets | undefined);
    get bucketIdRegexes(): string[];
}
export declare class DataGoogleStorageControlProjectFeatureConfigFilterIncludedCloudStorageBucketsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlProjectFeatureConfigFilterIncludedCloudStorageBucketsOutputReference;
}
export interface DataGoogleStorageControlProjectFeatureConfigFilter {
}
export declare function dataGoogleStorageControlProjectFeatureConfigFilterToTerraform(struct?: DataGoogleStorageControlProjectFeatureConfigFilter): any;
export declare function dataGoogleStorageControlProjectFeatureConfigFilterToHclTerraform(struct?: DataGoogleStorageControlProjectFeatureConfigFilter): any;
export declare class DataGoogleStorageControlProjectFeatureConfigFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlProjectFeatureConfigFilter | undefined;
    set internalValue(value: DataGoogleStorageControlProjectFeatureConfigFilter | undefined);
    private _includedCloudStorageBuckets;
    get includedCloudStorageBuckets(): DataGoogleStorageControlProjectFeatureConfigFilterIncludedCloudStorageBucketsList;
}
export declare class DataGoogleStorageControlProjectFeatureConfigFilterList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlProjectFeatureConfigFilterOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_control_project_feature_config google_storage_control_project_feature_config}
*/
export declare class DataGoogleStorageControlProjectFeatureConfig extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_storage_control_project_feature_config";
    /**
    * Generates CDKTN code for importing a DataGoogleStorageControlProjectFeatureConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleStorageControlProjectFeatureConfig to import
    * @param importFromId The id of the existing DataGoogleStorageControlProjectFeatureConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_control_project_feature_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleStorageControlProjectFeatureConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_control_project_feature_config google_storage_control_project_feature_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleStorageControlProjectFeatureConfigConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleStorageControlProjectFeatureConfigConfig);
    private _autoAnnotateConfig;
    get autoAnnotateConfig(): DataGoogleStorageControlProjectFeatureConfigAutoAnnotateConfigList;
    get createTime(): string;
    get deletionPolicy(): string;
    get description(): string;
    private _featureConfigId?;
    get featureConfigId(): string;
    set featureConfigId(value: string);
    get featureConfigIdInput(): string | undefined;
    private _filter;
    get filter(): DataGoogleStorageControlProjectFeatureConfigFilterList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get type(): string;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
