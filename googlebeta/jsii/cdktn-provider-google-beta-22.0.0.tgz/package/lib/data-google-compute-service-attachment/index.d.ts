/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleComputeServiceAttachmentConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_service_attachment#id DataGoogleComputeServiceAttachment#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the resource. The name must be 1-63 characters long, and
    * comply with RFC1035. Specifically, the name must be 1-63 characters
    * long and match the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?'
    * which means the first character must be a lowercase letter, and all
    * following characters must be a dash, lowercase letter, or digit,
    * except the last character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_service_attachment#name DataGoogleComputeServiceAttachment#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_service_attachment#project DataGoogleComputeServiceAttachment#project}
    */
    readonly project?: string;
    /**
    * URL of the region where the resource resides.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_service_attachment#region DataGoogleComputeServiceAttachment#region}
    */
    readonly region?: string;
}
export interface DataGoogleComputeServiceAttachmentConnectedEndpoints {
}
export declare function dataGoogleComputeServiceAttachmentConnectedEndpointsToTerraform(struct?: DataGoogleComputeServiceAttachmentConnectedEndpoints): any;
export declare function dataGoogleComputeServiceAttachmentConnectedEndpointsToHclTerraform(struct?: DataGoogleComputeServiceAttachmentConnectedEndpoints): any;
export declare class DataGoogleComputeServiceAttachmentConnectedEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeServiceAttachmentConnectedEndpoints | undefined;
    set internalValue(value: DataGoogleComputeServiceAttachmentConnectedEndpoints | undefined);
    get consumerNetwork(): string;
    get endpoint(): string;
    get natIps(): string[];
    get propagatedConnectionCount(): number;
    get pscConnectionId(): string;
    get status(): string;
}
export declare class DataGoogleComputeServiceAttachmentConnectedEndpointsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeServiceAttachmentConnectedEndpointsOutputReference;
}
export interface DataGoogleComputeServiceAttachmentConsumerAcceptLists {
}
export declare function dataGoogleComputeServiceAttachmentConsumerAcceptListsToTerraform(struct?: DataGoogleComputeServiceAttachmentConsumerAcceptLists): any;
export declare function dataGoogleComputeServiceAttachmentConsumerAcceptListsToHclTerraform(struct?: DataGoogleComputeServiceAttachmentConsumerAcceptLists): any;
export declare class DataGoogleComputeServiceAttachmentConsumerAcceptListsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeServiceAttachmentConsumerAcceptLists | undefined;
    set internalValue(value: DataGoogleComputeServiceAttachmentConsumerAcceptLists | undefined);
    get connectionLimit(): number;
    get endpointUrl(): string;
    get networkUrl(): string;
    get projectIdOrNum(): string;
}
export declare class DataGoogleComputeServiceAttachmentConsumerAcceptListsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeServiceAttachmentConsumerAcceptListsOutputReference;
}
export interface DataGoogleComputeServiceAttachmentPscServiceAttachmentId {
}
export declare function dataGoogleComputeServiceAttachmentPscServiceAttachmentIdToTerraform(struct?: DataGoogleComputeServiceAttachmentPscServiceAttachmentId): any;
export declare function dataGoogleComputeServiceAttachmentPscServiceAttachmentIdToHclTerraform(struct?: DataGoogleComputeServiceAttachmentPscServiceAttachmentId): any;
export declare class DataGoogleComputeServiceAttachmentPscServiceAttachmentIdOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeServiceAttachmentPscServiceAttachmentId | undefined;
    set internalValue(value: DataGoogleComputeServiceAttachmentPscServiceAttachmentId | undefined);
    get high(): string;
    get low(): string;
}
export declare class DataGoogleComputeServiceAttachmentPscServiceAttachmentIdList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeServiceAttachmentPscServiceAttachmentIdOutputReference;
}
export interface DataGoogleComputeServiceAttachmentTunnelingConfig {
}
export declare function dataGoogleComputeServiceAttachmentTunnelingConfigToTerraform(struct?: DataGoogleComputeServiceAttachmentTunnelingConfig): any;
export declare function dataGoogleComputeServiceAttachmentTunnelingConfigToHclTerraform(struct?: DataGoogleComputeServiceAttachmentTunnelingConfig): any;
export declare class DataGoogleComputeServiceAttachmentTunnelingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeServiceAttachmentTunnelingConfig | undefined;
    set internalValue(value: DataGoogleComputeServiceAttachmentTunnelingConfig | undefined);
    get encapsulationProfile(): string;
    get routingMode(): string;
}
export declare class DataGoogleComputeServiceAttachmentTunnelingConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeServiceAttachmentTunnelingConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_service_attachment google_compute_service_attachment}
*/
export declare class DataGoogleComputeServiceAttachment extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_compute_service_attachment";
    /**
    * Generates CDKTN code for importing a DataGoogleComputeServiceAttachment resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleComputeServiceAttachment to import
    * @param importFromId The id of the existing DataGoogleComputeServiceAttachment that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_service_attachment#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleComputeServiceAttachment to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_service_attachment google_compute_service_attachment} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleComputeServiceAttachmentConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleComputeServiceAttachmentConfig);
    private _connectedEndpoints;
    get connectedEndpoints(): DataGoogleComputeServiceAttachmentConnectedEndpointsList;
    get connectionPreference(): string;
    private _consumerAcceptLists;
    get consumerAcceptLists(): DataGoogleComputeServiceAttachmentConsumerAcceptListsList;
    get consumerRejectLists(): string[];
    get deletionPolicy(): string;
    get description(): string;
    get domainNames(): string[];
    get enableProxyProtocol(): cdktn.IResolvable;
    get fingerprint(): string;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    get natIpsPerEndpoint(): number;
    get natSubnets(): string[];
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get propagatedConnectionLimit(): number;
    private _pscServiceAttachmentId;
    get pscServiceAttachmentId(): DataGoogleComputeServiceAttachmentPscServiceAttachmentIdList;
    get reconcileConnections(): cdktn.IResolvable;
    private _region?;
    get region(): string;
    set region(value: string);
    resetRegion(): void;
    get regionInput(): string | undefined;
    get selfLink(): string;
    get sendPropagatedConnectionLimitIfZero(): cdktn.IResolvable;
    get serviceAttachmentId(): number;
    get showNatIps(): cdktn.IResolvable;
    get targetService(): string;
    private _tunnelingConfig;
    get tunnelingConfig(): DataGoogleComputeServiceAttachmentTunnelingConfigList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
