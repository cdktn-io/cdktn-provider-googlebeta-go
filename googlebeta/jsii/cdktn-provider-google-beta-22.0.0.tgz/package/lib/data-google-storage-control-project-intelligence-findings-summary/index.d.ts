/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleStorageControlProjectIntelligenceFindingsSummaryConfig extends cdktn.TerraformMetaArguments {
    /**
    * The filter expression. Supports filtering by FindingType.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_control_project_intelligence_findings_summary#filter DataGoogleStorageControlProjectIntelligenceFindingsSummary#filter}
    */
    readonly filter?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_control_project_intelligence_findings_summary#id DataGoogleStorageControlProjectIntelligenceFindingsSummary#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location of the intelligence findings summary. Currently default value is global and users cannot use for input for now.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_control_project_intelligence_findings_summary#location DataGoogleStorageControlProjectIntelligenceFindingsSummary#location}
    */
    readonly location?: string;
    /**
    * The ID of the project in which the resource belongs. If it is not provided, the provider project is used.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_control_project_intelligence_findings_summary#project DataGoogleStorageControlProjectIntelligenceFindingsSummary#project}
    */
    readonly project?: string;
    /**
    * Determines the granularity of the findings when the parent is an organization or folder. Possible values are PARENT and PROJECT. Default value is PARENT.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_control_project_intelligence_findings_summary#resource_scope DataGoogleStorageControlProjectIntelligenceFindingsSummary#resource_scope}
    */
    readonly resourceScope?: string;
}
export interface DataGoogleStorageControlProjectIntelligenceFindingsSummaryFindingSummariesSummaryDetails {
}
export declare function dataGoogleStorageControlProjectIntelligenceFindingsSummaryFindingSummariesSummaryDetailsToTerraform(struct?: DataGoogleStorageControlProjectIntelligenceFindingsSummaryFindingSummariesSummaryDetails): any;
export declare function dataGoogleStorageControlProjectIntelligenceFindingsSummaryFindingSummariesSummaryDetailsToHclTerraform(struct?: DataGoogleStorageControlProjectIntelligenceFindingsSummaryFindingSummariesSummaryDetails): any;
export declare class DataGoogleStorageControlProjectIntelligenceFindingsSummaryFindingSummariesSummaryDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlProjectIntelligenceFindingsSummaryFindingSummariesSummaryDetails | undefined;
    set internalValue(value: DataGoogleStorageControlProjectIntelligenceFindingsSummaryFindingSummariesSummaryDetails | undefined);
    get count(): string;
    get description(): string;
    get percentage(): number;
    get resourceType(): string;
}
export declare class DataGoogleStorageControlProjectIntelligenceFindingsSummaryFindingSummariesSummaryDetailsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlProjectIntelligenceFindingsSummaryFindingSummariesSummaryDetailsOutputReference;
}
export interface DataGoogleStorageControlProjectIntelligenceFindingsSummaryFindingSummaries {
}
export declare function dataGoogleStorageControlProjectIntelligenceFindingsSummaryFindingSummariesToTerraform(struct?: DataGoogleStorageControlProjectIntelligenceFindingsSummaryFindingSummaries): any;
export declare function dataGoogleStorageControlProjectIntelligenceFindingsSummaryFindingSummariesToHclTerraform(struct?: DataGoogleStorageControlProjectIntelligenceFindingsSummaryFindingSummaries): any;
export declare class DataGoogleStorageControlProjectIntelligenceFindingsSummaryFindingSummariesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlProjectIntelligenceFindingsSummaryFindingSummaries | undefined;
    set internalValue(value: DataGoogleStorageControlProjectIntelligenceFindingsSummaryFindingSummaries | undefined);
    get category(): string;
    get createTime(): string;
    get severity(): string;
    private _summaryDetails;
    get summaryDetails(): DataGoogleStorageControlProjectIntelligenceFindingsSummaryFindingSummariesSummaryDetailsList;
    get targetResource(): string;
    get type(): string;
    get updateTime(): string;
}
export declare class DataGoogleStorageControlProjectIntelligenceFindingsSummaryFindingSummariesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlProjectIntelligenceFindingsSummaryFindingSummariesOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_control_project_intelligence_findings_summary google_storage_control_project_intelligence_findings_summary}
*/
export declare class DataGoogleStorageControlProjectIntelligenceFindingsSummary extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_storage_control_project_intelligence_findings_summary";
    /**
    * Generates CDKTN code for importing a DataGoogleStorageControlProjectIntelligenceFindingsSummary resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleStorageControlProjectIntelligenceFindingsSummary to import
    * @param importFromId The id of the existing DataGoogleStorageControlProjectIntelligenceFindingsSummary that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_control_project_intelligence_findings_summary#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleStorageControlProjectIntelligenceFindingsSummary to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_control_project_intelligence_findings_summary google_storage_control_project_intelligence_findings_summary} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleStorageControlProjectIntelligenceFindingsSummaryConfig = {}
    */
    constructor(scope: Construct, id: string, config?: DataGoogleStorageControlProjectIntelligenceFindingsSummaryConfig);
    private _filter?;
    get filter(): string;
    set filter(value: string);
    resetFilter(): void;
    get filterInput(): string | undefined;
    private _findingSummaries;
    get findingSummaries(): DataGoogleStorageControlProjectIntelligenceFindingsSummaryFindingSummariesList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _resourceScope?;
    get resourceScope(): string;
    set resourceScope(value: string);
    resetResourceScope(): void;
    get resourceScopeInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
