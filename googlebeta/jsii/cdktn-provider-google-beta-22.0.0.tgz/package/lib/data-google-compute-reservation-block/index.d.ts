/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleComputeReservationBlockConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_reservation_block#id DataGoogleComputeReservationBlock#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The name of the reservation block.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_reservation_block#name DataGoogleComputeReservationBlock#name}
    */
    readonly name: string;
    /**
    * The project in which the resource belongs.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_reservation_block#project DataGoogleComputeReservationBlock#project}
    */
    readonly project?: string;
    /**
    * The name of the parent reservation.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_reservation_block#reservation DataGoogleComputeReservationBlock#reservation}
    */
    readonly reservation: string;
    /**
    * The zone where the reservation block resides.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_reservation_block#zone DataGoogleComputeReservationBlock#zone}
    */
    readonly zone?: string;
}
export interface DataGoogleComputeReservationBlockHealthInfo {
}
export declare function dataGoogleComputeReservationBlockHealthInfoToTerraform(struct?: DataGoogleComputeReservationBlockHealthInfo): any;
export declare function dataGoogleComputeReservationBlockHealthInfoToHclTerraform(struct?: DataGoogleComputeReservationBlockHealthInfo): any;
export declare class DataGoogleComputeReservationBlockHealthInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeReservationBlockHealthInfo | undefined;
    set internalValue(value: DataGoogleComputeReservationBlockHealthInfo | undefined);
    get degradedSubBlockCount(): number;
    get healthStatus(): string;
    get healthySubBlockCount(): number;
}
export declare class DataGoogleComputeReservationBlockHealthInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeReservationBlockHealthInfoOutputReference;
}
export interface DataGoogleComputeReservationBlockPhysicalTopology {
}
export declare function dataGoogleComputeReservationBlockPhysicalTopologyToTerraform(struct?: DataGoogleComputeReservationBlockPhysicalTopology): any;
export declare function dataGoogleComputeReservationBlockPhysicalTopologyToHclTerraform(struct?: DataGoogleComputeReservationBlockPhysicalTopology): any;
export declare class DataGoogleComputeReservationBlockPhysicalTopologyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeReservationBlockPhysicalTopology | undefined;
    set internalValue(value: DataGoogleComputeReservationBlockPhysicalTopology | undefined);
    get block(): string;
    get cluster(): string;
}
export declare class DataGoogleComputeReservationBlockPhysicalTopologyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeReservationBlockPhysicalTopologyOutputReference;
}
export interface DataGoogleComputeReservationBlockReservationMaintenance {
}
export declare function dataGoogleComputeReservationBlockReservationMaintenanceToTerraform(struct?: DataGoogleComputeReservationBlockReservationMaintenance): any;
export declare function dataGoogleComputeReservationBlockReservationMaintenanceToHclTerraform(struct?: DataGoogleComputeReservationBlockReservationMaintenance): any;
export declare class DataGoogleComputeReservationBlockReservationMaintenanceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeReservationBlockReservationMaintenance | undefined;
    set internalValue(value: DataGoogleComputeReservationBlockReservationMaintenance | undefined);
    get instanceMaintenanceOngoingCount(): number;
    get instanceMaintenancePendingCount(): number;
    get maintenanceOngoingCount(): number;
    get maintenancePendingCount(): number;
    get schedulingType(): string;
    get subblockInfraMaintenanceOngoingCount(): number;
    get subblockInfraMaintenancePendingCount(): number;
}
export declare class DataGoogleComputeReservationBlockReservationMaintenanceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeReservationBlockReservationMaintenanceOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_reservation_block google_compute_reservation_block}
*/
export declare class DataGoogleComputeReservationBlock extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_compute_reservation_block";
    /**
    * Generates CDKTN code for importing a DataGoogleComputeReservationBlock resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleComputeReservationBlock to import
    * @param importFromId The id of the existing DataGoogleComputeReservationBlock that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_reservation_block#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleComputeReservationBlock to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_reservation_block google_compute_reservation_block} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleComputeReservationBlockConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleComputeReservationBlockConfig);
    get blockCount(): number;
    get creationTimestamp(): string;
    private _healthInfo;
    get healthInfo(): DataGoogleComputeReservationBlockHealthInfoList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get inUseCount(): number;
    get kind(): string;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _physicalTopology;
    get physicalTopology(): DataGoogleComputeReservationBlockPhysicalTopologyList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _reservation?;
    get reservation(): string;
    set reservation(value: string);
    get reservationInput(): string | undefined;
    private _reservationMaintenance;
    get reservationMaintenance(): DataGoogleComputeReservationBlockReservationMaintenanceList;
    get reservationSubBlockCount(): number;
    get reservationSubBlockInUseCount(): number;
    get resourceId(): string;
    get selfLink(): string;
    get selfLinkWithId(): string;
    get status(): string;
    get subBlockNames(): string[];
    private _zone?;
    get zone(): string;
    set zone(value: string);
    resetZone(): void;
    get zoneInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
