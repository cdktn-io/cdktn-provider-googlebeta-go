/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleGkeHubMembershipConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_gke_hub_membership#id DataGoogleGkeHubMembership#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Location of the membership.
    * The default value is 'global'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_gke_hub_membership#location DataGoogleGkeHubMembership#location}
    */
    readonly location: string;
    /**
    * The client-provided identifier of the membership.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_gke_hub_membership#membership_id DataGoogleGkeHubMembership#membership_id}
    */
    readonly membershipId: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_gke_hub_membership#project DataGoogleGkeHubMembership#project}
    */
    readonly project?: string;
}
export interface DataGoogleGkeHubMembershipAuthority {
}
export declare function dataGoogleGkeHubMembershipAuthorityToTerraform(struct?: DataGoogleGkeHubMembershipAuthority): any;
export declare function dataGoogleGkeHubMembershipAuthorityToHclTerraform(struct?: DataGoogleGkeHubMembershipAuthority): any;
export declare class DataGoogleGkeHubMembershipAuthorityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubMembershipAuthority | undefined;
    set internalValue(value: DataGoogleGkeHubMembershipAuthority | undefined);
    get issuer(): string;
}
export declare class DataGoogleGkeHubMembershipAuthorityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubMembershipAuthorityOutputReference;
}
export interface DataGoogleGkeHubMembershipEndpointGkeCluster {
}
export declare function dataGoogleGkeHubMembershipEndpointGkeClusterToTerraform(struct?: DataGoogleGkeHubMembershipEndpointGkeCluster): any;
export declare function dataGoogleGkeHubMembershipEndpointGkeClusterToHclTerraform(struct?: DataGoogleGkeHubMembershipEndpointGkeCluster): any;
export declare class DataGoogleGkeHubMembershipEndpointGkeClusterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubMembershipEndpointGkeCluster | undefined;
    set internalValue(value: DataGoogleGkeHubMembershipEndpointGkeCluster | undefined);
    get resourceLink(): string;
}
export declare class DataGoogleGkeHubMembershipEndpointGkeClusterList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubMembershipEndpointGkeClusterOutputReference;
}
export interface DataGoogleGkeHubMembershipEndpoint {
}
export declare function dataGoogleGkeHubMembershipEndpointToTerraform(struct?: DataGoogleGkeHubMembershipEndpoint): any;
export declare function dataGoogleGkeHubMembershipEndpointToHclTerraform(struct?: DataGoogleGkeHubMembershipEndpoint): any;
export declare class DataGoogleGkeHubMembershipEndpointOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubMembershipEndpoint | undefined;
    set internalValue(value: DataGoogleGkeHubMembershipEndpoint | undefined);
    private _gkeCluster;
    get gkeCluster(): DataGoogleGkeHubMembershipEndpointGkeClusterList;
}
export declare class DataGoogleGkeHubMembershipEndpointList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubMembershipEndpointOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_gke_hub_membership google_gke_hub_membership}
*/
export declare class DataGoogleGkeHubMembership extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_gke_hub_membership";
    /**
    * Generates CDKTN code for importing a DataGoogleGkeHubMembership resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleGkeHubMembership to import
    * @param importFromId The id of the existing DataGoogleGkeHubMembership that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_gke_hub_membership#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleGkeHubMembership to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_gke_hub_membership google_gke_hub_membership} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleGkeHubMembershipConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleGkeHubMembershipConfig);
    private _authority;
    get authority(): DataGoogleGkeHubMembershipAuthorityList;
    get deletionPolicy(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _endpoint;
    get endpoint(): DataGoogleGkeHubMembershipEndpointList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels;
    get labels(): cdktn.StringMap;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _membershipId?;
    get membershipId(): string;
    set membershipId(value: string);
    get membershipIdInput(): string | undefined;
    get name(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
