/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleStorageBucketObjectContentsConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_bucket_object_contents#bucket DataGoogleStorageBucketObjectContents#bucket}
    */
    readonly bucket: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_bucket_object_contents#id DataGoogleStorageBucketObjectContents#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_bucket_object_contents#match_glob DataGoogleStorageBucketObjectContents#match_glob}
    */
    readonly matchGlob?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_bucket_object_contents#prefix DataGoogleStorageBucketObjectContents#prefix}
    */
    readonly prefix?: string;
}
export interface DataGoogleStorageBucketObjectContentsBucketObjects {
}
export declare function dataGoogleStorageBucketObjectContentsBucketObjectsToTerraform(struct?: DataGoogleStorageBucketObjectContentsBucketObjects): any;
export declare function dataGoogleStorageBucketObjectContentsBucketObjectsToHclTerraform(struct?: DataGoogleStorageBucketObjectContentsBucketObjects): any;
export declare class DataGoogleStorageBucketObjectContentsBucketObjectsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageBucketObjectContentsBucketObjects | undefined;
    set internalValue(value: DataGoogleStorageBucketObjectContentsBucketObjects | undefined);
    get content(): string;
    get contentBase64(): string;
    get contentBase64Sha512(): string;
    get contentHexsha512(): string;
    get contentType(): string;
    get mediaLink(): string;
    get name(): string;
    get selfLink(): string;
}
export declare class DataGoogleStorageBucketObjectContentsBucketObjectsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageBucketObjectContentsBucketObjectsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_bucket_object_contents google_storage_bucket_object_contents}
*/
export declare class DataGoogleStorageBucketObjectContents extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_storage_bucket_object_contents";
    /**
    * Generates CDKTN code for importing a DataGoogleStorageBucketObjectContents resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleStorageBucketObjectContents to import
    * @param importFromId The id of the existing DataGoogleStorageBucketObjectContents that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_bucket_object_contents#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleStorageBucketObjectContents to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_bucket_object_contents google_storage_bucket_object_contents} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleStorageBucketObjectContentsConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleStorageBucketObjectContentsConfig);
    private _bucket?;
    get bucket(): string;
    set bucket(value: string);
    get bucketInput(): string | undefined;
    private _bucketObjects;
    get bucketObjects(): DataGoogleStorageBucketObjectContentsBucketObjectsList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _matchGlob?;
    get matchGlob(): string;
    set matchGlob(value: string);
    resetMatchGlob(): void;
    get matchGlobInput(): string | undefined;
    private _prefix?;
    get prefix(): string;
    set prefix(value: string);
    resetPrefix(): void;
    get prefixInput(): string | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
