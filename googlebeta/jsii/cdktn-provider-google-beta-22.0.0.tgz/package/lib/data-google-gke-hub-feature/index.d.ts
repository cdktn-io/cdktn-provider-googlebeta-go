/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleGkeHubFeatureConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_gke_hub_feature#id DataGoogleGkeHubFeature#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The location for the resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_gke_hub_feature#location DataGoogleGkeHubFeature#location}
    */
    readonly location: string;
    /**
    * The full, unique name of this Feature resource
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_gke_hub_feature#name DataGoogleGkeHubFeature#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_gke_hub_feature#project DataGoogleGkeHubFeature#project}
    */
    readonly project?: string;
}
export interface DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncGit {
}
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncGitToTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncGit): any;
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncGitToHclTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncGit): any;
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncGitOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncGit | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncGit | undefined);
    get gcpServiceAccountEmail(): string;
    get httpsProxy(): string;
    get policyDir(): string;
    get secretType(): string;
    get syncBranch(): string;
    get syncRepo(): string;
    get syncRev(): string;
    get syncWaitSecs(): string;
}
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncGitList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncGitOutputReference;
}
export interface DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncOci {
}
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncOciToTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncOci): any;
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncOciToHclTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncOci): any;
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncOciOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncOci | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncOci | undefined);
    get gcpServiceAccountEmail(): string;
    get policyDir(): string;
    get secretType(): string;
    get syncRepo(): string;
    get syncWaitSecs(): string;
    get version(): string;
}
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncOciList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncOciOutputReference;
}
export interface DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSync {
}
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncToTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSync): any;
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncToHclTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSync): any;
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSync | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSync | undefined);
    get enabled(): cdktn.IResolvable;
    private _git;
    get git(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncGitList;
    get metricsGcpServiceAccountEmail(): string;
    private _oci;
    get oci(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncOciList;
    get preventDrift(): cdktn.IResolvable;
    get sourceFormat(): string;
}
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncOutputReference;
}
export interface DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagement {
}
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementToTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagement): any;
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementToHclTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagement): any;
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagement | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagement | undefined);
    private _configSync;
    get configSync(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementConfigSyncList;
    get management(): string;
    get version(): string;
}
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementOutputReference;
}
export interface DataGoogleGkeHubFeatureFleetDefaultMemberConfigMesh {
}
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigMeshToTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigMesh): any;
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigMeshToHclTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigMesh): any;
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigMeshOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigMesh | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureFleetDefaultMemberConfigMesh | undefined);
    get management(): string;
}
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigMeshList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureFleetDefaultMemberConfigMeshOutputReference;
}
export interface DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesLimits {
}
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesLimitsToTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesLimits): any;
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesLimitsToHclTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesLimits): any;
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesLimitsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesLimits | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesLimits | undefined);
    get cpu(): string;
    get memory(): string;
}
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesLimitsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesLimitsOutputReference;
}
export interface DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesRequests {
}
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesRequestsToTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesRequests): any;
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesRequestsToHclTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesRequests): any;
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesRequestsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesRequests | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesRequests | undefined);
    get cpu(): string;
    get memory(): string;
}
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesRequestsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesRequestsOutputReference;
}
export interface DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResources {
}
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesToTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResources): any;
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesToHclTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResources): any;
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResources | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResources | undefined);
    private _limits;
    get limits(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesLimitsList;
    private _requests;
    get requests(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesRequestsList;
}
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesOutputReference;
}
export interface DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsPodToleration {
}
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsPodTolerationToTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsPodToleration): any;
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsPodTolerationToHclTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsPodToleration): any;
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsPodTolerationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsPodToleration | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsPodToleration | undefined);
    get effect(): string;
    get key(): string;
    get operator(): string;
    get value(): string;
}
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsPodTolerationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsPodTolerationOutputReference;
}
export interface DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigs {
}
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsToTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigs): any;
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsToHclTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigs): any;
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigs | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigs | undefined);
    get component(): string;
    private _containerResources;
    get containerResources(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsContainerResourcesList;
    get podAffinity(): string;
    private _podToleration;
    get podToleration(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsPodTolerationList;
    get replicaCount(): number;
}
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsOutputReference;
}
export interface DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigMonitoring {
}
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigMonitoringToTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigMonitoring): any;
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigMonitoringToHclTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigMonitoring): any;
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigMonitoringOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigMonitoring | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigMonitoring | undefined);
    get backends(): string[];
}
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigMonitoringList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigMonitoringOutputReference;
}
export interface DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentBundles {
}
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentBundlesToTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentBundles): any;
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentBundlesToHclTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentBundles): any;
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentBundlesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentBundles | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentBundles | undefined);
    get bundle(): string;
    get exemptedNamespaces(): string[];
}
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentBundlesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentBundlesOutputReference;
}
export interface DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentTemplateLibrary {
}
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentTemplateLibraryToTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentTemplateLibrary): any;
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentTemplateLibraryToHclTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentTemplateLibrary): any;
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentTemplateLibraryOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentTemplateLibrary | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentTemplateLibrary | undefined);
    get installation(): string;
}
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentTemplateLibraryList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentTemplateLibraryOutputReference;
}
export interface DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContent {
}
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentToTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContent): any;
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentToHclTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContent): any;
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContent | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContent | undefined);
    private _bundles;
    get bundles(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentBundlesList;
    private _templateLibrary;
    get templateLibrary(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentTemplateLibraryList;
}
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentOutputReference;
}
export interface DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfig {
}
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigToTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfig): any;
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigToHclTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfig): any;
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfig | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfig | undefined);
    get auditIntervalSeconds(): number;
    get constraintViolationLimit(): number;
    private _deploymentConfigs;
    get deploymentConfigs(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigDeploymentConfigsList;
    get exemptableNamespaces(): string[];
    get installSpec(): string;
    get logDeniesEnabled(): cdktn.IResolvable;
    private _monitoring;
    get monitoring(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigMonitoringList;
    get mutationEnabled(): cdktn.IResolvable;
    private _policyContent;
    get policyContent(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigPolicyContentList;
    get referentialRulesEnabled(): cdktn.IResolvable;
}
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigOutputReference;
}
export interface DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontroller {
}
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerToTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontroller): any;
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerToHclTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontroller): any;
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontroller | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontroller | undefined);
    private _policyControllerHubConfig;
    get policyControllerHubConfig(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerPolicyControllerHubConfigList;
    get version(): string;
}
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerOutputReference;
}
export interface DataGoogleGkeHubFeatureFleetDefaultMemberConfig {
}
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigToTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfig): any;
export declare function dataGoogleGkeHubFeatureFleetDefaultMemberConfigToHclTerraform(struct?: DataGoogleGkeHubFeatureFleetDefaultMemberConfig): any;
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureFleetDefaultMemberConfig | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureFleetDefaultMemberConfig | undefined);
    private _configmanagement;
    get configmanagement(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigConfigmanagementList;
    private _mesh;
    get mesh(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigMeshList;
    private _policycontroller;
    get policycontroller(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigPolicycontrollerList;
}
export declare class DataGoogleGkeHubFeatureFleetDefaultMemberConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureFleetDefaultMemberConfigOutputReference;
}
export interface DataGoogleGkeHubFeatureResourceState {
}
export declare function dataGoogleGkeHubFeatureResourceStateToTerraform(struct?: DataGoogleGkeHubFeatureResourceState): any;
export declare function dataGoogleGkeHubFeatureResourceStateToHclTerraform(struct?: DataGoogleGkeHubFeatureResourceState): any;
export declare class DataGoogleGkeHubFeatureResourceStateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureResourceState | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureResourceState | undefined);
    get hasResources(): cdktn.IResolvable;
    get state(): string;
}
export declare class DataGoogleGkeHubFeatureResourceStateList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureResourceStateOutputReference;
}
export interface DataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesPostConditions {
}
export declare function dataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesPostConditionsToTerraform(struct?: DataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesPostConditions): any;
export declare function dataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesPostConditionsToHclTerraform(struct?: DataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesPostConditions): any;
export declare class DataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesPostConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesPostConditions | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesPostConditions | undefined);
    get soaking(): string;
}
export declare class DataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesPostConditionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesPostConditionsOutputReference;
}
export interface DataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesUpgrade {
}
export declare function dataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesUpgradeToTerraform(struct?: DataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesUpgrade): any;
export declare function dataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesUpgradeToHclTerraform(struct?: DataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesUpgrade): any;
export declare class DataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesUpgradeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesUpgrade | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesUpgrade | undefined);
    get name(): string;
    get version(): string;
}
export declare class DataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesUpgradeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesUpgradeOutputReference;
}
export interface DataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverrides {
}
export declare function dataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesToTerraform(struct?: DataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverrides): any;
export declare function dataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesToHclTerraform(struct?: DataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverrides): any;
export declare class DataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverrides | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverrides | undefined);
    private _postConditions;
    get postConditions(): DataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesPostConditionsList;
    private _upgrade;
    get upgrade(): DataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesUpgradeList;
}
export declare class DataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesOutputReference;
}
export interface DataGoogleGkeHubFeatureSpecClusterupgradePostConditions {
}
export declare function dataGoogleGkeHubFeatureSpecClusterupgradePostConditionsToTerraform(struct?: DataGoogleGkeHubFeatureSpecClusterupgradePostConditions): any;
export declare function dataGoogleGkeHubFeatureSpecClusterupgradePostConditionsToHclTerraform(struct?: DataGoogleGkeHubFeatureSpecClusterupgradePostConditions): any;
export declare class DataGoogleGkeHubFeatureSpecClusterupgradePostConditionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureSpecClusterupgradePostConditions | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureSpecClusterupgradePostConditions | undefined);
    get soaking(): string;
}
export declare class DataGoogleGkeHubFeatureSpecClusterupgradePostConditionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureSpecClusterupgradePostConditionsOutputReference;
}
export interface DataGoogleGkeHubFeatureSpecClusterupgrade {
}
export declare function dataGoogleGkeHubFeatureSpecClusterupgradeToTerraform(struct?: DataGoogleGkeHubFeatureSpecClusterupgrade): any;
export declare function dataGoogleGkeHubFeatureSpecClusterupgradeToHclTerraform(struct?: DataGoogleGkeHubFeatureSpecClusterupgrade): any;
export declare class DataGoogleGkeHubFeatureSpecClusterupgradeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureSpecClusterupgrade | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureSpecClusterupgrade | undefined);
    private _gkeUpgradeOverrides;
    get gkeUpgradeOverrides(): DataGoogleGkeHubFeatureSpecClusterupgradeGkeUpgradeOverridesList;
    private _postConditions;
    get postConditions(): DataGoogleGkeHubFeatureSpecClusterupgradePostConditionsList;
    get upstreamFleets(): string[];
}
export declare class DataGoogleGkeHubFeatureSpecClusterupgradeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureSpecClusterupgradeOutputReference;
}
export interface DataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigDefaultConfig {
}
export declare function dataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigDefaultConfigToTerraform(struct?: DataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigDefaultConfig): any;
export declare function dataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigDefaultConfigToHclTerraform(struct?: DataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigDefaultConfig): any;
export declare class DataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigDefaultConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigDefaultConfig | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigDefaultConfig | undefined);
    get mode(): string;
}
export declare class DataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigDefaultConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigDefaultConfigOutputReference;
}
export interface DataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigFleetScopeLogsConfig {
}
export declare function dataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigFleetScopeLogsConfigToTerraform(struct?: DataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigFleetScopeLogsConfig): any;
export declare function dataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigFleetScopeLogsConfigToHclTerraform(struct?: DataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigFleetScopeLogsConfig): any;
export declare class DataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigFleetScopeLogsConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigFleetScopeLogsConfig | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigFleetScopeLogsConfig | undefined);
    get mode(): string;
}
export declare class DataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigFleetScopeLogsConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigFleetScopeLogsConfigOutputReference;
}
export interface DataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfig {
}
export declare function dataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigToTerraform(struct?: DataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfig): any;
export declare function dataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigToHclTerraform(struct?: DataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfig): any;
export declare class DataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfig | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfig | undefined);
    private _defaultConfig;
    get defaultConfig(): DataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigDefaultConfigList;
    private _fleetScopeLogsConfig;
    get fleetScopeLogsConfig(): DataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigFleetScopeLogsConfigList;
}
export declare class DataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigOutputReference;
}
export interface DataGoogleGkeHubFeatureSpecFleetobservability {
}
export declare function dataGoogleGkeHubFeatureSpecFleetobservabilityToTerraform(struct?: DataGoogleGkeHubFeatureSpecFleetobservability): any;
export declare function dataGoogleGkeHubFeatureSpecFleetobservabilityToHclTerraform(struct?: DataGoogleGkeHubFeatureSpecFleetobservability): any;
export declare class DataGoogleGkeHubFeatureSpecFleetobservabilityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureSpecFleetobservability | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureSpecFleetobservability | undefined);
    private _loggingConfig;
    get loggingConfig(): DataGoogleGkeHubFeatureSpecFleetobservabilityLoggingConfigList;
}
export declare class DataGoogleGkeHubFeatureSpecFleetobservabilityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureSpecFleetobservabilityOutputReference;
}
export interface DataGoogleGkeHubFeatureSpecMulticlusteringress {
}
export declare function dataGoogleGkeHubFeatureSpecMulticlusteringressToTerraform(struct?: DataGoogleGkeHubFeatureSpecMulticlusteringress): any;
export declare function dataGoogleGkeHubFeatureSpecMulticlusteringressToHclTerraform(struct?: DataGoogleGkeHubFeatureSpecMulticlusteringress): any;
export declare class DataGoogleGkeHubFeatureSpecMulticlusteringressOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureSpecMulticlusteringress | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureSpecMulticlusteringress | undefined);
    get configMembership(): string;
}
export declare class DataGoogleGkeHubFeatureSpecMulticlusteringressList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureSpecMulticlusteringressOutputReference;
}
export interface DataGoogleGkeHubFeatureSpecRbacrolebindingactuation {
}
export declare function dataGoogleGkeHubFeatureSpecRbacrolebindingactuationToTerraform(struct?: DataGoogleGkeHubFeatureSpecRbacrolebindingactuation): any;
export declare function dataGoogleGkeHubFeatureSpecRbacrolebindingactuationToHclTerraform(struct?: DataGoogleGkeHubFeatureSpecRbacrolebindingactuation): any;
export declare class DataGoogleGkeHubFeatureSpecRbacrolebindingactuationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureSpecRbacrolebindingactuation | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureSpecRbacrolebindingactuation | undefined);
    get allowedCustomRoles(): string[];
}
export declare class DataGoogleGkeHubFeatureSpecRbacrolebindingactuationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureSpecRbacrolebindingactuationOutputReference;
}
export interface DataGoogleGkeHubFeatureSpecWorkloadidentity {
}
export declare function dataGoogleGkeHubFeatureSpecWorkloadidentityToTerraform(struct?: DataGoogleGkeHubFeatureSpecWorkloadidentity): any;
export declare function dataGoogleGkeHubFeatureSpecWorkloadidentityToHclTerraform(struct?: DataGoogleGkeHubFeatureSpecWorkloadidentity): any;
export declare class DataGoogleGkeHubFeatureSpecWorkloadidentityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureSpecWorkloadidentity | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureSpecWorkloadidentity | undefined);
    get scopeTenancyPool(): string;
}
export declare class DataGoogleGkeHubFeatureSpecWorkloadidentityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureSpecWorkloadidentityOutputReference;
}
export interface DataGoogleGkeHubFeatureSpec {
}
export declare function dataGoogleGkeHubFeatureSpecToTerraform(struct?: DataGoogleGkeHubFeatureSpec): any;
export declare function dataGoogleGkeHubFeatureSpecToHclTerraform(struct?: DataGoogleGkeHubFeatureSpec): any;
export declare class DataGoogleGkeHubFeatureSpecOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureSpec | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureSpec | undefined);
    private _clusterupgrade;
    get clusterupgrade(): DataGoogleGkeHubFeatureSpecClusterupgradeList;
    private _fleetobservability;
    get fleetobservability(): DataGoogleGkeHubFeatureSpecFleetobservabilityList;
    private _multiclusteringress;
    get multiclusteringress(): DataGoogleGkeHubFeatureSpecMulticlusteringressList;
    private _rbacrolebindingactuation;
    get rbacrolebindingactuation(): DataGoogleGkeHubFeatureSpecRbacrolebindingactuationList;
    private _workloadidentity;
    get workloadidentity(): DataGoogleGkeHubFeatureSpecWorkloadidentityList;
}
export declare class DataGoogleGkeHubFeatureSpecList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureSpecOutputReference;
}
export interface DataGoogleGkeHubFeatureStateState {
}
export declare function dataGoogleGkeHubFeatureStateStateToTerraform(struct?: DataGoogleGkeHubFeatureStateState): any;
export declare function dataGoogleGkeHubFeatureStateStateToHclTerraform(struct?: DataGoogleGkeHubFeatureStateState): any;
export declare class DataGoogleGkeHubFeatureStateStateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureStateState | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureStateState | undefined);
    get code(): string;
    get description(): string;
    get updateTime(): string;
}
export declare class DataGoogleGkeHubFeatureStateStateList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureStateStateOutputReference;
}
export interface DataGoogleGkeHubFeatureState {
}
export declare function dataGoogleGkeHubFeatureStateToTerraform(struct?: DataGoogleGkeHubFeatureState): any;
export declare function dataGoogleGkeHubFeatureStateToHclTerraform(struct?: DataGoogleGkeHubFeatureState): any;
export declare class DataGoogleGkeHubFeatureStateOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleGkeHubFeatureState | undefined;
    set internalValue(value: DataGoogleGkeHubFeatureState | undefined);
    private _state;
    get state(): DataGoogleGkeHubFeatureStateStateList;
}
export declare class DataGoogleGkeHubFeatureStateList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleGkeHubFeatureStateOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_gke_hub_feature google_gke_hub_feature}
*/
export declare class DataGoogleGkeHubFeature extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_gke_hub_feature";
    /**
    * Generates CDKTN code for importing a DataGoogleGkeHubFeature resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleGkeHubFeature to import
    * @param importFromId The id of the existing DataGoogleGkeHubFeature that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_gke_hub_feature#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleGkeHubFeature to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_gke_hub_feature google_gke_hub_feature} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleGkeHubFeatureConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleGkeHubFeatureConfig);
    get createTime(): string;
    get deleteTime(): string;
    get deletionPolicy(): string;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    private _fleetDefaultMemberConfig;
    get fleetDefaultMemberConfig(): DataGoogleGkeHubFeatureFleetDefaultMemberConfigList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _labels;
    get labels(): cdktn.StringMap;
    private _location?;
    get location(): string;
    set location(value: string);
    get locationInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _resourceState;
    get resourceState(): DataGoogleGkeHubFeatureResourceStateList;
    private _spec;
    get spec(): DataGoogleGkeHubFeatureSpecList;
    private _state;
    get state(): DataGoogleGkeHubFeatureStateList;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
