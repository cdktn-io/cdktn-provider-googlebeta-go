/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleComputeBackendServiceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_backend_service#id DataGoogleComputeBackendService#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Name of the resource. Provided by the client when the resource is
    * created. The name must be 1-63 characters long, and comply with
    * RFC1035. Specifically, the name must be 1-63 characters long and match
    * the regular expression '[a-z]([-a-z0-9]*[a-z0-9])?' which means the
    * first character must be a lowercase letter, and all following
    * characters must be a dash, lowercase letter, or digit, except the last
    * character, which cannot be a dash.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_backend_service#name DataGoogleComputeBackendService#name}
    */
    readonly name: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_backend_service#project DataGoogleComputeBackendService#project}
    */
    readonly project?: string;
}
export interface DataGoogleComputeBackendServiceBackendCustomMetrics {
}
export declare function dataGoogleComputeBackendServiceBackendCustomMetricsToTerraform(struct?: DataGoogleComputeBackendServiceBackendCustomMetrics): any;
export declare function dataGoogleComputeBackendServiceBackendCustomMetricsToHclTerraform(struct?: DataGoogleComputeBackendServiceBackendCustomMetrics): any;
export declare class DataGoogleComputeBackendServiceBackendCustomMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceBackendCustomMetrics | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceBackendCustomMetrics | undefined);
    get dryRun(): cdktn.IResolvable;
    get maxUtilization(): number;
    get name(): string;
}
export declare class DataGoogleComputeBackendServiceBackendCustomMetricsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceBackendCustomMetricsOutputReference;
}
export interface DataGoogleComputeBackendServiceBackend {
}
export declare function dataGoogleComputeBackendServiceBackendToTerraform(struct?: DataGoogleComputeBackendServiceBackend): any;
export declare function dataGoogleComputeBackendServiceBackendToHclTerraform(struct?: DataGoogleComputeBackendServiceBackend): any;
export declare class DataGoogleComputeBackendServiceBackendOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceBackend | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceBackend | undefined);
    get balancingMode(): string;
    get capacityScaler(): number;
    private _customMetrics;
    get customMetrics(): DataGoogleComputeBackendServiceBackendCustomMetricsList;
    get description(): string;
    get group(): string;
    get maxConnections(): number;
    get maxConnectionsPerEndpoint(): number;
    get maxConnectionsPerInstance(): number;
    get maxInFlightRequests(): number;
    get maxInFlightRequestsPerEndpoint(): number;
    get maxInFlightRequestsPerInstance(): number;
    get maxRate(): number;
    get maxRatePerEndpoint(): number;
    get maxRatePerInstance(): number;
    get maxUtilization(): number;
    get preference(): string;
    get trafficDuration(): string;
}
export declare class DataGoogleComputeBackendServiceBackendList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceBackendOutputReference;
}
export interface DataGoogleComputeBackendServiceCdnPolicyBypassCacheOnRequestHeaders {
}
export declare function dataGoogleComputeBackendServiceCdnPolicyBypassCacheOnRequestHeadersToTerraform(struct?: DataGoogleComputeBackendServiceCdnPolicyBypassCacheOnRequestHeaders): any;
export declare function dataGoogleComputeBackendServiceCdnPolicyBypassCacheOnRequestHeadersToHclTerraform(struct?: DataGoogleComputeBackendServiceCdnPolicyBypassCacheOnRequestHeaders): any;
export declare class DataGoogleComputeBackendServiceCdnPolicyBypassCacheOnRequestHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceCdnPolicyBypassCacheOnRequestHeaders | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceCdnPolicyBypassCacheOnRequestHeaders | undefined);
    get headerName(): string;
}
export declare class DataGoogleComputeBackendServiceCdnPolicyBypassCacheOnRequestHeadersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceCdnPolicyBypassCacheOnRequestHeadersOutputReference;
}
export interface DataGoogleComputeBackendServiceCdnPolicyCacheKeyPolicy {
}
export declare function dataGoogleComputeBackendServiceCdnPolicyCacheKeyPolicyToTerraform(struct?: DataGoogleComputeBackendServiceCdnPolicyCacheKeyPolicy): any;
export declare function dataGoogleComputeBackendServiceCdnPolicyCacheKeyPolicyToHclTerraform(struct?: DataGoogleComputeBackendServiceCdnPolicyCacheKeyPolicy): any;
export declare class DataGoogleComputeBackendServiceCdnPolicyCacheKeyPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceCdnPolicyCacheKeyPolicy | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceCdnPolicyCacheKeyPolicy | undefined);
    get includeHost(): cdktn.IResolvable;
    get includeHttpHeaders(): string[];
    get includeNamedCookies(): string[];
    get includeProtocol(): cdktn.IResolvable;
    get includeQueryString(): cdktn.IResolvable;
    get queryStringBlacklist(): string[];
    get queryStringWhitelist(): string[];
}
export declare class DataGoogleComputeBackendServiceCdnPolicyCacheKeyPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceCdnPolicyCacheKeyPolicyOutputReference;
}
export interface DataGoogleComputeBackendServiceCdnPolicyNegativeCachingPolicy {
}
export declare function dataGoogleComputeBackendServiceCdnPolicyNegativeCachingPolicyToTerraform(struct?: DataGoogleComputeBackendServiceCdnPolicyNegativeCachingPolicy): any;
export declare function dataGoogleComputeBackendServiceCdnPolicyNegativeCachingPolicyToHclTerraform(struct?: DataGoogleComputeBackendServiceCdnPolicyNegativeCachingPolicy): any;
export declare class DataGoogleComputeBackendServiceCdnPolicyNegativeCachingPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceCdnPolicyNegativeCachingPolicy | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceCdnPolicyNegativeCachingPolicy | undefined);
    get code(): number;
    get ttl(): number;
}
export declare class DataGoogleComputeBackendServiceCdnPolicyNegativeCachingPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceCdnPolicyNegativeCachingPolicyOutputReference;
}
export interface DataGoogleComputeBackendServiceCdnPolicy {
}
export declare function dataGoogleComputeBackendServiceCdnPolicyToTerraform(struct?: DataGoogleComputeBackendServiceCdnPolicy): any;
export declare function dataGoogleComputeBackendServiceCdnPolicyToHclTerraform(struct?: DataGoogleComputeBackendServiceCdnPolicy): any;
export declare class DataGoogleComputeBackendServiceCdnPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceCdnPolicy | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceCdnPolicy | undefined);
    private _bypassCacheOnRequestHeaders;
    get bypassCacheOnRequestHeaders(): DataGoogleComputeBackendServiceCdnPolicyBypassCacheOnRequestHeadersList;
    private _cacheKeyPolicy;
    get cacheKeyPolicy(): DataGoogleComputeBackendServiceCdnPolicyCacheKeyPolicyList;
    get cacheMode(): string;
    get clientTtl(): number;
    get defaultTtl(): number;
    get maxTtl(): number;
    get negativeCaching(): cdktn.IResolvable;
    private _negativeCachingPolicy;
    get negativeCachingPolicy(): DataGoogleComputeBackendServiceCdnPolicyNegativeCachingPolicyList;
    get requestCoalescing(): cdktn.IResolvable;
    get serveWhileStale(): number;
    get signedUrlCacheMaxAgeSec(): number;
}
export declare class DataGoogleComputeBackendServiceCdnPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceCdnPolicyOutputReference;
}
export interface DataGoogleComputeBackendServiceCircuitBreakersConnectTimeout {
}
export declare function dataGoogleComputeBackendServiceCircuitBreakersConnectTimeoutToTerraform(struct?: DataGoogleComputeBackendServiceCircuitBreakersConnectTimeout): any;
export declare function dataGoogleComputeBackendServiceCircuitBreakersConnectTimeoutToHclTerraform(struct?: DataGoogleComputeBackendServiceCircuitBreakersConnectTimeout): any;
export declare class DataGoogleComputeBackendServiceCircuitBreakersConnectTimeoutOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceCircuitBreakersConnectTimeout | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceCircuitBreakersConnectTimeout | undefined);
    get nanos(): number;
    get seconds(): number;
}
export declare class DataGoogleComputeBackendServiceCircuitBreakersConnectTimeoutList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceCircuitBreakersConnectTimeoutOutputReference;
}
export interface DataGoogleComputeBackendServiceCircuitBreakers {
}
export declare function dataGoogleComputeBackendServiceCircuitBreakersToTerraform(struct?: DataGoogleComputeBackendServiceCircuitBreakers): any;
export declare function dataGoogleComputeBackendServiceCircuitBreakersToHclTerraform(struct?: DataGoogleComputeBackendServiceCircuitBreakers): any;
export declare class DataGoogleComputeBackendServiceCircuitBreakersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceCircuitBreakers | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceCircuitBreakers | undefined);
    private _connectTimeout;
    get connectTimeout(): DataGoogleComputeBackendServiceCircuitBreakersConnectTimeoutList;
    get maxConnections(): number;
    get maxPendingRequests(): number;
    get maxRequests(): number;
    get maxRequestsPerConnection(): number;
    get maxRetries(): number;
}
export declare class DataGoogleComputeBackendServiceCircuitBreakersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceCircuitBreakersOutputReference;
}
export interface DataGoogleComputeBackendServiceConsistentHashHttpCookieTtl {
}
export declare function dataGoogleComputeBackendServiceConsistentHashHttpCookieTtlToTerraform(struct?: DataGoogleComputeBackendServiceConsistentHashHttpCookieTtl): any;
export declare function dataGoogleComputeBackendServiceConsistentHashHttpCookieTtlToHclTerraform(struct?: DataGoogleComputeBackendServiceConsistentHashHttpCookieTtl): any;
export declare class DataGoogleComputeBackendServiceConsistentHashHttpCookieTtlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceConsistentHashHttpCookieTtl | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceConsistentHashHttpCookieTtl | undefined);
    get nanos(): number;
    get seconds(): number;
}
export declare class DataGoogleComputeBackendServiceConsistentHashHttpCookieTtlList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceConsistentHashHttpCookieTtlOutputReference;
}
export interface DataGoogleComputeBackendServiceConsistentHashHttpCookie {
}
export declare function dataGoogleComputeBackendServiceConsistentHashHttpCookieToTerraform(struct?: DataGoogleComputeBackendServiceConsistentHashHttpCookie): any;
export declare function dataGoogleComputeBackendServiceConsistentHashHttpCookieToHclTerraform(struct?: DataGoogleComputeBackendServiceConsistentHashHttpCookie): any;
export declare class DataGoogleComputeBackendServiceConsistentHashHttpCookieOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceConsistentHashHttpCookie | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceConsistentHashHttpCookie | undefined);
    get name(): string;
    get path(): string;
    private _ttl;
    get ttl(): DataGoogleComputeBackendServiceConsistentHashHttpCookieTtlList;
}
export declare class DataGoogleComputeBackendServiceConsistentHashHttpCookieList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceConsistentHashHttpCookieOutputReference;
}
export interface DataGoogleComputeBackendServiceConsistentHash {
}
export declare function dataGoogleComputeBackendServiceConsistentHashToTerraform(struct?: DataGoogleComputeBackendServiceConsistentHash): any;
export declare function dataGoogleComputeBackendServiceConsistentHashToHclTerraform(struct?: DataGoogleComputeBackendServiceConsistentHash): any;
export declare class DataGoogleComputeBackendServiceConsistentHashOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceConsistentHash | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceConsistentHash | undefined);
    private _httpCookie;
    get httpCookie(): DataGoogleComputeBackendServiceConsistentHashHttpCookieList;
    get httpHeaderName(): string;
    get minimumRingSize(): number;
}
export declare class DataGoogleComputeBackendServiceConsistentHashList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceConsistentHashOutputReference;
}
export interface DataGoogleComputeBackendServiceCustomMetrics {
}
export declare function dataGoogleComputeBackendServiceCustomMetricsToTerraform(struct?: DataGoogleComputeBackendServiceCustomMetrics): any;
export declare function dataGoogleComputeBackendServiceCustomMetricsToHclTerraform(struct?: DataGoogleComputeBackendServiceCustomMetrics): any;
export declare class DataGoogleComputeBackendServiceCustomMetricsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceCustomMetrics | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceCustomMetrics | undefined);
    get dryRun(): cdktn.IResolvable;
    get name(): string;
}
export declare class DataGoogleComputeBackendServiceCustomMetricsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceCustomMetricsOutputReference;
}
export interface DataGoogleComputeBackendServiceDynamicForwardingForwardProxy {
}
export declare function dataGoogleComputeBackendServiceDynamicForwardingForwardProxyToTerraform(struct?: DataGoogleComputeBackendServiceDynamicForwardingForwardProxy): any;
export declare function dataGoogleComputeBackendServiceDynamicForwardingForwardProxyToHclTerraform(struct?: DataGoogleComputeBackendServiceDynamicForwardingForwardProxy): any;
export declare class DataGoogleComputeBackendServiceDynamicForwardingForwardProxyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceDynamicForwardingForwardProxy | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceDynamicForwardingForwardProxy | undefined);
    get enabled(): cdktn.IResolvable;
    get proxyMode(): string;
}
export declare class DataGoogleComputeBackendServiceDynamicForwardingForwardProxyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceDynamicForwardingForwardProxyOutputReference;
}
export interface DataGoogleComputeBackendServiceDynamicForwardingIpPortSelection {
}
export declare function dataGoogleComputeBackendServiceDynamicForwardingIpPortSelectionToTerraform(struct?: DataGoogleComputeBackendServiceDynamicForwardingIpPortSelection): any;
export declare function dataGoogleComputeBackendServiceDynamicForwardingIpPortSelectionToHclTerraform(struct?: DataGoogleComputeBackendServiceDynamicForwardingIpPortSelection): any;
export declare class DataGoogleComputeBackendServiceDynamicForwardingIpPortSelectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceDynamicForwardingIpPortSelection | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceDynamicForwardingIpPortSelection | undefined);
    get enabled(): cdktn.IResolvable;
}
export declare class DataGoogleComputeBackendServiceDynamicForwardingIpPortSelectionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceDynamicForwardingIpPortSelectionOutputReference;
}
export interface DataGoogleComputeBackendServiceDynamicForwarding {
}
export declare function dataGoogleComputeBackendServiceDynamicForwardingToTerraform(struct?: DataGoogleComputeBackendServiceDynamicForwarding): any;
export declare function dataGoogleComputeBackendServiceDynamicForwardingToHclTerraform(struct?: DataGoogleComputeBackendServiceDynamicForwarding): any;
export declare class DataGoogleComputeBackendServiceDynamicForwardingOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceDynamicForwarding | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceDynamicForwarding | undefined);
    private _forwardProxy;
    get forwardProxy(): DataGoogleComputeBackendServiceDynamicForwardingForwardProxyList;
    private _ipPortSelection;
    get ipPortSelection(): DataGoogleComputeBackendServiceDynamicForwardingIpPortSelectionList;
}
export declare class DataGoogleComputeBackendServiceDynamicForwardingList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceDynamicForwardingOutputReference;
}
export interface DataGoogleComputeBackendServiceIap {
}
export declare function dataGoogleComputeBackendServiceIapToTerraform(struct?: DataGoogleComputeBackendServiceIap): any;
export declare function dataGoogleComputeBackendServiceIapToHclTerraform(struct?: DataGoogleComputeBackendServiceIap): any;
export declare class DataGoogleComputeBackendServiceIapOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceIap | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceIap | undefined);
    get enabled(): cdktn.IResolvable;
    get oauth2ClientId(): string;
    get oauth2ClientIdWo(): string;
    get oauth2ClientIdWoVersion(): string;
    get oauth2ClientSecret(): string;
    get oauth2ClientSecretSha256(): string;
    get oauth2ClientSecretWo(): string;
    get oauth2ClientSecretWoVersion(): string;
}
export declare class DataGoogleComputeBackendServiceIapList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceIapOutputReference;
}
export interface DataGoogleComputeBackendServiceLocalityLbPoliciesCustomPolicy {
}
export declare function dataGoogleComputeBackendServiceLocalityLbPoliciesCustomPolicyToTerraform(struct?: DataGoogleComputeBackendServiceLocalityLbPoliciesCustomPolicy): any;
export declare function dataGoogleComputeBackendServiceLocalityLbPoliciesCustomPolicyToHclTerraform(struct?: DataGoogleComputeBackendServiceLocalityLbPoliciesCustomPolicy): any;
export declare class DataGoogleComputeBackendServiceLocalityLbPoliciesCustomPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceLocalityLbPoliciesCustomPolicy | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceLocalityLbPoliciesCustomPolicy | undefined);
    get data(): string;
    get name(): string;
}
export declare class DataGoogleComputeBackendServiceLocalityLbPoliciesCustomPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceLocalityLbPoliciesCustomPolicyOutputReference;
}
export interface DataGoogleComputeBackendServiceLocalityLbPoliciesPolicy {
}
export declare function dataGoogleComputeBackendServiceLocalityLbPoliciesPolicyToTerraform(struct?: DataGoogleComputeBackendServiceLocalityLbPoliciesPolicy): any;
export declare function dataGoogleComputeBackendServiceLocalityLbPoliciesPolicyToHclTerraform(struct?: DataGoogleComputeBackendServiceLocalityLbPoliciesPolicy): any;
export declare class DataGoogleComputeBackendServiceLocalityLbPoliciesPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceLocalityLbPoliciesPolicy | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceLocalityLbPoliciesPolicy | undefined);
    get name(): string;
}
export declare class DataGoogleComputeBackendServiceLocalityLbPoliciesPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceLocalityLbPoliciesPolicyOutputReference;
}
export interface DataGoogleComputeBackendServiceLocalityLbPolicies {
}
export declare function dataGoogleComputeBackendServiceLocalityLbPoliciesToTerraform(struct?: DataGoogleComputeBackendServiceLocalityLbPolicies): any;
export declare function dataGoogleComputeBackendServiceLocalityLbPoliciesToHclTerraform(struct?: DataGoogleComputeBackendServiceLocalityLbPolicies): any;
export declare class DataGoogleComputeBackendServiceLocalityLbPoliciesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceLocalityLbPolicies | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceLocalityLbPolicies | undefined);
    private _customPolicy;
    get customPolicy(): DataGoogleComputeBackendServiceLocalityLbPoliciesCustomPolicyList;
    private _policy;
    get policy(): DataGoogleComputeBackendServiceLocalityLbPoliciesPolicyList;
}
export declare class DataGoogleComputeBackendServiceLocalityLbPoliciesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceLocalityLbPoliciesOutputReference;
}
export interface DataGoogleComputeBackendServiceLogConfigRequestHeaders {
}
export declare function dataGoogleComputeBackendServiceLogConfigRequestHeadersToTerraform(struct?: DataGoogleComputeBackendServiceLogConfigRequestHeaders): any;
export declare function dataGoogleComputeBackendServiceLogConfigRequestHeadersToHclTerraform(struct?: DataGoogleComputeBackendServiceLogConfigRequestHeaders): any;
export declare class DataGoogleComputeBackendServiceLogConfigRequestHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceLogConfigRequestHeaders | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceLogConfigRequestHeaders | undefined);
    get headerName(): string;
}
export declare class DataGoogleComputeBackendServiceLogConfigRequestHeadersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceLogConfigRequestHeadersOutputReference;
}
export interface DataGoogleComputeBackendServiceLogConfigResponseHeaders {
}
export declare function dataGoogleComputeBackendServiceLogConfigResponseHeadersToTerraform(struct?: DataGoogleComputeBackendServiceLogConfigResponseHeaders): any;
export declare function dataGoogleComputeBackendServiceLogConfigResponseHeadersToHclTerraform(struct?: DataGoogleComputeBackendServiceLogConfigResponseHeaders): any;
export declare class DataGoogleComputeBackendServiceLogConfigResponseHeadersOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceLogConfigResponseHeaders | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceLogConfigResponseHeaders | undefined);
    get headerName(): string;
}
export declare class DataGoogleComputeBackendServiceLogConfigResponseHeadersList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceLogConfigResponseHeadersOutputReference;
}
export interface DataGoogleComputeBackendServiceLogConfig {
}
export declare function dataGoogleComputeBackendServiceLogConfigToTerraform(struct?: DataGoogleComputeBackendServiceLogConfig): any;
export declare function dataGoogleComputeBackendServiceLogConfigToHclTerraform(struct?: DataGoogleComputeBackendServiceLogConfig): any;
export declare class DataGoogleComputeBackendServiceLogConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceLogConfig | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceLogConfig | undefined);
    get enable(): cdktn.IResolvable;
    get optionalFields(): string[];
    get optionalMode(): string;
    private _requestHeaders;
    get requestHeaders(): DataGoogleComputeBackendServiceLogConfigRequestHeadersList;
    private _responseHeaders;
    get responseHeaders(): DataGoogleComputeBackendServiceLogConfigResponseHeadersList;
    get sampleRate(): number;
}
export declare class DataGoogleComputeBackendServiceLogConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceLogConfigOutputReference;
}
export interface DataGoogleComputeBackendServiceMaxStreamDuration {
}
export declare function dataGoogleComputeBackendServiceMaxStreamDurationToTerraform(struct?: DataGoogleComputeBackendServiceMaxStreamDuration): any;
export declare function dataGoogleComputeBackendServiceMaxStreamDurationToHclTerraform(struct?: DataGoogleComputeBackendServiceMaxStreamDuration): any;
export declare class DataGoogleComputeBackendServiceMaxStreamDurationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceMaxStreamDuration | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceMaxStreamDuration | undefined);
    get nanos(): number;
    get seconds(): string;
}
export declare class DataGoogleComputeBackendServiceMaxStreamDurationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceMaxStreamDurationOutputReference;
}
export interface DataGoogleComputeBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinity {
}
export declare function dataGoogleComputeBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinityToTerraform(struct?: DataGoogleComputeBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinity): any;
export declare function dataGoogleComputeBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinityToHclTerraform(struct?: DataGoogleComputeBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinity): any;
export declare class DataGoogleComputeBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinityOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinity | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinity | undefined);
    get spillover(): string;
    get spilloverRatio(): number;
}
export declare class DataGoogleComputeBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinityList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinityOutputReference;
}
export interface DataGoogleComputeBackendServiceNetworkPassThroughLbTrafficPolicy {
}
export declare function dataGoogleComputeBackendServiceNetworkPassThroughLbTrafficPolicyToTerraform(struct?: DataGoogleComputeBackendServiceNetworkPassThroughLbTrafficPolicy): any;
export declare function dataGoogleComputeBackendServiceNetworkPassThroughLbTrafficPolicyToHclTerraform(struct?: DataGoogleComputeBackendServiceNetworkPassThroughLbTrafficPolicy): any;
export declare class DataGoogleComputeBackendServiceNetworkPassThroughLbTrafficPolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceNetworkPassThroughLbTrafficPolicy | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceNetworkPassThroughLbTrafficPolicy | undefined);
    private _zonalAffinity;
    get zonalAffinity(): DataGoogleComputeBackendServiceNetworkPassThroughLbTrafficPolicyZonalAffinityList;
}
export declare class DataGoogleComputeBackendServiceNetworkPassThroughLbTrafficPolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceNetworkPassThroughLbTrafficPolicyOutputReference;
}
export interface DataGoogleComputeBackendServiceOutlierDetectionBaseEjectionTime {
}
export declare function dataGoogleComputeBackendServiceOutlierDetectionBaseEjectionTimeToTerraform(struct?: DataGoogleComputeBackendServiceOutlierDetectionBaseEjectionTime): any;
export declare function dataGoogleComputeBackendServiceOutlierDetectionBaseEjectionTimeToHclTerraform(struct?: DataGoogleComputeBackendServiceOutlierDetectionBaseEjectionTime): any;
export declare class DataGoogleComputeBackendServiceOutlierDetectionBaseEjectionTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceOutlierDetectionBaseEjectionTime | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceOutlierDetectionBaseEjectionTime | undefined);
    get nanos(): number;
    get seconds(): number;
}
export declare class DataGoogleComputeBackendServiceOutlierDetectionBaseEjectionTimeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceOutlierDetectionBaseEjectionTimeOutputReference;
}
export interface DataGoogleComputeBackendServiceOutlierDetectionInterval {
}
export declare function dataGoogleComputeBackendServiceOutlierDetectionIntervalToTerraform(struct?: DataGoogleComputeBackendServiceOutlierDetectionInterval): any;
export declare function dataGoogleComputeBackendServiceOutlierDetectionIntervalToHclTerraform(struct?: DataGoogleComputeBackendServiceOutlierDetectionInterval): any;
export declare class DataGoogleComputeBackendServiceOutlierDetectionIntervalOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceOutlierDetectionInterval | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceOutlierDetectionInterval | undefined);
    get nanos(): number;
    get seconds(): number;
}
export declare class DataGoogleComputeBackendServiceOutlierDetectionIntervalList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceOutlierDetectionIntervalOutputReference;
}
export interface DataGoogleComputeBackendServiceOutlierDetection {
}
export declare function dataGoogleComputeBackendServiceOutlierDetectionToTerraform(struct?: DataGoogleComputeBackendServiceOutlierDetection): any;
export declare function dataGoogleComputeBackendServiceOutlierDetectionToHclTerraform(struct?: DataGoogleComputeBackendServiceOutlierDetection): any;
export declare class DataGoogleComputeBackendServiceOutlierDetectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceOutlierDetection | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceOutlierDetection | undefined);
    private _baseEjectionTime;
    get baseEjectionTime(): DataGoogleComputeBackendServiceOutlierDetectionBaseEjectionTimeList;
    get consecutiveErrors(): number;
    get consecutiveGatewayFailure(): number;
    get enforcingConsecutiveErrors(): number;
    get enforcingConsecutiveGatewayFailure(): number;
    get enforcingSuccessRate(): number;
    private _interval;
    get interval(): DataGoogleComputeBackendServiceOutlierDetectionIntervalList;
    get maxEjectionPercent(): number;
    get successRateMinimumHosts(): number;
    get successRateRequestVolume(): number;
    get successRateStdevFactor(): number;
}
export declare class DataGoogleComputeBackendServiceOutlierDetectionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceOutlierDetectionOutputReference;
}
export interface DataGoogleComputeBackendServiceParams {
}
export declare function dataGoogleComputeBackendServiceParamsToTerraform(struct?: DataGoogleComputeBackendServiceParams): any;
export declare function dataGoogleComputeBackendServiceParamsToHclTerraform(struct?: DataGoogleComputeBackendServiceParams): any;
export declare class DataGoogleComputeBackendServiceParamsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceParams | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceParams | undefined);
    private _resourceManagerTags;
    get resourceManagerTags(): cdktn.StringMap;
}
export declare class DataGoogleComputeBackendServiceParamsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceParamsOutputReference;
}
export interface DataGoogleComputeBackendServiceSecuritySettingsAwsV4Authentication {
}
export declare function dataGoogleComputeBackendServiceSecuritySettingsAwsV4AuthenticationToTerraform(struct?: DataGoogleComputeBackendServiceSecuritySettingsAwsV4Authentication): any;
export declare function dataGoogleComputeBackendServiceSecuritySettingsAwsV4AuthenticationToHclTerraform(struct?: DataGoogleComputeBackendServiceSecuritySettingsAwsV4Authentication): any;
export declare class DataGoogleComputeBackendServiceSecuritySettingsAwsV4AuthenticationOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceSecuritySettingsAwsV4Authentication | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceSecuritySettingsAwsV4Authentication | undefined);
    get accessKey(): string;
    get accessKeyId(): string;
    get accessKeyVersion(): string;
    get originRegion(): string;
}
export declare class DataGoogleComputeBackendServiceSecuritySettingsAwsV4AuthenticationList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceSecuritySettingsAwsV4AuthenticationOutputReference;
}
export interface DataGoogleComputeBackendServiceSecuritySettings {
}
export declare function dataGoogleComputeBackendServiceSecuritySettingsToTerraform(struct?: DataGoogleComputeBackendServiceSecuritySettings): any;
export declare function dataGoogleComputeBackendServiceSecuritySettingsToHclTerraform(struct?: DataGoogleComputeBackendServiceSecuritySettings): any;
export declare class DataGoogleComputeBackendServiceSecuritySettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceSecuritySettings | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceSecuritySettings | undefined);
    private _awsV4Authentication;
    get awsV4Authentication(): DataGoogleComputeBackendServiceSecuritySettingsAwsV4AuthenticationList;
    get clientTlsPolicy(): string;
    get subjectAltNames(): string[];
}
export declare class DataGoogleComputeBackendServiceSecuritySettingsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceSecuritySettingsOutputReference;
}
export interface DataGoogleComputeBackendServiceStrongSessionAffinityCookieTtl {
}
export declare function dataGoogleComputeBackendServiceStrongSessionAffinityCookieTtlToTerraform(struct?: DataGoogleComputeBackendServiceStrongSessionAffinityCookieTtl): any;
export declare function dataGoogleComputeBackendServiceStrongSessionAffinityCookieTtlToHclTerraform(struct?: DataGoogleComputeBackendServiceStrongSessionAffinityCookieTtl): any;
export declare class DataGoogleComputeBackendServiceStrongSessionAffinityCookieTtlOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceStrongSessionAffinityCookieTtl | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceStrongSessionAffinityCookieTtl | undefined);
    get nanos(): number;
    get seconds(): number;
}
export declare class DataGoogleComputeBackendServiceStrongSessionAffinityCookieTtlList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceStrongSessionAffinityCookieTtlOutputReference;
}
export interface DataGoogleComputeBackendServiceStrongSessionAffinityCookie {
}
export declare function dataGoogleComputeBackendServiceStrongSessionAffinityCookieToTerraform(struct?: DataGoogleComputeBackendServiceStrongSessionAffinityCookie): any;
export declare function dataGoogleComputeBackendServiceStrongSessionAffinityCookieToHclTerraform(struct?: DataGoogleComputeBackendServiceStrongSessionAffinityCookie): any;
export declare class DataGoogleComputeBackendServiceStrongSessionAffinityCookieOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceStrongSessionAffinityCookie | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceStrongSessionAffinityCookie | undefined);
    get name(): string;
    get path(): string;
    private _ttl;
    get ttl(): DataGoogleComputeBackendServiceStrongSessionAffinityCookieTtlList;
}
export declare class DataGoogleComputeBackendServiceStrongSessionAffinityCookieList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceStrongSessionAffinityCookieOutputReference;
}
export interface DataGoogleComputeBackendServiceTlsSettingsSubjectAltNames {
}
export declare function dataGoogleComputeBackendServiceTlsSettingsSubjectAltNamesToTerraform(struct?: DataGoogleComputeBackendServiceTlsSettingsSubjectAltNames): any;
export declare function dataGoogleComputeBackendServiceTlsSettingsSubjectAltNamesToHclTerraform(struct?: DataGoogleComputeBackendServiceTlsSettingsSubjectAltNames): any;
export declare class DataGoogleComputeBackendServiceTlsSettingsSubjectAltNamesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceTlsSettingsSubjectAltNames | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceTlsSettingsSubjectAltNames | undefined);
    get dnsName(): string;
    get uniformResourceIdentifier(): string;
}
export declare class DataGoogleComputeBackendServiceTlsSettingsSubjectAltNamesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceTlsSettingsSubjectAltNamesOutputReference;
}
export interface DataGoogleComputeBackendServiceTlsSettings {
}
export declare function dataGoogleComputeBackendServiceTlsSettingsToTerraform(struct?: DataGoogleComputeBackendServiceTlsSettings): any;
export declare function dataGoogleComputeBackendServiceTlsSettingsToHclTerraform(struct?: DataGoogleComputeBackendServiceTlsSettings): any;
export declare class DataGoogleComputeBackendServiceTlsSettingsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleComputeBackendServiceTlsSettings | undefined;
    set internalValue(value: DataGoogleComputeBackendServiceTlsSettings | undefined);
    get authenticationConfig(): string;
    get identity(): string;
    get sni(): string;
    private _subjectAltNames;
    get subjectAltNames(): DataGoogleComputeBackendServiceTlsSettingsSubjectAltNamesList;
}
export declare class DataGoogleComputeBackendServiceTlsSettingsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleComputeBackendServiceTlsSettingsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_backend_service google_compute_backend_service}
*/
export declare class DataGoogleComputeBackendService extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_compute_backend_service";
    /**
    * Generates CDKTN code for importing a DataGoogleComputeBackendService resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleComputeBackendService to import
    * @param importFromId The id of the existing DataGoogleComputeBackendService that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_backend_service#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleComputeBackendService to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_compute_backend_service google_compute_backend_service} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleComputeBackendServiceConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleComputeBackendServiceConfig);
    get affinityCookieTtlSec(): number;
    private _backend;
    get backend(): DataGoogleComputeBackendServiceBackendList;
    private _cdnPolicy;
    get cdnPolicy(): DataGoogleComputeBackendServiceCdnPolicyList;
    private _circuitBreakers;
    get circuitBreakers(): DataGoogleComputeBackendServiceCircuitBreakersList;
    get compressionMode(): string;
    get connectionDrainingTimeoutSec(): number;
    private _consistentHash;
    get consistentHash(): DataGoogleComputeBackendServiceConsistentHashList;
    get creationTimestamp(): string;
    private _customMetrics;
    get customMetrics(): DataGoogleComputeBackendServiceCustomMetricsList;
    get customRequestHeaders(): string[];
    get customResponseHeaders(): string[];
    get deletionPolicy(): string;
    get description(): string;
    private _dynamicForwarding;
    get dynamicForwarding(): DataGoogleComputeBackendServiceDynamicForwardingList;
    get edgeSecurityPolicy(): string;
    get enableCdn(): cdktn.IResolvable;
    get externalManagedMigrationState(): string;
    get externalManagedMigrationTestingPercentage(): number;
    get fingerprint(): string;
    get generatedId(): number;
    get healthChecks(): string[];
    private _iap;
    get iap(): DataGoogleComputeBackendServiceIapList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get ipAddressSelectionPolicy(): string;
    get loadBalancingScheme(): string;
    private _localityLbPolicies;
    get localityLbPolicies(): DataGoogleComputeBackendServiceLocalityLbPoliciesList;
    get localityLbPolicy(): string;
    private _logConfig;
    get logConfig(): DataGoogleComputeBackendServiceLogConfigList;
    private _maxStreamDuration;
    get maxStreamDuration(): DataGoogleComputeBackendServiceMaxStreamDurationList;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _networkPassThroughLbTrafficPolicy;
    get networkPassThroughLbTrafficPolicy(): DataGoogleComputeBackendServiceNetworkPassThroughLbTrafficPolicyList;
    private _outlierDetection;
    get outlierDetection(): DataGoogleComputeBackendServiceOutlierDetectionList;
    private _params;
    get params(): DataGoogleComputeBackendServiceParamsList;
    get portName(): string;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    get protocol(): string;
    get securityPolicy(): string;
    private _securitySettings;
    get securitySettings(): DataGoogleComputeBackendServiceSecuritySettingsList;
    get selfLink(): string;
    get serviceLbPolicy(): string;
    get sessionAffinity(): string;
    private _strongSessionAffinityCookie;
    get strongSessionAffinityCookie(): DataGoogleComputeBackendServiceStrongSessionAffinityCookieList;
    get timeoutSec(): number;
    private _tlsSettings;
    get tlsSettings(): DataGoogleComputeBackendServiceTlsSettingsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
