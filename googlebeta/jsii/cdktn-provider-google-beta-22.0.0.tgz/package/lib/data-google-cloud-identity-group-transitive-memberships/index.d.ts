/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleCloudIdentityGroupTransitiveMembershipsConfig extends cdktn.TerraformMetaArguments {
    /**
    * The name of the Group to get memberships from.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_identity_group_transitive_memberships#group DataGoogleCloudIdentityGroupTransitiveMemberships#group}
    */
    readonly group: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_identity_group_transitive_memberships#id DataGoogleCloudIdentityGroupTransitiveMemberships#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
}
export interface DataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsPreferredMemberKey {
}
export declare function dataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsPreferredMemberKeyToTerraform(struct?: DataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsPreferredMemberKey): any;
export declare function dataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsPreferredMemberKeyToHclTerraform(struct?: DataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsPreferredMemberKey): any;
export declare class DataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsPreferredMemberKeyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsPreferredMemberKey | undefined;
    set internalValue(value: DataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsPreferredMemberKey | undefined);
    get id(): string;
    get namespace(): string;
}
export declare class DataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsPreferredMemberKeyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsPreferredMemberKeyOutputReference;
}
export interface DataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsRoles {
}
export declare function dataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsRolesToTerraform(struct?: DataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsRoles): any;
export declare function dataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsRolesToHclTerraform(struct?: DataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsRoles): any;
export declare class DataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsRolesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsRoles | undefined;
    set internalValue(value: DataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsRoles | undefined);
    get role(): string;
}
export declare class DataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsRolesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsRolesOutputReference;
}
export interface DataGoogleCloudIdentityGroupTransitiveMembershipsMemberships {
}
export declare function dataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsToTerraform(struct?: DataGoogleCloudIdentityGroupTransitiveMembershipsMemberships): any;
export declare function dataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsToHclTerraform(struct?: DataGoogleCloudIdentityGroupTransitiveMembershipsMemberships): any;
export declare class DataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleCloudIdentityGroupTransitiveMembershipsMemberships | undefined;
    set internalValue(value: DataGoogleCloudIdentityGroupTransitiveMembershipsMemberships | undefined);
    get member(): string;
    private _preferredMemberKey;
    get preferredMemberKey(): DataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsPreferredMemberKeyList;
    get relationType(): string;
    private _roles;
    get roles(): DataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsRolesList;
}
export declare class DataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_identity_group_transitive_memberships google_cloud_identity_group_transitive_memberships}
*/
export declare class DataGoogleCloudIdentityGroupTransitiveMemberships extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_cloud_identity_group_transitive_memberships";
    /**
    * Generates CDKTN code for importing a DataGoogleCloudIdentityGroupTransitiveMemberships resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleCloudIdentityGroupTransitiveMemberships to import
    * @param importFromId The id of the existing DataGoogleCloudIdentityGroupTransitiveMemberships that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_identity_group_transitive_memberships#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleCloudIdentityGroupTransitiveMemberships to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_cloud_identity_group_transitive_memberships google_cloud_identity_group_transitive_memberships} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleCloudIdentityGroupTransitiveMembershipsConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleCloudIdentityGroupTransitiveMembershipsConfig);
    private _group?;
    get group(): string;
    set group(value: string);
    get groupInput(): string | undefined;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _memberships;
    get memberships(): DataGoogleCloudIdentityGroupTransitiveMembershipsMembershipsList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
