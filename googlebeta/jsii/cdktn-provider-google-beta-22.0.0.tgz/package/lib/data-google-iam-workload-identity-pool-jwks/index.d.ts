/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleIamWorkloadIdentityPoolJwksConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_iam_workload_identity_pool_jwks#id DataGoogleIamWorkloadIdentityPoolJwks#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * The JWKS URI to retrieve the public keys from (e.g. from google_iam_workload_identity_pool_openid_config.jwks_uri).
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_iam_workload_identity_pool_jwks#resource_name DataGoogleIamWorkloadIdentityPoolJwks#resource_name}
    */
    readonly resourceName: string;
    /**
    * timeouts block
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_iam_workload_identity_pool_jwks#timeouts DataGoogleIamWorkloadIdentityPoolJwks#timeouts}
    */
    readonly timeouts?: DataGoogleIamWorkloadIdentityPoolJwksTimeouts;
}
export interface DataGoogleIamWorkloadIdentityPoolJwksKeys {
}
export declare function dataGoogleIamWorkloadIdentityPoolJwksKeysToTerraform(struct?: DataGoogleIamWorkloadIdentityPoolJwksKeys): any;
export declare function dataGoogleIamWorkloadIdentityPoolJwksKeysToHclTerraform(struct?: DataGoogleIamWorkloadIdentityPoolJwksKeys): any;
export declare class DataGoogleIamWorkloadIdentityPoolJwksKeysOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleIamWorkloadIdentityPoolJwksKeys | undefined;
    set internalValue(value: DataGoogleIamWorkloadIdentityPoolJwksKeys | undefined);
    get alg(): string;
    get e(): string;
    get kid(): string;
    get kty(): string;
    get n(): string;
    get use(): string;
}
export declare class DataGoogleIamWorkloadIdentityPoolJwksKeysList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleIamWorkloadIdentityPoolJwksKeysOutputReference;
}
export interface DataGoogleIamWorkloadIdentityPoolJwksTimeouts {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_iam_workload_identity_pool_jwks#read DataGoogleIamWorkloadIdentityPoolJwks#read}
    */
    readonly read?: string;
}
export declare function dataGoogleIamWorkloadIdentityPoolJwksTimeoutsToTerraform(struct?: DataGoogleIamWorkloadIdentityPoolJwksTimeouts | cdktn.IResolvable): any;
export declare function dataGoogleIamWorkloadIdentityPoolJwksTimeoutsToHclTerraform(struct?: DataGoogleIamWorkloadIdentityPoolJwksTimeouts | cdktn.IResolvable): any;
export declare class DataGoogleIamWorkloadIdentityPoolJwksTimeoutsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    private resolvableValue?;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string);
    get internalValue(): DataGoogleIamWorkloadIdentityPoolJwksTimeouts | cdktn.IResolvable | undefined;
    set internalValue(value: DataGoogleIamWorkloadIdentityPoolJwksTimeouts | cdktn.IResolvable | undefined);
    private _read?;
    get read(): string;
    set read(value: string);
    resetRead(): void;
    get readInput(): string | undefined;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_iam_workload_identity_pool_jwks google_iam_workload_identity_pool_jwks}
*/
export declare class DataGoogleIamWorkloadIdentityPoolJwks extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_iam_workload_identity_pool_jwks";
    /**
    * Generates CDKTN code for importing a DataGoogleIamWorkloadIdentityPoolJwks resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleIamWorkloadIdentityPoolJwks to import
    * @param importFromId The id of the existing DataGoogleIamWorkloadIdentityPoolJwks that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_iam_workload_identity_pool_jwks#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleIamWorkloadIdentityPoolJwks to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_iam_workload_identity_pool_jwks google_iam_workload_identity_pool_jwks} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleIamWorkloadIdentityPoolJwksConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleIamWorkloadIdentityPoolJwksConfig);
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    get jwksJson(): string;
    private _keys;
    get keys(): DataGoogleIamWorkloadIdentityPoolJwksKeysList;
    private _resourceName?;
    get resourceName(): string;
    set resourceName(value: string);
    get resourceNameInput(): string | undefined;
    private _timeouts;
    get timeouts(): DataGoogleIamWorkloadIdentityPoolJwksTimeoutsOutputReference;
    putTimeouts(value: DataGoogleIamWorkloadIdentityPoolJwksTimeouts): void;
    resetTimeouts(): void;
    get timeoutsInput(): cdktn.IResolvable | DataGoogleIamWorkloadIdentityPoolJwksTimeouts | undefined;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
