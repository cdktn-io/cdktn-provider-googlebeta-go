/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleStorageControlProjectIntelligenceConfigConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_control_project_intelligence_config#id DataGoogleStorageControlProjectIntelligenceConfig#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Identifier of the GCP project. For GCP project, this field can be project name or project number.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_control_project_intelligence_config#name DataGoogleStorageControlProjectIntelligenceConfig#name}
    */
    readonly name: string;
}
export interface DataGoogleStorageControlProjectIntelligenceConfigEffectiveIntelligenceConfig {
}
export declare function dataGoogleStorageControlProjectIntelligenceConfigEffectiveIntelligenceConfigToTerraform(struct?: DataGoogleStorageControlProjectIntelligenceConfigEffectiveIntelligenceConfig): any;
export declare function dataGoogleStorageControlProjectIntelligenceConfigEffectiveIntelligenceConfigToHclTerraform(struct?: DataGoogleStorageControlProjectIntelligenceConfigEffectiveIntelligenceConfig): any;
export declare class DataGoogleStorageControlProjectIntelligenceConfigEffectiveIntelligenceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlProjectIntelligenceConfigEffectiveIntelligenceConfig | undefined;
    set internalValue(value: DataGoogleStorageControlProjectIntelligenceConfigEffectiveIntelligenceConfig | undefined);
    get effectiveEdition(): string;
    get intelligenceConfig(): string;
}
export declare class DataGoogleStorageControlProjectIntelligenceConfigEffectiveIntelligenceConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlProjectIntelligenceConfigEffectiveIntelligenceConfigOutputReference;
}
export interface DataGoogleStorageControlProjectIntelligenceConfigFilterExcludedCloudStorageBuckets {
}
export declare function dataGoogleStorageControlProjectIntelligenceConfigFilterExcludedCloudStorageBucketsToTerraform(struct?: DataGoogleStorageControlProjectIntelligenceConfigFilterExcludedCloudStorageBuckets): any;
export declare function dataGoogleStorageControlProjectIntelligenceConfigFilterExcludedCloudStorageBucketsToHclTerraform(struct?: DataGoogleStorageControlProjectIntelligenceConfigFilterExcludedCloudStorageBuckets): any;
export declare class DataGoogleStorageControlProjectIntelligenceConfigFilterExcludedCloudStorageBucketsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlProjectIntelligenceConfigFilterExcludedCloudStorageBuckets | undefined;
    set internalValue(value: DataGoogleStorageControlProjectIntelligenceConfigFilterExcludedCloudStorageBuckets | undefined);
    get bucketIdRegexes(): string[];
}
export declare class DataGoogleStorageControlProjectIntelligenceConfigFilterExcludedCloudStorageBucketsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlProjectIntelligenceConfigFilterExcludedCloudStorageBucketsOutputReference;
}
export interface DataGoogleStorageControlProjectIntelligenceConfigFilterExcludedCloudStorageLocations {
}
export declare function dataGoogleStorageControlProjectIntelligenceConfigFilterExcludedCloudStorageLocationsToTerraform(struct?: DataGoogleStorageControlProjectIntelligenceConfigFilterExcludedCloudStorageLocations): any;
export declare function dataGoogleStorageControlProjectIntelligenceConfigFilterExcludedCloudStorageLocationsToHclTerraform(struct?: DataGoogleStorageControlProjectIntelligenceConfigFilterExcludedCloudStorageLocations): any;
export declare class DataGoogleStorageControlProjectIntelligenceConfigFilterExcludedCloudStorageLocationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlProjectIntelligenceConfigFilterExcludedCloudStorageLocations | undefined;
    set internalValue(value: DataGoogleStorageControlProjectIntelligenceConfigFilterExcludedCloudStorageLocations | undefined);
    get locations(): string[];
}
export declare class DataGoogleStorageControlProjectIntelligenceConfigFilterExcludedCloudStorageLocationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlProjectIntelligenceConfigFilterExcludedCloudStorageLocationsOutputReference;
}
export interface DataGoogleStorageControlProjectIntelligenceConfigFilterIncludedCloudStorageBuckets {
}
export declare function dataGoogleStorageControlProjectIntelligenceConfigFilterIncludedCloudStorageBucketsToTerraform(struct?: DataGoogleStorageControlProjectIntelligenceConfigFilterIncludedCloudStorageBuckets): any;
export declare function dataGoogleStorageControlProjectIntelligenceConfigFilterIncludedCloudStorageBucketsToHclTerraform(struct?: DataGoogleStorageControlProjectIntelligenceConfigFilterIncludedCloudStorageBuckets): any;
export declare class DataGoogleStorageControlProjectIntelligenceConfigFilterIncludedCloudStorageBucketsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlProjectIntelligenceConfigFilterIncludedCloudStorageBuckets | undefined;
    set internalValue(value: DataGoogleStorageControlProjectIntelligenceConfigFilterIncludedCloudStorageBuckets | undefined);
    get bucketIdRegexes(): string[];
}
export declare class DataGoogleStorageControlProjectIntelligenceConfigFilterIncludedCloudStorageBucketsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlProjectIntelligenceConfigFilterIncludedCloudStorageBucketsOutputReference;
}
export interface DataGoogleStorageControlProjectIntelligenceConfigFilterIncludedCloudStorageLocations {
}
export declare function dataGoogleStorageControlProjectIntelligenceConfigFilterIncludedCloudStorageLocationsToTerraform(struct?: DataGoogleStorageControlProjectIntelligenceConfigFilterIncludedCloudStorageLocations): any;
export declare function dataGoogleStorageControlProjectIntelligenceConfigFilterIncludedCloudStorageLocationsToHclTerraform(struct?: DataGoogleStorageControlProjectIntelligenceConfigFilterIncludedCloudStorageLocations): any;
export declare class DataGoogleStorageControlProjectIntelligenceConfigFilterIncludedCloudStorageLocationsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlProjectIntelligenceConfigFilterIncludedCloudStorageLocations | undefined;
    set internalValue(value: DataGoogleStorageControlProjectIntelligenceConfigFilterIncludedCloudStorageLocations | undefined);
    get locations(): string[];
}
export declare class DataGoogleStorageControlProjectIntelligenceConfigFilterIncludedCloudStorageLocationsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlProjectIntelligenceConfigFilterIncludedCloudStorageLocationsOutputReference;
}
export interface DataGoogleStorageControlProjectIntelligenceConfigFilter {
}
export declare function dataGoogleStorageControlProjectIntelligenceConfigFilterToTerraform(struct?: DataGoogleStorageControlProjectIntelligenceConfigFilter): any;
export declare function dataGoogleStorageControlProjectIntelligenceConfigFilterToHclTerraform(struct?: DataGoogleStorageControlProjectIntelligenceConfigFilter): any;
export declare class DataGoogleStorageControlProjectIntelligenceConfigFilterOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlProjectIntelligenceConfigFilter | undefined;
    set internalValue(value: DataGoogleStorageControlProjectIntelligenceConfigFilter | undefined);
    private _excludedCloudStorageBuckets;
    get excludedCloudStorageBuckets(): DataGoogleStorageControlProjectIntelligenceConfigFilterExcludedCloudStorageBucketsList;
    private _excludedCloudStorageLocations;
    get excludedCloudStorageLocations(): DataGoogleStorageControlProjectIntelligenceConfigFilterExcludedCloudStorageLocationsList;
    private _includedCloudStorageBuckets;
    get includedCloudStorageBuckets(): DataGoogleStorageControlProjectIntelligenceConfigFilterIncludedCloudStorageBucketsList;
    private _includedCloudStorageLocations;
    get includedCloudStorageLocations(): DataGoogleStorageControlProjectIntelligenceConfigFilterIncludedCloudStorageLocationsList;
}
export declare class DataGoogleStorageControlProjectIntelligenceConfigFilterList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlProjectIntelligenceConfigFilterOutputReference;
}
export interface DataGoogleStorageControlProjectIntelligenceConfigTrialConfig {
}
export declare function dataGoogleStorageControlProjectIntelligenceConfigTrialConfigToTerraform(struct?: DataGoogleStorageControlProjectIntelligenceConfigTrialConfig): any;
export declare function dataGoogleStorageControlProjectIntelligenceConfigTrialConfigToHclTerraform(struct?: DataGoogleStorageControlProjectIntelligenceConfigTrialConfig): any;
export declare class DataGoogleStorageControlProjectIntelligenceConfigTrialConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleStorageControlProjectIntelligenceConfigTrialConfig | undefined;
    set internalValue(value: DataGoogleStorageControlProjectIntelligenceConfigTrialConfig | undefined);
    get expireTime(): string;
}
export declare class DataGoogleStorageControlProjectIntelligenceConfigTrialConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleStorageControlProjectIntelligenceConfigTrialConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_control_project_intelligence_config google_storage_control_project_intelligence_config}
*/
export declare class DataGoogleStorageControlProjectIntelligenceConfig extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_storage_control_project_intelligence_config";
    /**
    * Generates CDKTN code for importing a DataGoogleStorageControlProjectIntelligenceConfig resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleStorageControlProjectIntelligenceConfig to import
    * @param importFromId The id of the existing DataGoogleStorageControlProjectIntelligenceConfig that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_control_project_intelligence_config#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleStorageControlProjectIntelligenceConfig to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_storage_control_project_intelligence_config google_storage_control_project_intelligence_config} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleStorageControlProjectIntelligenceConfigConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleStorageControlProjectIntelligenceConfigConfig);
    get editionConfig(): string;
    private _effectiveIntelligenceConfig;
    get effectiveIntelligenceConfig(): DataGoogleStorageControlProjectIntelligenceConfigEffectiveIntelligenceConfigList;
    private _filter;
    get filter(): DataGoogleStorageControlProjectIntelligenceConfigFilterList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _name?;
    get name(): string;
    set name(value: string);
    get nameInput(): string | undefined;
    private _trialConfig;
    get trialConfig(): DataGoogleStorageControlProjectIntelligenceConfigTrialConfigList;
    get updateTime(): string;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
