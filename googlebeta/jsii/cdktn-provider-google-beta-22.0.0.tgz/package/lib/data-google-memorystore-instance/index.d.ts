/**
 * Copyright IBM Corp. 2021, 2026
 * SPDX-License-Identifier: MPL-2.0
 */
import { Construct } from 'constructs';
import * as cdktn from 'cdktn';
export interface DataGoogleMemorystoreInstanceConfig extends cdktn.TerraformMetaArguments {
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_memorystore_instance#id DataGoogleMemorystoreInstance#id}
    *
    * Please be aware that the id field is automatically added to all resources in Terraform providers using a Terraform provider SDK version below 2.
    * If you experience problems setting this value it might not be settable. Please take a look at the provider documentation to ensure it should be settable.
    */
    readonly id?: string;
    /**
    * Required. The ID to use for the instance, which will become the final component of
    * the instance's resource name.
    *
    * This value is subject to the following restrictions:
    *
    * * Must be 4-63 characters in length
    * * Must begin with a letter or digit
    * * Must contain only lowercase letters, digits, and hyphens
    * * Must not end with a hyphen
    * * Must be unique within a location
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_memorystore_instance#instance_id DataGoogleMemorystoreInstance#instance_id}
    */
    readonly instanceId: string;
    /**
    * Resource ID segment making up resource 'name'. It identifies the resource within its parent collection as described in https://google.aip.dev/122. See documentation for resource type 'memorystore.googleapis.com/CertificateAuthority'.
    *
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_memorystore_instance#location DataGoogleMemorystoreInstance#location}
    */
    readonly location?: string;
    /**
    * Docs at Terraform Registry: {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_memorystore_instance#project DataGoogleMemorystoreInstance#project}
    */
    readonly project?: string;
}
export interface DataGoogleMemorystoreInstanceAutomatedBackupConfigFixedFrequencyScheduleStartTime {
}
export declare function dataGoogleMemorystoreInstanceAutomatedBackupConfigFixedFrequencyScheduleStartTimeToTerraform(struct?: DataGoogleMemorystoreInstanceAutomatedBackupConfigFixedFrequencyScheduleStartTime): any;
export declare function dataGoogleMemorystoreInstanceAutomatedBackupConfigFixedFrequencyScheduleStartTimeToHclTerraform(struct?: DataGoogleMemorystoreInstanceAutomatedBackupConfigFixedFrequencyScheduleStartTime): any;
export declare class DataGoogleMemorystoreInstanceAutomatedBackupConfigFixedFrequencyScheduleStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstanceAutomatedBackupConfigFixedFrequencyScheduleStartTime | undefined;
    set internalValue(value: DataGoogleMemorystoreInstanceAutomatedBackupConfigFixedFrequencyScheduleStartTime | undefined);
    get hours(): number;
}
export declare class DataGoogleMemorystoreInstanceAutomatedBackupConfigFixedFrequencyScheduleStartTimeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstanceAutomatedBackupConfigFixedFrequencyScheduleStartTimeOutputReference;
}
export interface DataGoogleMemorystoreInstanceAutomatedBackupConfigFixedFrequencySchedule {
}
export declare function dataGoogleMemorystoreInstanceAutomatedBackupConfigFixedFrequencyScheduleToTerraform(struct?: DataGoogleMemorystoreInstanceAutomatedBackupConfigFixedFrequencySchedule): any;
export declare function dataGoogleMemorystoreInstanceAutomatedBackupConfigFixedFrequencyScheduleToHclTerraform(struct?: DataGoogleMemorystoreInstanceAutomatedBackupConfigFixedFrequencySchedule): any;
export declare class DataGoogleMemorystoreInstanceAutomatedBackupConfigFixedFrequencyScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstanceAutomatedBackupConfigFixedFrequencySchedule | undefined;
    set internalValue(value: DataGoogleMemorystoreInstanceAutomatedBackupConfigFixedFrequencySchedule | undefined);
    private _startTime;
    get startTime(): DataGoogleMemorystoreInstanceAutomatedBackupConfigFixedFrequencyScheduleStartTimeList;
}
export declare class DataGoogleMemorystoreInstanceAutomatedBackupConfigFixedFrequencyScheduleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstanceAutomatedBackupConfigFixedFrequencyScheduleOutputReference;
}
export interface DataGoogleMemorystoreInstanceAutomatedBackupConfig {
}
export declare function dataGoogleMemorystoreInstanceAutomatedBackupConfigToTerraform(struct?: DataGoogleMemorystoreInstanceAutomatedBackupConfig): any;
export declare function dataGoogleMemorystoreInstanceAutomatedBackupConfigToHclTerraform(struct?: DataGoogleMemorystoreInstanceAutomatedBackupConfig): any;
export declare class DataGoogleMemorystoreInstanceAutomatedBackupConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstanceAutomatedBackupConfig | undefined;
    set internalValue(value: DataGoogleMemorystoreInstanceAutomatedBackupConfig | undefined);
    private _fixedFrequencySchedule;
    get fixedFrequencySchedule(): DataGoogleMemorystoreInstanceAutomatedBackupConfigFixedFrequencyScheduleList;
    get retention(): string;
}
export declare class DataGoogleMemorystoreInstanceAutomatedBackupConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstanceAutomatedBackupConfigOutputReference;
}
export interface DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipPrimaryInstance {
}
export declare function dataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipPrimaryInstanceToTerraform(struct?: DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipPrimaryInstance): any;
export declare function dataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipPrimaryInstanceToHclTerraform(struct?: DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipPrimaryInstance): any;
export declare class DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipPrimaryInstanceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipPrimaryInstance | undefined;
    set internalValue(value: DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipPrimaryInstance | undefined);
    get instance(): string;
    get uid(): string;
}
export declare class DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipPrimaryInstanceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipPrimaryInstanceOutputReference;
}
export interface DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipSecondaryInstance {
}
export declare function dataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipSecondaryInstanceToTerraform(struct?: DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipSecondaryInstance): any;
export declare function dataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipSecondaryInstanceToHclTerraform(struct?: DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipSecondaryInstance): any;
export declare class DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipSecondaryInstanceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipSecondaryInstance | undefined;
    set internalValue(value: DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipSecondaryInstance | undefined);
    get instance(): string;
    get uid(): string;
}
export declare class DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipSecondaryInstanceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipSecondaryInstanceOutputReference;
}
export interface DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembership {
}
export declare function dataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipToTerraform(struct?: DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembership): any;
export declare function dataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipToHclTerraform(struct?: DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembership): any;
export declare class DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembership | undefined;
    set internalValue(value: DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembership | undefined);
    private _primaryInstance;
    get primaryInstance(): DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipPrimaryInstanceList;
    private _secondaryInstance;
    get secondaryInstance(): DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipSecondaryInstanceList;
}
export declare class DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipOutputReference;
}
export interface DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigPrimaryInstance {
}
export declare function dataGoogleMemorystoreInstanceCrossInstanceReplicationConfigPrimaryInstanceToTerraform(struct?: DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigPrimaryInstance): any;
export declare function dataGoogleMemorystoreInstanceCrossInstanceReplicationConfigPrimaryInstanceToHclTerraform(struct?: DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigPrimaryInstance): any;
export declare class DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigPrimaryInstanceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigPrimaryInstance | undefined;
    set internalValue(value: DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigPrimaryInstance | undefined);
    get instance(): string;
    get uid(): string;
}
export declare class DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigPrimaryInstanceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigPrimaryInstanceOutputReference;
}
export interface DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigSecondaryInstances {
}
export declare function dataGoogleMemorystoreInstanceCrossInstanceReplicationConfigSecondaryInstancesToTerraform(struct?: DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigSecondaryInstances): any;
export declare function dataGoogleMemorystoreInstanceCrossInstanceReplicationConfigSecondaryInstancesToHclTerraform(struct?: DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigSecondaryInstances): any;
export declare class DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigSecondaryInstancesOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigSecondaryInstances | undefined;
    set internalValue(value: DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigSecondaryInstances | undefined);
    get instance(): string;
    get uid(): string;
}
export declare class DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigSecondaryInstancesList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigSecondaryInstancesOutputReference;
}
export interface DataGoogleMemorystoreInstanceCrossInstanceReplicationConfig {
}
export declare function dataGoogleMemorystoreInstanceCrossInstanceReplicationConfigToTerraform(struct?: DataGoogleMemorystoreInstanceCrossInstanceReplicationConfig): any;
export declare function dataGoogleMemorystoreInstanceCrossInstanceReplicationConfigToHclTerraform(struct?: DataGoogleMemorystoreInstanceCrossInstanceReplicationConfig): any;
export declare class DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstanceCrossInstanceReplicationConfig | undefined;
    set internalValue(value: DataGoogleMemorystoreInstanceCrossInstanceReplicationConfig | undefined);
    get instanceRole(): string;
    private _membership;
    get membership(): DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigMembershipList;
    private _primaryInstance;
    get primaryInstance(): DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigPrimaryInstanceList;
    private _secondaryInstances;
    get secondaryInstances(): DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigSecondaryInstancesList;
    get updateTime(): string;
}
export declare class DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigOutputReference;
}
export interface DataGoogleMemorystoreInstanceDesiredAutoCreatedEndpoints {
}
export declare function dataGoogleMemorystoreInstanceDesiredAutoCreatedEndpointsToTerraform(struct?: DataGoogleMemorystoreInstanceDesiredAutoCreatedEndpoints): any;
export declare function dataGoogleMemorystoreInstanceDesiredAutoCreatedEndpointsToHclTerraform(struct?: DataGoogleMemorystoreInstanceDesiredAutoCreatedEndpoints): any;
export declare class DataGoogleMemorystoreInstanceDesiredAutoCreatedEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstanceDesiredAutoCreatedEndpoints | undefined;
    set internalValue(value: DataGoogleMemorystoreInstanceDesiredAutoCreatedEndpoints | undefined);
    get network(): string;
    get projectId(): string;
}
export declare class DataGoogleMemorystoreInstanceDesiredAutoCreatedEndpointsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstanceDesiredAutoCreatedEndpointsOutputReference;
}
export interface DataGoogleMemorystoreInstanceDesiredPscAutoConnections {
}
export declare function dataGoogleMemorystoreInstanceDesiredPscAutoConnectionsToTerraform(struct?: DataGoogleMemorystoreInstanceDesiredPscAutoConnections): any;
export declare function dataGoogleMemorystoreInstanceDesiredPscAutoConnectionsToHclTerraform(struct?: DataGoogleMemorystoreInstanceDesiredPscAutoConnections): any;
export declare class DataGoogleMemorystoreInstanceDesiredPscAutoConnectionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstanceDesiredPscAutoConnections | undefined;
    set internalValue(value: DataGoogleMemorystoreInstanceDesiredPscAutoConnections | undefined);
    get network(): string;
    get projectId(): string;
}
export declare class DataGoogleMemorystoreInstanceDesiredPscAutoConnectionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstanceDesiredPscAutoConnectionsOutputReference;
}
export interface DataGoogleMemorystoreInstanceDiscoveryEndpoints {
}
export declare function dataGoogleMemorystoreInstanceDiscoveryEndpointsToTerraform(struct?: DataGoogleMemorystoreInstanceDiscoveryEndpoints): any;
export declare function dataGoogleMemorystoreInstanceDiscoveryEndpointsToHclTerraform(struct?: DataGoogleMemorystoreInstanceDiscoveryEndpoints): any;
export declare class DataGoogleMemorystoreInstanceDiscoveryEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstanceDiscoveryEndpoints | undefined;
    set internalValue(value: DataGoogleMemorystoreInstanceDiscoveryEndpoints | undefined);
    get address(): string;
    get network(): string;
    get port(): number;
}
export declare class DataGoogleMemorystoreInstanceDiscoveryEndpointsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstanceDiscoveryEndpointsOutputReference;
}
export interface DataGoogleMemorystoreInstanceEndpointsConnectionsPscAutoConnection {
}
export declare function dataGoogleMemorystoreInstanceEndpointsConnectionsPscAutoConnectionToTerraform(struct?: DataGoogleMemorystoreInstanceEndpointsConnectionsPscAutoConnection): any;
export declare function dataGoogleMemorystoreInstanceEndpointsConnectionsPscAutoConnectionToHclTerraform(struct?: DataGoogleMemorystoreInstanceEndpointsConnectionsPscAutoConnection): any;
export declare class DataGoogleMemorystoreInstanceEndpointsConnectionsPscAutoConnectionOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstanceEndpointsConnectionsPscAutoConnection | undefined;
    set internalValue(value: DataGoogleMemorystoreInstanceEndpointsConnectionsPscAutoConnection | undefined);
    get connectionType(): string;
    get forwardingRule(): string;
    get ipAddress(): string;
    get network(): string;
    get port(): number;
    get projectId(): string;
    get pscConnectionId(): string;
    get serviceAttachment(): string;
}
export declare class DataGoogleMemorystoreInstanceEndpointsConnectionsPscAutoConnectionList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstanceEndpointsConnectionsPscAutoConnectionOutputReference;
}
export interface DataGoogleMemorystoreInstanceEndpointsConnections {
}
export declare function dataGoogleMemorystoreInstanceEndpointsConnectionsToTerraform(struct?: DataGoogleMemorystoreInstanceEndpointsConnections): any;
export declare function dataGoogleMemorystoreInstanceEndpointsConnectionsToHclTerraform(struct?: DataGoogleMemorystoreInstanceEndpointsConnections): any;
export declare class DataGoogleMemorystoreInstanceEndpointsConnectionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstanceEndpointsConnections | undefined;
    set internalValue(value: DataGoogleMemorystoreInstanceEndpointsConnections | undefined);
    private _pscAutoConnection;
    get pscAutoConnection(): DataGoogleMemorystoreInstanceEndpointsConnectionsPscAutoConnectionList;
}
export declare class DataGoogleMemorystoreInstanceEndpointsConnectionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstanceEndpointsConnectionsOutputReference;
}
export interface DataGoogleMemorystoreInstanceEndpoints {
}
export declare function dataGoogleMemorystoreInstanceEndpointsToTerraform(struct?: DataGoogleMemorystoreInstanceEndpoints): any;
export declare function dataGoogleMemorystoreInstanceEndpointsToHclTerraform(struct?: DataGoogleMemorystoreInstanceEndpoints): any;
export declare class DataGoogleMemorystoreInstanceEndpointsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstanceEndpoints | undefined;
    set internalValue(value: DataGoogleMemorystoreInstanceEndpoints | undefined);
    private _connections;
    get connections(): DataGoogleMemorystoreInstanceEndpointsConnectionsList;
}
export declare class DataGoogleMemorystoreInstanceEndpointsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstanceEndpointsOutputReference;
}
export interface DataGoogleMemorystoreInstanceGcsSource {
}
export declare function dataGoogleMemorystoreInstanceGcsSourceToTerraform(struct?: DataGoogleMemorystoreInstanceGcsSource): any;
export declare function dataGoogleMemorystoreInstanceGcsSourceToHclTerraform(struct?: DataGoogleMemorystoreInstanceGcsSource): any;
export declare class DataGoogleMemorystoreInstanceGcsSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstanceGcsSource | undefined;
    set internalValue(value: DataGoogleMemorystoreInstanceGcsSource | undefined);
    get uris(): string[];
}
export declare class DataGoogleMemorystoreInstanceGcsSourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstanceGcsSourceOutputReference;
}
export interface DataGoogleMemorystoreInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTime {
}
export declare function dataGoogleMemorystoreInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTimeToTerraform(struct?: DataGoogleMemorystoreInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTime): any;
export declare function dataGoogleMemorystoreInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTimeToHclTerraform(struct?: DataGoogleMemorystoreInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTime): any;
export declare class DataGoogleMemorystoreInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTimeOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTime | undefined;
    set internalValue(value: DataGoogleMemorystoreInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTime | undefined);
    get hours(): number;
    get minutes(): number;
    get nanos(): number;
    get seconds(): number;
}
export declare class DataGoogleMemorystoreInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTimeList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTimeOutputReference;
}
export interface DataGoogleMemorystoreInstanceMaintenancePolicyWeeklyMaintenanceWindow {
}
export declare function dataGoogleMemorystoreInstanceMaintenancePolicyWeeklyMaintenanceWindowToTerraform(struct?: DataGoogleMemorystoreInstanceMaintenancePolicyWeeklyMaintenanceWindow): any;
export declare function dataGoogleMemorystoreInstanceMaintenancePolicyWeeklyMaintenanceWindowToHclTerraform(struct?: DataGoogleMemorystoreInstanceMaintenancePolicyWeeklyMaintenanceWindow): any;
export declare class DataGoogleMemorystoreInstanceMaintenancePolicyWeeklyMaintenanceWindowOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstanceMaintenancePolicyWeeklyMaintenanceWindow | undefined;
    set internalValue(value: DataGoogleMemorystoreInstanceMaintenancePolicyWeeklyMaintenanceWindow | undefined);
    get day(): string;
    get duration(): string;
    private _startTime;
    get startTime(): DataGoogleMemorystoreInstanceMaintenancePolicyWeeklyMaintenanceWindowStartTimeList;
}
export declare class DataGoogleMemorystoreInstanceMaintenancePolicyWeeklyMaintenanceWindowList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstanceMaintenancePolicyWeeklyMaintenanceWindowOutputReference;
}
export interface DataGoogleMemorystoreInstanceMaintenancePolicy {
}
export declare function dataGoogleMemorystoreInstanceMaintenancePolicyToTerraform(struct?: DataGoogleMemorystoreInstanceMaintenancePolicy): any;
export declare function dataGoogleMemorystoreInstanceMaintenancePolicyToHclTerraform(struct?: DataGoogleMemorystoreInstanceMaintenancePolicy): any;
export declare class DataGoogleMemorystoreInstanceMaintenancePolicyOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstanceMaintenancePolicy | undefined;
    set internalValue(value: DataGoogleMemorystoreInstanceMaintenancePolicy | undefined);
    get createTime(): string;
    get updateTime(): string;
    private _weeklyMaintenanceWindow;
    get weeklyMaintenanceWindow(): DataGoogleMemorystoreInstanceMaintenancePolicyWeeklyMaintenanceWindowList;
}
export declare class DataGoogleMemorystoreInstanceMaintenancePolicyList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstanceMaintenancePolicyOutputReference;
}
export interface DataGoogleMemorystoreInstanceMaintenanceSchedule {
}
export declare function dataGoogleMemorystoreInstanceMaintenanceScheduleToTerraform(struct?: DataGoogleMemorystoreInstanceMaintenanceSchedule): any;
export declare function dataGoogleMemorystoreInstanceMaintenanceScheduleToHclTerraform(struct?: DataGoogleMemorystoreInstanceMaintenanceSchedule): any;
export declare class DataGoogleMemorystoreInstanceMaintenanceScheduleOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstanceMaintenanceSchedule | undefined;
    set internalValue(value: DataGoogleMemorystoreInstanceMaintenanceSchedule | undefined);
    get endTime(): string;
    get scheduleDeadlineTime(): string;
    get startTime(): string;
}
export declare class DataGoogleMemorystoreInstanceMaintenanceScheduleList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstanceMaintenanceScheduleOutputReference;
}
export interface DataGoogleMemorystoreInstanceManagedBackupSource {
}
export declare function dataGoogleMemorystoreInstanceManagedBackupSourceToTerraform(struct?: DataGoogleMemorystoreInstanceManagedBackupSource): any;
export declare function dataGoogleMemorystoreInstanceManagedBackupSourceToHclTerraform(struct?: DataGoogleMemorystoreInstanceManagedBackupSource): any;
export declare class DataGoogleMemorystoreInstanceManagedBackupSourceOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstanceManagedBackupSource | undefined;
    set internalValue(value: DataGoogleMemorystoreInstanceManagedBackupSource | undefined);
    get backup(): string;
}
export declare class DataGoogleMemorystoreInstanceManagedBackupSourceList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstanceManagedBackupSourceOutputReference;
}
export interface DataGoogleMemorystoreInstanceManagedServerCaCaCerts {
}
export declare function dataGoogleMemorystoreInstanceManagedServerCaCaCertsToTerraform(struct?: DataGoogleMemorystoreInstanceManagedServerCaCaCerts): any;
export declare function dataGoogleMemorystoreInstanceManagedServerCaCaCertsToHclTerraform(struct?: DataGoogleMemorystoreInstanceManagedServerCaCaCerts): any;
export declare class DataGoogleMemorystoreInstanceManagedServerCaCaCertsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstanceManagedServerCaCaCerts | undefined;
    set internalValue(value: DataGoogleMemorystoreInstanceManagedServerCaCaCerts | undefined);
    get certificates(): string[];
}
export declare class DataGoogleMemorystoreInstanceManagedServerCaCaCertsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstanceManagedServerCaCaCertsOutputReference;
}
export interface DataGoogleMemorystoreInstanceManagedServerCa {
}
export declare function dataGoogleMemorystoreInstanceManagedServerCaToTerraform(struct?: DataGoogleMemorystoreInstanceManagedServerCa): any;
export declare function dataGoogleMemorystoreInstanceManagedServerCaToHclTerraform(struct?: DataGoogleMemorystoreInstanceManagedServerCa): any;
export declare class DataGoogleMemorystoreInstanceManagedServerCaOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstanceManagedServerCa | undefined;
    set internalValue(value: DataGoogleMemorystoreInstanceManagedServerCa | undefined);
    private _caCerts;
    get caCerts(): DataGoogleMemorystoreInstanceManagedServerCaCaCertsList;
}
export declare class DataGoogleMemorystoreInstanceManagedServerCaList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstanceManagedServerCaOutputReference;
}
export interface DataGoogleMemorystoreInstanceNodeConfig {
}
export declare function dataGoogleMemorystoreInstanceNodeConfigToTerraform(struct?: DataGoogleMemorystoreInstanceNodeConfig): any;
export declare function dataGoogleMemorystoreInstanceNodeConfigToHclTerraform(struct?: DataGoogleMemorystoreInstanceNodeConfig): any;
export declare class DataGoogleMemorystoreInstanceNodeConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstanceNodeConfig | undefined;
    set internalValue(value: DataGoogleMemorystoreInstanceNodeConfig | undefined);
    get sizeGb(): number;
}
export declare class DataGoogleMemorystoreInstanceNodeConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstanceNodeConfigOutputReference;
}
export interface DataGoogleMemorystoreInstancePersistenceConfigAofConfig {
}
export declare function dataGoogleMemorystoreInstancePersistenceConfigAofConfigToTerraform(struct?: DataGoogleMemorystoreInstancePersistenceConfigAofConfig): any;
export declare function dataGoogleMemorystoreInstancePersistenceConfigAofConfigToHclTerraform(struct?: DataGoogleMemorystoreInstancePersistenceConfigAofConfig): any;
export declare class DataGoogleMemorystoreInstancePersistenceConfigAofConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstancePersistenceConfigAofConfig | undefined;
    set internalValue(value: DataGoogleMemorystoreInstancePersistenceConfigAofConfig | undefined);
    get appendFsync(): string;
}
export declare class DataGoogleMemorystoreInstancePersistenceConfigAofConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstancePersistenceConfigAofConfigOutputReference;
}
export interface DataGoogleMemorystoreInstancePersistenceConfigRdbConfig {
}
export declare function dataGoogleMemorystoreInstancePersistenceConfigRdbConfigToTerraform(struct?: DataGoogleMemorystoreInstancePersistenceConfigRdbConfig): any;
export declare function dataGoogleMemorystoreInstancePersistenceConfigRdbConfigToHclTerraform(struct?: DataGoogleMemorystoreInstancePersistenceConfigRdbConfig): any;
export declare class DataGoogleMemorystoreInstancePersistenceConfigRdbConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstancePersistenceConfigRdbConfig | undefined;
    set internalValue(value: DataGoogleMemorystoreInstancePersistenceConfigRdbConfig | undefined);
    get rdbSnapshotPeriod(): string;
    get rdbSnapshotStartTime(): string;
}
export declare class DataGoogleMemorystoreInstancePersistenceConfigRdbConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstancePersistenceConfigRdbConfigOutputReference;
}
export interface DataGoogleMemorystoreInstancePersistenceConfig {
}
export declare function dataGoogleMemorystoreInstancePersistenceConfigToTerraform(struct?: DataGoogleMemorystoreInstancePersistenceConfig): any;
export declare function dataGoogleMemorystoreInstancePersistenceConfigToHclTerraform(struct?: DataGoogleMemorystoreInstancePersistenceConfig): any;
export declare class DataGoogleMemorystoreInstancePersistenceConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstancePersistenceConfig | undefined;
    set internalValue(value: DataGoogleMemorystoreInstancePersistenceConfig | undefined);
    private _aofConfig;
    get aofConfig(): DataGoogleMemorystoreInstancePersistenceConfigAofConfigList;
    get mode(): string;
    private _rdbConfig;
    get rdbConfig(): DataGoogleMemorystoreInstancePersistenceConfigRdbConfigList;
}
export declare class DataGoogleMemorystoreInstancePersistenceConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstancePersistenceConfigOutputReference;
}
export interface DataGoogleMemorystoreInstancePscAttachmentDetails {
}
export declare function dataGoogleMemorystoreInstancePscAttachmentDetailsToTerraform(struct?: DataGoogleMemorystoreInstancePscAttachmentDetails): any;
export declare function dataGoogleMemorystoreInstancePscAttachmentDetailsToHclTerraform(struct?: DataGoogleMemorystoreInstancePscAttachmentDetails): any;
export declare class DataGoogleMemorystoreInstancePscAttachmentDetailsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstancePscAttachmentDetails | undefined;
    set internalValue(value: DataGoogleMemorystoreInstancePscAttachmentDetails | undefined);
    get connectionType(): string;
    get serviceAttachment(): string;
}
export declare class DataGoogleMemorystoreInstancePscAttachmentDetailsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstancePscAttachmentDetailsOutputReference;
}
export interface DataGoogleMemorystoreInstancePscAutoConnections {
}
export declare function dataGoogleMemorystoreInstancePscAutoConnectionsToTerraform(struct?: DataGoogleMemorystoreInstancePscAutoConnections): any;
export declare function dataGoogleMemorystoreInstancePscAutoConnectionsToHclTerraform(struct?: DataGoogleMemorystoreInstancePscAutoConnections): any;
export declare class DataGoogleMemorystoreInstancePscAutoConnectionsOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstancePscAutoConnections | undefined;
    set internalValue(value: DataGoogleMemorystoreInstancePscAutoConnections | undefined);
    get connectionType(): string;
    get forwardingRule(): string;
    get ipAddress(): string;
    get network(): string;
    get port(): number;
    get projectId(): string;
    get pscConnectionId(): string;
    get pscConnectionStatus(): string;
    get serviceAttachment(): string;
}
export declare class DataGoogleMemorystoreInstancePscAutoConnectionsList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstancePscAutoConnectionsOutputReference;
}
export interface DataGoogleMemorystoreInstanceStateInfoUpdateInfo {
}
export declare function dataGoogleMemorystoreInstanceStateInfoUpdateInfoToTerraform(struct?: DataGoogleMemorystoreInstanceStateInfoUpdateInfo): any;
export declare function dataGoogleMemorystoreInstanceStateInfoUpdateInfoToHclTerraform(struct?: DataGoogleMemorystoreInstanceStateInfoUpdateInfo): any;
export declare class DataGoogleMemorystoreInstanceStateInfoUpdateInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstanceStateInfoUpdateInfo | undefined;
    set internalValue(value: DataGoogleMemorystoreInstanceStateInfoUpdateInfo | undefined);
    get targetEngineVersion(): string;
    get targetNodeType(): string;
    get targetReplicaCount(): number;
    get targetShardCount(): number;
}
export declare class DataGoogleMemorystoreInstanceStateInfoUpdateInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstanceStateInfoUpdateInfoOutputReference;
}
export interface DataGoogleMemorystoreInstanceStateInfo {
}
export declare function dataGoogleMemorystoreInstanceStateInfoToTerraform(struct?: DataGoogleMemorystoreInstanceStateInfo): any;
export declare function dataGoogleMemorystoreInstanceStateInfoToHclTerraform(struct?: DataGoogleMemorystoreInstanceStateInfo): any;
export declare class DataGoogleMemorystoreInstanceStateInfoOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstanceStateInfo | undefined;
    set internalValue(value: DataGoogleMemorystoreInstanceStateInfo | undefined);
    private _updateInfo;
    get updateInfo(): DataGoogleMemorystoreInstanceStateInfoUpdateInfoList;
}
export declare class DataGoogleMemorystoreInstanceStateInfoList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstanceStateInfoOutputReference;
}
export interface DataGoogleMemorystoreInstanceZoneDistributionConfig {
}
export declare function dataGoogleMemorystoreInstanceZoneDistributionConfigToTerraform(struct?: DataGoogleMemorystoreInstanceZoneDistributionConfig): any;
export declare function dataGoogleMemorystoreInstanceZoneDistributionConfigToHclTerraform(struct?: DataGoogleMemorystoreInstanceZoneDistributionConfig): any;
export declare class DataGoogleMemorystoreInstanceZoneDistributionConfigOutputReference extends cdktn.ComplexObject {
    private isEmptyObject;
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param complexObjectIndex the index of this item in the list
    * @param complexObjectIsFromSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, complexObjectIndex: number, complexObjectIsFromSet: boolean);
    get internalValue(): DataGoogleMemorystoreInstanceZoneDistributionConfig | undefined;
    set internalValue(value: DataGoogleMemorystoreInstanceZoneDistributionConfig | undefined);
    get mode(): string;
    get zone(): string;
}
export declare class DataGoogleMemorystoreInstanceZoneDistributionConfigList extends cdktn.ComplexList {
    /**
    * @param terraformResource The parent resource
    * @param terraformAttribute The attribute on the parent resource this class is referencing
    * @param wrapsSet whether the list is wrapping a set (will add tolist() to be able to access an item via an index)
    */
    constructor(terraformResource: cdktn.IInterpolatingParent, terraformAttribute: string, wrapsSet: boolean);
    /**
    * @param index the index of the item to return
    */
    get(index: number): DataGoogleMemorystoreInstanceZoneDistributionConfigOutputReference;
}
/**
* Represents a {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_memorystore_instance google_memorystore_instance}
*/
export declare class DataGoogleMemorystoreInstance extends cdktn.TerraformDataSource {
    static readonly tfResourceType = "google_memorystore_instance";
    /**
    * Generates CDKTN code for importing a DataGoogleMemorystoreInstance resource upon running "cdktn plan <stack-name>"
    * @param scope The scope in which to define this construct
    * @param importToId The construct id used in the generated config for the DataGoogleMemorystoreInstance to import
    * @param importFromId The id of the existing DataGoogleMemorystoreInstance that should be imported. Refer to the {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_memorystore_instance#import import section} in the documentation of this resource for the id to use
    * @param provider? Optional instance of the provider where the DataGoogleMemorystoreInstance to import is found
    */
    static generateConfigForImport(scope: Construct, importToId: string, importFromId: string, provider?: cdktn.TerraformProvider): cdktn.ImportableResource;
    /**
    * Create a new {@link https://registry.terraform.io/providers/hashicorp/google-beta/8.9.0/docs/data-sources/google_memorystore_instance google_memorystore_instance} Data Source
    *
    * @param scope The scope in which to define this construct
    * @param id The scoped construct ID. Must be unique amongst siblings in the same scope
    * @param options DataGoogleMemorystoreInstanceConfig
    */
    constructor(scope: Construct, id: string, config: DataGoogleMemorystoreInstanceConfig);
    get aclPolicy(): string;
    get authorizationMode(): string;
    private _automatedBackupConfig;
    get automatedBackupConfig(): DataGoogleMemorystoreInstanceAutomatedBackupConfigList;
    get availableMaintenanceVersions(): string[];
    get backupCollection(): string;
    get createTime(): string;
    private _crossInstanceReplicationConfig;
    get crossInstanceReplicationConfig(): DataGoogleMemorystoreInstanceCrossInstanceReplicationConfigList;
    get deletionPolicy(): string;
    get deletionProtectionEnabled(): cdktn.IResolvable;
    private _desiredAutoCreatedEndpoints;
    get desiredAutoCreatedEndpoints(): DataGoogleMemorystoreInstanceDesiredAutoCreatedEndpointsList;
    private _desiredPscAutoConnections;
    get desiredPscAutoConnections(): DataGoogleMemorystoreInstanceDesiredPscAutoConnectionsList;
    private _discoveryEndpoints;
    get discoveryEndpoints(): DataGoogleMemorystoreInstanceDiscoveryEndpointsList;
    private _effectiveLabels;
    get effectiveLabels(): cdktn.StringMap;
    get effectiveMaintenanceVersion(): string;
    private _endpoints;
    get endpoints(): DataGoogleMemorystoreInstanceEndpointsList;
    private _engineConfigs;
    get engineConfigs(): cdktn.StringMap;
    get engineVersion(): string;
    private _gcsSource;
    get gcsSource(): DataGoogleMemorystoreInstanceGcsSourceList;
    private _id?;
    get id(): string;
    set id(value: string);
    resetId(): void;
    get idInput(): string | undefined;
    private _instanceId?;
    get instanceId(): string;
    set instanceId(value: string);
    get instanceIdInput(): string | undefined;
    get isAclPolicyInSync(): cdktn.IResolvable;
    get kmsKey(): string;
    private _labels;
    get labels(): cdktn.StringMap;
    private _location?;
    get location(): string;
    set location(value: string);
    resetLocation(): void;
    get locationInput(): string | undefined;
    private _maintenancePolicy;
    get maintenancePolicy(): DataGoogleMemorystoreInstanceMaintenancePolicyList;
    private _maintenanceSchedule;
    get maintenanceSchedule(): DataGoogleMemorystoreInstanceMaintenanceScheduleList;
    get maintenanceVersion(): string;
    private _managedBackupSource;
    get managedBackupSource(): DataGoogleMemorystoreInstanceManagedBackupSourceList;
    private _managedServerCa;
    get managedServerCa(): DataGoogleMemorystoreInstanceManagedServerCaList;
    get mode(): string;
    get name(): string;
    private _nodeConfig;
    get nodeConfig(): DataGoogleMemorystoreInstanceNodeConfigList;
    get nodeType(): string;
    private _persistenceConfig;
    get persistenceConfig(): DataGoogleMemorystoreInstancePersistenceConfigList;
    private _project?;
    get project(): string;
    set project(value: string);
    resetProject(): void;
    get projectInput(): string | undefined;
    private _pscAttachmentDetails;
    get pscAttachmentDetails(): DataGoogleMemorystoreInstancePscAttachmentDetailsList;
    private _pscAutoConnections;
    get pscAutoConnections(): DataGoogleMemorystoreInstancePscAutoConnectionsList;
    get replicaCount(): number;
    get serverCaMode(): string;
    get serverCaPool(): string;
    get shardCount(): number;
    get state(): string;
    private _stateInfo;
    get stateInfo(): DataGoogleMemorystoreInstanceStateInfoList;
    private _terraformLabels;
    get terraformLabels(): cdktn.StringMap;
    get transitEncryptionMode(): string;
    get uid(): string;
    get updateTime(): string;
    private _zoneDistributionConfig;
    get zoneDistributionConfig(): DataGoogleMemorystoreInstanceZoneDistributionConfigList;
    protected synthesizeAttributes(): {
        [name: string]: any;
    };
    protected synthesizeHclAttributes(): {
        [name: string]: any;
    };
}
